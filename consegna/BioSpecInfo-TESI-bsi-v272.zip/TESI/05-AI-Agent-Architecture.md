# Architettura dell'Agente AI "Spectra" — BioSpecInfo

| Campo | Valore |
|-------|--------|
| **Progetto** | BioSpecInfo — componente Spectra (copilota AI agentico) |
| **Autore** | Samuele Pio Provenzano |
| **Relatore tesi** | Prof. Savino Longo — Università degli Studi di Bari Aldo Moro |
| **Componente** | `bsi-ai-hub.js` — 6.254 righe, nessuna dipendenza runtime |
| **Tipo** | Agente conversazionale multi-provider con esecuzione di strumenti lato client |
| **Repository** | `samupropio1-ship-it/BioSpecInfo-v11` |
| **Versione documentata** | Service Worker `bsi-v272` |

---

## 1. Sintesi esecutiva

Spectra è un **agente** — non un semplice wrapper su un modello linguistico.
La differenza è misurabile: il modello non risponde a memoria sui dati
quantitativi, ma **invoca strumenti deterministici** che calcolano il risultato,
e il ciclo di controllo gli permette di **concatenare fino a 10 chiamate**
verificando ogni passaggio prima di rispondere.

L'architettura affronta tre problemi che distinguono un agente utilizzabile da
una demo:

1. **Fondatezza (*grounding*)** — un dato chimico inventato può essere
   pericoloso. 60 strumenti coprono calcolo, banche dati pubbliche e i dataset
   interni dell'applicazione; il prompt di sistema vieta esplicitamente di
   citare valori numerici a memoria.
2. **Trasparenza** — il ragionamento del modello è mostrato in tempo reale e
   conservato accanto alla risposta, insieme all'elenco degli strumenti
   effettivamente invocati. L'operato dell'agente è verificabile a posteriori.
3. **Portabilità fra fornitori** — un unico registro di strumenti viene
   tradotto nei tre formati di *function calling* oggi in uso (OpenAI-compatibile,
   Anthropic, Gemini), così l'agente funziona identico su dieci configurazioni
   di modello, quattro delle quali gratuite.

---

## 2. Architettura

### 2.1 Vista d'insieme

```
┌──────────────────────── browser dell'utente ────────────────────────┐
│                                                                     │
│   UI chat ── pannello ragionamento ── note strumenti                │
│        │                                                            │
│   ciclo agentico  (max 10 giri)                                     │
│        │                                                            │
│        ├── adattatore provider ──► API del modello (HTTPS diretto)  │
│        │      · OpenAI-compatibile (Groq, Z.AI, xAI, DeepSeek) │
│        │      · Anthropic (Fable 5.1 · Opus 5 · Sonnet 5 · Haiku)   │
│        │      · Gemini                                              │
│        │                                                            │
│        └── esecutore strumenti (53, tutti locali salvo 2 di rete)   │
│               ├── motore di calcolo (parser proprio, no eval)       │
│               ├── risolutori di dominio (13 aree scientifiche)      │
│               ├── dataset interni dell'app (9 basi dati)            │
│               ├── rete: PubChem · PubMed · ricerca web              │
│               └── memoria persistente (localStorage)                │
└─────────────────────────────────────────────────────────────────────┘
```

Non esiste un backend. Le chiavi API restano nel `localStorage` del browser e
viaggiano solo verso il fornitore scelto: nessun dato transita da server di
BioSpecInfo, che non esistono.

### 2.2 Ciclo agentico

Ad ogni giro il ciclo: invia la cronologia (ultimi 40 turni) più il prompt di
sistema e lo schema dei 60 strumenti → riceve la risposta in *streaming* →
se contiene chiamate a strumenti le esegue **tutte** → ricostruisce il turno
assistente nel formato nativo del fornitore → ripete.

Tre condizioni di uscita: nessuna chiamata a strumenti (risposta finale),
`MAX_ROUNDS = 10` esaurito, o interruzione dell'utente.

### 2.3 Registro strumenti neutrale rispetto al fornitore

Gli strumenti sono definiti una sola volta in JSON-Schema e tradotti a runtime:

| Famiglia | Formato richiesto |
|---|---|
| Anthropic | `{name, description, input_schema}` |
| Gemini | `[{functionDeclarations: [...]}]` |
| OpenAI-compatibile | `{type:"function", function:{...}}` |

Lo stesso vale per i messaggi: i turni con chiamate a strumenti vengono
serializzati nella forma nativa di ciascun fornitore e conservati in un campo
`_native`, così una conversazione resta coerente anche cambiando modello.

### 2.4 Nessun nome di modello cablato

Un nome di modello scritto nel codice è una bomba a orologeria: funziona
finché il fornitore non ritira quel modello, e allora l'applicazione si ferma
con un 404 che l'utente non può risolvere. È successo due volte in questo
progetto:

| Fornitore | Errore | Quando |
|---|---|---|
| Google | `models/gemini-1.5-flash is not found for API version v1beta` | ritiro da `v1beta` |
| Groq | `The model llama-3.3-70b-versatile does not exist or you do not have access to it` | deprecato il 17/06/2026 |

Il problema è strutturale su alcuni servizi: gli id dei modelli gratuiti
cambiano di continuo, per costruzione. (È il motivo per cui OpenRouter è stato
poi tolto dall'elenco, vedi 2.4.)

La correzione non è scrivere il nome nuovo — sarebbe la stessa bomba con la
miccia più lunga — ma **togliere il nome** e chiederlo all'API, che sa quali
modelli esistono *per quella chiave*. Il che risolve anche l'ambiguità del
messaggio di Groq: «non esiste» **oppure** «non ci hai accesso» sono casi
diversi, e un elenco per chiave li distingue.

Ogni configurazione con `modelliCandidati` parte da `model: null` e viene
risolta a runtime. Le due famiglie hanno strategie diverse perché i loro nomi
lo sono:

**Gemini — punteggio per versione.** I nomi seguono uno schema regolare
(`gemini-<major>.<minor>-<famiglia>`), quindi si può ordinare: versione più
recente, famiglia `flash`, con penalità per varianti sperimentali, `preview` e
`-lite`; scartati i modelli senza `streamGenerateContent` e quelli non
conversazionali (embedding, immagini, audio nativo, Live API). Quando uscirà
Gemini 3.0 verrà scelto da solo.

**Famiglia OpenAI — i candidati in ordine di preferenza.** Qui i nomi non sono
confrontabili fra loro (`openai/gpt-oss-120b` contro `qwen/qwen3.6-27b`), e un
punteggio automatico sceglierebbe male. Si interroga `GET /models` e si prende
**il primo candidato ancora esistente**: l'ordine della lista *è* la
preferenza, e l'elenco serve a saltare quelli spariti. Solo se nessun
candidato sopravvive si ricorre a un punteggio generico sui modelli
disponibili — che scarta trascrizione, sintesi vocale, embedding e
classificatori, e a parità d'altro preferisce il modello più grande.

Tre livelli di riserva in entrambi i casi: elenco dei modelli → sonda dei
candidati → primo candidato, lasciando parlare l'errore vero della chiamata di
generazione invece di inventarne uno.

La scelta resta in cache sette giorni per fornitore, legata a un'impronta
FNV-1a a 32 bit della chiave (chiavi diverse vedono cataloghi diversi; la
chiave in chiaro non viene mai duplicata). Se il modello viene ritirato
*mentre* è in cache, il `404` — o un `400` il cui testo parla di modello, come
fanno alcuni fornitori — invalida la cache, ririsolve e ritenta **una volta sola**: un
flag impedisce il ciclo infinito quando anche il modello nuovo fallisce.

Anthropic resta l'eccezione voluta: i suoi modelli sono a pagamento, scelti
esplicitamente dall'utente e con deprecazioni annunciate con largo anticipo.

#### I quattro servizi gratuiti, scelti uno per uno

La qualità gratuita non è tutta uguale, e la differenza conta: un modello da 8
miliardi di parametri non regge un problema di chimica fisica in più passaggi.
L'elenco è stato **ridotto**, non allungato — due servizi sono stati tolti
perché peggioravano la risposta invece di migliorarla.

| Servizio | Modelli | Il ruolo |
|---|---|---|
| **Groq** | GPT-OSS 120B, Qwen3 | Il cavallo da tiro: 131K di contesto, ~30 richieste/minuto |
| **Google Gemini** | Gemini Flash | Fino a 1M di contesto: documenti e PDF interi |
| **Z.AI GLM** | GLM-4.7-Flash | Gratuito **senza scadenza**: la riserva che resta quando i crediti finiscono |

**Tolti.** *GitHub Models*: c'era, ed è stato tolto perché GitHub lo ha
**ritirato del tutto il 30 luglio 2026** — playground, catalogo e API di
inferenza spenti per tutti. Era stato aggiunto due giorni prima sulla base di
pagine che descrivevano il servizio ancora attivo: la lezione è che verificare
*che una cosa esista* non è verificare *che sia ancora viva*, e la ricerca da
fare è «<nome> retired / shutdown / deprecated <anno>». Il guasto non si è
fermato alla voce in tendina: il rango che gli era stato assegnato lo rendeva
anche la scelta automatica della Modalità Nucleo.

*Mistral*: qualità media e piano gratuito che richiede
il consenso all'uso dei dati per l'addestramento — un prezzo che non vale la
pena pagare per materiale di tesi non pubblicato, quando esistono cinque
alternative senza quella clausola. *OpenRouter*: modelli gratuiti piccoli e id
che cambiano di continuo, inadatti a un agente che concatena dieci chiamate a
strumenti. *Cerebras*: dall'agosto 2026 niente più piano senza carta, e
contesto gratuito limitato a 8K — Spectra manda 32 definizioni di strumenti
oltre alla cronologia, non ci sta.

Nessuno dei cinque eguaglia un modello di frontiera a pagamento sui problemi
più difficili; Z.AI GLM ci va vicino, al prezzo di tetti
di richieste bassi. Per questo la scelta resta dell'utente, invece di imporre
un solo servizio.

#### La frontiera, a pagamento

I gratuiti bastano per studiare; per un problema difficile no. Il criterio di
scelta è stato **GPQA Diamond** — domande di livello dottorato in fisica,
chimica e biologia — perché è l'unico banco che misura ciò che quest'app
chiede davvero.

| Servizio | Perché c'è |
|---|---|
| **GPT-5.6** | 94,6% su GPQA Diamond: il punteggio più alto oggi disponibile. ~4 $/M in ingresso |
| **Gemini 3 Pro** | Oltre 1M di contesto, e **la stessa chiave** del Gemini gratuito. ~2 $/M |
| **DeepSeek V4** | Ragionamento di fascia alta a ~0,66 $/M: il miglior rapporto qualità/prezzo |
| **Grok 4.6** | Primo su *tool calling* agentico e con il minor tasso di allucinazione — esattamente il profilo che serve a un agente che concatena strumenti. ~2 $/M |
| **Claude** (Fable 5.1, Opus 5, Sonnet 5) | Una sola chiave per tutti e tre; gli unici con il sandbox Python in Modalità Nucleo |

Due configurazioni possono usare **la stessa chiave**: i quattro Claude sono un
solo account Anthropic, e Gemini Flash e Gemini 3 Pro una sola chiave di AI
Studio. `chiaveCondivisaCon` le fa puntare alla stessa voce, così l'utente la
incolla una volta. Chi la cancella la cancella per tutti i gemelli — lasciarne
una la farebbe riapparire sull'altro.

Il caso dei due Gemini ha richiesto di generalizzare il punteggio: condividono
famiglia, endpoint e chiave ma vogliono modelli **opposti**. La preferenza è
ora dichiarata in configurazione (`/flash/` contro `/pro/`) e vince sul resto
del punteggio. Senza, la configurazione gratuita avrebbe scelto
`gemini-3-pro`: una generazione più avanti, quindi con punteggio più alto, ma
**a pagamento** — un modello che la chiave gratuita non può usare.

Nello stesso passaggio è emersa una seconda cosa: il numero minore nel nome è
**opzionale**. Dalla generazione 3 Google lo ha tolto (`gemini-3-pro`, non
`gemini-3.0-pro`), e la regex che pretendeva il punto valutava i modelli *più
nuovi* come alias generici — quindi perdevano contro i vecchi, e
l'aggiornamento automatico descritto in 2.4 non sarebbe mai scattato.

#### L'audit dei fornitori, e perché va rifatto

Il sistema si ripara da solo sui **nomi dei modelli** — interroga il catalogo
e sceglie fra ciò che esiste. Non si ripara su un **servizio morto**: quello va
verificato a mano, e il ritiro di GitHub Models ha mostrato cosa costa non
farlo.

Verifica di settembre 2026, fornitore per fornitore:

| Fornitore | Esito |
|---|---|
| Groq | Attivo. `llama-3.3-70b-versatile` **non è più servito** da agosto 2026 e `llama-3.1-8b-instant` è deprecato: tolti dai candidati, restano i sostituti indicati da Groq |
| Google Gemini | Attivo |
| NVIDIA NIM | Rimosso 09/2026: attivo, ma senza header CORS non è chiamabile da una pagina web |
| Z.AI | Attivo, GLM-4.7-Flash e 4.5-Flash ancora gratuiti |
| OpenAI, DeepSeek, Anthropic | Attivi |
| xAI | Attivo, ma i candidati erano di **due generazioni** precedenti: il vertice è `grok-4.6` dal 12/08/2026 |

Due trappole registrate perché non si ripetano. La prima: non mettere un
modello a pagamento fra i candidati di una configurazione gratuita — vale per
`glm-5.x` su Z.AI come valeva per `gemini-3-pro`, e la configurazione
sceglierebbe qualcosa che la chiave gratuita non può usare. La seconda: un
fornitore morto con un rango alto non rompe solo la voce in tendina, **diventa
la scelta automatica** della Modalità Nucleo.

#### Quando un fornitore non risponde

Un `fetch` che fallisce **prima** di ricevere una risposta significa una di tre
cose: rete assente, il servizio non accetta chiamate dirette dal browser
(CORS), oppure il servizio non esiste più. Il browser, per ragioni di
sicurezza, non permette di distinguere quale — l'errore è volutamente generico.

Prima questo fermava il turno. Ma se le tre cause non si distinguono, la
risposta giusta è la stessa per tutte e tre: **passare a un altro fornitore**
per cui l'utente ha una chiave, esattamente come per la quota esaurita. È il
comportamento che avrebbe mascherato del tutto il ritiro di GitHub Models,
invece di lasciare ogni richiesta bloccata su un servizio spento.

Restano fuori dalla riserva gli errori che si ripeterebbero identici ovunque —
una chiave sbagliata, una richiesta malformata: provarli su tutti i fornitori
per poi riportare l'ultimo errore a caso nasconderebbe la causa vera.

**Togliere un servizio dall'elenco è un'operazione che rompe le cose**, e
merita una nota: chi lo aveva selezionato ha quel nome salvato in
`localStorage`, e senza validazione si ritroverebbe `PROVIDERS[undefined]` —
Spectra non si aprirebbe più. `getSavedProvider()` valida sempre contro il
registro e ripiega su un servizio esistente.

### 2.5 Il proxy opzionale — Spectra senza chiave

La chiave API vive nel browser dell'utente: senza backend non c'e' alternativa,
ed e' il limite dichiarato apertamente in fondo a questo documento. Ogni
visitatore deve procurarsi la propria chiave gratuita e incollarla.

`proxy/spectra-proxy.js` e' la via d'uscita, e sta **fuori** dalla pagina: un
Worker Cloudflare (piano gratuito) che tiene le chiavi come segreti lato
server. Quando e' configurato, il browser non contiene nessuna chiave e chi
apre BioSpecInfo usa Spectra senza inserire niente.

Non e' un semplice inoltro:

- **Il percorso passa tale e quale.** La rotta e' `/<fornitore>/<percorso>`, e
  il resto viene inoltrato come arriva: il proxy non conosce i formati delle
  API e continua a funzionare quando Spectra cambia modello o parametri.
- **Piu' chiavi per fornitore, con subentro automatico.** Ogni segreto e' una
  lista separata da virgole; su `429` (quota) o `401/403` (chiave revocata) si
  passa alla successiva nella stessa richiesta. Su `400` no: e' un errore
  nella richiesta e si ripeterebbe identico.
- **Lo streaming non viene bufferizzato**: il corpo della risposta passa
  direttamente, altrimenti le risposte comparirebbero tutte insieme alla fine.
- **Non e' un relay aperto.** Credenziali che arrivano dal client
  (`Authorization`, `x-api-key`, `?key=`) vengono scartate e sostituite:
  nessuno puo' usare il proxy per far viaggiare una chiave propria.
- **Tre freni** contro l'abuso: elenco di origini ammesse, limite per IP e
  tetto giornaliero.

Lato Spectra l'innesto e' in un punto solo. `GET /stato` dice quali fornitori
il proxy copre davvero, cosi' non viene offerto come "senza chiave" un modello
per cui manca il segreto; `buildRequest` instrada al proxy **e omette del tutto
l'autenticazione**; `chiaveDaUsare()` restituisce un segnaposto perche' i
controlli "manca la chiave" non blocchino l'invio — segnaposto che non lascia
mai il browser.

Le due strade convivono: senza `PROXY_URL` tutto funziona come prima, e per i
fornitori non coperti dal proxy Spectra continua a usare la chiave locale.

### 2.6 Ricominciare da capo

Tutto ciò che Spectra ricorda vive in `localStorage`: chat, cronologia, chiavi
API, memoria persistente, schede di ripasso. Un pulsante "cancella cronologia"
che togliesse solo le conversazioni non farebbe ripartire da capo — alla
riapertura si ritroverebbe lo stesso stato.

Il punto delicato è che le chiavi hanno **due formati**: la mappa attuale
(`bsi_api_keys`, una chiave per fornitore) e il formato singolo delle versioni
precedenti (`bsi_api_key`). `getKeysMap()` migra automaticamente il secondo nel
primo, quindi cancellare solo la mappa **fa riapparire la chiave vecchia** al
primo accesso successivo. Vanno tolti entrambi — e con loro le cache dei
modelli risolti, che senza chiave non hanno più significato.

Per questo l'elenco di ciò che l'applicazione scrive sta in un punto solo,
`DATI_CANCELLABILI`, diviso in cinque gruppi con etichetta e descrizione. Il
pannello di conferma si costruisce da lì: mostra quante voci esistono davvero
per ciascun gruppo, disattiva quelli già vuoti e richiede un secondo clic
esplicito. Spuntati di partenza solo chat e chiavi; memoria, ripasso e
progressi del resto dell'app restano da scegliere a mano, perché cancellano
lavoro che non c'entra con il ripartire da capo della conversazione.

Restano fuori di proposito la licenza PRO, il periodo di prova e l'identità del
dispositivo: sono dati che l'utente non si aspetta di perdere svuotando una
chat, e una licenza non si cancella per sbaglio. Il pannello lo dichiara.

Dopo la cancellazione viene azzerato anche lo stato in memoria del processo —
elenco dei fornitori coperti dal proxy, modello risolto per ciascun provider —
altrimenti resterebbe valido fino al ricaricamento della pagina, e Spectra
continuerebbe a usare un modello scelto con una chiave che non esiste più.

### 2.7 Far reggere un carico vero alle chiavi gratuite

I piani gratuiti hanno due limiti diversi, e vanno affrontati in modo diverso.

**Il tetto per richiesta.** GitHub Models accetta 8.000 token in ingresso.
Il costo fisso di Spectra è ~8.150 — 2.009 di prompt di sistema più **6.128 di
sole definizioni degli strumenti** — quindi quel servizio non partirebbe
nemmeno: fallirebbe prima che l'utente scriva una parola. La misura è stata
fatta prima di scrivere il rimedio, e ha cambiato la soluzione.

Il rimedio non è tagliare la cronologia — è tagliare **il costo fisso**. Gli
strumenti si pagano ad ogni turno, la conversazione è il contenuto: fra i due,
è il costo fisso a doversi stringere per primo. `adattaAlBudget()` seleziona i
**strumenti pertinenti** alla domanda invece di tutti e 32, poi accorcia la
cronologia con quel che resta.

La pertinenza si misura su una mappa di parole chiave tenuta **fuori** dal
registro degli strumenti: le parole con cui la gente *chiede* una cosa non sono
quelle con cui lo strumento è *documentato*. La descrizione di `astrofisica`
parla di Wien e Stefan-Boltzmann; l'utente scrive «che temperatura ha questa
nebulosa». Confrontando la domanda con la sola descrizione, su una domanda di
astrochimica veniva scelto `farmacocinetica` — misurato, non ipotizzato. Il
confronto è per radice (primi cinque caratteri) perché l'italiano flette:
«nebulosa» e «nebulose» devono coincidere.

**I limiti di frequenza.** Un `429` sui piani gratuiti è quasi sempre il limite
*al minuto*, non la quota esaurita: aspettare pochi secondi lo risolve. Il
fornitore lo dice in `Retry-After`, oppure nel testo dell'errore («*Please try
again in 7.5s*»); quando non lo dice si usa una crescita esponenziale con un
po' di casualità, per non far ripartire tutte le schede aperte nello stesso
istante. Se l'attesa richiesta è assurda non si aspetta affatto: meglio dire
«quota finita» che lasciare l'utente davanti a una clessidra per un'ora.

**La riserva fra fornitori.** Quando una quota è davvero esaurita, il turno
viene rifatto su un altro servizio per cui l'utente ha una chiave. È il motivo
per cui più chiavi gratuite messe insieme reggono un carico che nessuna
reggerebbe da sola.

Due vincoli non negoziabili:

- Si riparte dai messaggi **originali**, non dalla cronologia a metà. I turni
  con chiamate a strumenti sono salvati nel formato nativo del fornitore
  precedente e non si possono passare a un altro. Si perde il lavoro del turno,
  si guadagna una risposta corretta.
- La riserva usa **solo servizi gratuiti**. Passare da solo a uno a pagamento
  spenderebbe i soldi dell'utente senza che li abbia stanziati; se il servizio
  scelto era a pagamento resta comunque il primo tentativo.

E si passa oltre **soltanto** per quota esaurita. Un `401` o una richiesta
malformata si ripeterebbero identici su ogni fornitore: provarli tutti per poi
riportare l'ultimo errore a caso nasconderebbe la causa vera.

### 2.8 Modalità Nucleo, e dire cosa sta succedendo

**La modalità.** Un interruttore che cambia quattro cose insieme, perché
nessuna delle quattro da sola sposterebbe l'ago: passa alla configurazione più
capace fra quelle per cui esiste una chiave, porta i giri del ciclo agentico da
10 a 16 (una catena lunga di strumenti si esauriva a metà), chiede la
profondità di ragionamento massima ai modelli che la espongono, e aggiunge al
prompt l'istruzione di lavorare per passaggi verificati invece che per risposta
rapida.

Il cambio di modello viene **dichiarato in chat**, e se il nuovo è a pagamento
lo dice: passare di nascosto a un servizio a consumo significherebbe spendere i
soldi dell'utente senza dirglielo. Per lo stesso motivo è un interruttore e non
il comportamento predefinito — costa più quota, e su un servizio a pagamento
costa denaro.

**Dire cosa sta succedendo.** Fra l'invio e la prima parola della risposta
possono passare parecchi secondi: il modello ragiona, invoca strumenti, aspetta
la rete. Prima l'utente vedeva una pausa muta e concludeva che si fosse
bloccata.

L'intestazione ha ora un nucleo atomico i cui orbitali cambiano velocità e
colore con lo stato — lento e ciano a riposo, rapido quando ragiona, ambra
quando sta usando uno strumento — accompagnato da una riga che dice la stessa
cosa a parole, per chi non guarda l'animazione. Gli stati si agganciano ai
callback che il ciclo agentico già emetteva: non è stato aggiunto nessun
meccanismo, solo reso visibile quello che c'era.

**Tre difetti di impaginazione corretti nello stesso passaggio**, tutti trovati
misurando invece che guardando:

- Il campo di scrittura divideva la riga con quattro pulsanti e restava largo
  156 px: il testo del segnaposto andava a capo e veniva **tagliato**. Ora il
  testo ha una riga propria e i comandi stanno sotto. La lunghezza del
  segnaposto è stata scelta provandola a 360 px di larghezza, non a occhio.
- Il titolo «Spectra — il copilota AI di BioSpecInfo» non entrava e si
  troncava a metà. Resta il nome; il resto è diventato la riga di stato, che
  ora ha un uso.
- Gli orbitali del nucleo, ruotando, uscivano dal riquadro e finivano sopra il
  nome.

### 2.9 Le capacità del fornitore, usate davvero

Tre cose che l'API di Anthropic offre e che non erano sfruttate. Verificate
contro il riferimento ufficiale, non a memoria — due delle tre hanno un
vincolo che a memoria non si sarebbe indovinato.

**La cache del prompt.** Il costo fisso di ogni richiesta è di circa 8.150
token: 2.000 di prompt di sistema più 6.128 di definizioni degli strumenti,
identici ad ogni turno. Marcandoli si pagano una volta e poi si rileggono a
una frazione del prezzo.

Il vincolo è che la cache funziona per *prefisso*: un solo byte diverso
all'inizio la invalida tutta. Il prompt di Spectra però contiene anche la
memoria dell'utente e il contesto della domanda, che cambiano ad ogni
messaggio. Concatenandoli in un'unica stringa la cache **non avrebbe mai
preso**. Ora il prompt viaggia in due blocchi — stabile e marcato, volatile e
no — e il marcatore va anche sull'ultimo strumento, perché l'ordine di
composizione è `tools` → `system` → `messages`.

**Il sandbox Python, e perché esclude la ricerca web.** `code_execution` dà al
modello un ambiente con sympy, numpy, scipy e matplotlib: integrazione
numerica, algebra simbolica, diagonalizzazione di matrici — cose che i 32
risolutori non coprono perché non si possono prevedere tutte.

Ma la ricerca web di nuova generazione **porta già dentro un ambiente di
esecuzione** (filtra i risultati scrivendo codice), e dichiarare anche
`code_execution` ne creerebbe un secondo, confondendo il modello. Sono
alternative, non complementari. La scelta segue la Modalità Nucleo: normalmente
ricerca web e lettura di pagine, in Nucleo il sandbox — perché quando si chiede
il massimo della potenza il problema è di calcolo, non di documentazione. Un
test verifica che i due non compaiano mai insieme.

**La lettura di pagine.** `web_fetch` affianca la ricerca: se l'utente incolla
il link di un articolo, Spectra lo legge invece di limitarsi a cercarne il
titolo.

I risultati del sandbox arrivano come `bash_code_execution_tool_result` e
`text_editor_code_execution_tool_result` — non come un generico
`code_execution_tool_result` — e vanno conservati nel turno dell'assistente
come i blocchi della ricerca web, altrimenti un turno messo in pausa dal server
non si può riprendere.

---

## 3. I 60 strumenti

L'elenco è quello **misurato** in `window.BSI_AI_TOOLS` sull'applicazione in
esecuzione, non trascritto a memoria: questo documento ne dichiarava 32 quando
erano già 35, e tre — `analizza_molecola`, `disegna_molecola`, `mostra_spettri`
— non comparivano affatto.

| Area | Strumenti |
|---|---|
| **Calcolo generale** | `calcola`, `risolvi_equazione`, `analisi_dati` |
| **Chimica generale** | `bilancia_equazione`, `stechiometria`, `massa_molecolare`, `converti_unita`, `costante_fisica` |
| **Chimica fisica** | `termodinamica`, `equilibrio_acido_base`, `cinetica`, `gas_e_soluzioni`, `elettrochimica` |
| **Struttura e spettri** | `spettroscopia`, `quantistica_e_spettroscopia`, `cristallografia`, `analizza_molecola`, `disegna_molecola`, `mostra_spettri` |
| **Scienze della vita** | `biochimica`, `farmacocinetica`, `valuta_druglikeness` |
| **Fisica** | `astrofisica`, `nucleare`, `statistica_inferenziale` |
| **Banche dati esterne** | `cerca_pubchem` (NIH), `cerca_letteratura` (PubMed) |
| **Dati interni** | `cerca_nel_database` (9 dataset), `cerca_molecola` |
| **Macro-aree** | `risolvi_matematica`, `risolvi_fisica`, `risolvi_chimica` — lo stesso motore dell'assistente delle tre aree: domanda in linguaggio naturale, oppure modello e dati espliciti; svolgimento, dati con la loro origine, problema inverso |
| **Controllo app** | `naviga_sezione` (194 sezioni), `apri_strumento` (12 laboratori), `stato_app` |
| **Memoria** | `ricorda`, `ricordi` |
| **Animazioni** | `apri_animazione` (6 meccanismi di reazione) |
| **Simulazioni** (v260) | `spaccato_stellare` — apre uno dei nove Spaccati stellari (supernova, Sole, buco nero, Ia, kilonova, Big Bang, Terra, Giove, Galassia) solo quando l'utente lo chiede |
| **Schermo e pagina** (Spectra Live) | `leggi_schermo` (materia, sezione, scheda, controlli con i valori, pulsanti, testo della nota), `imposta_controllo`, `scegli_scheda`, `premi_pulsante`, `cambia_materia` |
| **Studio** (Spectra Live) | `consulta_kit` (riassunti, formulario, glossario, quiz della materia), `stato_studio` (flashcard da ripassare, errori dei quiz), `disegna_grafico`, `apri_strumento_rapido` |

I nove strumenti delle ultime due righe sono definiti in `bsi-spectra-live.js`
e aggiunti allo stesso registro `window.BSI_AI_TOOLS` all'avvio della pagina:
il ciclo agentico li tratta come gli altri, sia nella chat sia nella console.

> **La ricerca web non è fra questi trentacinque**, ed è bene distinguerla. I
> trentacinque sono eseguiti **dall'applicazione**, nel browser dell'utente.
> Sui fornitori che li offrono, l'agente aggiunge allo schema due strumenti
> eseguiti **dal fornitore** — `web_search` e `web_fetch`, con un tetto di usi
> per turno. Contarli insieme agli altri li farebbe sembrare disponibili sempre,
> mentre dipendono dal fornitore scelto.

### 3.1 Dataset interni esposti

297 reazioni di sintesi · 118 elementi · 67 amminoacidi · 263 farmaci ·
63 patologie · 46 strategie retrosintetiche · 36 interazioni farmacologiche ·
29 vie metaboliche · 29 potenziali redox.

I farmaci e le strategie sono i due numeri che `tools/verifica-affermazioni.js`
misura sull'applicazione in esecuzione a ogni batteria: qui erano rimasti a 143
e 39 mentre l'app ne contava 178 e 46.

Sono i dati curati dall'autore per l'applicazione: l'agente li consulta come
fonte primaria e ha istruzione di **segnalare le discrepanze** fra database e
propria memoria invece di appianarle silenziosamente.

---

## 4. Decisioni ingegneristiche rilevanti

Questa sezione documenta le scelte non ovvie e il motivo per cui sono state
prese. È la parte del documento che descrive il ragionamento progettuale.

### 4.1 Motore di calcolo senza `eval()`

**Problema.** Servire calcoli arbitrari di chimica fisica richiede un
valutatore di espressioni. `eval()` lo risolverebbe in poche righe.

**Perché è stato escluso.** L'agente legge contenuti esterni non fidati
(risultati PubChem, abstract PubMed, pagine web). Un'iniezione in quei
contenuti potrebbe indurre il modello a emettere un'espressione ostile; con
`eval()` quella stringa verrebbe eseguita nel contesto della pagina, **dove
risiede la chiave API dell'utente**.

**Soluzione.** Parser a discesa ricorsiva con insieme *chiuso* di 27 funzioni e
costanti. Non ha accesso all'ambito globale: può solo fare aritmetica.
Verificato con 10 tentativi di evasione (`window.localStorage`, `constructor`,
`this`, `fetch(...)`, chiamate a funzioni non in whitelist), tutti respinti,
anche eseguendo il test in un browser reale.

### 4.2 Conservazione dei blocchi di ragionamento

Sui modelli con ragionamento adattivo i blocchi `thinking` fanno parte del
turno assistente e devono essere **rimandati indietro identici, firma
crittografica inclusa**, nel giro successivo di *tool use*. Scartarli fa
rifiutare la richiesta.

L'implementazione accumula `thinking_delta` e `signature_delta` dallo stream e
li reinserisce **in testa** al turno ricostruito. Verificato in test
d'integrazione: firma preservata, ordine corretto.

### 4.3 Ripresa dei turni sospesi (`pause_turn`)

La ricerca web è uno strumento eseguito sui server del fornitore. Quando il suo
ciclo interno esaurisce le iterazioni disponibili, la risposta termina con
`stop_reason: "pause_turn"`.

Il turno va ripreso **rimandando indietro il turno assistente così com'è, senza
aggiungere alcun messaggio utente**: è il server a riconoscere il blocco
`server_tool_use` in coda e a riprendere da lì. Aggiungere un "continua"
spezzerebbe il meccanismo.

### 4.4 Configurazione per modello, non globale

I quattro livelli Claude non accettano gli stessi parametri:

| Modello | `effort` | Ricerca web | Note |
|---|---|---|---|
| Fable 5.1 | `xhigh` | sì (8) | fallback su rifiuto; ragionamento sempre attivo |
| Opus 5 | `high` | sì (6) | predefinito |
| Sonnet 5 | `high` | sì (5) | |
| Haiku 4.5 | **non supportato** | **non supportata** | inviarli produce HTTP 400 |

Su tutti i modelli recenti `temperature`, `top_p` e `budget_tokens` sono stati
rimossi dall'API e la loro presenza causa un errore: nessuno dei quattro li
invia. Ogni parametro è quindi condizionato al fornitore, non impostato
globalmente.

### 4.5 Ingresso multimodale e lettura dei materiali

L'agente accetta immagini, PDF e file di testo, anche molti insieme, trattati
come pagine consecutive di un unico documento. Tre vincoli hanno guidato
l'implementazione:

- **Le immagini vengono ridimensionate a 2000 px** e ricompresse in JPEG prima
  dell'invio. Una foto da telefono passa da circa 1 MB a 440 KB: senza questo
  passaggio una singola immagine avvicinerebbe il tetto di richiesta e
  moltiplicherebbe il costo in token. 2000 px sono il minimo per leggere una
  grafia minuta — a 1600 px la scrittura piccola diventava illeggibile.
- **Il tetto di pagine dei PDF dipende dal modello**, non è una costante: 600
  pagine per i modelli con finestra da 1M, 100 per quelli da 200K. Il conteggio
  avviene leggendo gli oggetti `/Type /Page` nei byte del file, senza librerie.
- **Nella cronologia va una miniatura da 160 px**, non l'immagine inviata.
  Salvare quella grande (440 KB l'una) riempiva `localStorage` in una decina di
  foto, e a quota piena ogni scrittura successiva fallisce in silenzio.

Sei azioni rapide trasformano il materiale in un prodotto di studio (riassunto,
mappa concettuale, schema, flashcard, domande d'esame, trascrizione) e due lo
traducono. Per le trascrizioni l'agente ha istruzione di scrivere
`[illeggibile]` invece di indovinare: un termine chimico inventato è peggio di
una lacuna dichiarata.

### 4.6 Renderer di grafi proprio, senza CDN

Le mappe concettuali sono prodotte dal modello come diagrammi Mermaid e
disegnate da un renderer scritto nell'applicazione (~190 righe): livelli per
cammino più lungo dalle radici con interruzione dei cicli, riordino per
baricentro dei predecessori su tre passate per ridurre gli incroci, output SVG
con archi di Bézier.

La scelta di non caricare Mermaid da CDN nasce dalla natura offline-first
dell'app: una mappa deve potersi disegnare anche senza rete. Le sintassi non
coperte vengono riconosciute e lasciate come blocco di codice leggibile,
invece di essere disegnate male.

### 4.7 Comando vocale con parola di attivazione

Ascolto continuo attivabile dall'utente: la frase «Hey Spectra» seguita dal
comando lo invia automaticamente. Due dettagli non ovvi:

- il riconoscimento vocale del browser **termina da solo** dopo qualche secondo
  di silenzio e va riavviato, altrimenti l'ascolto muore alla prima pausa;
- vengono esaminate **tutte le alternative di trascrizione**, non solo la
  prima, e sono accettate le varianti fonetiche più comuni: il riconoscimento
  italiano rende "Spectra" in molti modi diversi.

Il rifiuto del permesso al microfono interrompe il ciclo invece di ritentare
all'infinito. Il termine "spettroscopia", frequentissimo in questo dominio, è
stato verificato come non attivante.

### 4.8 Guardia sui risultati non finiti

Un audit sistematico ha rivelato che, con input degeneri legittimi (lunghezza
d'onda nulla, volume nullo, emivita nulla, transizione fra livelli identici),
otto risolutori restituivano `ok: true` con `Infinity` o `NaN` fra i campi.

È il guasto più insidioso in questo contesto: un'eccezione si nota, un valore
formalmente valido ma privo di senso viene riportato all'utente come corretto.
La correzione è un controllo unico nel punto in cui transitano tutti i
risultati: se un campo numerico non è finito, il risultato diventa un errore
esplicito che nomina i campi e indica la causa probabile. Vale anche per gli
strumenti aggiunti in futuro.

### 4.9 Degradazione controllata

- **Modelli senza *function calling* affidabile** (alcuni gratuiti): al primo
  errore riconducibile agli strumenti, la richiesta viene ripetuta una volta in
  modalità solo testo, invece di fallire.
- **Timeout di inattività (45 s)**, azzerato ad ogni byte ricevuto: una risposta
  lunga non viene troncata, ma una connessione morta viene segnalata subito con
  un messaggio esplicito.
- **Quota di `localStorage`**: lo storico è limitato (30 conversazioni, 100
  messaggi) con potatura progressiva. Senza questo limite il superamento della
  quota faceva fallire *in silenzio* ogni scrittura successiva, **compreso il
  salvataggio della chiave API**.
- **Rifiuto dei classificatori** (`stop_reason: "refusal"`, HTTP 200): rilevato
  e comunicato, invece di presentarsi come risposta vuota.

### 4.10 Spectra Live: voce, schermo e comandi locali

`bsi-spectra-live.js` aggiunge una console a tutto schermo. Si apre da ogni
schermata con l'unico pulsante di Spectra: il volto in un cerchio
(`#bsiJV-fab`), che dalla v239 prende il posto della pillola «Spectra»
(`#bsi-spectra-fab`). La pillola resta nel documento, nascosta dalla classe
`bsiJV-solo-volto` sul `body`, perché altri moduli e i banchi la usano per
aprire la chat; dalla console la chat si apre con 💬. Il cerchio compare subito
con il volto vettoriale e passa al ritratto (`models/spectra-ritratto.jpg`)
dopo l'evento `load`. Restano il pulsante «◈ Live» nella testata di Spectra e
`Ctrl+Shift+J`:

- **conversazione a mani libere**: il riconoscimento vocale del browser
  ascolta, la risposta viene detta frase per frase con la sintesi vocale del
  sistema (si preferisce una voce maschile, velocità 0,95, tono 0,7) oppure,
  dalla v239 e solo con una chiave OpenAI salvata, con la voce di
  `bsi-spectra-voce.js` (§4.15); alla fine la console torna ad ascoltare; «stop» o un tocco la interrompono. Se
  una delle due capacità manca nel browser, la console lo dice;
- **comandi locali**, riconosciuti con espressioni regolari prima di
  chiamare il modello e quindi disponibili senza rete e senza chiave: aprire
  una sezione o cambiare materia, calcolare, derivare e integrare (con il
  motore simbolico dell'app), convertire unità, cercare una costante,
  definire un termine, fare un grafico, interrogare, ripassare, muovere un
  cursore, cambiare scheda, fermare e riprendere un'animazione, dire ora e
  data, e i comandi della mente («cosa ricordi di me», «come stai»,
  «dimentica tutto»);
- **contesto dello schermo**: a ogni domanda che va al modello si aggiunge un
  breve quadro di ciò che l'utente ha davanti (materia, sezione, scheda,
  valori dei controlli, fino a 700 caratteri del testo visibile). Se la
  domanda contiene parole come «questo», «qui», «grafico», o se l'utente ha
  premuto 👁, si allega anche un'immagine delle tele visibili della scheda.

Tutto ciò che va al modello passa dalla stessa strada della chat, verso il
fornitore scelto dall'utente. Il riconoscimento vocale è quello del browser:
dove il browser lo esegue su un servizio remoto, l'audio segue le regole di
quel browser, non di BioSpecInfo.

**Impaginazione e navigazione (v238).** Sul telefono con l'app installata la
barra di stato e i tasti di Android stanno sopra la pagina. La console usa
`env(safe-area-inset-top/bottom)` quando il sistema li comunica e, con la
classe `.bsiJV-bordi` (finestra a schermo intero su un dispositivo touch, o app
installata), almeno 34 px in alto e 46 px in basso. Le posizioni non sono più
fisse: a ogni fotogramma si misurano testata, telemetria e barra dei comandi, e
il volto, lo stato, il pensiero e il dialogo occupano lo spazio che resta. Il
navigatore 🧭 costruisce dalla barra stessa, per ognuna delle tre materie,
l'elenco di gruppi e sezioni, poi gli strumenti rapidi (`BSIAttrezzi`) e le
frasi riconosciute localmente; il pulsante 💬 passa alla chat; le scorciatoie
di contesto cambiano con la sezione aperta. La telemetria mostra UTENTE
(ospite o creatore), LIVELLO e CONCENTRAZIONE.

**Livello e concentrazione.** `difficolta(testo)` parte dal livello della
sezione aperta, cioè il primo livello del percorso di `bsi-percorsi.js` in cui
compare (scuola superiore 0, triennale 1, magistrale 2, dottorato 3: valore
0,15 + 0,22·livello), aggiunge 0,3 per le parole da corso avanzato (teorema,
hamiltoniana, autovalori, …), fino a 0,2 per i simboli, 0,1 per una domanda
lunga, toglie 0,25 per «in parole semplici», e limita il risultato fra 0,05 e
1. Il valore va al volto con `concentra()`.

**Iniziativa.** Con la console aperta, in attesa e in silenzio da più di un
minuto, se la mente ha un pensiero di peso ≥ 2 (una pausa, gli errori da
rivedere, l'ora tarda) Spectra lo dice, al massimo una volta ogni tre minuti e
mai lo stesso due volte, con l'espressione adatta.

### 4.11 Il volto

`bsi-spectra-androide.js` mostra nella console il modello 3D «Noir» di
Skyfox13 (Sketchfab, CC BY 4.0, modificato; attribuzione nella console e in
[`07-SBOM.md`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/07-SBOM.md)). Il modello non ha scheletro né forme per la
bocca, quindi l'animazione è costruita nel codice:

- la **testa** è staccata dal collo e ruota con lo sguardo e il respiro;
- la **bocca** si apre sul testo pronunciato: lo spostamento della mandibola
  è calcolato una volta per vertice e lo shader lo moltiplica per l'apertura
  del momento;
- le **espressioni** sono 17 emozioni, ognuna una miscela di **11 campi
  espressivi** (sorriso, labbra arrotondate, bocca larga, sopracciglia alzate,
  aggrottate, …). WebGL non concede più di 16 attributi per vertice, quindi
  gli undici campi restano in memoria e vengono **fusi sulla CPU** in un
  attributo solo quando l'espressione cambia, ricalcolando solo i vertici che
  qualche campo muove;
- l'emozione di una frase viene da parole chiave in italiano e in inglese
  (`emozioneDi`); senza segnali vale «serena»;
- gli **occhi** (versione 3.0, v238) hanno **palpebre vere**: i vertici di
  ciascun occhio sono deformati sulla CPU attorno al suo centro, per
  apertura e asimmetria propri di ogni emozione (la gioia li stringe, la
  sorpresa li spalanca, il dubbio li rende asimmetrici); lo sguardo li sposta;
  la **tinta** cambia con l'emozione nella famiglia del blu del tema
  (`#1a3050` a riposo, più viva nella gioia e nella sorpresa);
- la **concentrazione** (0–1, da `difficolta()`) socchiude gli occhi, li
  accende, avvicina le sopracciglia, stringe le labbra e rallenta il battito;
- ogni muscolo del viso è una **molla smorzata**, così le espressioni hanno
  inerzia e un piccolo assestamento; ogni pochi secondi compare una
  **micro-espressione** di un quarto di secondo; la bocca usa la
  **coarticolazione**: il visema della lettera successiva comincia prima che
  finisca quello corrente;
- luci neutre (i controluce blu saturi tingevano il metallo), densità reale
  dello schermo fino a 3× e filtraggio anisotropo sulle mappe del metallo;
- dopo **due minuti senza contatto** (tocco, voce, risposta) il volto si
  addormenta: palpebre pesanti, testa bassa, respiro lento; al primo tocco si
  sveglia con un'espressione di sorpresa e poi un sorriso. Lo sguardo segue
  il puntatore e, sul telefono, il punto toccato.

Come la mente, è una **simulazione di comportamento, non una coscienza**.

Senza WebGL, o se il modello non arriva, la console usa la testa costruita da
`bsi-spectra-robot.js` e, in ultima istanza, il ritratto vettoriale di
`bsi-spectra-volto.js`. Con «riduci movimento» la testa resta ferma.

### 4.12 La mente

`bsi-spectra-mente.js` dà a Spectra continuità fra le sessioni. **È una
simulazione di comportamento, non una coscienza**: cinque numeri fra 0 e 1 e
alcune regole, non stati soggettivi.

- **Memoria**: gli episodi di conversazione (al massimo 300, ognuno con ora,
  materia, sezione e i primi 160 caratteri della domanda), il tempo passato
  in ogni sezione, le ore di studio, le emozioni rilevate nelle frasi
  dell'utente (al massimo 60).
- **Stato interno**: curiosità (sale con le domande nuove), attenzione (sale
  quando si lavora insieme, scende nelle pause), premura (cresce con la
  durata della sessione e di notte), umore (si sposta con il tono delle
  frasi dell'utente e torna verso un equilibrio), legame (cresce con ogni
  conversazione, sempre più lentamente). Lo stato sceglie l'emozione di
  fondo del volto e il tono del saluto.
- **Pensieri**: suggerimenti nati da questi dati (una pausa dopo 90 minuti,
  il ripasso degli errori dei quiz, una materia rimasta indietro).
- **Quadro per il modello**: a ogni domanda che va al modello si aggiunge un
  riassunto di tempo di studio, sezioni frequentate, ultimi argomenti e
  stato interno.

Tutto è salvato solo nel `localStorage` del browser, chiave
`bsi-spectra-mente-v1` ([`11-Data-Model.md`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/11-Data-Model.md)); «cosa ricordi
di me» lo mostra, «dimentica tutto» lo cancella.

### 4.13 Il creatore

`bsi-spectra-creatore.js` (v238) dice a Spectra chi l'ha creato: Samuele Pio
Provenzano. «Chi ti ha creato?» ha una risposta locale. «Sono il tuo creatore»
apre una prova: il campo della console diventa di tipo password per un minuto,
l'ascolto vocale si ferma, e il testo inviato **non passa da `elabora()`**:
niente dialogo, memoria, voce né modello. Se ne calcola l'impronta SHA-256
(`crypto.subtle`) e la si confronta con quella del File Manager; la frase non
compare nel codice. Tre tentativi sbagliati portano a un minuto di attesa.

Riconosciuto, Spectra scrive nel `localStorage` solo
`bsi-spectra-creatore-v1` (`ok`, `dal`, `ultima`), saluta per nome
all'apertura della console, mostra «CREATORE» nella telemetria e aggiunge al
quadro per il modello (`contesto()`, anche dentro `coscienza()` della mente)
che sta parlando con il suo autore. A un ospite il quadro dice che non è stato
riconosciuto e che la frase non va mai chiesta in chat. «Dimentica che sono il
tuo creatore» toglie il segno; lo toglie anche «Cancella dati → Memoria
persistente».

**Limite.** Come la password del File Manager è un deterrente, non un
controllo d'accesso: l'impronta è nel codice e il segno può essere scritto a
mano da chi ha il dispositivo (`09-Release-Conformance-Statement.md`, D-13).

### 4.14 La lezione guidata

`bsi-lezione.js` (v239, oggetto `BSILezione`) trasforma ogni sezione in una
lezione in capitoli condotta da Spectra. Non usa il modello: la lezione si
costruisce leggendo la sezione aperta. Va in rete solo la voce, e solo con una
chiave OpenAI salvata (§4.15).

- **Costruzione** (`costruisci(sezione)`): un passo di apertura con titolo e
  sottotitolo; per ogni scheda (`.bsiFX-schede button`) un capitolo, i cui
  passi si leggono quando la scheda è aperta: la spiegazione spezzata in pezzi
  di una o due frasi (al massimo tre pezzi, circa 260 caratteri l'uno), la
  prima tela o scena 3D visibile, fino a quattro cursori e scelte; per le
  sezioni senza schede un solo capitolo con titoli e paragrafi visibili e gli
  stessi comandi. Poi una **domanda di verifica** dal kit di studio della
  materia (`BSIStudio.dati(materia).quiz`): vince quella con più parole
  (di più di quattro lettere) in comune con titolo, sottotitolo e schede, con
  un peso doppio per le parole dell'argomento; serve un punteggio di almeno 2,
  altrimenti la verifica non c'è. Infine il **riepilogo** dei capitoli.
- **Dimostrazioni**: un cursore va dal valore attuale al minimo, al massimo e
  di nuovo al valore di partenza in circa 4 s, generando eventi `input` e
  `change` come farebbe l'utente; una scelta passa per le prime cinque
  opzioni e torna a quella di partenza. Se si passa oltre a metà, o si chiude
  la lezione, il comando viene rimesso com'era.
- **Lettore**: pannello `#bsiLZ` (a destra sullo schermo grande, in basso sotto
  i 760 px; da 1100 px `#main` si sposta a sinistra), avanzamento per capitoli,
  testo che compare parola per parola, ◀ ▶, pausa, voce, `Esc` per chiudere,
  frecce per muoversi. Il riflettore `#bsiLZ-luce` oscura il resto e segue il
  pezzo di cui si parla. La voce è quella di Spectra Live
  (`BSISpectraLive.parla`) e, se la console non c'è, quella di
  `BSISpectraVoce.parla`; senza voce, il tempo di lettura dipende dalla
  lunghezza del testo. Con «riduci movimento» i cursori saltano al valore, il
  testo compare tutto insieme e il riflettore non pulsa.
- **Pulsanti flottanti**: durante la lezione si nascondono (anche quelli con
  `visibility` scritta in linea, il cui valore viene annotato e rimesso alla
  chiusura).
- **Avvio**: il pulsante «🎓 Lezione guidata con Spectra» che il modulo aggiunge
  sotto il titolo di ogni sezione visibile; il comando locale «fammi lezione»
  di Spectra Live, che chiude la console e avvia la lezione della sezione
  aperta; la scorciatoia 🎓 della console.

La lezione non ha chiavi sue nel `localStorage`; a fine lezione segnala alla
mente di Spectra un'emozione (`sente('fiera', 'lezione')`), che la mente
registra in `bsi-spectra-mente-v1` come le altre.

### 4.15 Spectra incarnato: lo studio, il corpo, la voce

Dalla v239 Spectra ha anche un corpo, in una pagina a sé:
`spectra-studio.html`, raggiungibile dal navigatore 🧭 della console. Il
progetto completo (requisiti del modello, scelta dello stack, moduli, stato,
ciclo delle lezioni, migrazione, copertura dei domini) è nei documenti di
[`docs/spectra/`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/01-Analisi-modello-e-piano.md):
[analisi e piano](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/01-Analisi-modello-e-piano.md),
[architettura](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/02-Architettura.md),
[mappa dei domini](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/03-Mappa-dei-domini.md). Qui si riassume ciò che
è nel codice.

- **Lo studio** (`spectra-studio.html`): una scena three.js r128 (pavimento a
  griglia, luci al neon, banco olografico) con Spectra in piedi; un pannello
  accessibile con tutto il testo. Le lezioni di
  `bsi-spectra-studio-lezioni.js` (`BSIStudioLezioni`: `LEZIONI`, `SCENE`,
  `calcolo`) seguono quattro fasi: **predici** (scelte con le idee sbagliate
  più comuni e una giusta, ciascuna spiegata), **testa** (la simulazione con i
  numeri misurati in scena), **dimostra** (la derivazione passo per passo),
  **rivela** (perché, collegamenti, esercizi su quattro livelli). I calcoli
  stanno in `calcolo` e si eseguono anche in node: caduta con Eulero
  semi-implicito (e resistenza quadratica facoltativa), VSEPR come minimo
  dell'energia w_i·w_j/r di domini sulla sfera (w = 1 per i legami, 1,25 per
  i doppietti), somme parziali, coda, Fourier di x², coprimi Monte Carlo.
- **La memoria dello studio**: `bsi-spectra-studio-v1` conserva per lezione
  le previsioni (`quando`, `scelta`, `giusta`) e gli esercizi aperti; il
  livello consigliato è il numero di previsioni giuste più gli esercizi
  aperti, fino a 3. Ogni previsione va anche alla mente
  (`BSISpectraMente.ricorda`). L'interruttore 🔊/🔇 nella barra delle azioni
  spegne la voce dello studio e la scelta resta in `bsi-spectra-studio-voce`
  (`'0'` = spenta). Entrambe le chiavi rientrano in «Cancella dati → Memoria
  persistente».
- **Il corpo** (`bsi-spectra-corpo.js`, `BSISpectraCorpo`): il driver
  riconosce ossa, blendshape ARKit, capelli e clip di un GLB umanoide; ogni
  posa è una direzione nel mondo, convertita nel sistema locale dell'osso
  (`orienta`, una cinematica inversa minima valida per ogni rig); emozioni,
  labiale, palpebre, sguardo, gesti, passo e seduta sono fusi con molle. Il
  manichino di `BSISpectraCorpo.manichino()` (ossa con nomi Mixamo in posa a
  T, 26 blendshape ARKit, capelli rossi che il driver rende neri) serve **solo
  al banco del driver** (`opz.manichino === true`): dalla v240 non è più
  Spectra da nessuna parte. **Il corpo di Spectra** lo sceglie il controllore
  condiviso `BSISpectraFigura.Spectra()` (`bsi-spectra-figura.js`), nello
  studio e nelle sezioni dell'AI. Dalla v241 il corpo è **sempre presente**:
  `carica()` scarica `models/spectra-corpo.bsi`, il «Bounty Hunter» (CGTrader,
  licenza Royalty Free) incorporato come blocco impacchettato da
  `tools/impacchetta-corpo.js`, e lo riapre con `apri`; il file pubblicato
  non è un `.glb` riutilizzabile (non è una protezione assoluta). Mentre
  arriva, «Spectra sta arrivando…»; se non arriva, «↻ Riprova». Solo nello
  studio, in sviluppo, se il blocco manca si prova `models/spectra-corpo.glb`
  (fuori da git); nell'app (`soloDispositivo`) nessun file di sviluppo si
  chiede, niente 404. Il pulsante «🧍 Corpo», il corpo caricato dall'utente
  nell'IndexedDB e il ripiego `models/spectra-cyberpunk.glb` sono stati
  tolti; un vecchio corpo in `bsi-spectra-modelli` si cancella all'avvio.
  Nessun sostituto. Il corpo senza scheletro passa dal rig automatico
  (`bsi-spectra-rig.js`); sul colletto va il volto «Noir»
  (`BSISpectraAndroide.crea(cont, { scena, renderer, senzaBusto: true })`),
  allineato misurando il mento, del quale si vede solo il viso, «solidale» con
  la testa del corpo.
- **La figura nelle sezioni dell'AI** (`BSISpectraFigura.monta`,
  `sezioni`, v240): una figura sola, spostata nella sezione aperta fra
  Spectra AI e le tre aree con l'assistente, mostra Spectra in piedi in un
  riquadro da laboratorio e **reagisce agli eventi dell'app**:
  `bsi-spectra-stato` (pensa, strumenti, scrive) → concentrato, mano al
  mento, «SPECTRA · PENSA»; `bsi-spectra-risposta` (la risposta del
  modello) → spiega con le mani, labiale di corpo e viso dal testo, emozione
  dal contenuto, «SPECTRA · PARLA»; un errore → dubbio; `bsi-spectra-dice`,
  emesso da `parla()` di Spectra Live e dall'assistente locale
  (`bsi-assistente.js`) quando risolve un esercizio («Ecco lo svolgimento:
  …», oppure dubbio se non ha capito) → la figura dice quel testo. Si
  disegna solo quando è visibile e la pagina è in primo piano. Gli eventi
  sono a senso unico: la figura non cambia ciò che il modello risponde.
- **La figura nella console Spectra Live** (v242): con la console aperta,
  `sezioni()` sposta la figura condivisa in `#bsiJV-figura` (fra la
  telemetria e il dialogo; sullo schermo grande a destra), aggiunge la classe
  `con-figura` e nasconde il busto `#bsiJV-volto`: al posto del solo volto,
  Spectra col corpo e l'ologramma. La console emette `bsi-spectra-stato` a
  ogni cambio di stato (attesa, ascolta, pensa, parla): pensa → concentrato,
  mano al mento; ascolta → curioso, «SPECTRA · TI ASCOLTA». L'evento della
  console porta la firma `daLive: true` e la console ignora i propri eventi:
  senza la firma la console, che ascolta lo stesso evento per gli altri
  moduli, si richiamava all'infinito (ricorsione trovata dal banco). Chiusa la
  console, la figura torna nella sezione.
- **«🧠 Spiega»** (`bsi-spectra-spiega.js`, `BSISpiega`, v240): la scheda
  seconda nella finestra di Spectra, dopo «💬 Chat», per una **spiegazione
  esaustiva** di qualunque domanda di chimica, fisica o matematica. Il
  prompt di sistema (`sistema(livello, materia)`) fissa il livello — cinque,
  da Scuola superiore a PhD avanzato · frontiera, ciascuno con le sue
  istruzioni in `PROFONDITA` e «Non semplificare sotto questo livello e non
  tralasciare nulla di rilevante» — e una **struttura obbligatoria** a titoli
  `##`: in sintesi; che cosa stai guardando (solo con lo schermo: lettura
  quantitativa di assi, unità, curve e valori; per gli spettri NMR δ,
  molteplicità, J, integrale e attribuzione di ogni segnale, IR bande e
  gruppi, MS ione molecolare, frammenti e isotopi, UV-Vis λmax, transizioni
  ed ε, poi la struttura e la sua coerenza; per le scene 3D geometria,
  simmetria, nodi, punti critici, isosuperfici e campi; per i grafici
  matematici dominio, asintoti, zeri, estremi, flessi, convergenza);
  fondamenti; derivazione numerata; esempi calcolati; casi limite ed errori
  comuni; collegamenti fra le tre materie; applicazioni e frontiera
  (letteratura solo se certa); tre domande di verifica con risposta.
  **Lo schermo** (`schermo()`, casella «📺 Includi lo schermo»): sezione,
  scheda, ogni comando con valore e intervallo, tabelle visibili (fino a
  4 × 40 righe), testo visibile, numero dei grafici; `immagine()` compone le
  tele visibili (le scene di `BSILab3D` ridisegnate prima, con
  `BSISpectraLive.cattura`) e gli SVG visibili trasformati in immagine, larghi
  al massimo 1400 px, in JPEG. L'immagine va ai modelli che accettano
  immagini con la conversione per fornitore della chat, solo nel primo turno;
  le domande successive continuano la conversazione, che resta in memoria
  per la sessione. Fornitore e chiave sono quelli della chat
  (`window.bsiLLM`). La figura condivisa si sposta nella scheda (precedenza
  sulle sezioni), pensa mentre il modello scrive, poi parla e gesticola.
  **Senza modello non finge**: lo dice e mostra ciò che l'app sa da sola
  (riconoscimento dell'assistente locale, capitoli della lezione guidata
  della sezione, dati dello schermo come testo). Con lo schermo incluso,
  testo e immagine vanno al fornitore configurato insieme alla domanda.
  **Il catalogo** (`catalogo()`): ogni pulsante di sezione della barra
  (`.nav-group-panel [data-s]`) con l'etichetta del gruppo e la materia
  (`BSIMaterie.materiaDi`), 226 sezioni dalla v242 (chimica 93, fisica 70,
  matematica 34, comuni 29), letto dalla barra e non scritto a mano. Il riquadro
  «🗂️ Tutte le sezioni nell'ologramma» le elenca per gruppo, con ricerca e
  filtro per materia; `mostraSezione(id)` apre la sezione dietro la finestra
  (`BSISpectraLive.calcolo.apriSezione`, che cambia materia se serve),
  l'ologramma la mostra dal vivo e la casella dello schermo si spunta, se
  l'utente non l'ha tolta;
  `giro(materia)` («🎞️ Mostrami tutto») le mostra a turno ogni 7 s, con il
  contatore «n/N · nome», e `giroFerma()` lo ferma. `sezioneDi(testo)`
  trova la sezione che una domanda nomina (parole significative dei nomi,
  anche per radice; sigle MS, IR, UV, NMR, MO… pesate di più; sinonimi
  «spettro di massa» → MS, «infrarosso» → IR, «risonanza magnetica» → NMR,
  «orbitali molecolari» → MO; a parità il nome più corto; nessuna se la
  domanda non nomina un argomento): chiedendo senza lo schermo incluso, la
  sezione nominata si apre, si mostra nell'ologramma e la spiegazione
  comprende il suo schermo. **La spunta tolta dall'utente si rispetta**
  (`ST.schermoNo`, dall'evento `change` della casella): la sezione si apre e
  si mostra lo stesso, ma al modello va solo la domanda, senza testo né
  immagine dello schermo; le domande rapide sullo schermo rimettono la
  spunta (scelta esplicita). Una sezione senza grafici si
  proietta nell'ologramma come scheda (titolo, scheda, fino a 6 comandi con
  i valori, testo visibile), così ogni sezione è mostrabile.
- **L'ologramma interattivo, «⛶ Interagisci»** (`bsi-spectra-olointerattivo.js`,
  `BSIOloInterattivo`, v242): il pulsante sull'ologramma della figura
  condivisa apre `#bsi-olo-ov`, a tutto schermo; `sezioni()` dà la precedenza
  a `#bsiOI-figura` quando la finestra è aperta, quindi Spectra col corpo ci
  si sposta, e chiusa la finestra torna nella sezione. La modalità viene
  dalla scena dell'ologramma (pianeti → universo; spettro e molecola →
  spettri; superficie e orbitale → matematica; onda → fisica; lo «schermo»
  secondo la sezione aperta). **Nessuna chiamata a un modello**: gli spettri
  vengono dalle sei molecole di riferimento (valori tipici di letteratura) o
  da `leggiTraccia` (attribuzioni candidate dalle tabelle di frequenze di
  gruppo, spostamenti chimici e perdite neutre, con la forma della banda);
  i pianeti dalla scheda NASA con Keplero e vis-viva calcolati; matematica e
  fisica dall'assistente locale (`bsi-assistente.js`, `bsi-mat-cas.js`), il
  cui svolgimento diventa la lista dei passaggi e il cui risultato guida il
  grafico (funzione e derivata con zeri e punti stazionari, traiettoria del
  proiettile, pendolo). Ogni passaggio ha un titolo e un testo; «🔊 Spectra
  spiega i passaggi» li dà a `BSISpectraLive.parla` uno per uno e la figura
  li dice con labiale e gesti; un tocco su un picco o su un pianeta chiama
  `scegli(i)`. Solo **«🧠 Approfondisci»** passa a un modello, attraverso
  «🧠 Spiega» con i dati dell'ologramma, e con le sue regole.
- **«⚡ Esplora con Spectra»** (`bsi-spectra-esplora.js`, `BSIEsplora`,
  v242): tre sezioni, una per materia (`sesplchim`, `sesplfis`,
  `sesplmat`), registrate con `BSIFisica.sezione`, nello stile delle lezioni
  esplorabili. Dieci capitoli per materia (`CAPITOLI`, livelli 0→4, dalla
  Scuola superiore al PhD avanzato · frontiera), ciascuno con il fenomeno, una
  previsione a quattro risposte con il perché di ognuna, in 19 capitoli un
  cursore calcolato (`calcola(id, v)`), la sezione dell'app collegata e la
  scena dell'ologramma. La figura condivisa entra nella sezione con la classe
  `bsiEX-palco` (`position: sticky` sotto la testata misurata dell'app; sul
  telefono più bassa) e resta in scena mentre si scorre; il capitolo che
  attraversa il centro dello spazio libero sotto la figura diventa attivo:
  `bsi-spectra-dice` (Spectra lo racconta, curioso) e `olo.mostra(scena)`.
  La previsione emette `bsi-spectra-dice` con gioia o sorpresa. «📺 Guardalo
  dal vivo» apre la finestra su «🧠 Spiega» e la sezione dietro
  (`BSISpiega.mostraSezione`); «🧠 Spiegamelo tutto» chiama
  `BSISpiega.chiedi(titolo + domanda, { schermo: true, livello })`, quindi
  passa per lo stesso fornitore e le stesse regole sullo schermo di «🧠
  Spiega»; «🔊 Ascolta Spectra» usa `BSISpectraLive.parla`. Le sezioni
  Esplora contano come sezioni dell'AI: chiusa la finestra si torna lì.
  Nessuna chiamata a un modello senza un gesto dell'utente; le previsioni
  restano in `bsi-esplora-v1`.
- **La voce** (`bsi-spectra-voce.js`, `BSISpectraVoce`): `qualita()` vale
  `'audio'` con una chiave OpenAI in `bsi_api_keys` e Web Audio disponibile,
  `'sistema'` con la sola sintesi del browser, `'testo'` senza. In modalità
  audio il testo (fino a 3 800 caratteri) va a
  `api.openai.com/v1/audio/speech` (`gpt-4o-mini-tts`, voce «onyx», con
  istruzioni sul timbro; `tts-1` se fallisce); l'audio decodificato resta in
  una cache in memoria per frase e passa nella catena del `TIMBRO` (bassi
  +5 dB sotto 140 Hz, −3 dB a 350 Hz, +3 dB a 2,8 kHz, modulatore ad anello a
  55 Hz al 12 %, pettine di 4,3 ms, saturazione, riverbero sintetico di 1,4 s
  al 16 %, compressore). Un analizzatore dà energia e centroide spettrale a
  ogni fotogramma per il labiale. Il testo da pronunciare esce dal
  dispositivo: vedi [`03-Security-Privacy-Compliance.md`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/03-Security-Privacy-Compliance.md) §1.2.

Come la mente e il volto, il corpo è una **simulazione di comportamento, non
una coscienza**.

### 4.16 La memoria a cinque livelli (v254)

Fase 1 del progetto (`progetto/PROGETTO-BIOSPECINFO-SPECTRA.md` §2). Prima la
memoria era in tre posti che non si parlavano: i fatti salvati dal modello
(`bsi_ai_memory`, al massimo 40, tutti nel prompt), la mente (episodi e tempo
per sezione) e l'agenda. `bsi-spectra-memoria.js` (`BSIMemoria`) li riunisce in
un archivio IndexedDB solo, con lo schema del servizio Spectra 2.0.

- **I livelli**: lavoro (la conversazione in corso, che resta della Chat),
  episodi, fatti, procedure (come preferisce studiare), autobiografia (una
  pagina al giorno, un capitolo al mese).
- **Il recupero** (`cerca`): sei segnali pesati — significato 0,34 (coseno su
  un incorporamento locale di 256 componenti da radici e trigrammi), parole in
  comune 0,20, recenza 0,14 con oblio R = e^(−Δt/S), importanza 0,12, sezione
  aperta 0,12, obiettivi 0,08 — più la diffusione ai ricordi collegati e la
  diversità (scarta i quasi doppioni, coseno > 0,92). Senza parole in comune e
  con significato < 0,3 il punteggio si riduce a un terzo: un ricordo estraneo
  non arriva al modello. Soglia 0,2.
- **Il prompt**: la catena `window._bsiMente(testo)` (mente → agenda →
  memoria) aggiunge i blocchi `[RICORDI]`, `[PROCEDURE]` e `[STORIA]` con i soli
  ricordi pertinenti alla domanda.
- **La cura** (`consolida`, alla prima apertura del giorno): importa gli
  episodi nuovi della mente e i fatti di `bsi_ai_memory`; un concetto che torna
  almeno 3 volte in 14 giorni, su almeno 2 giorni, diventa un fatto; impara la
  fascia oraria preferita e le sezioni più usate come procedure; archivia gli
  episodi sbiaditi (R < 0,02, importanza < 0,6, più vecchi di 60 giorni, non
  fissati); scrive la pagina di diario del giorno prima e, a mese nuovo, il
  capitolo. Regole dichiarate, nessun modello linguistico.
- **A parole**: «preferisco…», «consolida la memoria», «cosa ricordi di me»,
  «dimentica X». Lo strumento `cerca_nella_memoria` permette al modello di
  cercare da sé; `ricorda` e `ricordi` scrivono anche qui.
- **Portabilità**: ogni ricordo porta il dispositivo e un orologio, pronti per
  la sincronizzazione (fase 6); la memoria viaggia con «esporta» dell'agenda.

L'incorporamento locale riconosce le parole, non i sinonimi: per questo il
recupero pesa anche le parole in comune.

---

## 5. Verifica

La verifica è stata condotta su tre livelli, con esiti registrati.

### 5.1 Correttezza numerica — confronto con valori di riferimento

| Ambito | Caso | Atteso | Ottenuto |
|---|---|---|---|
| Bilanciamento | `KMnO₄ + HCl → …` | 2:16:2:2:8:5 | ✓ esatto |
| Massa molecolare | `K₄[Fe(CN)₆]` (annidata) | 368,35 | 368,345 |
| Massa molecolare | `CuSO₄·5H₂O` (idrato) | 249,68 | 249,677 |
| Equilibrio | acido acetico 0,1 M, Kₐ 1,8·10⁻⁵ | pH 2,874 | 2,875 |
| Termodinamica | ΔG (N₂O₄/NO₂) a 298 K | +4,79 kJ/mol | ✓ |
| Cinetica | Eₐ da k(300 K) e k(320 K) | 55,3 kJ/mol | 55,33 |
| Gas reali | van der Waals CO₂ | scostamento −10 % | −10,13 % |
| Spettroscopia | M+2 del bromo | 97,3 % | ✓ |
| Biochimica | glicilglicina | 132,12 Da | ✓ |
| Farmacocinetica | t½ da V_d 50 L, Cl 5 L/h | 6,93 h | ✓ |
| Astrofisica | picco di emissione solare (Wien) | 501,5 nm | 501,52 |
| Astrofisica | velocità di fuga terrestre | 11,19 km/s | 11,186 |
| Nucleare | energia di legame ⁵⁶Fe | 8,79 MeV/nucleone | 8,790 |
| Statistica | t critico, 95 %, df = 4 | 2,7764 | ✓ |
| Cristallografia | densità del rame (fcc) | 8,96 g/cm³ | 8,935 |

I p-value non sono tabulati: sono calcolati con la funzione beta incompleta
regolarizzata (frazione continua di Lentz) e la gamma incompleta.

### 5.2 Robustezza — casi che devono fallire

Verificato che vengano **respinti**: equazioni non bilanciabili, formule con
parentesi non bilanciate o elementi inesistenti, specie assenti
dall'equazione, tipi di database non validi, e i 10 tentativi di iniezione
nel motore di calcolo.

### 5.3 Integrazione — browser reale

Test automatizzati con Chromium *headless* su tutte le 14 pagine
dell'applicazione: nessun errore JavaScript, nessuna risorsa mancante.
Percorse una per una le 194 sezioni di `index.html` e i 18 tab della sezione
Astrochimica. Ispezionato il corpo delle richieste per i quattro livelli
Claude, e simulato un ciclo completo con ricerca web, sospensione e ripresa
del turno.

---

## 6. Riepilogo quantitativo

| Metrica | Valore |
|---|---|
| Righe del componente | 6.254 |
| Strumenti | 53 (38 in `bsi-ai-hub.js`, 9 in `bsi-spectra-live.js`, 3 in `bsi-spectra-agenda.js`, 1 in `bsi-spectra-risveglio.js`, 1 in `bsi-teoria.js`, 1 in `bsi-spectra-memoria.js`) |
| Configurazioni di modello | 10 (3 gratuite) |
| Aree scientifiche coperte | 13 |
| Record nei dataset interni esposti | oltre 800 |
| Giri massimi del ciclo agentico | 10 |
| Cronologia inviata al modello | 40 turni |
| Dipendenze runtime | nessuna |

---

## 7. Limiti dichiarati

Documentati per onestà tecnica; sono scelte consapevoli, non omissioni.

- **La chiave API risiede nel browser** — a meno di pubblicare il proxy.
  Nella configurazione predefinita la chiave non lascia il dispositivo, ma è
  accessibile a chi ha accesso a quel browser, e ogni utente deve procurarsi la
  propria. Il Worker della sezione 2.5 toglie questo limite spostando le chiavi
  su un server, al prezzo di un componente da mantenere fuori dalla pagina: è
  una scelta di distribuzione, non un requisito.
- **Gli strumenti di rete dipendono dalla disponibilità dei servizi.** PubChem
  e PubMed sono interrogati direttamente dal browser; in caso di
  irraggiungibilità lo strumento restituisce un errore esplicito e l'agente ha
  istruzione di dichiararlo, non di sostituirlo con una stima.
- **I risolutori applicano modelli semplificati** dove la letteratura ne
  prevede di più raffinati (per esempio Woodward–Fieser per l'UV, o le rese in
  ATP con rapporti P/O medi). Ogni strumento dichiara il metodo usato nel
  proprio risultato.
- **Il contesto dello schermo e il quadro della mente vanno al fornitore.**
  Quando una domanda va al modello, il fornitore scelto riceve anche il
  riassunto della sezione aperta e, se c'è memoria, quello della mente
  (§4.10, §4.12). Restano nel browser solo le risposte dei comandi locali.
- **La verifica è funzionale e numerica**, non formale: non esiste prova di
  correttezza dei risolutori, ma un insieme di casi di riferimento tratti dalla
  letteratura didattica.

---

*Documento redatto a corredo del dossier tecnico BioSpecInfo.
Vedi anche: `01-Software-Architecture-Document.md`,
`02-Verification-Validation-Report.md`, `03-Security-Privacy-Compliance.md`.*
