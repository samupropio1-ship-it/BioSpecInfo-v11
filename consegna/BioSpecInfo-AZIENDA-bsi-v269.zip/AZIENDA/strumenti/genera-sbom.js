#!/usr/bin/env node
/* ═══════════════════════════════════════════════════════════════════════
   DISTINTA DEI COMPONENTI SOFTWARE (SBOM) — BioSpecInfo
   ═══════════════════════════════════════════════════════════════════════

   Una SBOM compilata a mano invecchia al primo aggiornamento e nessuno se ne
   accorge. Questa viene GENERATA dai file realmente presenti nel repository:
   ogni voce porta la dimensione e l'impronta SHA-256 del file effettivamente
   distribuito, cosi' che un revisore possa verificare di avere sotto mano lo
   stesso artefatto descritto.

   Produce due formati, perche' servono a due lettori diversi:
     · docs/07-SBOM.md            leggibile, per il dossier
     · docs/evidence/sbom.cdx.json  CycloneDX 1.5, per gli strumenti di audit

   USO   node tools/genera-sbom.js
   ═══════════════════════════════════════════════════════════════════════ */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');

const RADICE = path.resolve(__dirname, '..');

/* Ogni componente e' dichiarato con la licenza e il ruolo. Le licenze sono
   quelle dei progetti a monte: vanno aggiornate se si cambia versione. */
const COMPONENTI = [
  { file: 'RDKit_minimal.js',  nome: 'RDKit MinimalLib (JS glue)', licenza: 'BSD-3-Clause',
    fornitore: 'RDKit / Greg Landrum', url: 'https://github.com/rdkit/rdkit',
    ruolo: 'Chemioinformatica: interpretazione SMILES, SMARTS, descrittori, disegno 2D.',
    ruoloEn: 'Cheminformatics: SMILES and SMARTS parsing, descriptors, 2D drawing.' },
  { file: 'RDKit_minimal.wasm', nome: 'RDKit MinimalLib (WebAssembly)', licenza: 'BSD-3-Clause',
    fornitore: 'RDKit / Greg Landrum', url: 'https://github.com/rdkit/rdkit',
    ruolo: 'Binario WebAssembly del motore chemioinformatico.',
    ruoloEn: 'WebAssembly binary of the cheminformatics engine.' },
  { file: 'three.min.js', nome: 'three.js', licenza: 'MIT',
    fornitore: 'mrdoob e collaboratori', url: 'https://threejs.org',
    ruolo: 'Motore di rendering WebGL per le scene 3D.',
    ruoloEn: 'WebGL rendering engine for the 3D scenes.' },
  { file: 'three_bloom.js', nome: 'three.js — UnrealBloomPass', licenza: 'MIT',
    fornitore: 'mrdoob e collaboratori', url: 'https://threejs.org',
    ruolo: 'Effetto di post-produzione per le visualizzazioni astronomiche.',
    ruoloEn: 'Post-processing effect for the astronomical visualisations.' },
  { file: 'gltf_loader.js', nome: 'three.js — GLTFLoader', licenza: 'MIT',
    fornitore: 'mrdoob e collaboratori', url: 'https://threejs.org',
    ruolo: 'Caricamento dei modelli anatomici e molecolari in formato glTF.',
    ruoloEn: 'Loading of anatomical and molecular models in glTF format.' },
  { file: '3Dmol-min.js', nome: '3Dmol.js', licenza: 'BSD-3-Clause',
    fornitore: 'University of Pittsburgh / David Koes', url: 'https://3dmol.csb.pitt.edu',
    ruolo: 'Visualizzazione molecolare 3D (PDB, SDF, superfici).',
    ruoloEn: '3D molecular visualisation (PDB, SDF, surfaces).' },
  { file: 'smiles-drawer.min.js', nome: 'SmilesDrawer', licenza: 'MIT',
    fornitore: 'Daniel Probst', url: 'https://github.com/reymond-group/smilesDrawer',
    ruolo: 'Disegno 2D delle strutture a partire da SMILES.',
    ruoloEn: '2D structure drawing from SMILES.' },
  { file: 'vendor/pdfjs/pdf.min.mjs', nome: 'PDF.js (build legacy)', licenza: 'Apache-2.0',
    fornitore: 'Mozilla Foundation', url: 'https://mozilla.github.io/pdf.js/',
    ruolo: 'Apertura dei documenti PDF nel lettore di spettri: ogni pagina disegnata e il suo strato di testo. E\' la build legacy, perche\' quella predefinita usa funzioni di linguaggio recentissime e si rompe sui browser che non le hanno ancora.',
    ruoloEn: 'Opening PDF documents in the spectrum reader: every page drawn and its text layer. It is the legacy build, because the default one uses very recent language features and breaks on browsers that do not have them yet.' },
  { file: 'vendor/pdfjs/pdf.worker.min.mjs', nome: 'PDF.js — worker', licenza: 'Apache-2.0',
    fornitore: 'Mozilla Foundation', url: 'https://mozilla.github.io/pdf.js/',
    ruolo: 'Il lavoro di decodifica di un PDF, fuori dal filo principale: una pagina complessa non blocca l\'interfaccia.',
    ruoloEn: 'The PDF decoding work, off the main thread: a complex page does not freeze the interface.' },
  { file: 'lib/sql-wasm.js', nome: 'sql.js (JS glue)', licenza: 'MIT',
    fornitore: 'sql.js / SQLite', url: 'https://github.com/sql-js/sql.js',
    ruolo: 'Database SQLite in-browser per le esercitazioni sui dati.',
    ruoloEn: 'In-browser SQLite database for the data exercises.' },
  { file: 'lib/sql-wasm.wasm', nome: 'SQLite (WebAssembly)', licenza: 'Public Domain',
    fornitore: 'SQLite Consortium', url: 'https://sqlite.org',
    ruolo: 'Motore SQLite compilato in WebAssembly.',
    ruoloEn: 'SQLite engine compiled to WebAssembly.' },
  { file: 'lib/dimuon.js', nome: 'Dataset dimuoni (CERN Open Data)', licenza: 'CC0-1.0',
    fornitore: 'CERN Open Data Portal', url: 'https://opendata.cern.ch',
    ruolo: 'Dati sperimentali per l\'esercitazione di fisica delle particelle.',
    ruoloEn: 'Experimental data for the particle-physics exercise.' },
  { file: 'models/spectra-noir.glb', nome: 'Modello 3D «Noir» (Skyfox13, Sketchfab)', licenza: 'CC-BY-4.0',
    fornitore: 'Skyfox13 — https://sketchfab.com/podderkuntal25', url: 'https://sketchfab.com/3d-models/noir-8edf174437494f0080b4cd5aa0f0509c',
    ruolo: 'Volto di Spectra nella console Spectra Live. Modificato: texture ricompresse, tangenti tolte, viso in metallo grigio scuro, bocca e testa animate. Attribuzione nella console.',
    ruoloEn: 'Spectra\'s face in the Spectra Live console. Modified: textures recompressed, tangents removed, face in dark grey metal, mouth and head animated. Credited in the console.' }
];

/* Il codice scritto per questo progetto: non e' una dipendenza, ma un
   revisore deve poterne verificare l'integrita' allo stesso modo. */
const PROPRI = [
  { file: 'index.html',     ruolo: 'Applicazione principale: interfaccia, sezioni didattiche, dati chimici.',
    ruoloEn: 'Main application: interface, teaching sections, chemical data.' },
  { file: 'bsi-ai-hub.js',  ruolo: 'Agente AI «Spectra»: ciclo agentico, strumenti, gestione dei fornitori.',
    ruoloEn: '«Spectra» AI agent: agentic loop, tools, provider management.' },
  { file: 'bsi-spettri.js', ruolo: 'Motore di predizione spettrale IR/NMR su grafo molecolare.',
    ruoloEn: 'IR/NMR spectral prediction engine over the molecular graph.' },
  { file: 'bsi-cheminfo.js', ruolo: 'Motore di chemioinformatica: standardizzazione, impronte, raggruppamento, PCA, modelli QSAR con modello nullo.',
    ruoloEn: 'Cheminformatics engine: standardisation, fingerprints, clustering, PCA, QSAR models with a null model.' },
  { file: 'bsi-pretsch.js', ruolo: 'Le tabelle di stima NMR trascritte intere da Pretsch–Bühlmann–Badertscher, 4ª ed.: benzeni ¹³C e ¹H, etileni, alcani, alchini, alifatici ¹³C, correzioni steriche, ¹J(C,H). Solo numeri, nessun codice.',
    ruoloEn: 'The NMR estimation tables transcribed in full from Pretsch–Bühlmann–Badertscher, 4th ed.: ¹³C and ¹H benzenes, ethylenes, alkanes, alkynes, ¹³C aliphatics, steric corrections, ¹J(C,H). Numbers only, no code.' },
  { file: 'bsi-nmr.js',     ruolo: 'Predizione NMR ¹H e ¹³C assegnata per atomo: applica le tabelle di bsi-pretsch.js camminando l\'anello e misurando le distanze, con composto di riferimento ciclico ed equivalenza chimica per codice d\'intorno.',
    ruoloEn: 'Per-atom ¹H and ¹³C NMR prediction: applies the bsi-pretsch.js tables by walking the ring and measuring distances, with a cyclic reference compound and chemical equivalence by environment code.' },
  { file: 'bsi-geom3d.js',  ruolo: 'Coordinate 3D da uno SMILES per geometria delle distanze, con gli stessi indici del predittore NMR: è la condizione del collegamento picco↔atomo↔3D.',
    ruoloEn: '3D coordinates from a SMILES by distance geometry, carrying the NMR predictor\'s own atom indices: the precondition for the peak↔atom↔3D link.' },
  { file: 'bsi-fisica-comune.js', ruolo: 'La casa comune delle sezioni di fisica: intestazione, schede, cursori, grafici su tela, lingua.',
    ruoloEn: 'The shared home of the physics sections: header, tabs, sliders, canvas charts, language.' },
  { file: 'bsi-fis-schrodinger.js', ruolo: 'Equazione di Schrödinger 1D: differenze finite, bisezione di Sturm, iterazione inversa, Crank-Nicolson, Morse delle molecole reali.',
    ruoloEn: '1D Schrödinger equation: finite differences, Sturm bisection, inverse iteration, Crank-Nicolson, Morse for real molecules.' },
  { file: 'bsi-fis-hartreefock.js', ruolo: 'Hartree-Fock ristretto con base STO-3G: integrali di McMurchie-Davidson, funzione di Boys, SCF con DIIS, orbitali molecolari.',
    ruoloEn: 'Restricted Hartree-Fock in the STO-3G basis: McMurchie-Davidson integrals, Boys function, SCF with DIIS, molecular orbitals.' },
  { file: 'bsi-fis-rotovib.js', ruolo: 'Spettri rotovibrazionali IR e Raman delle biatomiche dalle costanti molecolari; differenze di combinazione.',
    ruoloEn: 'IR and Raman rovibrational spectra of diatomics from molecular constants; combination differences.' },
  { file: 'bsi-fis-termostat.js', ruolo: 'Termodinamica statistica: funzioni di partizione, entropia, capacità termica, popolazioni di Boltzmann.',
    ruoloEn: 'Statistical thermodynamics: partition functions, entropy, heat capacity, Boltzmann populations.' },
  { file: 'bsi-fis-dinamica.js', ruolo: 'Dinamica molecolare di Lennard-Jones 2D: velocity Verlet, termostato, viriale, distribuzione radiale.',
    ruoloEn: '2D Lennard-Jones molecular dynamics: velocity Verlet, thermostat, virial, radial distribution.' },
  { file: 'bsi-fis-matematica.js', ruolo: 'Matematica per la chimica: FFT del FID, Hückel, Runge-Kutta per le cinetiche, minimi quadrati con gli errori.',
    ruoloEn: 'Mathematics for chemistry: FFT of the FID, Hückel, Runge-Kutta for kinetics, least squares with errors.' },
  { file: 'bsi-fis-cristalli.js', ruolo: 'Cristallografia: reticoli di Bravais, indici di Miller, diffrattogramma di polvere con fattore di struttura ed estinzioni.',
    ruoloEn: 'Crystallography: Bravais lattices, Miller indices, powder pattern with structure factor and absences.' },
  { file: 'bsi-fis-nucleare.js', ruolo: 'Radiochimica: equazioni di Bateman, datazione radiometrica, formula semiempirica di Weizsäcker.',
    ruoloEn: 'Radiochemistry: Bateman equations, radiometric dating, Weizsäcker semi-empirical formula.' },
  { file: 'bsi-mat-cas.js', ruolo: 'Motore di calcolo simbolico: analizzatore, frazioni esatte, forma canonica, derivate, primitive verificate, serie troncate, limiti.',
    ruoloEn: 'Computer-algebra engine: parser, exact fractions, canonical form, derivatives, verified antiderivatives, truncated series, limits.' },
  { file: 'bsi-mat-basi.js', ruolo: 'Basi di matematica: cifre significative, logaritmi e pH, equazioni con i passaggi, allenamento.',
    ruoloEn: 'Mathematics basics: significant figures, logarithms and pH, equations with working, practice.' },
  { file: 'bsi-mat-funzioni.js', ruolo: 'Studio di funzione: dominio, zeri, estremi, flessi, asintoti; famiglie e trasformazioni.',
    ruoloEn: 'Function analysis: domain, zeros, extrema, inflections, asymptotes; families and transformations.' },
  { file: 'bsi-mat-calcolo.js', ruolo: 'Derivate con le regole, integrali e somme di Riemann, polinomi di Taylor, limiti.',
    ruoloEn: 'Derivatives with rules, integrals and Riemann sums, Taylor polynomials, limits.' },
  { file: 'bsi-mat-lineare.js', ruolo: 'Algebra lineare in frazioni esatte: Gauss-Jordan con i passi, determinante, inversa, autovalori, bilanciamento come nucleo.',
    ruoloEn: 'Exact-fraction linear algebra: step-by-step Gauss-Jordan, determinant, inverse, eigenvalues, balancing as a null space.' },
  { file: 'bsi-mat-ode.js', ruolo: 'Equazioni differenziali: campo di direzioni, Eulero/Heun/RK4, piano delle fasi ed equilibri dallo jacobiano.',
    ruoloEn: 'Differential equations: direction field, Euler/Heun/RK4, phase plane and equilibria from the Jacobian.' },
  { file: 'bsi-mat-multi.js', ruolo: 'Funzioni di più variabili: superfici, punti critici con l\'hessiano, relazioni di Maxwell, differenziali esatti.',
    ruoloEn: 'Functions of several variables: surfaces, critical points from the Hessian, Maxwell relations, exact differentials.' },
  { file: 'bsi-mat-complessi.js', ruolo: 'Numeri complessi (piano di Argand, radici, Eulero) e serie di Fourier.',
    ruoloEn: 'Complex numbers (Argand plane, roots, Euler) and Fourier series.' },
  { file: 'bsi-mat-risolutore.js', ruolo: 'Risolutore d’esame di matematica: svolgimento passo per passo di 16 tipi di esercizio.',
    ruoloEn: 'Mathematics exam solver: step-by-step working for 16 exercise types.' },
  { file: 'bsi-mat-esame.js', ruolo: 'Esame di Istituzioni di Matematiche I e II: programma, risolutore, appelli svolti, simulazione.',
    ruoloEn: 'Istituzioni di Matematiche I and II exam: syllabus, solver, solved papers, simulation.' },
  { file: 'bsi-fis-esame.js', ruolo: 'Esame di Fisica Generale I e II: programma, 48 modelli di problema, prove svolte.',
    ruoloEn: 'General Physics I and II exam: syllabus, 48 problem models, solved papers.' },
  { file: 'bsi-percorsi.js', ruolo: 'Percorsi di studio dalle superiori al dottorato per chimica, fisica e matematica.',
    ruoloEn: 'Study paths from high school to PhD for chemistry, physics and mathematics.' },
  { file: 'bsi-mat-probabilita.js', ruolo: 'Probabilità in movimento: Galton, limite centrale, Monte Carlo, Bayes.',
    ruoloEn: 'Probability in motion: Galton, central limit, Monte Carlo, Bayes.' },
  { file: 'bsi-mat-visiva.js', ruolo: 'Matematica visiva: trasformazioni lineari, epicicli di Fourier, frattali, mappa logistica.',
    ruoloEn: 'Visual mathematics: linear maps, Fourier epicycles, fractals, logistic map.' },
  { file: 'bsi-fis-em.js', ruolo: 'Elettromagnetismo in movimento: cariche, induzione, generatore, onde EM.',
    ruoloEn: 'Electromagnetism in motion: charges, induction, generator, EM waves.' },
  { file: 'bsi-fis-suono.js', ruolo: 'Suono e acustica con Web Audio: armoniche, timbro, Doppler, decibel.',
    ruoloEn: 'Sound and acoustics with Web Audio: harmonics, timbre, Doppler, decibels.' },
  { file: 'bsi-fis-solido.js', ruolo: 'Semiconduttori: Fermi-Dirac, drogaggio, giunzione p-n, LED.',
    ruoloEn: 'Semiconductors: Fermi-Dirac, doping, p-n junction, LEDs.' },
  { file: 'bsi-chi-distillazione.js', ruolo: 'Distillazione: Antoine, van Laar, McCabe-Thiele, Rayleigh.',
    ruoloEn: 'Distillation: Antoine, van Laar, McCabe-Thiele, Rayleigh.' },
  { file: 'bsi-chi-voltammetria.js', ruolo: 'Voltammetria ciclica simulata: diffusione e Butler-Volmer.',
    ruoloEn: 'Simulated cyclic voltammetry: diffusion and Butler-Volmer.' },
  { file: 'bsi-mat-numeri.js', ruolo: 'Numeri e crittografia: crivello, Euclide, aritmetica modulare, RSA, distribuzione dei primi.',
    ruoloEn: 'Numbers and cryptography: sieve, Euclid, modular arithmetic, RSA, prime distribution.' },
  { file: 'bsi-mat-grafi.js', ruolo: 'Grafi e ottimizzazione: Dijkstra, Kruskal, discesa del gradiente, programmazione lineare.',
    ruoloEn: 'Graphs and optimisation: Dijkstra, Kruskal, gradient descent, linear programming.' },
  { file: 'bsi-mat-serie.js', ruolo: 'Successioni e serie: limite ε–N, criteri, riordino, raggio di convergenza.',
    ruoloEn: 'Sequences and series: ε–N limit, tests, rearrangement, radius of convergence.' },
  { file: 'bsi-mat-variazioni.js', ruolo: 'Calcolo delle variazioni: brachistocrona, catenaria, catenoide, Fermat.',
    ruoloEn: 'Calculus of variations: brachistochrone, catenary, catenoid, Fermat.' },
  { file: 'bsi-mat-topologia.js', ruolo: 'Topologia: caratteristica di Eulero, superfici, poligoni fondamentali, nodi.',
    ruoloEn: 'Topology: Euler characteristic, surfaces, fundamental polygons, knots.' },
  { file: 'bsi-mat-algebra.js', ruolo: 'Strutture algebriche: gruppi diedrali, permutazioni, campi finiti, Lagrange.',
    ruoloEn: 'Algebraic structures: dihedral groups, permutations, finite fields, Lagrange.' },
  { file: 'bsi-mat-giochi.js', ruolo: 'Teoria dei giochi: Nash, dilemma ripetuto, minimax, Nim.',
    ruoloEn: 'Game theory: Nash, iterated dilemma, minimax, Nim.' },
  { file: 'bsi-mat-logica.js', ruolo: 'Logica e calcolabilità: tavole di verità, circuiti, macchina di Turing, insiemi.',
    ruoloEn: 'Logic and computability: truth tables, circuits, Turing machine, sets.' },
  { file: 'bsi-mat-inferenza.js', ruolo: 'Statistica inferenziale: intervalli, test e potenza, regressione, bootstrap.',
    ruoloEn: 'Statistical inference: intervals, tests and power, regression, bootstrap.' },
  { file: 'bsi-mat-noneuclidea.js', ruolo: 'Geometrie non euclidee: sfera, disco di Poincaré, curvatura e trasporto parallelo.',
    ruoloEn: 'Non-Euclidean geometries: sphere, Poincaré disk, curvature and parallel transport.' },
  { file: 'bsi-fis-gravita.js', ruolo: 'Gravitazione: N corpi con Verlet, punti di Lagrange, fionda gravitazionale.',
    ruoloEn: 'Gravitation: N bodies with Verlet, Lagrange points, gravity assist.' },
  { file: 'bsi-fis-calore.js', ruolo: 'Calore e diffusione: equazione del calore 1D e 2D, Newton, pareti.',
    ruoloEn: 'Heat and diffusion: 1D and 2D heat equation, Newton cooling, walls.' },
  { file: 'bsi-fis-ising.js', ruolo: 'Modello di Ising: Metropolis, transizione di fase, isteresi.',
    ruoloEn: 'Ising model: Metropolis, phase transition, hysteresis.' },
  { file: 'bsi-fis-particelle.js', ruolo: 'Fisica delle particelle: Modello Standard, conservazione, massa invariante, vite medie.',
    ruoloEn: 'Particle physics: Standard Model, conservation, invariant mass, lifetimes.' },
  { file: 'bsi-fis-analitica.js', ruolo: 'Meccanica analitica: spazio delle fasi, doppio pendolo, Noether, Liouville.',
    ruoloEn: 'Analytical mechanics: phase space, double pendulum, Noether, Liouville.' },
  { file: 'bsi-fis-laser.js', ruolo: 'Laser e ottica quantistica: soglia, modi della cavità, Rabi, Mach–Zehnder.',
    ruoloEn: 'Lasers and quantum optics: threshold, cavity modes, Rabi, Mach–Zehnder.' },
  { file: 'bsi-fis-clima.js', ruolo: 'Fisica del clima: bilancio radiativo, forzante della CO2, ghiaccio-albedo, Coriolis.',
    ruoloEn: 'Climate physics: radiative balance, CO2 forcing, ice-albedo, Coriolis.' },
  { file: 'bsi-chi-fasi.js', ruolo: 'Diagrammi di fase: acqua e CO2 (IAPWS, Span-Wagner), eutettico, Clapeyron.',
    ruoloEn: 'Phase diagrams: water and CO2 (IAPWS, Span-Wagner), eutectic, Clapeyron.' },
  { file: 'bsi-chi-pes.js', ruolo: 'Superficie di energia potenziale LEPS di H + H2 e traiettorie.',
    ruoloEn: 'LEPS potential energy surface for H + H2 and trajectories.' },
  { file: 'bsi-articoli-nobel-fisica.js', ruolo: 'Spiegazioni per argomento dei Nobel per la fisica (nessun dato).',
    ruoloEn: 'Topic explanations of the Nobel Prizes in Physics (no data).' },
  { file: 'bsi-articoli-premi-matematica.js', ruolo: 'Spiegazioni per argomento dei premi Abel e Fields (nessun dato).',
    ruoloEn: 'Topic explanations of the Abel Prize and Fields Medal (no data).' },
  { file: 'bsi-materie.js', ruolo: 'Pulsanti per cambiare materia: chimica, fisica, matematica.',
    ruoloEn: 'Subject switch buttons: chemistry, physics, mathematics.' },
  { file: 'bsi-fis-astro.js', ruolo: 'Astrofisica: diagramma H-R, corpo nero, sistema solare, esopianeti, cosmologia.',
    ruoloEn: 'Astrophysics: H-R diagram, black body, solar system, exoplanets, cosmology.' },
  { file: 'bsi-fis-relativita.js', ruolo: 'Relatività ristretta: Minkowski, gemelli, dinamica.',
    ruoloEn: 'Special relativity: Minkowski, twins, dynamics.' },
  { file: 'bsi-materie-app.js', ruolo: 'Tre app in una: la materia scelta adatta menu ✨, Spectra, Studio e Utility.',
    ruoloEn: 'Three apps in one: the chosen subject adapts the ✨ menu, Spectra, Study and Utility.' },
  { file: 'bsi-attrezzi.js', ruolo: 'Strumenti rapidi del menu ✨ per fisica e matematica: calcolatrice, derivata, grafico, costante, unità, formula, glossario, quiz.',
    ruoloEn: 'Quick tools of the ✨ menu for physics and mathematics: calculator, derivative, graph, constant, units, formula, glossary, quiz.' },
  { file: 'bsi-studio.js', ruolo: 'Motore dei kit di studio: riassunti, quiz, flashcard di Leitner, formulario, glossario.',
    ruoloEn: 'Study-kit engine: summaries, quizzes, Leitner flashcards, formula sheet, glossary.' },
  { file: 'bsi-studio-fisica.js', ruolo: 'Dati del kit di studio di fisica (nessun codice).',
    ruoloEn: 'Physics study-kit data (no code).' },
  { file: 'bsi-studio-matematica.js', ruolo: 'Dati del kit di studio di matematica (nessun codice).',
    ruoloEn: 'Mathematics study-kit data (no code).' },
  { file: 'bsi-risorse-materie.js', ruolo: 'Risorse web, bibliografia e citazioni per le tre materie; costanti CODATA e unità; tavole matematiche con le prove.',
    ruoloEn: 'Web resources, bibliography and citations for the three subjects; CODATA constants and units; mathematical tables with their proofs.' },
  { file: 'bsi-astro-sistemasolare.js', ruolo: 'Sistema solare 3D alla data: elementi JPL di Standish, Keplero, Terra, Luna ed eclissi, Giove e Saturno.',
    ruoloEn: 'Solar system 3D at any date: Standish JPL elements, Kepler, Earth, Moon and eclipses, Jupiter and Saturn.' },
  { file: 'bsi-astro-orbite.js', ruolo: 'Meccanica orbitale 3D: elementi e stato, manovre, satelliti, Lambert.',
    ruoloEn: 'Orbital mechanics 3D: elements and state, manoeuvres, satellites, Lambert.' },
  { file: 'bsi-astro-matcelesti.js', ruolo: 'Matematica celeste: equazione di Keplero, rotazioni e quaternioni, integratori a N corpi, periodogrammi.',
    ruoloEn: 'Celestial mathematics: Kepler equation, rotations and quaternions, N-body integrators, periodograms.' },
  { file: 'bsi-astro-stelle.js', ruolo: 'Vita delle stelle 3D: Lane-Emden, evoluzione, nucleosintesi.',
    ruoloEn: 'Life of stars 3D: Lane-Emden, evolution, nucleosynthesis.' },
  { file: 'bsi-astro-buchineri.js', ruolo: 'Buchi neri e relatività generale: ray tracing di Schwarzschild, geodetiche, curvatura, Hawking.',
    ruoloEn: 'Black holes and general relativity: Schwarzschild ray tracing, geodesics, curvature, Hawking.' },
  { file: 'bsi-astro-ondegrav.js', ruolo: 'Onde gravitazionali: spirale, chirp, rivelatore, pulsar di Hulse-Taylor.',
    ruoloEn: 'Gravitational waves: inspiral, chirp, detector, Hulse-Taylor pulsar.' },
  { file: 'bsi-astro-galassie.js', ruolo: 'Galassie 3D: tipi di Hubble, curve di rotazione, collisione, Gruppo Locale.',
    ruoloEn: 'Galaxies 3D: Hubble types, rotation curves, collision, Local Group.' },
  { file: 'bsi-astro-cosmo.js', ruolo: 'Cosmologia 3D: Friedmann-Lemaître, distanze, CMB, storia termica.',
    ruoloEn: 'Cosmology 3D: Friedmann-Lemaître, distances, CMB, thermal history.' },
  { file: 'bsi-astro-cielo.js', ruolo: 'Planetario 3D: cielo da un luogo e un\'ora, coordinate, precessione, analemma.',
    ruoloEn: 'Planetarium 3D: the sky from any place and time, coordinates, precession, analemma.' },
  { file: 'bsi-astro-esopianeti.js', ruolo: 'Esopianeti 3D: zona abitabile, transito, velocità radiale, immagine diretta.',
    ruoloEn: 'Exoplanets 3D: habitable zone, transit, radial velocity, direct imaging.' },
  { file: 'bsi-astro-wormhole.js', ruolo: 'Spaziotempo curvo e wormhole: curvatura e maree, metrica di Morris–Thorne, materia esotica, Casimir, dilatazione del tempo.',
    ruoloEn: 'Curved spacetime and wormholes: curvature and tides, Morris–Thorne metric, exotic matter, Casimir, time dilation.' },
  { file: 'bsi-orbitali.js', ruolo: 'Laboratorio degli orbitali: funzioni d\'onda idrogenoidi esatte, isosuperficie al 90 %, fase come colore, sovrapposizioni nel tempo, corrente di probabilità, H₂⁺ LCAO.',
    ruoloEn: 'Orbital laboratory: exact hydrogen-like wavefunctions, 90 % isosurface, phase as colour, time-dependent superpositions, probability current, H₂⁺ LCAO.' },
  { file: 'bsi-elementi3d.js', ruolo: 'Gli elementi in 3D: nuvola elettronica di Slater per sottoguscio, nucleo con protoni e neutroni, configurazioni della tabella, righe di emissione NIST, tavola periodica e sequenza.',
    ruoloEn: 'The elements in 3D: Slater electron cloud per subshell, nucleus with protons and neutrons, table configurations, NIST emission lines, periodic table and sequence.' },
  { file: 'bsi-astro-materiaoscura.js', ruolo: 'Materia oscura e lenti gravitazionali: rete cosmica 3D, lente calcolata per pixel sulla GPU, rete neurale addestrata nel browser con fit fisico, curve di rotazione.',
    ruoloEn: 'Dark matter and gravitational lensing: 3D cosmic web, lens computed per pixel on the GPU, neural network trained in the browser with physical fit, rotation curves.' },
  { file: 'bsi-astro-materiaoscura-fisica.js', ruolo: 'Calcolo della materia oscura: cosmologia ΛCDM (Planck 2018), spettro BBKS con σ₈, FFT 3D, rete cosmica di Zel\'dovich, lenti puntiforme, SIS, SIE e NFW, curve critiche e caustiche, curve di rotazione.',
    ruoloEn: 'Dark matter computation: ΛCDM cosmology (Planck 2018), BBKS spectrum with σ₈, 3D FFT, Zel\'dovich cosmic web, point, SIS, SIE and NFW lenses, critical curves and caustics, rotation curves.' },
  { file: 'bsi-astro-viaggio.js', ruolo: 'Dal Sole alla Galassia: zoom logaritmico continuo con posizioni vere, flusso di Rankine, nube di Oort, Via Lattea, bolle di Fermi ed eROSITA.',
    ruoloEn: 'From the Sun to the Galaxy: continuous logarithmic zoom with true positions, Rankine flow, Oort cloud, Milky Way, Fermi and eROSITA bubbles.' },
  { file: 'bsi-orbitali-cinema.js', ruolo: 'Onde di fase e correnti: isosuperficie a reticolo per rotazione del contorno, scie della corrente di probabilità, onda di fase, anello di de Broglie.',
    ruoloEn: 'Phase waves and currents: wireframe isosurface by contour revolution, probability-current streaks, phase wave, de Broglie ring.' },
  { file: 'bsi-ar.js', ruolo: 'Realtà aumentata unificata: esportatori GLB e USDZ, WebXR su Android, Quick Look su iPhone, pulsante AR nelle scene 3D.',
    ruoloEn: 'Unified augmented reality: GLB and USDZ exporters, WebXR on Android, Quick Look on iPhone, AR button in 3D scenes.' },
  { file: 'bsi-astro-eliosfera.js', ruolo: 'L\'eliosfera: spirale di Parker, shock di terminazione, eliopausa di Rankine, gas interstellare, nastro di IBEX, Voyager.',
    ruoloEn: 'The heliosphere: Parker spiral, termination shock, Rankine heliopause, interstellar gas, IBEX ribbon, Voyagers.' },
  { file: 'bsi-med-fisiologia.js', ruolo: 'Fisiologia come sistema: ciclo cardiaco a elastanza variabile, acido–base con i compensi, modello minimo di Bergman, scambi gassosi.',
    ruoloEn: 'Physiology as a system: time-varying elastance cardiac cycle, acid–base with compensations, Bergman minimal model, gas exchange.' },
  { file: 'bsi-farm-quantitativa.js', ruolo: 'Farmacologia quantitativa: due compartimenti, dosi ripetute, farmacodinamica di Hill, indice terapeutico, interazioni di Rowland–Matin.',
    ruoloEn: 'Quantitative pharmacology: two compartments, repeated dosing, Hill pharmacodynamics, therapeutic index, Rowland–Matin interactions.' },
  { file: 'bsi-mat-mappa.js', ruolo: 'Mappa dei prerequisiti di matematica: 41 argomenti su quattro livelli, percorso per ordinamento topologico.',
    ruoloEn: 'Mathematics prerequisite map: 41 topics on four levels, path by topological sort.' },
  { file: 'bsi-fis-scene3d.js', ruolo: 'Scene fisiche 3D: H₂ nella curva di Morse con moto esatto e nuvola σg, magnetosfera di Dungey con magnetopausa di Shue e ovali aurorali calcolati, reticolo elastico di Kelvin.',
    ruoloEn: '3D physics scenes: H₂ in the Morse curve with exact motion and σg cloud, Dungey magnetosphere with Shue magnetopause and computed auroral ovals, Kelvin elastic lattice.' },
  { file: 'bsi-spectra-ponte.js', ruolo: 'Ponte WebSocket con Spectra Prime (spectra_core): telemetria della scena 3D, comandi load/update/toggle_layer/focus, risposte e direttive all\'avatar.',
    ruoloEn: 'WebSocket bridge to Spectra Prime (spectra_core): 3D scene telemetry, load/update/toggle_layer/focus commands, replies and avatar directives.' },
  { file: 'bsi-spectra-nucleo.js', ruolo: 'Spectra come nucleo olografico a forma di particella: nucleoni, nuvola elettronica dagli orbitali dell\'idrogeno, elettroni, guscio esagonale, anelli HUD, stati con transizioni morbide, HUD in DOM, versione 2D.', ruoloEn: 'Spectra as a particle-shaped holographic core: nucleons, electron cloud from hydrogen orbitals, electrons, hexagonal shell, HUD rings, smoothly blended states, DOM HUD, 2D version.' },
  { file: 'bsi-spectra-cervello.js', ruolo: 'La rete neurale di Spectra disegnata come un cervello: regioni con i ricordi veri, quote, sinapsi, stato interno.', ruoloEn: 'Spectra\'s neural network drawn as a brain: regions with real memories, shares, synapses, internal state.' },
  { file: 'bsi-cosmo-core.js', ruolo: 'Simulazioni cosmiche: motore comune (timeline cinematica, HUD, didascalie, 9:16, registrazione webm).', ruoloEn: 'Cosmic simulations: common engine (cinematic timeline, HUD, captions, 9:16, webm recording).' },
  { file: 'bsi-cosmo-h2.js', ruolo: 'H₂: Morse sui dati misurati, moto esatto, nuvola LCAO campionata esattamente, legame che si rompe.', ruoloEn: 'H₂: Morse on measured data, exact motion, exactly sampled LCAO cloud, breaking bond.' },
  { file: 'bsi-cosmo-geodetiche.js', ruolo: 'Geodetiche nulle di Schwarzschild con RK4, ΔE/E calcolato, cielo deformato dall\'equazione della lente.', ruoloEn: 'Schwarzschild null geodesics with RK4, computed ΔE/E, sky lensed by the lens equation.' },
  { file: 'bsi-cosmo-galassia.js', ruolo: 'Galassia a particelle test: Hernquist + Freeman + NFW, leapfrog, curva di rotazione misurata, con e senza materia oscura.', ruoloEn: 'Test-particle galaxy: Hernquist + Freeman + NFW, leapfrog, measured rotation curve, with and without dark matter.' },
  { file: 'bsi-cosmo-reticolo.js', ruolo: 'Reticolo 3D deformato dalla massa (visualizzazione), rilassamento con oscillatori smorzati, satellite kepleriano.', ruoloEn: '3D lattice deformed by mass (visualisation), relaxation with damped oscillators, Keplerian satellite.' },
  { file: 'bsi-cosmo-telo.js', ruolo: 'Telo di gomma (analogia) con orbite N corpi Velocity Verlet e lancio di un corpo.', ruoloEn: 'Rubber sheet (analogy) with N-body Velocity Verlet orbits and body launch.' },
  { file: 'bsi-cosmo-eliosfera.js', ruolo: 'Eliosfera dal modello adattato alle Voyager, vento solare, eliche dei pianeti, Galassia schematica.', ruoloEn: 'Heliosphere from the Voyager-fitted model, solar wind, planet helices, schematic Galaxy.' },
  { file: 'bsi-cosmo-vialattea.js', ruolo: 'Via Lattea sul telo con il profilo del potenziale vero (Hernquist + Freeman + NFW).', ruoloEn: 'Milky Way on the sheet with the true potential profile (Hernquist + Freeman + NFW).' },
  { file: 'bsi-cosmo-scala.js', ruolo: 'Simulazione cosmica 3: il Sole come pallina da tennis, scala 1 : 20,8 miliardi, le stelle vicine e il vuoto calcolato.', ruoloEn: 'Cosmic simulation 3: the Sun as a tennis ball, 1 : 20.8 billion scale, the nearby stars and the computed emptiness.' },
  { file: 'bsi-cosmo-sole.js', ruolo: 'Simulazione cosmica 1: foglio di corrente eliosferico, magnetosfera di Dungey e Shue, ovale aurorale calcolato, tende aurorali.', ruoloEn: 'Cosmic simulation 1: heliospheric current sheet, Dungey and Shue magnetosphere, computed auroral oval, auroral curtains.' },
  { file: 'bsi-astro-spaccato-scenari.js', ruolo: 'Dati degli Spaccati stellari: stadi, composizioni, reazioni bilanciate, fonti (WHW02, Sackmann 1993, Nadyozhin 1994, Kasen 2017, PDG).', ruoloEn: 'Stellar cutaway data: stages, compositions, balanced reactions, sources (WHW02, Sackmann 1993, Nadyozhin 1994, Kasen 2017, PDG).' },
  { file: 'bsi-astro-spaccato-eventi.js', ruolo: 'Quattordici eventi cosmici in più per gli Spaccati stellari (nascita di una stella, nane brune e rosse, Cefeidi, novae, lampi X, pulsar e magnetar, distruzioni mareali, lampi gamma, instabilità di coppia, GW150914, quasar, cristallizzazione delle nane bianche, ricombinazione) con i numeri calcolati e le fonti.', ruoloEn: 'Fourteen more cosmic events for the stellar cutaways (star birth, brown and red dwarfs, Cepheids, novae, X-ray bursts, pulsars and magnetars, tidal disruptions, gamma-ray bursts, pair instability, GW150914, quasars, white-dwarf crystallisation, recombination) with computed numbers and sources.' },
  { file: 'bsi-chim-meccanismi3d.js', ruolo: 'Meccanismi 3D: otto reazioni organiche come film (atomi, legami parziali, frecce degli elettroni, cariche, profilo energetico vivo).', ruoloEn: '3D mechanisms: eight organic reactions as films (atoms, partial bonds, electron arrows, charges, live energy profile).' },
  { file: 'bsi-mat-animazioni.js', ruolo: 'Animazioni matematiche: Fourier, Riemann, Taylor, derivata, Eulero, Galton, Buffon, Fibonacci, e, con i numeri calcolati.', ruoloEn: 'Maths animations: Fourier, Riemann, Taylor, derivative, Euler, Galton, Buffon, Fibonacci, e, with computed numbers.' },
  { file: 'bsi-spectra-elevenlabs.js', ruolo: 'La voce di Spectra con ElevenLabs: coda, interruzione, testi lunghi a pezzi, cache, errori e ripiego; diretta o tramite il proxy (POST /voce).', ruoloEn: 'Spectra\'s voice with ElevenLabs: queue, interruption, long texts in chunks, cache, errors and fallback; direct or through the proxy (POST /voce).' },
  { file: 'bsi-bio-lab3d-dati.js', ruolo: 'Biochimica 3D Lab, i dati: sette vie passo per passo con i carboni seguiti, i 12 capitoli della dispensa d\'esame, Michaelis–Menten e inibitori, ossigrafo e rotore dell\'ATP sintasi.', ruoloEn: 'Biochemistry 3D Lab data: seven pathways step by step with tracked carbons, the 12 exam-notes chapters, Michaelis–Menten and inhibitors, oxygraph and ATP synthase rotor.' },
  { file: 'bsi-bio-lab3d.js', ruolo: 'Biochimica 3D Lab: ATP sintasi rotante con l\'ossigrafo, enzimi e cinetica, vie metaboliche in 3D con i carboni colorati, teoria d\'esame e quiz.', ruoloEn: 'Biochemistry 3D Lab: rotating ATP synthase with the oxygraph, enzymes and kinetics, 3D metabolic pathways with coloured carbons, exam theory and quiz.' },
  { file: 'bsi-risoluzione.js', ruolo: 'La risoluzione di tutte le animazioni: 4K supercampionata, nativa o risparmio, con il limite di 3840 px; aggiorna al volo i renderer three.js e le tele 2D; foto PNG in 4K.', ruoloEn: 'Resolution of every animation: supersampled 4K, native or saver, capped at 3840 px; updates three.js renderers and 2D canvases on the fly; 4K PNG photos.' },
  { file: 'bsi-quantum-studio-dati.js', ruolo: 'Quantum Studio, i dati e i modelli: 13 aree, 16 moduli, Morse, NMR, dose–risposta, PCA, Van Deemter, PES, Hodgkin–Huxley, Rabi, n-cubi, Calabi–Yau, Gibbs.', ruoloEn: 'Quantum Studio data and models: 13 areas, 16 modules, Morse, NMR, dose–response, PCA, Van Deemter, PES, Hodgkin–Huxley, Rabi, n-cubes, Calabi–Yau, Gibbs.' },
  { file: 'bsi-quantum-studio.js', ruolo: 'Quantum Studio, la base: stile, testi 3D, kit di disegno, registro dei motori.', ruoloEn: 'Quantum Studio base: style, 3D text, drawing kit, motor registry.' },
  { file: 'bsi-quantum-studio-motori.js', ruolo: 'Quantum Studio, i motori 1–7: ATP sintasi, enzimi, orbitali, SN2, NMR, recettore, PCA.', ruoloEn: 'Quantum Studio motors 1–7: ATP synthase, enzymes, orbitals, SN2, NMR, receptor, PCA.' },
  { file: 'bsi-quantum-studio-motori2.js', ruolo: 'Quantum Studio, i motori 8–16: CRISPR, paracetamolo, HPLC, PES, Hodgkin–Huxley, qubit, n-cubi, Calabi–Yau, Gibbs.', ruoloEn: 'Quantum Studio motors 8–16: CRISPR, paracetamol, HPLC, PES, Hodgkin–Huxley, qubit, n-cubes, Calabi–Yau, Gibbs.' },
  { file: 'bsi-quantum-studio-pagina.js', ruolo: 'Quantum Studio, la pagina: sezione squantum, palco 3D con grafico, cursori, teoria, ponte SPECTRA_3D_BRIDGE e strumento quantum_studio.', ruoloEn: 'Quantum Studio page: squantum section, 3D stage with chart, sliders, theory, SPECTRA_3D_BRIDGE bridge and quantum_studio tool.' },
  { file: 'bsi-spectra-voce-live.js', ruolo: 'Spectra Prime: assistente vocale full-duplex collegato al Quantum Studio (SPECTRA_3D_BRIDGE). AudioWorklet 16 kHz, riproduzione 24 kHz, VAD e barge-in, HUD olografico, tre strumenti vocali, riconnessione.', ruoloEn: 'Spectra Prime: full-duplex voice assistant wired to the Quantum Studio (SPECTRA_3D_BRIDGE). 16 kHz AudioWorklet, 24 kHz playback, VAD and barge-in, holographic HUD, three voice tools, reconnection.' },
  { file: 'bsi-inorganica-quantum-dati.js', ruolo: 'Inorganica quantistica, i solutori: regole di Slater, metodo di Hückel (determinante secolare, Jacobi), SALC con soglia energetica, complessi in tripla teoria VBT+CFT+LFT.', ruoloEn: 'Quantum inorganic chemistry solvers: Slater rules, Hückel method (secular determinant, Jacobi), SALC with an energy threshold, triple-theory VBT+CFT+LFT complexes.' },
  { file: 'bsi-inorganica-quantum.js', ruolo: 'Inorganica quantistica, la pagina 3D: quattro schede (Slater, Hückel, SALC, complessi) con modello 3D e report calcolato; strumento inorganica_quantica.', ruoloEn: 'Quantum inorganic chemistry 3D page: four tabs (Slater, Hückel, SALC, complexes) with 3D model and computed report; inorganica_quantica tool.' },
  { file: 'bsi-arrowlab.js', ruolo: 'Arrow Lab e Retrosintesi: lavagna SVG per le frecce curve dei meccanismi (propanone+NaBH₄, SN2) con verifica passo per passo, e pianificatore retrosintetico con percorsi, chimica verde e inventario; strumento arrow_lab. Offline.', ruoloEn: 'Arrow Lab & RetroSynth: SVG board for mechanism curved arrows (propanone+NaBH₄, SN2) with step-by-step checking, and a retrosynthesis planner with routes, green chemistry and inventory; arrow_lab tool. Offline.' },
  { file: 'bsi-astro-spaccato.js', ruolo: 'Motore degli Spaccati stellari: corpo tagliato a spicchio, strati a cipolla, ciambella della composizione, orologio, evento finale; strumento per Spectra.', ruoloEn: 'Stellar cutaway engine: wedge-cut body, onion layers, composition donut, clock, final event; Spectra tool.' },
  { file: 'bsi-cosmo-sezione.js', ruolo: 'La sezione «Simulazioni cosmiche» con le schede-anteprima.', ruoloEn: 'The «Cosmic simulations» section with preview cards.' },
  { file: 'bsi-costruttore.js', ruolo: 'Costruttore molecolare 3D e AR: atomi legati al tocco, valenze e cariche, VSEPR, campo di forze con raggi covalenti di Cordero, anelli aromatici, esportazione MOL/XYZ e realtà aumentata.',
    ruoloEn: '3D and AR molecule builder: atoms bonded by tapping, valences and charges, VSEPR, force field with Cordero covalent radii, aromatic rings, MOL/XYZ export and augmented reality.' },
  { file: 'bsi-fis-motore.js', ruolo: 'Il motore in spaccato: ciclo Otto ad aria standard con manovellismo, flussi proporzionali, bilancio e dettaglio p–V.',
    ruoloEn: 'The engine in cutaway: air-standard Otto cycle with slider-crank, proportional flows, balance and p–V detail.' },
  { file: 'bsi-fis-spaccati.js', ruolo: 'Gli spaccati tecnici di fisica: circuito a due maglie con Kirchhoff e deriva nel rame, laser Nd:YAG con bilancio di potenza e quattro livelli, giunzione p–n con il campo integrato da Poisson.',
    ruoloEn: 'The physics technical cutaways: two-loop circuit with Kirchhoff and drift in copper, Nd:YAG laser with power balance and four levels, p–n junction with the field integrated from Poisson.' },
  { file: 'bsi-teoria-a.js', ruolo: 'Dati della teoria per sezione: chimica, spettroscopia, farmacologia.',
    ruoloEn: 'Per-section theory data: chimica, spettroscopia, farmacologia.' },
  { file: 'bsi-teoria-b.js', ruolo: 'Dati della teoria per sezione: biochimica e chimica fisica.',
    ruoloEn: 'Per-section theory data: biochimica e chimica fisica.' },
  { file: 'bsi-teoria-c.js', ruolo: 'Dati della teoria per sezione: fisica.',
    ruoloEn: 'Per-section theory data: fisica.' },
  { file: 'bsi-teoria-d.js', ruolo: 'Dati della teoria per sezione: fisica moderna e astrofisica.',
    ruoloEn: 'Per-section theory data: fisica moderna e astrofisica.' },
  { file: 'bsi-teoria-e.js', ruolo: 'Dati della teoria per sezione: matematica.',
    ruoloEn: 'Per-section theory data: matematica.' },
  { file: 'bsi-teoria-f.js', ruolo: 'Dati della teoria per sezione: chimica fisica e analitica.',
    ruoloEn: 'Per-section theory data: chimica fisica e analitica.' },
  { file: 'bsi-teoria-g.js', ruolo: 'Dati della teoria per sezione: spaziotempo e wormhole.',
    ruoloEn: 'Per-section theory data: spaziotempo e wormhole.' },
  { file: 'bsi-teoria-h.js', ruolo: 'Dati della teoria per sezione: orbitali, eliosfera, materia oscura, fisiologia, farmacologia quantitativa, mappa dei prerequisiti.',
    ruoloEn: 'Per-section theory data: orbitals, heliosphere, dark matter, physiology, quantitative pharmacology, prerequisite map.' },
  { file: 'bsi-teoria.js', ruolo: 'Teoria di ogni sezione: pulsante, scheda di lettura, indice e ricerca, strumento leggi_teoria per Spectra.',
    ruoloEn: 'Theory of every section: button, reading sheet, index and search, leggi_teoria tool for Spectra.' },
  { file: 'bsi-chim-hammett.js', ruolo: 'Equazione di Hammett: costanti σ (Hansch, Leo, Taft 1991), cinque reazioni con ρ, previsioni di k/k₀ e pKa, ρ ricavato dai dati.',
    ruoloEn: 'Hammett equation: σ constants (Hansch, Leo, Taft 1991), five reactions with ρ, predictions of k/k₀ and pKa, ρ fitted to data.' },
  { file: 'bsi-fis-foucault.js', ruolo: 'Pendolo di Foucault (Runge–Kutta nel riferimento terrestre), precessione per latitudine, deviazione di Coriolis.',
    ruoloEn: 'Foucault pendulum (Runge–Kutta in the Earth frame), precession by latitude, Coriolis deflection.' },
  { file: 'bsi-mat-frenet.js', ruolo: 'Curve nello spazio: curvatura, torsione, triedro di Frenet, cerchio osculatore, lunghezza d\'arco; curve scritte dall\'utente.',
    ruoloEn: 'Space curves: curvature, torsion, Frenet frame, osculating circle, arc length; user-written curves.' },
  { file: 'bsi-astro-chimica.js', ruolo: 'Chimica di una nube interstellare (formazione e fotodissociazione di H₂ e CO) e equazione di Saha con le classi spettrali.',
    ruoloEn: 'Chemistry of an interstellar cloud (formation and photodissociation of H₂ and CO) and the Saha equation with the spectral classes.' },
  { file: 'bsi-chem-mappe.js', ruolo: 'Mappa dello spazio chimico (t-SNE esatto sulle distanze di Tanimoto) e deconvoluzione di picchi (Levenberg–Marquardt).',
    ruoloEn: 'Chemical space map (exact t-SNE on Tanimoto distances) and peak deconvolution (Levenberg–Marquardt).' },
  { file: 'bsi-fis-spin.js', ruolo: 'Spin, qubit ed entanglement: Stern-Gerlach, sfera di Bloch, CHSH, BB84.',
    ruoloEn: 'Spin, qubits and entanglement: Stern-Gerlach, Bloch sphere, CHSH, BB84.' },
  { file: 'bsi-fis-statistica.js', ruolo: 'Meccanica statistica: Schottky, Maxwell-Boltzmann, Fermi e Bose, Einstein e Debye.',
    ruoloEn: 'Statistical mechanics: Schottky, Maxwell-Boltzmann, Fermi and Bose, Einstein and Debye.' },
  { file: 'bsi-fis-nuclei.js', ruolo: 'Nuclei e reazioni: valle di stabilità, valori Q, tunnel, nucleo 3D, reattore.',
    ruoloEn: 'Nuclei and reactions: valley of stability, Q values, tunnelling, 3D nucleus, reactor.' },
  { file: 'bsi-fis-materiali.js', ruolo: 'Elasticità e materiali: trazione, travi, Eulero, suono nei solidi.',
    ruoloEn: 'Elasticity and materials: tension, beams, Euler, sound in solids.' },
  { file: 'bsi-fis-elettronica.js', ruolo: 'Elettronica: raddrizzatori, diodi e Zener, emettitore comune, operazionali, ADC e DAC.',
    ruoloEn: 'Electronics: rectifiers, diodes and Zener, common emitter, op-amps, ADC and DAC.' },
  { file: 'bsi-mat-edp.js', ruolo: 'Equazioni alle derivate parziali: corda, membrana, calore, Laplace, Burgers.',
    ruoloEn: 'Partial differential equations: string, membrane, heat, Laplace, Burgers.' },
  { file: 'bsi-mat-analisicomplessa.js', ruolo: 'Analisi complessa: colorazione del dominio, mappe conformi, Joukowski, residui.',
    ruoloEn: 'Complex analysis: domain colouring, conformal maps, Joukowski, residues.' },
  { file: 'bsi-mat-markov.js', ruolo: 'Catene di Markov e processi stocastici: PageRank, rovina del giocatore, passeggiate, code.',
    ruoloEn: 'Markov chains and stochastic processes: PageRank, gambler\'s ruin, walks, queues.' },
  { file: 'bsi-mat-svd.js', ruolo: 'SVD e algebra lineare applicata: SVD 2×2 e 3×3, compressione, PCA, minimi quadrati.',
    ruoloEn: 'SVD and applied linear algebra: 2×2 and 3×3 SVD, compression, PCA, least squares.' },
  { file: 'bsi-mat-codici.js', ruolo: 'Codici e curve ellittiche: Hamming, CRC, curve su ℝ e F_p, ECDH.',
    ruoloEn: 'Codes and elliptic curves: Hamming, CRC, curves over ℝ and F_p, ECDH.' },
  { file: 'bsi-spectra-live.js', ruolo: 'Spectra Live: console vocale, comandi locali, lettura dello schermo, nove strumenti dell\'agente.',
    ruoloEn: 'Spectra Live: voice console, local commands, screen reading, nine agent tools.' },
  { file: 'bsi-spectra-androide.js', ruolo: 'Volto di Spectra sul modello «Noir»: testa e bocca animate, 17 emozioni da 11 campi espressivi.',
    ruoloEn: 'Spectra\'s face on the «Noir» model: animated head and mouth, 17 emotions from 11 expressive fields.' },
  { file: 'bsi-spectra-mente.js', ruolo: 'Mente di Spectra: memoria locale, stato interno, pensieri (simulazione di comportamento).',
    ruoloEn: 'Spectra\'s mind: local memory, internal state, thoughts (a simulation of behaviour).' },
  { file: 'bsi-spectra-agenda.js', ruolo: 'Agenda di Spectra: promemoria, compiti, eventi, date dette a parole, continuità per il modello, memoria esportabile.',
    ruoloEn: 'Spectra\'s agenda: reminders, tasks, events, dates said in words, continuity for the model, exportable memory.' },
  { file: 'bsi-spectra-risveglio.js', ruolo: 'Risveglio di Spectra: sequenza di avvio, meteo (Open-Meteo), punto alle 8 e alle 20, batteria, rete neurale della memoria.',
    ruoloEn: 'Spectra\'s wake-up: start-up sequence, weather (Open-Meteo), briefing at 8 and 20, battery, neural network of the memory.' },
  { file: 'bsi-spectra-memoria.js', ruolo: 'Memoria di Spectra a cinque livelli (IndexedDB): recupero a sei segnali, consolidamento giornaliero, procedure, diario, strumento cerca_nella_memoria.',
    ruoloEn: 'Spectra\'s five-level memory (IndexedDB): six-signal retrieval, daily consolidation, procedures, diary, cerca_nella_memoria tool.' },
  { file: 'bsi-spectra-robot.js', ruolo: 'Volto di ripiego: testa di androide costruita in three.js.',
    ruoloEn: 'Fallback face: android head built in three.js.' },
  { file: 'bsi-spectra-volto.js', ruolo: 'Volto di ultimo ripiego: ritratto vettoriale SVG.',
    ruoloEn: 'Last-resort face: SVG vector portrait.' },
  { file: 'bsi-lezione.js', ruolo: 'Lezione guidata con Spectra per ogni sezione: capitoli dalle schede, comandi mostrati al lavoro, riflettore, verifica dal kit di studio.',
    ruoloEn: 'Guided lesson with Spectra for every section: chapters from the tabs, controls demonstrated, spotlight, check question from the study kit.' },
  { file: 'bsi-spectra-voce.js', ruolo: 'Voce di Spectra: audio TTS (con chiave OpenAI) in una catena Web Audio (bassi, metallo, stanza) e labiale dall\'audio; ripiego sulla sintesi del browser.',
    ruoloEn: 'Spectra\'s voice: TTS audio (with an OpenAI key) through a Web Audio chain (bass, metal, room) and lip-sync from the audio; falls back to browser synthesis.' },
  { file: 'bsi-spectra-corpo.js', ruolo: 'Driver del corpo di Spectra per qualunque avatar umanoide (ossa, blendshape ARKit, capelli neri, sguardo, gesti, passo, seduta) e manichino riggato di prova.',
    ruoloEn: 'Body driver for any humanoid avatar (bones, ARKit blendshapes, black hair, gaze, gestures, walking, sitting) and a rigged test mannequin.' },
  { file: 'bsi-spectra-olointerattivo.js', ruolo: 'Ologramma interattivo di Spectra: spettri IR/¹H/¹³C/massa/UV di molecole di riferimento o della traccia scritta, con attribuzione di ogni segnale; universo con dati NASA, Keplero e vis-viva; matematica e fisica con lo svolgimento dell\'assistente; ogni passaggio spiegato a voce e per iscritto.',
    ruoloEn: 'Spectra\'s interactive hologram: IR/¹H/¹³C/mass/UV spectra of reference molecules or of a written trace with each signal assigned; universe with NASA data, Kepler and vis-viva; maths and physics with the assistant\'s working; every step explained aloud and in writing.' },
  { file: 'bsi-spectra-esplora.js', ruolo: '«⚡ Esplora con Spectra»: una sezione per materia nello stile delle lezioni esplorabili, dieci capitoli dalle superiori al PhD avanzato con previsione, cursore che ricalcola, visione dal vivo nell\'ologramma e spiegazione completa.',
    ruoloEn: '«⚡ Explore with Spectra»: one section per subject in the style of explorable lessons, ten chapters from high school to advanced PhD with prediction, a recomputing slider, live view in the hologram and full explanation.' },
  { file: 'bsi-spectra-spiega.js', ruolo: '«🧠 Spiega»: la spiegazione completa ed esaustiva di chimica, fisica e matematica dalle superiori al PhD avanzato, anche di ciò che è sullo schermo (testo, valori, tabelle e immagine di spettri, grafici e scene 3D); senza modello mostra ciò che l\'app sa da sola.',
    ruoloEn: '«🧠 Explain»: the complete, exhaustive explanation of chemistry, physics and mathematics from high school to advanced PhD, including what is on screen (text, values, tables and an image of spectra, graphs and 3D scenes); without a model it shows what the app knows on its own.' },
  { file: 'bsi-spectra-figura.js', ruolo: 'Spectra col corpo in un modulo solo: il controllore del corpo (incorporato nell\'app e impacchettato, rig, viso «Noir» allineato) usato dallo studio e la figura nelle sezioni dell\'AI, che pensa, parla e gesticola con le risposte.',
    ruoloEn: 'Spectra with a body in one module: the body controller (embedded in the app and packed, rig, aligned «Noir» face) used by the studio, and the figure in the AI sections that thinks, speaks and gestures with the answers.' },
  { file: 'bsi-spectra-rig.js', ruolo: 'Rig automatico nel browser per le figure umanoidi senza scheletro: misura, scheletro con nomi Mixamo, pesi della pelle (distanza, normale, geodetica), testa tolta col cappuccio, ricolorazione in blu notte.',
    ruoloEn: 'In-browser auto-rig for humanoid figures without a skeleton: measuring, Mixamo-named skeleton, skin weights (distance, normal, geodesic), head removed keeping the hood, night-blue recolouring.' },
  { file: 'bsi-spectra-studio-lezioni.js', ruolo: 'Lezioni dello studio di Spectra (predici → testa → dimostra → rivela): caduta, forma dell\'acqua, problema di Basilea, con calcoli verificati.',
    ruoloEn: 'Spectra Studio lessons (predict → test → prove → reveal): the fall, the shape of water, the Basel problem, with verified computations.' },
  { file: 'bsi-spectra-creatore.js', ruolo: 'Spectra riconosce il suo creatore: prova con la frase segreta confrontata come impronta SHA-256 (deterrente, non controllo d\'accesso).',
    ruoloEn: 'Spectra recognises its creator: a secret-phrase check compared as a SHA-256 fingerprint (a deterrent, not access control).' },
  { file: 'bsi-aggiorna.js', ruolo: '«Controlla aggiornamenti»: versione in uso dal service worker, versione pubblicata da sw.js.',
    ruoloEn: '«Check for updates»: version in use from the service worker, published version from sw.js.' },
  { file: 'bsi-fis-fluidi.js', ruolo: 'Fluidi: Venturi e Bernoulli, viscosità e Stokes, capillarità.',
    ruoloEn: 'Fluids: Venturi and Bernoulli, viscosity and Stokes, capillarity.' },
  { file: 'bsi-mat-vettoriale.js', ruolo: 'Calcolo vettoriale: campi, Green, gradiente.',
    ruoloEn: 'Vector calculus: fields, Green, gradient.' },
  { file: 'bsi-chi-cinetica.js', ruolo: 'Cinetica complessa: reazioni composte, oscillanti, strutture di Turing.',
    ruoloEn: 'Complex kinetics: composite and oscillating reactions, Turing patterns.' },
  { file: 'bsi-fis-meccanica.js', ruolo: 'Meccanica in movimento: proiettile con l’aria, urti, pendolo vero, oscillatori accoppiati.',
    ruoloEn: 'Mechanics in motion: projectile with air, collisions, real pendulum, coupled oscillators.' },
  { file: 'bsi-fis-onde.js', ruolo: 'Onde e ottica: sovrapposizione, lenti e specchi, diffrazione.',
    ruoloEn: 'Waves and optics: superposition, lenses and mirrors, diffraction.' },
  { file: 'bsi-fis-circuiti.js', ruolo: 'Circuiti: transitori RLC, corrente alternata, filtri e Bode.',
    ruoloEn: 'Circuits: RLC transients, alternating current, filters and Bode.' },
  { file: 'bsi-fis-termo.js', ruolo: 'Termodinamica in movimento: cicli, gas di particelle, moto browniano.',
    ruoloEn: 'Thermodynamics in motion: cycles, particle gas, Brownian motion.' },
  { file: 'bsi-mat-numerici.js', ruolo: 'Metodi numerici: zeri, integrazione, EDO, interpolazione con gli ordini misurati.',
    ruoloEn: 'Numerical methods: roots, integration, ODEs, interpolation with measured orders.' },
  { file: 'bsi-mat-geometria.js', ruolo: 'Geometria analitica e vettori: vettori, rette e piani in 3D, coniche.',
    ruoloEn: 'Analytic geometry and vectors: vectors, lines and planes in 3D, conics.' },
  { file: 'bsi-chi-equilibrio.js', ruolo: 'Equilibrio chimico e Le Chatelier: simulatore cinetico e K(T).',
    ruoloEn: 'Chemical equilibrium and Le Chatelier: kinetic simulator and K(T).' },
  { file: 'bsi-lab3d.js', ruolo: 'Laboratorio 3D: superfici, orbitali |ψ|², moti nello spazio, strutture cristalline e piani di Miller, linee di campo (three.js).',
    ruoloEn: '3D Laboratory: surfaces, |ψ|² orbitals, motion in space, crystal structures and Miller planes, field lines (three.js).' },
  { file: 'bsi-vista-molecole.js', ruolo: 'Qualità e barra dei comandi per tutti i visori molecolari 3Dmol.',
    ruoloEn: 'Quality settings and control bar for every 3Dmol molecular viewer.' },
  { file: 'bsi-assistente.js', ruolo: 'Le tre macro-aree Chimica, Fisica e Matematica: assistente in linguaggio naturale con svolgimento e problema inverso, catalogo degli strumenti, livelli.',
    ruoloEn: 'The three macro-areas Chemistry, Physics and Mathematics: natural-language assistant with full working and inverse problem, tool catalogue, levels.' },
  { file: 'bsi-chi-esame.js', ruolo: 'Esame di chimica dalla base all’avanzatissimo: 40 modelli di problema, prove svolte.',
    ruoloEn: 'Chemistry exam from basic to expert: 40 problem models, solved papers.' },
  { file: 'bsi-fis-elettrodi.js', ruolo: 'Cinetica elettrodica (Butler-Volmer, Tafel) e teoria dello stato di transizione (Eyring).',
    ruoloEn: 'Electrode kinetics (Butler-Volmer, Tafel) and transition-state theory (Eyring).' },
  { file: 'bsi-fis-superfici.js', ruolo: 'Fotofisica (Jablonski, Stern-Volmer), isoterme di adsorbimento (Langmuir, Freundlich, BET), polimeri.',
    ruoloEn: 'Photophysics (Jablonski, Stern-Volmer), adsorption isotherms (Langmuir, Freundlich, BET), polymers.' },
  { file: 'bsi-mat-statistica.js', ruolo: 'Statistica di laboratorio: t, F, Grubbs, Dixon, propagazione delle incertezze, retta di taratura con LOD e LOQ.',
    ruoloEn: 'Laboratory statistics: t, F, Grubbs, Dixon, uncertainty propagation, calibration line with LOD and LOQ.' },
  { file: 'bsi-nmr2d.js',   ruolo: 'NMR bidimensionale: COSY, HSQC editato e HMBC, costruiti camminando il grafo sulle due predizioni per atomo.',
    ruoloEn: 'Two-dimensional NMR: COSY, edited HSQC and HMBC, built by walking the graph over the two per-atom predictions.' },
  { file: 'bsi-moldraw.js', ruolo: 'Spettro NMR interattivo: zoom, tabella di assegnazione, collegamento picco↔atomo, cronologia SMILES/InChI, uscite CSV/JCAMP-DX/PNG.',
    ruoloEn: 'Interactive NMR spectrum: zoom, assignment table, peak↔atom link, SMILES/InChI history, CSV/JCAMP-DX/PNG exports.' },
  { file: 'bsi-documento.js', ruolo: 'Apertura di qualunque documento — PDF, immagini, testo, Word, OpenDocument, PowerPoint, Excel — con l\'elenco esplicito di cio\' che NON si e\' potuto leggere.',
    ruoloEn: 'Opening of any document — PDF, images, text, Word, OpenDocument, PowerPoint, Excel — with an explicit list of what could NOT be read.' },
  { file: 'bsi-quesito.js', ruolo: 'Riconoscimento dei dati spettroscopici nel testo di un quesito, con la provenienza di ogni dato, e svolgimento passo per passo tramite bsi-elucida.js.',
    ruoloEn: 'Recognition of spectroscopic data in a problem\'s text, with each datum\'s provenance, and step-by-step working through bsi-elucida.js.' },
  { file: 'bsi-spettrolettore.js', ruolo: 'Lettore di spettri: JCAMP-DX con compressione ASDF, ricerca dei picchi per prominenza, assegnazione delle bande IR, perdite neutre, apertura di documenti.',
    ruoloEn: 'Spectrum reader: JCAMP-DX with ASDF compression, prominence-based peak finding, IR band assignment, neutral losses.' },
  { file: 'bsi-mol3d.js',   ruolo: 'Visore 3D delle molecole: animazione di formazione, selezione degli atomi, misura di angoli, lunghezze e diedri.',
    ruoloEn: '3D molecule viewer: formation animation, atom selection, measurement of angles, lengths and dihedrals.' },
  { file: 'bsi-lingue.js',  ruolo: 'Motore di internazionalizzazione: quattordici lingue, verso di scrittura compreso.',
    ruoloEn: 'Internationalisation engine: fourteen languages, writing direction included.' },
  { file: 'bsi-molingue.js', ruolo: 'Linguaggi chimici: venticinque uscite da SMILES, con nomenclatura IUPAC su una classe dichiarata.',
    ruoloEn: 'Chemical languages: twenty-five outputs from SMILES, with IUPAC naming over a declared class.' },
  { file: 'bsi-pannelli-lingua.js', ruolo: 'Pannelli delle lingue e dei linguaggi chimici.',
    ruoloEn: 'Panels for languages and chemical languages.' },
  { file: 'sw.js',          ruolo: 'Service Worker: funzionamento offline e strategia di rete.',
    ruoloEn: 'Service Worker: offline operation and network strategy.' },
  { file: 'rdkit_lab.html', ruolo: 'Laboratorio di chemioinformatica.', ruoloEn: 'Cheminformatics laboratory.' },
  { file: 'astro.html',     ruolo: 'Modulo di astrochimica.', ruoloEn: 'Astrochemistry module.' },
  { file: 'chimorga.html',  ruolo: 'Modulo di chimica organica.', ruoloEn: 'Organic chemistry module.' },
  { file: 'proxy/spectra-proxy.js', ruolo: 'Proxy opzionale (Cloudflare Worker) per le chiamate all\'AI.',
    ruoloEn: 'Optional proxy (Cloudflare Worker) for the AI calls.' }
];

function info(rel){
  const p = path.join(RADICE, rel);
  try {
    const b = fs.readFileSync(p);
    return { byte: b.length, sha: crypto.createHash('sha256').update(b).digest('hex') };
  } catch (e) { return { byte: 0, sha: null }; }
}

function kb(n){ return n ? (n / 1024).toFixed(0) + ' kB' : '—'; }

function main(){
  let commit = '(non disponibile)', versione = '(non letta)';
  try { commit = execSync('git rev-parse HEAD', { cwd: RADICE, encoding: 'utf8' }).trim(); } catch (e) {}
  try {
    const m = fs.readFileSync(path.join(RADICE, 'sw.js'), 'utf8').match(/CACHE\s*=\s*'([^']+)'/);
    if (m) versione = m[1];
  } catch (e) {}
  const istante = new Date().toISOString();

  // dipendenze di sviluppo, dal lockfile reale
  let dev = [];
  try {
    const lock = JSON.parse(fs.readFileSync(path.join(RADICE, 'package-lock.json'), 'utf8'));
    Object.keys(lock.packages || {}).forEach(function(k){
      if (!k.startsWith('node_modules/')) return;
      dev.push({ nome: k.replace('node_modules/', ''), versione: lock.packages[k].version,
                 licenza: lock.packages[k].license || '(non dichiarata)' });
    });
  } catch (e) {}

  /* ── Markdown, in due lingue ──────────────────────────────────────────
     La versione inglese non e' una cortesia: e' cio' che un revisore non
     italofono legge in sede di due diligence, ed era l'unico documento
     della serie 00-05 a non esistere affatto. Generarla dalla STESSA
     sorgente e' l'unico modo perche' non diverga: le impronte, le
     dimensioni e le licenze sono calcolate una volta sola. */
  const T = {
    it: {
      titolo: 'Distinta dei componenti software (SBOM)',
      sotto: '**BioSpecInfo** · documento generato da `tools/genera-sbom.js`.',
      rVersione: 'Versione applicazione', rCommit: 'Commit', rGenerato: 'Generato (UTC)',
      rMacchina: 'Formato macchina',
      nota: ['> Le impronte SHA-256 si riferiscono ai file effettivamente distribuiti in',
             '> questo commit. Un revisore può ricalcolarle con `sha256sum <file>` e',
             '> confrontarle, verificando di avere sotto mano lo stesso artefatto descritto.'],
      h1: '1. Componenti di terze parti distribuiti con l\'applicazione',
      p1: ['Tutti i componenti sono **inclusi nel repository** e serviti dallo stesso',
           'dominio: l\'applicazione non carica codice da CDN esterne in fase di',
           'esecuzione. È la condizione che le rende utilizzabile offline e che elimina',
           'la dipendenza dalla disponibilità di terzi.'],
      cCompo: 'Componente', cVersFile: 'Versione/File', cLic: 'Licenza', cDim: 'Dimensione',
      cRuolo: 'Ruolo', cFile: 'File', hImpronte: 'Impronte', assente: 'file assente',
      h2: '2. Codice proprio del progetto',
      h3: '3. Dipendenze di sviluppo',
      p3: ['Usate **solo** per l\'esecuzione dei banchi di prova. Non vengono distribuite',
           'con l\'applicazione e non sono presenti in produzione.'],
      cPacch: 'Pacchetto', cVers: 'Versione', nessunaDev: '_Nessuna dipendenza di sviluppo rilevata nel lockfile._',
      h4: '4. Dipendenze di esecuzione',
      p4: ['**Nessuna.** L\'applicazione non ha backend, non installa pacchetti a runtime e',
           'non carica script da domini esterni. Le uniche chiamate di rete sono opzionali',
           'e dirette a servizi pubblici documentati:'],
      cServ: 'Servizio', cScopo: 'Scopo', cKo: 'Se non raggiungibile',
      servizi: [['PubChem PUG-REST', 'nome IUPAC, CAS, pittogrammi GHS, conformeri 3D', 'l\'app usa i dati locali e lo dichiara'],
                ['NASA / ESA', 'immagini e dati astronomici', 'il modulo mostra i dati tabulati'],
                ['Open-Meteo (dalla v251)', 'il meteo di Spectra: riceve solo il nome della città chiesta e le sue coordinate, senza chiave', 'Spectra dice che il servizio non risponde e non inventa'],
                ['Fornitori AI (a scelta dell\'utente)', 'risposte dell\'assistente', 'l\'assistente lo segnala e propone alternative']],
      p4b: ['Nessun dato personale viene trasmesso: le chiavi API, se inserite, restano nel',
            '`localStorage` del dispositivo, oppure sul proxy dell\'utente (vedi `proxy/`).'],
      h5: '5. Compatibilità delle licenze',
      p5: ['Tutte le licenze dei componenti distribuiti (MIT, BSD-3-Clause, CC0, CC BY 4.0,',
           'Public Domain) sono **permissive** e reciprocamente compatibili. Nessun componente è',
           'soggetto a licenza copyleft forte (GPL/AGPL): non esistono vincoli di',
           'ridistribuzione del codice proprio del progetto.', '',
           'Gli obblighi residui sono di **attribuzione**: le note di licenza dei progetti a',
           'monte sono riportate in `THIRD_PARTY_NOTICES.md`.'],
      avviso: ['> **La licenza dell\'applicazione è distinta da quelle dei componenti.**',
               '> Il codice proprio di BioSpecInfo è **proprietario** — *All rights reserved*',
               '> (vedi [`LICENSE`](' + '../LICENSE' + ')): visibile e valutabile, ma copia, riuso e uso',
               '> commerciale richiedono autorizzazione scritta dell\'Autore. Le licenze',
               '> permissive elencate sopra riguardano **soltanto** le librerie di terze parti',
               '> incluse, e non si estendono all\'applicazione.'],
      firma: function(t){ return '_Generato il ' + t + '._'; },
      ruolo: function(c){ return c.ruolo; },
      cdx: 'evidence/sbom.cdx.json',
      licenza: '../LICENSE'
    },
    en: {
      titolo: 'Software Bill of Materials (SBOM)',
      sotto: '**BioSpecInfo** · document generated by `tools/genera-sbom.js`.',
      rVersione: 'Application version', rCommit: 'Commit', rGenerato: 'Generated (UTC)',
      rMacchina: 'Machine-readable format',
      nota: ['> The SHA-256 digests refer to the files actually distributed in this',
             '> commit. A reviewer can recompute them with `sha256sum <file>` and compare,',
             '> confirming they hold the very artefact described here.'],
      h1: '1. Third-party components distributed with the application',
      p1: ['Every component is **included in the repository** and served from the same',
           'origin: the application loads no code from external CDNs at runtime. That is',
           'what makes it usable offline and what removes any dependence on third-party',
           'availability.'],
      cCompo: 'Component', cVersFile: 'Version/File', cLic: 'Licence', cDim: 'Size',
      cRuolo: 'Role', cFile: 'File', hImpronte: 'Digests', assente: 'file missing',
      h2: '2. Code written for this project',
      h3: '3. Development dependencies',
      p3: ['Used **only** to run the verification benches. They are not distributed with',
           'the application and are not present in production.'],
      cPacch: 'Package', cVers: 'Version', nessunaDev: '_No development dependency found in the lockfile._',
      h4: '4. Runtime dependencies',
      p4: ['**None.** The application has no backend, installs no package at runtime and',
           'loads no script from external domains. The only network calls are optional and',
           'go to documented public services:'],
      cServ: 'Service', cScopo: 'Purpose', cKo: 'If unreachable',
      servizi: [['PubChem PUG-REST', 'IUPAC name, CAS, GHS pictograms, 3D conformers', 'the app uses local data and says so'],
                ['NASA / ESA', 'astronomical images and data', 'the module shows the tabulated data'],
                ['Open-Meteo (since v251)', 'Spectra\'s weather: it receives only the name of the city asked for and its coordinates, no key', 'Spectra says the service is not answering and invents nothing'],
                ['AI providers (user\'s choice)', 'assistant answers', 'the assistant reports it and offers alternatives']],
      p4b: ['No personal data is transmitted: API keys, if entered, stay in the device\'s',
            '`localStorage`, or on the user\'s own proxy (see `proxy/`).'],
      h5: '5. Licence compatibility',
      p5: ['All licences of the distributed components (MIT, BSD-3-Clause, CC0, CC BY 4.0,',
           'Public Domain) are **permissive** and mutually compatible. No component is subject to',
           'a strong copyleft licence (GPL/AGPL): there is no redistribution constraint on',
           'the code written for this project.', '',
           'The remaining obligations are of **attribution**: the licence notices of the',
           'upstream projects are reproduced in `THIRD_PARTY_NOTICES.md`.'],
      avviso: ['> **The application\'s licence is distinct from those of its components.**',
               '> The code written for BioSpecInfo is **proprietary** — *All rights reserved*',
               '> (see [`LICENSE`](../../LICENSE)): readable and open to assessment, but copying,',
               '> reuse and commercial use require the Author\'s written permission. The',
               '> permissive licences listed above cover **only** the bundled third-party',
               '> libraries, and do not extend to the application.'],
      firma: function(t){ return '_Generated on ' + t + '._'; },
      ruolo: function(c){ return c.ruoloEn || c.ruolo; },
      cdx: '../evidence/sbom.cdx.json',
      licenza: '../../LICENSE'
    }
  };

  function markdown(L){
    let m = '';
    m += '# ' + L.titolo + '\n\n';
    m += L.sotto + '\n\n';
    m += '| | |\n|---|---|\n';
    m += '| ' + L.rVersione + ' | `' + versione + '` |\n';
    m += '| ' + L.rCommit + ' | `' + commit + '` |\n';
    m += '| ' + L.rGenerato + ' | `' + istante + '` |\n';
    m += '| ' + L.rMacchina + ' | [`' + L.cdx + '`](' + L.cdx + ') — CycloneDX 1.5 |\n\n';
    m += L.nota.join('\n') + '\n\n';

    m += '---\n\n## ' + L.h1 + '\n\n';
    m += L.p1.join('\n') + '\n\n';
    m += '| ' + L.cCompo + ' | ' + L.cVersFile + ' | ' + L.cLic + ' | ' + L.cDim + ' | ' + L.cRuolo + ' |\n';
    m += '|---|---|---|---:|---|\n';
    COMPONENTI.forEach(function(c){
      const i = info(c.file);
      m += '| **' + c.nome + '**<br><sub>' + c.fornitore + '</sub> | `' + c.file + '` | ' +
           c.licenza + ' | ' + kb(i.byte) + ' | ' + L.ruolo(c) + ' |\n';
    });

    m += '\n### ' + L.hImpronte + '\n\n| ' + L.cFile + ' | SHA-256 |\n|---|---|\n';
    COMPONENTI.forEach(function(c){
      const i = info(c.file);
      m += '| `' + c.file + '` | `' + (i.sha || L.assente) + '` |\n';
    });

    m += '\n---\n\n## ' + L.h2 + '\n\n';
    m += '| ' + L.cFile + ' | ' + L.cDim + ' | ' + L.cRuolo + ' |\n|---|---:|---|\n';
    PROPRI.forEach(function(c){
      const i = info(c.file);
      m += '| `' + c.file + '` | ' + kb(i.byte) + ' | ' + L.ruolo(c) + ' |\n';
    });
    m += '\n### ' + L.hImpronte + '\n\n| ' + L.cFile + ' | SHA-256 |\n|---|---|\n';
    PROPRI.forEach(function(c){
      const i = info(c.file);
      m += '| `' + c.file + '` | `' + (i.sha || L.assente) + '` |\n';
    });

    m += '\n---\n\n## ' + L.h3 + '\n\n';
    if (dev.length){
      m += L.p3.join('\n') + '\n\n';
      m += '| ' + L.cPacch + ' | ' + L.cVers + ' | ' + L.cLic + ' |\n|---|---|---|\n';
      dev.forEach(function(d){ m += '| `' + d.nome + '` | ' + d.versione + ' | ' + d.licenza + ' |\n'; });
    } else {
      m += L.nessunaDev + '\n';
    }

    m += '\n---\n\n## ' + L.h4 + '\n\n';
    m += L.p4.join('\n') + '\n\n';
    m += '| ' + L.cServ + ' | ' + L.cScopo + ' | ' + L.cKo + ' |\n|---|---|---|\n';
    L.servizi.forEach(function(r){ m += '| ' + r[0] + ' | ' + r[1] + ' | ' + r[2] + ' |\n'; });
    m += '\n' + L.p4b.join('\n') + '\n\n';

    m += '---\n\n## ' + L.h5 + '\n\n';
    m += L.p5.join('\n') + '\n\n';
    m += L.avviso.join('\n') + '\n\n';
    m += L.firma(istante) + '\n';
    return m;
  }

  fs.writeFileSync(path.join(RADICE, 'docs', '07-SBOM.md'), markdown(T.it));
  fs.mkdirSync(path.join(RADICE, 'docs', 'en'), { recursive: true });
  fs.writeFileSync(path.join(RADICE, 'docs', 'en', '07-SBOM.md'), markdown(T.en));

  /* ── CycloneDX ── */
  const cdx = {
    bomFormat: 'CycloneDX', specVersion: '1.5', version: 1,
    metadata: {
      timestamp: istante,
      /* La licenza dell'APPLICAZIONE e' proprietaria (vedi LICENSE): non va
         confusa con quelle permissive dei componenti di terze parti. Una
         prima stesura di questo generatore dichiarava MIT anche per
         l'applicazione — un errore che in una SBOM consegnata a un cliente
         avrebbe comunicato diritti d'uso che non esistono. */
      component: { type: 'application', name: 'BioSpecInfo', version: versione,
                   description: 'Piattaforma di chemioinformatica interattiva client-side',
                   licenses: [{ license: { name: 'Proprietary — All rights reserved (Samuele Pio Provenzano)' } }] },
      properties: [{ name: 'git.commit', value: commit }]
    },
    components: COMPONENTI.map(function(c){
      const i = info(c.file);
      const v = { type: 'library', name: c.nome, publisher: c.fornitore,
                  description: c.ruolo, externalReferences: [{ type: 'website', url: c.url }],
                  licenses: [{ license: /Public Domain/.test(c.licenza) ? { name: c.licenza } : { id: c.licenza } }] };
      if (i.sha) v.hashes = [{ alg: 'SHA-256', content: i.sha }];
      return v;
    }).concat(dev.map(function(d){
      return { type: 'library', name: d.nome, version: d.versione, scope: 'excluded',
               description: 'Dipendenza di sviluppo: esecuzione dei banchi di prova.',
               licenses: [{ license: { id: d.licenza } }] };
    }))
  };
  fs.mkdirSync(path.join(RADICE, 'docs', 'evidence'), { recursive: true });
  fs.writeFileSync(path.join(RADICE, 'docs', 'evidence', 'sbom.cdx.json'),
                   JSON.stringify(cdx, null, 2));

  console.log('→ docs/07-SBOM.md');
  console.log('→ docs/en/07-SBOM.md');
  console.log('→ docs/evidence/sbom.cdx.json  (' + cdx.components.length + ' componenti)');
}

main();
