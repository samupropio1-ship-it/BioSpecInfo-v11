# Changelog — BioSpecInfo

Tutte le modifiche rilevanti di questo progetto.

Il formato segue [Keep a Changelog](https://keepachangelog.com/it/1.1.0/).
La versione dell'applicazione coincide con la versione della cache del Service
Worker (`bsi-vNNN`) ed è visibile nell'app: menu ✨ → **Aggiornamenti**.

---
## [bsi-v261] — 2026-11-18

**Tutti gli eventi cosmici: ventitré spaccati con il grafico vivo nel palco; la voce di Spectra non è più muta; il nucleo più vivo; il diagramma H-R spiegato**

### Aggiunto
- **Quattordici eventi cosmici in più** negli Spaccati stellari (`bsi-astro-spaccato-eventi.js`), raggruppati in
  «Nascere e vivere», «Morti stellari», «Oggetti compatti e buchi neri», «Pianeti», «L'universo»:
  nasce una stella (caduta libera ~309 mila anni, getti e disco, Kelvin–Helmholtz ~31 milioni di anni), nana bruna (classi
  M, L, T, Y; CO → CH₄), nana rossa (migliaia di miliardi di anni, brillamenti), Cefeide (meccanismo κ, legge di Leavitt:
  δ Cephei a ~294 pc), nova (CNO caldo, ⁷Be → ⁷Li), lampo X (processo rp fino a Sn, Sb, Te), pulsar e magnetar (crosta,
  neutroni liberi, nucleo superfluido; il Granchio: B ≈ 3,8·10¹² G, età ≈ 1270 anni; fasci e linee di campo), una stella
  fatta a pezzi da un buco nero (raggio di marea 24 R_S, ricaduta ∝ t^−5/3), lampo gamma (Wolf–Rayet, getti a Γ ~ 300),
  supernova a instabilità di coppia, GW150914 (chirp calcolato, 3 M☉c² in onde gravitazionali), quasar (crescita al limite
  di Eddington, tempo di Salpeter ~50 milioni di anni), nana bianca che cristallizza (Gaia), ricombinazione e reionizzazione
  (Saha: metà neutro a ~3730 K). Ogni scenario con la spiegazione, le fonti e i numeri calcolati nell'HUD.
- **Il grafico vivo dentro il palco** (come nei reel che l'autore ha mandato): legenda in alto, curve che brillano, il punto
  che segue la simulazione mentre scorre. Diagramma H-R con il percorso della stella (Sole, supernova, nane, nova…),
  energia di legame per nucleone con il nucleo che la stella sta facendo, curve di luce, onda gravitazionale, P–Ṗ delle
  pulsar vere, ricaduta della marea, crescita del quasar, Saha, temperatura delle nane brune, lampo X; sotto, una riga che
  dice che cosa si sta guardando.
- **Più realismo**: guscio dell'esplosione come volume di gas (rumore frattale e filamenti, attraversato a passi che calano
  da soli se il telefono rallenta), macchie e facole sulle stelle, corona e protuberanze sul bordo, cielo con la Via Lattea,
  dischi di accrescimento con temperatura ∝ r^−3/4 e rotazione kepleriana, getti con i nodi, linee di campo e fasci della
  pulsar, filamento della marea, coppia di buchi neri con l'ombra e l'anello di luce.
- **Il nucleo di Spectra**: la nuvola elettronica a particelle morbide che sfarfallano; onde di luce che partono dal nucleo
  mentre parla (con l'energia della voce vera quando c'è); ai cambi di stato un fotone del colore della serie di Balmer;
  i tubi di flusso fra i nucleoni con la carica di colore che si scambia; il nucleo si inclina appena verso il dito.
- Banco **`test_voce_microfono`** (20 controlli); `test_spaccato` arriva a 113 controlli.

### Corretto
- **«Sento il bip della campanella per Spectra ma non la voce»**: su Android ogni avvio del riconoscimento vocale suona il
  bip del sistema e, finché resta acceso, la sintesi vocale non esce. La sentinella («Spectra…» sempre in ascolto) restava
  accesa mentre Spectra parlava. Ora console, chat e voce di qualità liberano il microfono prima di parlare, aspettano che
  Android lo rilasci, e la sentinella riparte quando la voce è finita. Il ripiego della voce di qualità dice il testo frase
  per frase e non annulla a vuoto (su Android faceva cadere la frase dopo).
- **«Clicco e si blocca tutto»**: la figura di Spectra disegnava 125 oggetti a ogni fotogramma, a 60 fps, anche quando la
  chat o un'altra finestra la copriva. Ora non disegna quando è coperta, a riposo va a 30 fps e, se il telefono fatica
  (fotogrammi oltre 26 ms in media), abbassa da sola la risoluzione fino a 1 pixel per punto.
- **«È sparito il pulsante per il ding della voce»**: «🔔 Prova voce» (un bip e una frase) è ora sempre nella chat, accanto a
  «Leggi automaticamente», e nella console di Spectra Live (🔔), oltre che nell'ologramma interattivo.
- **Il diagramma H-R** («non so cosa sia»): ora dice che cosa mostra, le etichette non si sovrappongono più (posti
  liberi attorno al punto, linee guida, raggi scritti lungo le rette), e si tocca una stella per leggerne i dati.

### Da verificare sul telefono
- La voce con la sentinella accesa: dire «Spectra, che ore sono?» e sentire la risposta; il bip del sistema resta (è di
  Android, ogni volta che il microfono si riaccende).
- Fluidità dell'esplosione col volume di gas; leggibilità del grafico vivo sotto i pulsanti flottanti; parallasse del nucleo.

---
## [bsi-v260] — 2026-11-18

**Spaccati stellari: un motore che taglia una stella a spicchio mentre la composizione cambia; le simulazioni cosmiche 1 e 3**

### Aggiunto
- **🌟 Spaccati stellari** (`bsi-astro-spaccato.js`, sezione `sastrospaccato` nel gruppo Astrofisica): un motore
  riutilizzabile, `BSISpaccato.crea(contenitore, scenario)`, con gli scenari descritti come dati
  (`bsi-astro-spaccato-scenari.js`). Il corpo è tagliato a spicchio (superficie granulata, pareti con gli strati a cipolla
  che compaiono man mano, bordi luminosi), il nucleo è una cavità con i nuclei che si agitano e le etichette stile tavola
  periodica dei nuclei appena formati; sotto, la ciambella SVG della composizione con la legenda (percentuali che sommano
  esattamente 100), l'orologio del tempo trascorso con il separatore italiano e la durata dello stadio; le reazioni in
  monospazio; un evento finale. Comandi: ▶/⏸, ↺, barra del tempo trascinabile, velocità, massa iniziale, strati a cipolla
  sì/no, 🎬 cinematico, formato 9:16 o 16:9. Tutto è funzione del tempo: trascinare la barra rimette la scena esattamente.
- **Nove scenari**, con le fonti in `FONTI`:
  1. **Supernova a collasso del nucleo** (20 M☉, cursore 10–40): H → He → C → Ne → O → Si → Fe con le durate di Woosley,
     Heger e Weaver 2002 (tab. 1, 15 e 25 M☉, interpolate in log M), T e ρ del nucleo, reazioni bilanciate (tre-alfa,
     ¹²C + ¹²C, fotodisintegrazione del neon, ¹⁶O + ¹⁶O, silicio in quasi-equilibrio fino a ⁵⁶Ni); collasso con le linee
     tratteggiate radiali, neutronizzazione p + e⁻ → n + νₑ, M_Ch = 5,83 Y_e² M☉, ~99 % dell'energia in neutrini; lampo,
     guscio turbolento che si svuota al centro e si raffredda dall'arancio al rosso, con Ni, Co, Fe, Si, O, Sr che compaiono;
     resta la stella di neutroni. Il grafico B/A contro A (AME2020, tocco per leggere i valori) spiega perché il ferro è il
     capolinea.
  2. **Il Sole** (Sackmann, Boothroyd e Kraemer 1993): catena pp fino a oggi, fine dell'idrogeno, gigante rossa fino al
     flash, ramo orizzontale, ramo asintotico con il processo s, nebulosa planetaria ad anello e nana bianca di 0,54 M☉.
  3. **Stella massiccia → buco nero** (40 M☉; sopra 25 M☉, soglia incerta dichiarata): ombra con l'anello di luce e il
     collegamento alla sezione dei buchi neri.
  4. **Supernova Ia**: accrescimento dalla compagna (con il flusso e il disco), «simmering», esplosione senza residuo; la
     composizione dopo l'esplosione è CALCOLATA con le equazioni di Bateman per ⁵⁶Ni → ⁵⁶Co → ⁵⁶Fe e la curva di luce di
     Nadyozhin 1994 (picco ~1,2·10⁴³ erg/s, coda di 77 giorni).
  5. **Kilonova** (GW170817): ultimi 100 s di spirale con le onde gravitazionali, fusione, processo r (lantanidi, platino,
     oro), kilonova blu e rossa (masse di Kasen et al. 2017), riscaldamento ∝ t^−1,3; collegamento alle onde gravitazionali.
  6. **Nucleosintesi del Big Bang**: congelamento di n/p a kT = 0,75 MeV, decadimento con τ_n = 878,4 s, Y = 2X_n = 0,241
     contro 0,245 misurato; D/H, ³He/H e il problema del litio dichiarati.
  7. **La Terra si separa in strati**: calore di ²⁶Al e ⁶⁰Fe calcolato (W/kg), oceano di magma, pioggia di ferro, nucleo in
     ~30 milioni di anni (Hf–W), composizione di McDonough 2003.
  8. **Giove**: H₂ molecolare, idrogeno metallico, nucleo diluito (Juno), pioggia di elio (Y = 0,234 di Galileo).
  9. **Arricchimento galattico**: modello a scatola chiusa con la metallicità del Sole ritrovata (Z ≈ 0,0134) e il
     «problema delle nane G» dichiarato.
- **🎞️ 1 · «Il Sole respira. La Terra si illumina.»** (`bsi-cosmo-sole.js`): il foglio di corrente eliosferico a gonna di
  ballerina, λ = arcsin(sin α sin(φ + Ωr/v)), con la spirale di Parker e i pianeti; il vento solare che investe la
  magnetosfera di Dungey e Shue; l'ovale aurorale calcolato visto dal polo; le tende aurorali sopra le montagne (shader
  illustrativo, dichiarato).
- **🎞️ 3 · La scala** (`bsi-cosmo-scala.js`): il Sole che si rimpicciolisce fino a una pallina da tennis (1 : 20,8
  miliardi), la Terra granello di 0,61 mm a 7,1 m, Nettuno a 215 m, Proxima a 1933 km sul globo centrato su Roma, e il vuoto
  calcolato dai raggi delle stelle entro 12 anni luce.
- La scheda **«Una stella muore: lo spaccato»** nelle Simulazioni cosmiche.
- **Strumento per Spectra** `spaccato_stellare`: «mostrami come muore una stella» apre lo scenario; si usa solo quando
  l'utente lo chiede, mai da solo. Il ponte 3D riconosce `spaccato_stellare` e `supernova`.
- Banco **`test_spaccato`** (68 controlli) e `test_cosmo` esteso (44).

### Corretto
- In «Esplora» la scena dell'ologramma scelta dal capitolo veniva sostituita da quella dedotta dalle parole di Spectra
  (v259): una scena fissata ora resta, e torna libera cambiando sezione (`test_spectra_esplora`).
- `test_potenzia252` allineato all'icona a particella: ferma a riposo, orbite che girano solo mentre Spectra parla.
- La v259 non ha avuto una consegna a sé: la sua batteria ha trovato questi tre difetti (109 superati, 3 falliti),
  corretti qui; la v260 li comprende.
- L'icona a particella di Spectra (v259) usava id di gradiente fissi: con più icone nella pagina si duplicavano
  (`test_lingue`). Ora ogni icona ha i suoi.

### Da verificare sul telefono
- Fluidità (fotogrammi al secondo) durante l'esplosione con 16 000 punti e il bagliore; luminosità del lampo (non deve
  abbagliare); leggibilità della ciambella e della legenda sotto i pulsanti flottanti; trascinamento della barra del tempo
  col dito; «riduci movimento» del sistema (niente partenza automatica, niente agitazione); rotazione dello schermo
  (9:16 ↔ 16:9); cursore della massa che passa da stella di neutroni a buco nero.

---
## [bsi-v259] — 2026-11-18

**Spectra non è più un robot: un nucleo olografico a forma di particella; nessuna apertura senza un gesto dell'utente**

### Cambiato
- **Spectra è un nucleo olografico** (`bsi-spectra-nucleo.js`, tutto procedurale, nessun file da scaricare) al posto della
  figura umanoide, nelle sezioni dell'AI, nella console dal vivo, nell'ologramma interattivo e nello studio delle lezioni.
  Il cuore è una particella: 24 nucleoni (protoni teal, neutroni blu) impacchettati, che vibrano appena, con tubi di flusso
  tenui; la nuvola elettronica di 6000 punti campionata da |ψ|² degli orbitali dell'idrogeno, che passa da 1s (in linea) a
  2p (pensa), 2s (parla, pulsa con la voce) e 3d (cerca); tre elettroni su orbite ellittiche con la scia. Attorno: guscio a
  celle esagonali (duale dell'icosfera) con fresnel dal teal al blu, tessere che si accendono quando pensa (al massimo 6),
  anelli HUD con tacche, cursori e micro-etichette, satelliti che in «cerca» escono su fili sottili.
- **HUD in DOM**: didascalia parola per parola (troncata a due righe, testo intero per i lettori di schermo), stato sotto la
  sfera in italiano o inglese, schede di dati reali (la sezione aperta e i suoi controlli), striscione d'avviso in ambra.
- **Stessa API** del controllore del corpo (`carica`, `fai`, `stato`, `dici`, `taci`, `emozione`, `dispose`, `cambiato`,
  `corpo.cammina`, `corpo.audio`): figura, console, ologramma interattivo e studio funzionano senza riscritture.
- **Luci e movimento**: niente laboratorio né luci dirette, al massimo 2 pixel per punto, esposizione 0,85, nessun elemento
  additivo sopra luminanza × opacità 0,8, mai bianco puro; transizioni easeInOutSine di 0,75 s; l'ologramma compare con
  dissolvenza (non più «pop»); «riduci movimento» ferma anelli e orbite.
- **L'icona di Spectra** sui pulsanti è la particella (ferma a riposo, le orbite girano solo mentre parla); niente più testa di
  robot che gira all'infinito né ritratto dell'androide.

### Tolto (aperture automatiche)
- Il risveglio, l'ascolto e la finestra delle novità non si aprono più da soli all'avvio: compaiono un invito da toccare e un
  pallino sul pulsante di Spectra. L'ologramma interattivo non parla da solo («Spiega a voce automaticamente», spento di base
  e ricordato). L'ologramma non cambia più scena ogni 14 s. Il menu ✨ non si apre più con clic finti (API `bsi14`); la
  navigazione usa `goSection`. Il pulsante di Spectra non pulsa più all'infinito. Il controllo della figura ogni 800 ms e
  l'ascolto di ogni clic diventano un MutationObserver.
- Il volto androide, il robot e il volto vettoriale non si caricano più (gli script restano nel repository, commentati);
  la cache non li scarica più.

### Verificato
- `test_spectra_nucleo` 41 controlli (nuovo); aggiornati `test_spectra_figura` 113, `test_spectra_olo` 69, `test_risveglio`
  110, `test_spectra_studio` 79, `test_spectra238` 66 e `test_v237` (il volto androide provato come componente a sé).
  La batteria sale a 112 banchi.

### Da verificare a mano
- Sul telefono: fluidità (≥ 55 fotogrammi al secondo), luminosità, transizioni fra gli stati, sincronia della didascalia con la
  voce vera. L'arco del microfono in ascolto è simulato: il riconoscimento vocale del browser non dà il flusso audio.

---
## [bsi-v258] — 2026-11-18

**Spectra Prime a sette agenti con il ponte 3D, la rete neurale come un cervello, le scene fisiche 3D, sette simulazioni cosmiche**

### Aggiunto
- **Spectra Prime** (`spectra_core/`, FastAPI + LangGraph): l'orchestratore a sette agenti (memoria, ragionamento,
  piano, esecuzione, critica, corpo, identità) con il WebSocket `/ws/spectra/{sessione}`; memoria su SQLite a tre
  tipi più lo stato interno, strumenti con quattro livelli di permesso (high e critical bloccati fino a CONFIRM),
  argomenti controllati contro lo schema, origini autorizzate, modelli scelti da variabili d'ambiente. 10 test Python
  con modelli finti. Spectra non dichiara di essere viva, cosciente o senziente.
- **Il ponte nel browser** (`bsi-spectra-ponte.js`): la telemetria della scena 3D aperta (solo quando cambia) e i
  comandi load, update, toggle_layer, focus sulle scene esistenti (`BSIMotore3D`); solo wss://, quattro azioni,
  valori controllati, ricollegamento con attese crescenti; il riquadro «Spectra Prime» nella guida dei dispositivi.
- **La rete neurale come un cervello** (`bsi-spectra-cervello.js`): undici regioni con i ricordi veri e le loro quote,
  sinapsi che passano dall'associazione con gli impulsi, quadro con neuroni, sinapsi, turni, memoria, stadio e le
  cinque barre dello stato interno, «LIVE» quando Spectra ascolta; i puntini decorativi dichiarati come tali.
- **🎬 Scene fisiche 3D** (`bsi-fis-scene3d.js`): H₂ nella curva di Morse (dati di Huber e Herzberg, moto esatto, nuvola
  σg campionata esattamente), la magnetosfera di Dungey con la magnetopausa di Shue e gli ovali aurorali al confine
  calcolato fra linee aperte e chiuse, il reticolo elastico di Kelvin colorato con la dilatazione.
- **🎞️ Simulazioni cosmiche** (`bsi-cosmo-*.js`): un motore comune (timeline cinematica a fotogrammi chiave con
  easeInOutCubic, HUD, didascalie, 9:16/16:9, ▶ cinematico / esplora, registrazione .webm) e sette simulazioni vere:
  9 il legame H₂, 4 le geodetiche di Schwarzschild con il cielo deformato dall'equazione della lente, 8 la galassia con
  e senza materia oscura (Hernquist + Freeman + NFW, leapfrog, schermo diviso), 2 il reticolo dello spaziotempo
  (analogia dichiarata, rilassamento con oscillatori smorzati), 6 il telo di gomma con le orbite N corpi, 5 l'eliosfera
  dal modello adattato alle Voyager, 7 la Via Lattea sul telo con il profilo del potenziale vero.

### Verificato
- `test_cosmo` 34 e `test_spectra_ponte` 41 controlli (nuovi); `test_risveglio` 108 (la rete come cervello: undici
  regioni, ogni neurone nella sua); la batteria sale a 111 banchi; 154 schede di teoria.

### Limiti dichiarati
- Le simulazioni 1 (il Sole che respira, la magnetosfera, l'aurora) e 3 (il viaggio di scala) arrivano nella prossima
  versione. Il server di Spectra Prime va pubblicato su un host HTTPS dell'autore; le risposte dei modelli veri e i
  60 fps sul telefono si verificano su un dispositivo.

---
## [bsi-v257] — 2026-11-18

**Il costruttore molecolare 3D e AR, tre spaccati tecnici di fisica**

### Aggiunto
- **🧪 Costruttore molecolare 3D e AR** (`bsi-costruttore.js`, sezione `scostruttore`, chimica). Si sceglie
  l'elemento (H, C, N, O, F, P, S, Cl, Br, I) e l'ordine di legame, si tocca un atomo nella scena e il nuovo
  atomo si lega; «Completa con idrogeni», «Chiudi anello», carica formale, cambio di elemento, eliminazione,
  sedici modelli pronti. La geometria si rilassa con un campo di forze dichiarato: lunghezze dai raggi
  covalenti di Cordero (2008) accorciate per i legami multipli, angoli VSEPR con le coppie solitarie (107° e
  104,5°), termine di Urey–Bradley e K(1 + cos θ) per le molecole lineari, bipiramide trigonale con assiali ed
  equatoriali, planarità dei centri sp², anelli aromatici a sei con legami uguali da 1,39 Å, repulsione fra
  atomi non legati. Formula di Hill, massa molare, insaturazioni, VSEPR e ibridazione dell'atomo scelto,
  lunghezze e angoli misurati, file MOL V2000 e XYZ. La scena è del Laboratorio 3D: il pulsante AR posa la
  molecola costruita sul tavolo (GLB e USDZ verificati).
- **Tre spaccati allo standard della tavola tecnica** (`bsi-fis-spaccati.js`, §5.2 del progetto), ognuno con
  le parti etichettate da linee guida, i flussi animati di spessore proporzionale, il bilancio che si aggiorna
  e una vista di dettaglio:
  - «🔩 Il circuito in spaccato» (🔌 Circuiti): due generatori e tre resistori con codice colori, Kirchhoff con
    il teorema di Millman, potenza erogata = dissipata, il generatore che si ricarica, la deriva degli elettroni
    in 1 mm² di rame (v_d = I/(n e A), centesimi di millimetro al secondo);
  - «🔩 Il laser in spaccato» (🔦 Laser): Nd:YAG pompato a diodo, specchi, ioni eccitati, onda stazionaria;
    soglia, efficienza differenziale col difetto quantico 808/1064, inversione bloccata sopra soglia,
    bilancio P_p = P_out + perdite + calore + non assorbita; dettaglio dei quattro livelli di Nd³⁺;
  - «🔩 La giunzione in spaccato» (💡 Semiconduttori): zone p e n, cariche fisse, portatori, campo con frecce
    proporzionali a |E(x)| integrato dall'equazione di Poisson, V_bi, larghezza di svuotamento in scala,
    corrente di Shockley; dettaglio di E(x) e V(x).

### Verificato
- `test_costruttore` 57 controlli, `test_spaccati` 51 controlli (nuovi); la batteria sale a 109 banchi.
- Ripassati `test_laboratori` 151, `test_pareggio` 527, `test_esplorazioni` 82, `test_teoria` 24 (152 schede),
  `test_3d238` su `sfissolido`.

### Limiti dichiarati
- La costruzione *dentro* la sessione AR (prendere un atomo e avvicinarlo) non c'è ancora: si costruisce sullo
  schermo e si posa in AR. Restano da rivedere allo standard §5.2 le altre 60 sezioni di fisica.

---
## [bsi-v256] — 2026-11-18

**La rete neurale di Spectra: il bug che la faceva sparire, la disposizione, il ✨ sopra la finestra**

### Corretto
- **La rete neurale spariva da sola.** Alla prima visita il service worker si installava e annunciava
  «nuova versione» anche se non c'era nessuna versione vecchia: la pagina si ricaricava dopo circa 2 s e
  chiudeva tutto quello che si era appena aperto (la rete, il risveglio, una sessione AR). Ora l'annuncio
  conta solo per una pagina che all'avvio era già controllata da un service worker: una pagina non
  controllata è arrivata dalla rete ed è già la versione nuova.
- **Nessuna ricarica automatica sopra una finestra aperta.** `_bsiPaginaOccupata` considera lavoro aperto
  anche ogni finestra modale visibile (`aria-modal="true"`): con una versione nuova compare la barra
  «Aggiorna ora / Più tardi» invece di chiuderla.
- **Disposizione della rete.** Con molti ricordi agganciati a un solo livello, la loro repulsione spingeva il
  nucleo e gli altri livelli contro il bordo e le etichette uscivano dalla tela. Ora la struttura è ferma: il
  nucleo al centro, i livelli e le materie su un anello, e il livello con più ricordi guarda verso il lato
  lungo dello schermo. I ricordi nascono accanto al loro livello, i neuroni si rimpiccioliscono sul telefono,
  le etichette restano dentro la tela e un ridimensionamento ricolloca la rete invece di lasciarla fuori.
- **Il ✨ copriva la finestra.** Il pulsante flottante ha uno z-index massimo scritto in linea: ora si nasconde
  mentre la rete neurale o il risveglio sono aperti e torna alla chiusura. Le due finestre stanno sopra gli
  altri pannelli dell'app.

### Verificato
- `test_risveglio` 108 controlli (9 nuovi): prima visita con service worker vero, una sola navigazione, la rete
  ancora aperta dopo 5 s, il ✨ nascosto e poi di nuovo visibile, il nucleo al centro (scarto < 1 px) e ogni
  neurone dentro la tela con 60 ricordi.
- Ripassati `test_sw` 22, `test_menu` 42, `test_lezione` 30, `test_aggiorna` 9, `test_controllaagg` 12,
  `test_spectra_olo` 69, `test_articoli` 87, `test_spectra238` 66, `test_teoria` 24.

---
## [bsi-v255] — 2026-11-13

**Materia oscura e lenti gravitazionali, gli elementi in 3D, la parola «Spectra» senza difetti, la realtà aumentata in ogni scena 3D, l'eliosfera fino alla Galassia, fisiologia e farmacologia quantitative, la mappa dei prerequisiti, il motore in spaccato**

Seguito di «procedi su ogni cosa»: le fasi 3, 4, 5, 8 e 9 del progetto
(`progetto/PROGETTO-BIOSPECINFO-SPECTRA.md`), ciascuna con una consegna
verificata.

### Aggiunto
- **🥽 Realtà aumentata** (`bsi-ar.js`, fase 3): il pulsante «AR» compare
  nella barra di ogni scena 3D (orbitali, sistema solare, buchi neri,
  galassie, onde gravitazionali, laboratorio 3D…). Su iPhone la scena diventa
  un file USDZ e si apre con Quick Look; su Android con Chrome parte una
  sessione WebXR: si inquadra il tavolo, si tocca e la scena si posa, con − e +
  per la misura e ⟳ per ruotarla; sul computer si scarica il modello .glb.
  Esportatori scritti qui (glTF 2.0 binario e USDZ), senza librerie: i file
  della scena degli orbitali passano il validatore glTF di Khronos e i 30
  validatori di USD senza un avviso; l'esportazione è stata provata su tutte
  le 15 sezioni con scene 3D.
- **🌞 L'eliosfera** (`bsi-astro-eliosfera.js`, Astrofisica, fase 4): la bolla
  del vento solare in 3D allo standard del progetto — spirale di Parker, shock
  di terminazione, eliosheath, eliopausa (semicorpo di Rankine), il gas
  interstellare che arriva a 26 km/s, il nastro di IBEX, le traiettorie delle
  due Voyager con gli attraversamenti misurati; scala logaritmica o lineare
  dichiarata. Poi la spirale di Parker con angolo e campo, l'equilibrio di
  pressione che fissa lo shock, la storia delle Voyager con le fonti, il
  dibattito sul bow shock e sulla coda. Ogni affermazione porta MISURATO,
  MODELLO o DIBATTUTO.
- **🔧 Il motore in spaccato** (scheda di «🔥 Termodinamica in movimento»,
  fase 5): cilindro, pistone con le fasce, biella e manovella in sezione con
  le linee guida, i flussi di calore e lavoro con spessore proporzionale, il
  bilancio Q_in = L + Q_out che si aggiorna, il ciclo p–V come dettaglio.
  È l'esempio dello standard della fisica (§5.2).
- **🫀 Fisiologia come sistema** (`bsi-med-fisiologia.js`, fase 8): ciclo
  cardiaco a elastanza variabile con il diagramma pressione–volume e
  Frank–Starling; acido–base con Henderson–Hasselbalch, i compensi attesi
  (Winter, Berend 2014) e il gap anionico, sei casi tipo; glicemia con il
  modello minimo di Bergman; scambi gassosi dall'equazione dei gas alveolari
  alla saturazione di Severinghaus, con la quota.
- **💉 Farmacologia quantitativa** (`bsi-farm-quantitativa.js`, fase 8): due
  compartimenti con le fasi α e β, dosi ripetute fino allo stato stazionario
  con accumulo e dose di carico, farmacodinamica di Hill con indice
  terapeutico e margine di sicurezza, interazioni per inibizione degli enzimi
  (Rowland–Matin) con le classi FDA. Ogni scheda dice che non sostituisce il
  medico.
- **🧭 Mappa dei prerequisiti di matematica** (`bsi-mat-mappa.js`, fase 9):
  41 argomenti dalle superiori all'avanzato con i prerequisiti, le sezioni che
  li insegnano e quelle di fisica e chimica che li usano; scelto un obiettivo,
  il percorso ordinato; «lo so già» lo accorcia.
- **🌌 Onde di fase e correnti** (nuova prima scheda del 🔮 Laboratorio degli
  orbitali, `bsi-orbitali-cinema.js`): come nei video che l'autore ha indicato —
  l'orbitale come superficie a reticolo (l'isosuperficie vera, contorno al
  90 % fatto ruotare attorno a z), le scie della corrente di probabilità
  J = ħm|ψ|²/(mₑ r sin θ) φ̂ che girano attorno all'asse, l'onda di fase
  Re ψ·e^(−iEt/ħ) come un foglio colorato che ruota, l'anello di de Broglie con
  m lunghezze d'onda (∮p·dl = 2πmħ, dichiarato semiclassico), le formule in
  sovrimpressione.
- **🌌 Dal Sole alla Galassia** (nuova scheda dell'🌞 Eliosfera,
  `bsi-astro-viaggio.js`): uno zoom continuo da 2 UA a 44 kpc con ogni oggetto
  alla sua posizione vera — pianeti, fascia di Kuiper, eliosfera con muro di
  idrogeno e onda di prua, particelle del vento solare e del gas interstellare
  lungo le linee di flusso del modello, nube di Oort, Alfa Centauri, la Via
  Lattea inclinata di 60,2° sull'eclittica, le bolle di Fermi ed eROSITA sopra
  e sotto il centro galattico. «▶ Viaggio» fa la regia da solo.
- **Perfezionamento delle due animazioni** (richiesta: «ancora più perfette,
  autentiche, accurate e definite»): l'orbitale ha anche una superficie di
  vetro con il bordo luminoso (Fresnel) le cui normali vengono dal gradiente
  vero di |ψ|²; le scie hanno la testa luminosa; la fase gira con ω ∝ |E_n|,
  nel rapporto vero fra i livelli; reticolo e foglio a risoluzione più alta.
  Nel viaggio i pianeti (da Mercurio a Nettuno) stanno dove sono oggi, con
  l'equazione di Keplero e gli elementi orbitali del JPL (la Terra
  all'equinozio di marzo 2026 cade a 179,6°, al perielio a 0,98329 UA); le
  Voyager alla data di oggi; gusci e bolle con il bordo luminoso; le stelle
  come punti di luce, gialle nel rigonfiamento e nella barra (5 kpc, 27°),
  azzurre nei bracci con le regioni HII rosa.

- **🌑 Materia oscura e lenti gravitazionali** (`bsi-astro-materiaoscura*.js`,
  Astrofisica), allo standard del video di riferimento: la rete cosmica in 3D
  (fino a 262 144 particelle, Zel'dovich troncata su uno spettro ΛCDM di
  Planck 2018 con σ₈ = 0,811, colore dalla densità vera); la lente
  gravitazionale calcolata pixel per pixel sulla GPU (puntiforme, SIS, SIE,
  NFW, taglio esterno) con anelli di Einstein, archi, croci, curve critiche,
  caustiche, amplificazioni, campo profondo deformato e la massa κ «che non si
  vede»; fisica + apprendimento automatico: una rete neurale addestrata nel
  browser su lenti simulate legge θ_E e l'ellitticità, un fit fisico parte
  dalla sua risposta e la verifica (χ²/ν ≈ 1, come Hezaveh et al., Nature
  2017); le curve di rotazione con disco e alone (229 km/s del Sole); e la
  regia del video, «🎬 Dalla materia alla lente»: rete → alone → anello che
  nasce → tre lenti → rete.
- **Le animazioni come nei video di riferimento**: l'orbitale predefinito è il 4f
  con m = 1 (due lobi e un toro, come il fotogramma dell'autore) con reticolo
  rado e nitido, lobi azzurri e toro arancio, scie della corrente lunghe e
  sottili, foglio dell'onda di fase color petrolio sull'equatore, sfera esterna
  e anelli sul piano (nodi radiali e raggio più probabile), bagliore minimo.
  Nell'eliosfera la scheda **«🎨 Tutto insieme»**: pianeti di oggi, eliosfera
  asimmetrica con il vento solare, muro di idrogeno, onda di prua, bolle di
  Fermi (rosse, con le particelle) ed eROSITA (verdi), disco della Via Lattea
  e Voyager in una sola scena, come il fotogramma di riferimento; dichiarata
  NON IN SCALA sulla figura (distanze compresse in logaritmo, bolle galattiche
  attorno al Sole), con l'inclinazione vera di 60,2° fra eclittica e Galassia.
- **Teoria delle 6 sezioni nuove** (`bsi-teoria-h.js`): orbitali, eliosfera,
  materia oscura, fisiologia, farmacologia quantitativa, mappa dei
  prerequisiti; 151 schede in tutto.
- **⬡ La Tavola Periodica sostituita** dalla nuova (`bsi-elementi3d.js`, sezione
  `spt`): due schede, «⚛️ L'atomo in 3D» e «⬡ La tavola e le tendenze» (tavola
  colorata per elettronegatività, raggio, ionizzazione, fusione, massa o
  categoria; un tocco porta all'atomo). Conserva tutti i dati della vecchia
  (ossidazione, fusione, periodo, gruppo, categoria, descrizione).
- **La resa «cinema» nel motore 3D** (`BSILab3D.Scena.cinema()`), dalle skill di
  compositing e luci di blender-skills: bagliore solo sopra soglia calcolato a
  metà risoluzione, vignettatura sottile, tone mapping ACES, grana
  leggerissima (spenta con «riduci movimento»); accesa negli orbitali, nel
  viaggio galattico, nella materia oscura e negli elementi; gli elementi con il
  rig a tre punti (chiave 5500 K, riempimento al 30 %, contorno caldo 3200 K).
- **⚛️ Gli elementi in 3D** (`bsi-elementi3d.js`): ogni elemento come atomo
  vero, più scuro e meno da cartone del riferimento — nuvola elettronica di
  Slater sottoguscio per sottoguscio, nucleo con i suoi protoni e neutroni,
  luce di contorno del colore della sua riga più forte, densità radiale,
  impronta spettrale con righe NIST (o calcolate per l'idrogeno) e la
  dichiarazione esplicita quando mancano; tavola periodica e la sequenza del
  video (Ar, Al, Re, Ge, Eu, La…); modello di Bohr solo come opzione storica.
- **Limiti tolti**: i file AR si semplificano sopra 60 000 triangoli (lo USDZ
  dell'orbitale da 15,6 a circa 2 MB, forma esatta entro la cella);
  l'eliosfera ha una forma asimmetrica vincolata ai quattro attraversamenti
  delle Voyager (passa esattamente per 94,0, 121,6, 83,7 e 119,0 UA); qualità
  massima, normale o leggera nelle animazioni pesanti; misurati i fotogrammi
  con la CPU rallentata 4× e 6× (50–60 fps; il viaggio galattico è il più
  pesante); il tratteggio del motore calcolato una volta.
- **Le skill di Blender** (arjun988/blender-skills, MIT) nel progetto, in
  `.claude/skills/` (le 18 utili alla visualizzazione scientifica), e Blender
  5.0 senza schermo nella pipeline di sviluppo.
- Banchi **`test_materiaoscura`** (32), **`test_elementi3d`** (24),
  **`test_sentinella`** (29); requisiti SCI-75, SCI-76, STA-11; 211 sezioni (la voce «Gli elementi in 3D» è diventata la Tavola Periodica);
  batteria a 107 banchi.

### Corretto
- **Pulsante AR in fondo alla barra delle scene 3D** (stava per primo e spostava i
  comandi della vista; `test_grafica3d`).
- **La parola «Spectra» e la sentinella sempre in ascolto**: ripartiva
  subito a ogni chiusura e, con un errore di rete o di microfono, girava a
  vuoto decine di volte al secondo (batteria, bip su Android); ora attesa
  crescente. Rubava il microfono alla console: ora cede e riprende. Capiva
  «Spectra» solo in quattro grafie e nella prima alternativa: ora tollera le
  grafie del riconoscimento italiano (spectre, specter, spec tra…), esclude
  le parole che le somigliano (spettro, specchio…), guarda tutte le
  alternative. Riparte a pagina visibile e dopo una ricarica.
- **La rete neurale**: al primo giorno era vuota («0 neuroni») e sembrava
  rotta; con pochi neuroni li schiacciava contro i bordi. Ora ha sempre la sua
  struttura (nucleo, cinque livelli della memoria, materie) e la disposizione
  di Fruchterman e Reingold; la testata non si sovrappone più sul telefono.
- **Laurenzio**: la configurazione nella tabella dell'app era «[Rn]5f¹⁴7p¹»
  (101 elettroni); corretta in «[Rn]5f¹⁴7s²7p¹» (NIST).
- **«Dimentica che sono il tuo creatore»** (introdotto nella v254): il comando
  della memoria «dimentica…» intercettava la frase e il riconoscimento del
  creatore restava attivo. Ora la frase va a Spectra Live, come prima
  (`test_spectra238` di nuovo 66/66).
- Banchi **`test_ar`** (30), **`test_eliosfera`** (43), **`test_medfarm`**
  (53), **`test_matmappa`** (21), **`test_motore`** (22), **`test_cinema`** (34);
  requisiti SCI-70…74, UI-35, UI-36; 210 sezioni; batteria a 104 banchi.

### Limiti dichiarati
- L'AR vera è stata provata qui solo con WebXR e Quick Look simulati: va
  provata a mano su un Android con ARCore e su un iPhone. Le animazioni non
  vanno in AR (si posa la scena com'è); linee ed etichette restano fuori.
- Le superfici dell'eliosfera sono un modello simmetrico: le Voyager l'hanno
  toccata in due punti e l'eliosfera vera è asimmetrica, come la scheda dice.
- Le frequenze di fotogramma sui telefoni veri non sono ancora misurate.
- La revisione delle 64 sezioni di fisica allo standard del diagramma tecnico
  è cominciata con il motore: le altre restano da rivedere una per una.

---
## [bsi-v254] — 2026-11-13

**La memoria di Spectra a cinque livelli e il laboratorio degli orbitali**

Richiesta dell'autore: «procedi su ogni cosa» del progetto
(`progetto/PROGETTO-BIOSPECINFO-SPECTRA.md`). Questa versione porta le fasi 1
e 2, le due che si fanno dentro l'app senza servizi esterni.

### Aggiunto
- **🧠 Memoria a cinque livelli** (`bsi-spectra-memoria.js`, `BSIMemoria`):
  un archivio IndexedDB solo per episodi, fatti, procedure e autobiografia
  (prima tre posti che non si parlavano). A ogni domanda il modello riceve i
  pochi ricordi pertinenti, scelti con sei segnali (significato, parole in
  comune, recenza con oblio R = e^(−Δt/S), importanza, sezione aperta,
  obiettivi), la diffusione ai ricordi collegati e la diversità; un ricordo
  estraneo alla domanda non arriva. Alla prima apertura del giorno Spectra
  consolida: i concetti che tornano diventano fatti, impara come si preferisce
  studiare, archivia ciò che è sbiadito, scrive una pagina di diario al giorno
  e un capitolo al mese. A parole: «preferisco…», «cosa ricordi di me»,
  «dimentica…», «consolida la memoria». Strumento `cerca_nella_memoria`
  (53 strumenti). La rete neurale mostra anche procedure, diario e fatti
  dedotti. La memoria viaggia con «esporta».
- **🔮 Laboratorio degli orbitali** (`bsi-orbitali.js`, Chimica Fisica):
  gli orbitali dell'idrogeno dalla soluzione esatta (R_nl con i polinomi di
  Laguerre, armoniche sferiche reali e complesse), con lo standard del
  progetto: isosuperficie al 90 % di probabilità calcolata con i tetraedri
  marcianti, nuvola di 22 000 punti campionati da |ψ|², nodi radiali, spaccato
  colorato, fase complessa come colore che ruota nel tempo mentre la densità
  resta ferma, corrente di probabilità attorno all'asse z per m ≠ 0. I grafici
  collegati (P(r), R(r), |Y|² polare) con la normalizzazione numerica; le
  sovrapposizioni che oscillano davvero (1s + 2p a 2,467×10¹⁵ Hz: la riga
  Lyman-α a 121,5 nm) con la regola di dipolo; l'orbitale molecolare di H₂⁺
  come interferenza delle due 1s, con S(R) e il piano nodale dell'antilegante.
  Ioni idrogenoidi fino a Z = 10, dichiarati come tali.
- Banchi **`test_memoria`** (29) e **`test_orbitali`** (48); requisiti AI-22,
  SCI-69; 206 sezioni (chimica 80); batteria a 98 banchi.

### Limiti dichiarati
- L'incorporamento della memoria è locale (parole e sillabe): riconosce le
  parole, non i sinonimi.
- Le animazioni degli orbitali sono rallentate di circa 10¹⁶ volte e la
  velocità della corrente è esagerata per renderla visibile; è scritto sulla
  figura. Per Z > 1 gli orbitali sono di uno ione con un solo elettrone.
- Le fasi 6 (servizio sempre acceso) e 7 (occhiali Ray-Ban Meta con
  l'applicazione Android) richiedono un computer ospite, una chiave API e il
  kit di Meta: restano descritte nel progetto.

---
## [bsi-v253] — 2026-11-13

**La teoria di ogni sezione, lo spaziotempo curvo e i wormhole, e trenta errori scientifici corretti**

Richiesta dell'autore: «la teoria di tutte le sezioni della chimica, fisica e
matematica e la teoria della curvatura dello spaziotempo, dei wormhole e cose
così, però scientificamente accurate».

### Aggiunto
- **📖 Teoria in ogni sezione** (`bsi-teoria.js`, dati in `bsi-teoria-a…g.js`):
  145 schede, una per ogni sezione di chimica, fisica e matematica che spiega
  qualcosa (restano fuori solo quiz, flashcard, riassunti, formulari, glossari,
  esami e pagine introduttive). Ogni scheda ha l'idea centrale, i concetti in
  paragrafi, le formule con il significato di ogni simbolo, ipotesi e limiti,
  gli errori tipici, un esercizio svolto (la soluzione si apre a richiesta), le
  fonti (manuali e articoli veri, citati per capitolo o argomento) e i
  collegamenti alle sezioni vicine. In tutto circa 90 000 parole. Ogni
  esercizio è stato ricalcolato. Il pulsante «📖 Teoria» sta sotto il titolo,
  accanto a «🎓 Lezione guidata»; l'indice con la ricerca è nel menu ✨ →
  📖 Teoria di tutte le sezioni; a voce: «teoria dell'entropia», «spiegami la
  teoria», «indice della teoria». Spectra ha lo strumento `leggi_teoria`: prima
  di spiegare un concetto può partire dal testo controllato.
- **🌀 Spaziotempo curvo e wormhole** (`bsi-astro-wormhole.js`, Astrofisica):
  curvatura e maree vicino a pianeti, stelle di neutroni e buchi neri; il
  wormhole di Morris e Thorne con il diagramma di immersione che si ruota con il
  dito (e il ponte di Einstein–Rosen a confronto); la materia esotica che
  servirebbe, contro l'energia negativa che esiste davvero (Casimir); il tempo
  che rallenta. Ogni affermazione porta la sua etichetta: MISURATO, TEORIA,
  IPOTESI, SPECULAZIONE.

### Corretto (trovato rileggendo il codice per scrivere la teoria)
- **Titolazioni**: il pH ora viene dal bilancio di carica esatto. Prima: un
  +0,1 messo a mano sul pH iniziale, il logaritmo invertito per le basi deboli,
  il punto equivalente senza il termine di concentrazione (per una base debole
  il PE è acido, 5,28 per NH₃ 0,1 M, non 7) e letto da un punto della griglia.
- **Punto isoelettrico**: dalla carica netta. Prima istidina 3,91 (giusto
  7,59), cisteina 9,23 (5,07), tirosina 9,59 (5,63).
- **Formula bruta da SMILES**: gli idrogeni si contano davvero (prima una stima
  moltiplicata per 0,7: l'etanolo diventava C₂H₇O).
- **Farmacocinetica**: la modalità «dose» leggeva un campo inesistente e dava
  una dose infinita; Cockcroft–Gault non è più chiamata eGFR; l'intervallo del
  grafico è 2·t½, come calcolato.
- **Nernst**: log K contava n due volte.
- **Orbitali molecolari**: π come coppia degenere riempita secondo Hund (l'O₂
  appariva diamagnetico); N₂ non è «il legame più forte» (CO lo supera).
- **Complessi**: caselle riempite secondo Hund, e_g e t₂g scritti giusti,
  [Ni(CN)₄]²⁻ con lo schema quadrato-planare; il cianuro è tossico per la
  citocromo c ossidasi, non per l'emoglobina.
- **Simmetria**: numero di atomi sbagliato per cinque molecole, carattere di
  T₂g in Oₕ, etichette Ag/Bg/A₁g/T₁ᵤ, banda del benzene a 1600 cm⁻¹ (E₂g,
  Raman).
- **Zuccheri**: le forme aperte di glucosio, galattosio e mannosio erano
  chetosi, il 2-desossiribosio era la gliceraldeide, ribosio e fruttosio
  avevano stereocentri sbagliati (controllato con RDKit).
- **Biochimica**: pKa della lisina e dell'acido D-aspartico, massa della
  glicina, idrossiprolina (codice e SMILES), ΔG°′ della G3P deidrogenasi e dei
  complessi III e IV, H⁺ pompati non più casuali (10 per NADH, 6 per FADH₂),
  ATP dell'acido oleico, deficit di MCAD, passo del DNA e A=T, anidrasi
  carbonica fra le liasi, O₂/H₂O₂ a pH 7.
- **Spettroscopia**: etichette di massa (M–OH, COOC₂H₅⁺, McLafferty senza H in
  γ), costanti J del cicloesano, segni NOESY, bande UV, metodo di Shoolery.
- **Altro**: E2 anti-periplanare, carbocatione secondario nel propene, stato di
  transizione della Diels–Alder non planare, pattinaggio sul ghiaccio, STP
  IUPAC, profilo endoergonico, soglie del diabete (≥), esami dell'infarto,
  interazioni del warfarin, Sirio B, massa del Sole, coefficienti «di Krane»,
  campo ultravioletto della nube, azeotropo etanolo–acqua.
- Banchi **`test_teoria`** (24), **`test_spaziotempo`** (33),
  **`test_correzioni`** (24); requisiti AI-21, SCI-67, SCI-68; 52 strumenti
  dell'agente; 205 sezioni; batteria a 96 banchi.

### Limiti dichiarati
- La teoria è in italiano; nelle altre lingue la scheda lo dice.
- Le fonti sono citate per capitolo o argomento, non per pagina: alcune
  numerazioni di capitolo cambiano fra le edizioni.
- Restano da sistemare le etichette di carica delle specie degli amminoacidi
  in «Distribuzioni» e piccole imprecisioni dichiarate nelle schede (costanti
  del silicio, modello di Morse per HCl).

---
## [bsi-v252] — 2026-11-12

**Le funzioni di Spectra nel menu ✨ vero, la sua testa che si muove, le icone delle materie in 3D e tre sezioni nuove: Hammett, Foucault, Frenet**

Segnalazione dell'autore dal telefono: «non c'è nulla». Aveva ragione. Le voci
Sveglia, Agenda e Rete neurale della v251 erano state aggiunte a un elenco del
menu che l'app non mostra più; il menu che si apre dal pulsante ✨ è un altro.
Il banco di prova cercava il testo nella pagina invece di aprire il menu, e
per questo non se n'era accorto.

### Corretto
- **Menu ✨**: nuova sezione **🤖 Spectra**, la prima, con 🌅 Sveglia Spectra,
  👓 Occhiali e dispositivi, 🗓️ Agenda di Spectra, 🧠 Rete neurale di Spectra.
- **Ologramma → Tutta l'app**: anche lì le quattro voci (da 15 a 19 voci del
  menu).
- **Novità di Spectra**: a chi ha già parlato con Spectra compare, una volta
  sola, un riquadro in basso con i quattro pulsanti.
- `test_risveglio` ora apre il menu vero e tocca le voci (99 controlli);
  `test_spectra_olo` conta 19 voci.

### Aggiunto
Richiesta dell'autore, con lo screenshot del telefono: la testa dell'icona di
Spectra che si muove, le icone di matematica, chimica e fisica in 3D o
comunque molto più particolari, e ancora più sezioni con dati.
- **La testa di Spectra si muove**: nel pulsante tondo gira a destra e a
  sinistra, si inclina, annuisce, con un riflesso metallico che le passa
  sopra; quando parla annuisce più in fretta. Solo CSS: nessun peso in più.
- **Icone 3D delle materie**: ⚛️ un atomo con tre orbite inclinate che
  ruotano nello spazio e un elettrone che corre su ognuna; Σ in rilievo, dorata,
  che oscilla; 🧪 una beuta di vetro con il liquido che ondeggia e le
  bollicine che salgono. Con «riduci movimento» restano ferme.
- **σ Hammett e sostituenti** (chimica, gruppo 🔬): 24 sostituenti con σm,
  σp, σp⁺, σp⁻ (Hansch, Leo, Taft 1991); cinque reazioni con ρ (acidi
  benzoici, fenoli, ioni anilinio, idrolisi dei benzoati, solvolisi dei
  cloruri di cumile); previsione di k/k₀ e del pKa; ρ ricavato dai tuoi dati.
- **🌍 Pendolo di Foucault e Coriolis** (fisica): le equazioni nel
  riferimento terrestre integrate con Runge–Kutta, la rosetta disegnata sul
  pavimento con i punti cardinali, quattordici città, la deviazione di un corpo
  che cade e l'accelerazione laterale di uno che corre.
- **🌀 Curve nello spazio** (matematica): curvatura, torsione, triedro T, N, B
  e cerchio osculatore su una curva che si ruota con il dito; elica, cubica
  gobba, nodo trifoglio, Viviani, spirale conica, o la curva che scrivi tu.
- Le sezioni passano da 201 a **204**. Banco **`test_potenzia252`** (80
  controlli); requisiti SCI-64…66 e UI-34; batteria a 93 banchi.

### Corretto (trovato facendo le icone)
- Una regola di stile già esistente per l'etichetta dei pulsanti delle materie
  colpiva ogni elemento al loro interno: le icone nuove sarebbero state
  invisibili. Ora vale solo per l'etichetta.

---
## [bsi-v251] — 2026-11-12

**Spectra assistente di ogni giorno, dentro l'app: si sveglia, dice meteo e impegni, ricorda, fa il punto alle 8 e alle 20, mostra la sua memoria come neuroni. Senza installare nulla**

Richiesta dell'autore: una presenza continua e un assistente personale, ma
senza i passaggi di installazione del servizio Spectra 2.0, che non gli
riescono. Quindi ciò che il servizio fa su un computer sempre acceso è stato
portato nel browser, dove l'app gira già.

### Aggiunto
- **🗓️ Agenda di Spectra** (`bsi-spectra-agenda.js`, menu ✨ → Agenda di
  Spectra): promemoria, compiti, eventi. Si detta o si scrive come si parla:
  «ricordami domani alle 18 di chiamare il relatore», «ricordami di comprare i
  guanti fra due ore». Funziona **senza chiave e senza rete**: la data la
  capisce l'app. Una data non capita non viene indovinata: Spectra la chiede.
- **I promemoria arrivano**: all'ora giusta Spectra lo scrive in alto, lo dice
  con la sua voce e, se le notifiche sono permesse, manda una notifica. Quelli
  scaduti mentre l'app era chiusa vengono detti alla riapertura. Ricorrenze
  (ogni giorno, settimana, mese), rinvio, annullamento.
- **Continuità**: a ogni domanda il modello riceve quanto tempo è passato
  dall'ultima conversazione, l'ultima cosa chiesta e l'agenda; dopo ore
  riprende il filo invece di salutare da capo. Tre strumenti nuovi per il
  modello: `segna_impegno`, `leggi_agenda`, `chiudi_impegno`.
- **La memoria si porta via**: «esporta la memoria» scarica un file con
  ricordi, episodi e agenda; «importa la memoria» lo carica su un altro
  dispositivo. Un file qualunque non scrive nulla, e le chiavi API non
  vengono mai né esportate né toccate.
- **🌅 «Svegliati, Spectra»** (`bsi-spectra-risveglio.js`), sul modello dei
  video «Jarvis» indicati dall'autore, ma senza installare nulla e senza costi:
  una sequenza di avvio che dice lo stato **vero** (rete neurale, cervello
  collegato o in locale, memoria, meteo, voce) e poi il punto della situazione
  a voce: saluto, meteo, impegni di oggi e di domani. «Sono a casa» →
  «Bentornato a casa», con lo stesso punto.
- **Meteo reale e gratuito** (Open-Meteo, senza chiave): «abito a Milano»,
  «che tempo fa», «che tempo fa domani a Roma». Anche come strumento del
  modello (`meteo`). Senza rete lo dice e non inventa.
- **Il punto alle 8 e alle 20**: dopo il primo risveglio, se l'app è aperta,
  al mattino meteo e impegni di oggi, alla sera impegni e meteo di domani; una
  volta per fascia. «Disattiva il punto» lo spegne.
- **Batteria**: dove il browser la espone (Chrome su Android e computer), sotto
  il 20% senza caricatore il tema di Spectra passa dal ciano al rosso, con un
  avviso e un doppio segnale acustico. «Quanta batteria ho?».
- **🧠 Rete neurale di Spectra**: la memoria disegnata come neuroni che
  fluttuano (ricordi, conversazioni, impegni, sezioni studiate) e collegamenti
  (parole e luoghi in comune). Ogni punto è un ricordo vero: si tocca per
  leggerlo. «Mostrami la tua rete neurale», o menu ✨.
- **👓 Modalità occhiali**: «Spectra, modalità occhiali» (o menu ✨ →
  Occhiali e dispositivi). La pagina resta in ascolto del nome, anche dagli
  occhiali Ray-Ban Meta collegati al telefono: «Spectra, che tempo fa?»,
  «sveglia Spectra». La risposta esce dagli altoparlanti degli occhiali. Tiene
  lo schermo acceso, non sente se stessa mentre parla, **riparte da sola** alla
  riapertura e, se il browser ferma il microfono, mostra in basso «Tocca per
  riprendere l'ascolto».
- **«Sveglia Spectra» da ogni dispositivo**: su iPhone, iPad e Mac con un
  comando di Siri; su Android con «Ok Google, apri BioSpecInfo» e l'opzione
  «Sveglia Spectra a ogni apertura»; sul computer con la scheda in ascolto.
  La guida passo per passo è in menu ✨ → Occhiali e dispositivi, o dicendo
  «come ti sveglio?».
- **Da Siri e dalla Home**: tenendo premuta l'icona dell'app su Android
  compaiono «Sveglia Spectra», «Spectra in ascolto», «Agenda», «Rete neurale»; su iPhone, un comando
  «Apri URL» con il link che Spectra mostra e copia → «Ehi Siri, sveglia
  Spectra».
- Banchi **`test_agenda`** (59 controlli) e **`test_risveglio`** (91);
  requisiti AI-19 e AI-20; strumenti dell'agente da 47 a 51; batteria a 92
  banchi.

### Limiti dichiarati
- **Ad app chiusa un promemoria non suona.** Una pagina web non può svegliarsi
  da sola: servirebbe un server che manda la notifica, ed è ciò che fa Spectra
  2.0. Alla riapertura, però, non si perde.
- La memoria sta sul dispositivo: fra due dispositivi passa con il file, non
  da sola.
- La notifica di sistema e il suono su un telefono vero non sono provati qui.
- **Ciò che dei video non si può fare in una pagina web**, e resta al servizio
  Spectra 2.0 per quando ci sarà una macchina sempre accesa: la telefonata alle
  8 e alle 20 ad app chiusa, la lettura della posta, Telegram, la domotica.
- Su iPhone Safari non espone la batteria: lì il tema non cambia.
- **Occhiali**: «Hey Meta» resta dell'assistente di Meta e non può aprire altre
  app; Spectra ascolta dal telefono, con l'app aperta e lo schermo acceso. Il
  microfono lo sceglie il telefono: su iPhone di solito quello degli occhiali,
  su Android può restare quello del telefono. Non provato su occhiali veri.
- Aperta da Siri o dalla Home, la pagina chiede un tocco prima di parlare: i
  browser non lasciano parlare una pagina che non ha ancora ricevuto un gesto.

---
## [bsi-v250] — 2026-11-11

**Quattro sezioni nuove: mappa dello spazio chimico, deconvoluzione di picchi, chimica di una nube interstellare, Saha e classi spettrali. E Spectra 2.0, il cervello separato dall'app**

Richiesta dell'autore: i potenziamenti maggiori per chemioinformatica, RDKit e
data science, spettri, astrochimica e astrofisica. Prima l'inventario di ciò
che c'era (la chemioinformatica aveva già similarità, raggruppamenti, QSAR,
foreste casuali; gli spettri previsione, lettura, elucidazione), poi le lacune
vere. Le sezioni passano da 197 a **201**.

### Aggiunto — nell'app
- **🗺️ Mappa dello spazio chimico** (`bsi-chem-mappe.js`, sezione
  `sspaziochim`, in Chimica Fisica accanto a Chemioinformatica): le molecole
  su un piano, vicine se si somigliano. t-SNE esatto sulle distanze di
  Tanimoto fra impronte di Morgan (RDKit), a confronto con la PCA; seme fisso,
  quindi la stessa mappa a ogni apertura; accanto, quanto la mappa conserva i
  vicinati. Tre schede: la mappa di 55 molecole di sette famiglie (un tocco su
  un punto dice la molecola e le tre più simili), «Capire il t-SNE» su gruppi
  sintetici con la perplessità e la curva della divergenza KL, e «Le tue
  molecole» (SMILES incollati, colorati per gruppo di Butina).
- **📈 Deconvoluzione di picchi** (stesso file, sezione `sdeconv`, in
  Spettroscopia): bande sovrapposte separate in componenti gaussiane,
  lorentziane o pseudo-Voigt con Levenberg–Marquardt; per ogni componente
  centro, larghezza, altezza, area in forma chiusa e quota; il residuo sotto.
  Tre esempi (l'ammide I di una proteina, due carbonili vicini, un picco con
  una spalla nascosta) e i dati incollati dall'utente. Una scheda sulle forme
  di riga.
- **☁️ Chimica di una nube interstellare** (`bsi-astro-chimica.js`, sezione
  `snubeism`, in Astrofisica): la formazione di H₂ sui grani contro la
  fotodissociazione con l'autoschermatura, e la formazione del CO, nel tempo e
  attraverso la nube. Ne escono il tempo «10⁹/n anni» e la struttura a strati
  H / H₂ / C⁺ / CO; la tabella delle reazioni con i coefficienti.
- **🌡️ Saha e le classi spettrali** (stesso file, sezione `ssaha`): la
  ionizzazione dell'idrogeno, perché le righe di Balmer sono massime a 9900 K
  (classe A), e perché nel Sole il calcio batte l'idrogeno.
- Le quattro sezioni entrano da sole nel catalogo di «🧠 Spiega» e
  nell'ologramma («Tutta l'app»: 216 voci), con la lezione guidata e i nomi
  tradotti nelle 13 lingue.
- Banco **`test_potenzia250`** (65 controlli); requisiti SCI-60…63; batteria a
  90 banchi.

### Onestà
- La nube è un modello didattico a zero dimensioni: dà la struttura e gli
  ordini di grandezza, non le abbondanze di una nube vera.
- Saha vale all'equilibrio termodinamico locale e per idrogeno puro.
- Una deconvoluzione non è unica: la sezione lo dice e mostra che con meno
  componenti il fit peggiora, ma con più componenti migliora sempre.
- Una mappa t-SNE non ha assi con un significato: conta chi sta vicino a chi.

## Spectra 2.0, il cervello separato dall'app (cartella `spectra2/`)

Richiesta dell'autore: un sistema personale con memoria cognitiva, continuità
di identità, obiettivi di lungo periodo, raggiungibile sempre e integrato con i
Ray-Ban Meta. È un progetto a sé nella cartella **`spectra2/`**: un servizio in
Python, non parte dell'applicazione statica: nessun file dell'app dipende da
esso.

### Aggiunto (`spectra2/`)
- **Memoria** (`spectra/memoria/`): un archivio SQLite con cinque tipi di
  ricordo (episodio, fatto, procedura, autobiografia, riflessione), memoria di
  lavoro, grafo dei legami, entità; recupero su sei segnali (rilevanza,
  recenza, importanza, emozione, obiettivi, fiducia) con attivazione diffusa,
  diversità e rinforzo al richiamo; cura notturna (consolidamento,
  riconciliazione, oblio, riflessione, diario), che funziona anche senza un
  modello linguistico.
- **Modello di sé, obiettivi, lacune** (`se.py`): sfaccettature con fiducia e
  storia; il nucleo (identità, valori, stile) lo cambia solo l'utente;
  capacità misurate dagli esiti; «non lo so» diventa una lacuna con un piano.
- **Ciclo principale** (`cervello.py`), **fornitori** (`fornitori.py`: Claude
  con l'SDK ufficiale, protocollo chat/completions, Gemini, con riserva),
  **voce** (`voce.py`), **servizio** sempre attivo con gettone e relè degli
  strumenti (`servizio.py`), **prompt di sistema** (`prompt/sistema.md`).
- **Ponte** (`ponte/`): gli strumenti di BioSpecInfo esposti via WebMCP e via
  relè (`biospecinfo-strumenti.js`); il progetto dell'app Android per gli
  occhiali (`android/PonteOcchiali.kt`).
- **47 prove** (`prove/`), senza rete e senza chiavi.

### Onestà
- Nessuna chiamata a un modello vero è stata fatta: i fornitori sono scritti
  secondo la documentazione, da provare con una chiave.
- Il ponte Android **non è compilato**; l'adattatore del toolkit degli occhiali
  è da completare sul riferimento della versione installata.
- WebMCP è un'anteprima dietro un'opzione di Chrome: qui è provato contro un
  oggetto finto con la forma documentata.
- Il dettaglio, voce per voce, è in `spectra2/README.md`, sezione 7.

### Aggiunto dopo la v250 (`spectra2/`): continuità, assistente personale, più dispositivi
Richiesta dell'autore: non un assistente ma una presenza continua, la stessa su
computer, Android, iPhone e occhiali, che risponde al nome «Spectra» e fa anche
da assistente di ogni giorno. L'app BioSpecInfo non cambia.
- **Continuità** (`spectra/presenza.py`): a ogni turno il blocco `[CONTINUITÀ]`
  dice quanto tempo è passato, da quale dispositivo parlava e da quale parla
  ora, e che cosa Spectra ha fatto da solo nel frattempo, letto dal registro.
- **Una conversazione, più dispositivi**: la sessione è una; ogni turno diventa
  un evento che gli altri dispositivi mostrano; ciò che Spectra dice di sua
  iniziativa lo dice **un solo** dispositivo, l'ultimo usato.
- **Battito**: ogni 30 secondi il servizio controlla se un promemoria è giunto
  all'ora o se c'è un'iniziativa che vale l'interruzione.
- **Agenda** (`spectra/memoria/agenda.py`): promemoria, compiti, eventi; date
  dette a parole («domani alle 18», «fra due ore»); ricorrenze, rinvii. Una
  data non capita viene rifiutata e chiesta, non indovinata.
- **Client web** (`client/index.html`), servito dal servizio stesso: testo,
  voce, e l'ascolto del nome «Spectra» come parola di attivazione.
- **Ponte per gli occhiali**: ascolto del nome sul telefono, stessa
  conversazione degli altri dispositivi, promemoria detti negli occhiali.
- **Documenti**: `IDENTITA.md`, `GUIDA.md` (passo per passo, per chi non
  programma), `PROMEMORIA.md` (per riprendere il lavoro in una nuova
  conversazione).
- Prove: da 47 a **60**, fra cui il client in un browser vero con un computer
  e un iPhone emulato.

### Limiti dichiarati
- Nessun turno con un modello vero è stato ancora eseguito.
- Il ponte Android non è mai stato compilato; «Hey Meta» resta di Meta, e
  Spectra risponde al suo nome solo con l'ascolto acceso sul telefono.
- Una pagina web non ascolta con lo schermo spento: è un limite di Android e
  iOS. Voce e microfono veri non sono stati provati su un telefono.

---
## [bsi-v249] — 2026-11-11

**Il giro di controllo di tutta l'app: 197 sezioni e 14 pagine aperte una per una**

Richiesta dell'autore: «deve essere controllato al massimo». I banchi provano
a fondo le singole funzioni, ma nessuno apriva tutte le sezioni una per una.
Fatto il giro, a misura di telefono e di computer, è emerso questo.

### Corretto
- **Sei sezioni aprivano la sezione sbagliata** quando le si chiedeva dal
  navigatore di Spectra, da «🧠 Spiega» o dall'elenco dell'ologramma: «Orbitali
  MO» apriva «Molecola», «Calcolatore» apriva «Calc. Avanz.», «Quiz» apriva
  «Quiz Spettri», «Tutto su una molecola» apriva «Centro spettri», e così
  «Diagrammi di distribuzione» e «Guida all'uso». La ricerca per somiglianza
  del nome vinceva sull'identificativo: ora l'identificativo esatto viene
  prima (`bsi-spectra-live.js`, `apriSezione`).
- **36 reazioni della sezione «Sintesi Org.» comparivano come «undefined»**,
  senza titolo e senza schema: erano scritte con un altro schema di campi. Ora
  sono portate allo schema della banca (`bsiNormRXN`).
- **Quattro pagine sbordavano in orizzontale sul telefono**: Chimica Organica
  1+2 (155 px, per le tabelle larghe: ora scorrono nel loro riquadro), Guida
  alla retrosintesi (107 px, la barra in alto), Accademia (12 px) e i due
  eserciziari di sintesi (9 px, il campo di ricerca).

### Aggiunto
- Banco **`test_giro`** (24 controlli): rifà il giro a ogni versione.
  Requisito STA-10; batteria a 89 banchi.

### Onestà
- Il giro controlla che ogni sezione si apra, non sia vuota e non mostri
  valori mancanti; non giudica la correttezza scientifica del contenuto, che
  resta ai banchi dedicati.

---
## [bsi-v248] — 2026-11-11

**L'ologramma interattivo mostra tutta l'app (197 sezioni e il menu ✨) e si legge bene sul telefono; corpo più leggero; voce ricontrollata per Android; PDF impaginati meglio**

Schermata dell'autore dall'ologramma interattivo sul telefono: «non sento
nulla» e «non c'è abbastanza spazio: fammi scorrere la sezione verso il basso
per leggere tutto». Nella schermata i passaggi stavano in una striscia in
fondo, sotto i tasti di Android, e la barra di stato mostrava l'icona del
**muto**.

### Cambiato
- `bsi-spectra-olointerattivo.js`, sul telefono (≤ 820 px): **tutta la
  finestra scorre**. La testata resta in alto (senza il titolo, per stare in
  meno righe), poi Spectra (170 px), il grafico, i comandi e i passaggi per
  intero, a 15,5 px, con 130 px di spazio in fondo per i tasti del telefono.
  Prima Spectra e il grafico erano fissi e ai passaggi restava il 20 % dello
  schermo.

### Aggiunto
- **«🔔 Prova audio»** nell'ologramma interattivo e nel comando «prova la
  voce»: un bip con Web Audio (non dipende dal motore vocale) e una frase di
  prova, con la spiegazione: se non si sente nemmeno il bip il telefono è in
  muto o il volume «Multimedia» è a zero; se si sente il bip ma non la voce,
  manca la voce del telefono (`BSISpectraLive.provaAudio()`).

- **«🗂️ Tutta l'app» nell'ologramma interattivo** (richiesta: «l'ologramma è
  impostato solo su alcuni argomenti: voglio selezionare io ogni cosa
  dell'app, dalla Tavola Periodica ai pianeti»). Un elenco di **tutte le 197
  sezioni** (letto dal catalogo dell'app, non scritto a mano), filtrabile per
  materia e per nome. Scelta una sezione: se ha grafici o scene 3D si vede
  **dal vivo** nel riquadro (4 volte al secondo); se è fatta di testo e
  tabelle (la Tavola Periodica) viene **ospitata** nel riquadro, cioè la
  sezione vera viene spostata lì, con i suoi tocchi che funzionano, e rimessa
  al suo posto dopo. I passaggi sono la lezione che l'app costruisce dalla
  sezione; Spectra li dice a voce. «↗ Apri la sezione» porta alla sezione
  vera; chiusa la finestra si torna da dove si era partiti.
- **Anche il menu ✨ nell'ologramma** (schermate dell'autore: «mancano la
  sezione Astro, il Centro spettri… deve esserci tutto»): all'elenco si
  aggiungono le 15 voci del menu ✨, lette dal menu stesso. Le 8 **pagine**
  (Astrochimica 3D PRO, Accademia, Chimica Organica 1+2, RDKit Lab, PRO Hub,
  Simulazioni, Guida alla retrosintesi, Documentazione) si aprono **dentro il
  riquadro**, vere e usabili; le 7 **finestre** (Lab Quantistico, Editor di
  struttura, Sintesi & Retrosintesi, Sfida, Glossario, Costanti J, Esporta
  figure) si aprono con «↗ Apri la sezione». Restano fuori le voci di
  servizio (impostazioni, aggiornamenti, installa, stampa, File Manager con
  password). Il Centro spettri era già fra le 197 sezioni. In tutto 212 voci.
- **La voce, ricontrollata per Android** (`bsi-spectra-live.js`,
  `bsi-ai-hub.js`, `bsi-spectra-voce.js`): (1) al primo tocco non si manda più
  la frase vuota «di sblocco» (serve a iPhone; certi motori vocali di Android
  si bloccano su una frase di soli spazi e lasciano in coda tutto il resto);
  (2) dopo un annullamento la frase nuova parte 160 ms dopo (parlare subito
  la fa cadere); (3) non si sceglie più la voce per nome (può essere una voce
  «di rete», muta senza risposta): si dichiara la lingua e il telefono usa la
  sua voce predefinita; (4) l'enunciato si tiene in vita finché parla.
  `test_voce` a 21 controlli.
- **I PDF dei documenti** (`tools/genera-pdf.js`), per l'azienda, il tirocinio
  e la tesi: una riga di tabella lunga ora **continua nella pagina seguente**
  con l'intestazione ripetuta (prima non poteva spezzarsi e lasciava mezze
  pagine bianche: la Matrice di tracciabilità passa da 37 a 31 pagine); le
  tabelle senza titoli non stampano più una riga d'intestazione vuota; il
  frontespizio non ripete «BioSpecInfo» nel titolo.
  **Controllati tutti i 36 PDF, pagina per pagina** (893 pagine, analisi
  automatica dell'inchiostro di ogni pagina più un campione a vista): nessun
  testo fuori dai margini, nessun carattere mancante, tutti i caratteri
  incorporati. Tre difetti trovati e tolti: una pagina finale con la sola riga
  «Generato il…» (SBOM); mezza pagina bianca prima di un blocco di codice
  lungo (la specifica OpenAPI, ora continua di pagina); una pagina tutta
  bianca nel dossier completo inglese, quando un documento finiva proprio a
  fine pagina. Il corsivo scritto con i trattini bassi ora si stampa in
  corsivo. Nel dossier completo restano, volute, le fini di capitolo: ogni
  documento comincia a pagina nuova.
- **Impaginazione formale dei PDF** (richiesta: «con impaginazioni più formali
  e migliori»): ogni documento apre con un **frontespizio** con la fascia
  «Documentazione tecnica di progetto», il titolo e il **riquadro di controllo
  del documento** (identificativo `BSI-DOC-NN-IT/EN`, titolo, versione del
  software, revisione = commit, data di emissione, autore, lingua, stato),
  tutti ricavati dal repository; segue l'**indice** dei capitoli (se sono
  almeno quattro), con i collegamenti; ogni pagina ha la **testata** (titolo
  del documento e progetto, con un filo) e il **piè** (versione, revisione,
  data, autore, pagina / totale); il testo è **giustificato**, i margini più
  ampi. Pedici, apici e grassetti scritti in HTML nel sorgente (`<sub>`,
  `<sup>`, `<b>`) ora si stampano come tali; i riquadri lunghi continuano di
  pagina; la riga di chiusura non resta sola. Il dossier completo ha il suo
  frontespizio e il suo indice, in italiano e in inglese. Ricontrollate tutte
  le 1 004 pagine: nessuna pagina bianca, nessun testo fuori dai margini.

- **Il corpo di Spectra più leggero** su telefoni e tablet (richiesta:
  «alleggerisci il corpo»): le tre mappe del corpo a 1024 px invece di 2048
  (un quarto dei pixel da ricolorare all'apertura e da tenere in memoria
  grafica), rapporto di pixel fino a 2 invece di 2,5, 30 fotogrammi al
  secondo invece di 60. Sul computer e nello studio resta la definizione
  piena. `test_spectra_figura` a 111 controlli.

### Onestà
- L'app non può sapere se il telefono è in muto né alzare il volume: può solo
  suonare e dire che cosa controllare.
- Il corpo leggero non è stato misurato su un telefono vero: il risparmio è
  quello dei pixel (un quarto per le mappe, circa un terzo in meno a
  fotogramma). Il calcolo dello scheletro all'apertura è rimasto com'era.

---
## [bsi-v247] — 2026-11-10

**Avvio più leggero: il motore chimico non si carica più da solo mentre si usa l'app**

Richiesta dell'autore: «ottimizza tutto». Prima si è misurato: profilo
dell'avvio su un telefono simulato lento (CPU ×4). Un solo compito bloccava lo
schermo per ~2 s, pochi secondi dopo l'apertura: il caricamento di RDKit
(6,7 MB di wasm) e l'indicizzazione di tutte le molecole, partiti da soli.

### Cambiato
- `bsi-pannelli-lingua.js`: l'archivio dei nomi di «Linguaggi delle molecole»
  non si costruisce più 3 s dopo l'avvio, ma quando si apre il convertitore.
- `bsi-spettri.js`: RDKit si scalda solo nella materia Chimica, solo quando
  l'app è ferma da 4 secondi (nessun tocco, tasto o scorrimento) e mai con
  «Risparmio dati». Chi apre una sezione che lo usa lo carica subito, come
  prima.

### Misurato (telefono simulato lento, Chimica)
- blocco più lungo dell'avvio: da ~1960 ms a ~250 ms;
- tempo di blocco totale: da ~2560 ms a ~640–815 ms;
- chi studia Fisica o Matematica non scarica né avvia RDKit all'apertura.

### Verifiche
- Banco **`test_avvio`** (9 controlli sui comportamenti); requisito STA-09;
  batteria a 88 banchi.

### Onestà
- I millisecondi vengono da una CPU rallentata in simulazione, non da un
  telefono vero: dicono la proporzione del guadagno, non il valore assoluto.
- Il primo caricamento di Spectra col corpo resta pesante (lo scheletro si
  calcola nel browser): non è stato toccato in questa versione.

---
## [bsi-v246] — 2026-11-10

**La voce robotica di Spectra nella Chat: ogni risposta si ascolta, anche da sola**

Richiesta dell'autore: ogni risposta di Spectra deve potersi leggere ad alta
voce con una voce maschile robotica, bassa e fredda («stile Ultron»), solo con
la Web Speech API del browser (niente librerie né servizi a pagamento, anche
offline), con pitch 0,58, rate 0,88, volume 1; un pulsante 🔊 su ogni
risposta; «Leggi automaticamente» ricordato; stop chiudendo la chat o
cambiando sezione.

### Aggiunto
- `bsi-ai-hub.js`: `speakRobotic(testo)`, `stopSpeaking()`,
  `toggleAutoSpeak()`, `createSpeakButton(testo)` (anche globali, con questi
  nomi). Voce italiana maschile → italiana → maschile → la prima; si riscelgono
  quando il browser le carica in ritardo.
- Nella barra della Chat l'interruttore **«🔊 Leggi automaticamente»**
  (`localStorage` `spectraAutoSpeak`): a fine risposta Spectra la legge da
  sola, col suo pulsante acceso (non se la console Spectra Live è aperta, che
  ha già la sua voce).
- Il pulsante **«🔊 Ascolta»** di ogni risposta diventa **«⏹ Ferma»** mentre
  legge; senza sintesi vocale non compare.
- La figura di Spectra muove le labbra mentre legge.
- Banco **`test_voce`** (17 controlli); requisito UI-33; batteria a 87 banchi.

### Cambiato
- Il vecchio «🔊 Ascolta» leggeva solo i primi **600 caratteri**, con la voce
  predefinita, e annullava sempre prima di parlare (su Android fa cadere la
  frase): ora legge la risposta **intera**, a frasi, ripulita da markdown e
  formule, e annulla solo se c'è qualcosa in corso.
- La console Spectra Live e il ripiego della voce di qualità usano gli stessi
  parametri (0,58 / 0,88): Spectra ha la stessa voce ovunque.

---
## [bsi-v245] — 2026-11-06

**Nuova frase segreta dell'autore, per il File Manager e per Spectra**

L'autore non ricordava la frase impostata alla `bsi-v188` e ne ha scelta una
nuova. Come sempre, nel codice c'è solo la sua impronta SHA-256
(`file_manager.html` · `CORRECT_HASH`, `bsi-spectra-creatore.js` ·
`IMPRONTA`, la stessa nei due file); il testo non compare nel repository.
La frase precedente non apre più nulla. Su un dispositivo dove Spectra aveva
già riconosciuto il creatore il riconoscimento resta; per legare l'impronta
del dito serve la frase nuova.

### Corretto
- **La voce che si accavallava**: quando Spectra cominciava a parlare mentre
  un discorso precedente era rimasto a metà (un timer o un «onend» in
  ritardo), il vecchio discorso riprendeva insieme al nuovo. Ora ogni
  discorso ha il suo numero e uno vecchio non riparte (`bsi-spectra-live.js`,
  `parla()`/`taci()`). Trovato da `test_impronta`, che vedeva arrivare 5
  frasi invece di 2.

### Verificato
- Con la frase nuova Spectra riconosce il creatore e il File Manager si apre;
  la stessa frase con un carattere in più è rifiutata da entrambi.

---
## [bsi-v244] — 2026-11-05

**«sono il tuo creatore» anche dalla Chat; Gemini sovraccarico passa da solo a un altro modello**

Schermata dell'autore sulla v243: nella scheda 💬 Chat «sono il tuo creatore»
→ «⚠ Google Gemini Flash è sovraccarico in questo momento — ho già riprovato
4 volte… [503]». «Risolvi tutto».

### Corretto
- **«sono il tuo creatore» scritto nella scheda 💬 Chat** finiva al modello
  (e con Gemini sovraccarico, a un errore 503). Le frasi su Spectra stesso
  — il creatore, l'impronta, «prova la voce» — ora chiudono la finestra
  dell'AI e aprono la console Spectra Live, che ha il campo nascosto per la
  frase segreta e il sensore.
- **Gemini sovraccarico con una sola chiave** («ho già riprovato 4 volte» e
  poi niente): un 503 «This model is currently experiencing high demand»
  riguarda quel modello, non la chiave. Ora si passa **subito** a un altro
  modello candidato dello stesso fornitore con la stessa chiave (il modello
  sovraccarico resta da parte 10 minuti, non viene bocciato); solo quando non
  resta nessun candidato si aspetta e poi si passa a un altro fornitore. La
  nota in chat dice «è sovraccarico, passo a …».

### Verifiche
- `test_impronta` a 25 controlli (la frase dalla Chat, Gemini 503 → un altro
  modello in meno di 5 s); `test_503` aggiornato: tre modelli diversi senza
  attese, e solo finiti i candidati la riserva su un altro fornitore.

---
## [bsi-v243] — 2026-11-05

**La voce di Spectra che si sente anche sul telefono; il creatore riconosciuto dall'impronta, solo lui**

Richiesta dell'autore sulla v242: «Funziona tutto alla perfezione tranne che
non sento la voce; inoltre vorrei che fossi io con un riconoscimento impronta
o qualcosa del genere, però solo con me».

### Corretto
- **La voce muta sul telefono** (`bsi-spectra-live.js`, `parla()`): se il
  motore vocale non mandava «onstart» entro 1,2 s, la frase veniva
  **annullata** e restava il solo labiale; su Android il motore ci mette
  spesso di più. Ora, finché il browser dice che sta parlando o ha la frase in
  coda, si aspetta (fino a ~8 s); «onend» porta avanti anche senza «onstart»;
  si annulla solo se c'è qualcosa in corso, e la sintesi si riprende
  (`resume`) prima di parlare.
- **Sblocco al primo tocco**: una frase vuota a volume zero e il contesto audio
  della voce di qualità ripreso dentro un gesto (`BSISpectraVoce.sblocca()`);
  un contesto audio ancora sospeso passa alla voce del sistema invece di
  suonare in silenzio; le voci, che il browser carica in ritardo, si
  riscelgono quando arrivano.

### Aggiunto
- **«prova la voce» / «non ti sento»** nella console: Spectra dice quale voce
  usa e quante ne vede; se il telefono non ne ha, spiega dove scaricare la
  voce italiana su Android e di controllare il volume dei contenuti
  multimediali. `BSISpectraLive.statoVoce()`.
- **L'impronta del creatore** (`bsi-spectra-creatore.js`, WebAuthn, lo
  standard dei passkey): dopo la frase segreta Spectra propone «👆 Attiva
  l'impronta»; il sensore del telefono (impronta o volto) verifica la persona
  **dentro il telefono** e l'app riceve solo una risposta firmata; si
  conserva solo l'identificativo della credenziale. Da quel momento, su quel
  telefono, Spectra riconosce il creatore **solo dopo l'impronta**, una volta
  per sessione: all'apertura della console chiede «Sei tu, Samuele?» con
  «👆 Sono io». Comandi «attiva l'impronta», «riconoscimi»; «dimentica che
  sono il tuo creatore» toglie anche l'impronta. Per tutti gli altri l'app
  resta com'è.
- Banco **`test_impronta`** (22 controlli, autenticatore virtuale di
  Chromium e sintesi vocale finta e lenta); batteria a 86 banchi.
  Requisiti SEC-10 e UI-32.

### Onestà
- Senza un server la verifica dell'impronta avviene nel browser: come la frase
  segreta, è una serratura contro chi passa, non contro chi ha il telefono e
  vuole forzarla. Il sensore accetta ogni impronta registrata nel telefono:
  se altre persone vi hanno registrato la loro, vale anche quella.
- Che la voce **si senta** su un telefono vero non si può provare da qui: il
  banco prova che non viene più annullata.

---
## [bsi-v242] — 2026-11-05

**«⚡ Esplora con Spectra»: una sezione per materia nello stile delle lezioni esplorabili; l'ologramma interattivo («⛶ Interagisci»); Spectra col corpo anche nella console Spectra Live**

Richiesta dell'autore, guardando la console Spectra Live: «Esce ancora così
(il busto) e soprattutto non c'è la sezione richiesta per ogni materia come
every-joule».

### Aggiunto
- **`bsi-spectra-esplora.js`** (oggetto globale `BSIEsplora`): tre sezioni
  nuove, una per materia, nella barra della loro materia subito dopo il
  pulsante «Area … · assistente»: **«⚡ Esplora la chimica con Spectra»**
  (`sesplchim`), **«⚡ Esplora la fisica con Spectra»** (`sesplfis`),
  **«⚡ Esplora la matematica con Spectra»** (`sesplmat`). Sono registrate con
  il framework delle sezioni `BSIFisica` (una scheda, «⚡ Esplora»).
  - **Una pagina da scorrere**, nello stile delle lezioni esplorabili
    (every-joule). **Spectra col corpo resta in scena in alto mentre si
    scorre** (la figura condivisa, `position: sticky` subito sotto la testata
    fissa dell'app, misurata da sé; sul telefono più bassa,
    `clamp(220px, 32vh, 280px)`); l'ologramma cambia con il capitolo che si ha
    davanti.
  - **Dieci capitoli per materia, dalla Scuola superiore al PhD avanzato ·
    frontiera.**
    Chimica: l'atomo e l'energia di ionizzazione; la forma delle molecole
    (VSEPR); il pH di un acido forte molto diluito; il tampone e
    Henderson–Hasselbalch; la cinetica del primo ordine; la spettroscopia IR;
    l'¹H-NMR e l'accoppiamento spin–spin; gli orbitali molecolari (perché O₂ è
    magnetico); la teoria di Marcus e la regione invertita; la frontiera:
    l'errore di delocalizzazione della DFT.
    Fisica: la caduta dei gravi; il moto del proiettile; le leggi di Keplero;
    il pendolo; il rendimento di Carnot; l'interferenza da due fenditure; la
    particella in una scatola; l'effetto tunnel; la dilatazione del tempo e i
    muoni; la frontiera: le onde gravitazionali (GW150914).
    Matematica: la derivata come pendenza; il numero e; l'integrale e il
    logaritmo; la serie di Basilea; la serie armonica; gli autovalori della
    rotazione del piano; la serie di Fourier e il fenomeno di Gibbs; l'analisi
    complessa e i residui; l'equazione del calore; la frontiera: l'ipotesi di
    Riemann.
  - **Ogni capitolo**: il fenomeno in poche righe esatte; **🔮 Prevedi**, una
    domanda con quattro risposte (fra cui le idee sbagliate più comuni);
    scelta la risposta, la rivelazione — giusta o no, e **perché ciascuna
    risposta è giusta o sbagliata** — e Spectra reagisce (gioia se giusta,
    sorpresa se no); **🧪 Prova**, in 19 capitoli su 30, un cursore che
    ricalcola davvero la grandezza (pH con l'autoprotolisi dell'acqua,
    Henderson–Hasselbalch, t½, ΔG‡ di Marcus e velocità relativa, tempo di
    caduta, gittata, periodo del pendolo, Carnot, E₁ della particella in una
    scatola, trasmissione per effetto tunnel, γ e percorso medio dei muoni,
    derivata, (1+1/n)ⁿ, ln b, somme parziali di Basilea con la coda fra
    1/(N+1) e 1/N, H_N contro ln N + γ, autovalori della rotazione, massimo di
    Gibbs calcolato numericamente, decadimento di un modo dell'equazione del
    calore); **«📺 Guardalo dal vivo»** apre la sezione dell'app collegata
    dietro la finestra di Spectra (scheda «🧠 Spiega») e l'ologramma la mostra
    dal vivo; chiusa la finestra, si torna alla sezione Esplora; **«🧠
    Spiegamelo tutto»** chiede a «🧠 Spiega» la spiegazione al livello del
    capitolo, con lo schermo della sezione; **«🔊 Ascolta Spectra»** legge il
    capitolo con la voce di Spectra Live.
  - **Scorrendo**, il capitolo che attraversa il centro dello spazio libero
    sotto Spectra diventa «attivo» (funziona anche per i capitoli più alti
    dello schermo): Spectra lo racconta (labiale e gesti, evento
    `bsi-spectra-dice`) e l'ologramma prende la sua scena.
  - **La memoria**: le previsioni fatte, giuste o sbagliate, per capitolo
    (`localStorage`, chiave `bsi-esplora-v1`) e la barra dei progressi
    «n/10»; un capitolo già previsto mostra «Già previsto ✓/✗» e si può
    rivedere senza ripetere la reazione. Si cancella con «Cancella dati →
    Memoria persistente».
  - API: `BSIEsplora.CAPITOLI`, `calcola(id, valore)`, `costruisci(materia,
    pannello)`, `gibbsMax(N)`, `SEZIONI`, `MEM`.
- **L'ologramma interattivo, «⛶ Interagisci»** (`bsi-spectra-olointerattivo.js`,
  oggetto globale `BSIOloInterattivo`). Richiesta dell'autore: «selezionare
  l'ologramma e, una volta fatto, interagire: nei grafici i vari passaggi e i
  dati, che significato hanno e come ci si è arrivati; nei pianeti o
  nell'universo tutto ciò che li riguarda; negli spettri vederli modificare in
  base alla traccia e ai dati che scrivo, selezionando i vari tipi di spettri;
  in matematica o fisica, in base a cosa chiedo, l'ologramma si modifica in
  tempo reale; tutto spiegato sia a voce da Spectra sia dettagliatamente, ogni
  passaggio per iscritto».
  - **Il pulsante «⛶ Interagisci»** sta sull'ologramma, ovunque ci sia la
    figura (sezioni dell'AI, sezioni Esplora, finestra «🧠 Spiega», console
    Spectra Live). Apre una finestra a tutto schermo (`#bsi-olo-ov`, chiamata
    come le altre sovrapposizioni dell'app, così i pulsanti flottanti si
    nascondono da soli con `_bsiSyncFabs`) con Spectra col corpo (la figura
    condivisa ci si sposta), l'ologramma grande e il pannello dei passaggi. La
    modalità si sceglie da ciò che l'ologramma stava mostrando.
  - **🧪 Spettri**: IR, ¹H-NMR (campo da 60 a 600 MHz, con un riquadro
    ingrandito del multipletto scelto, così si vedono la struttura n+1 e
    J/ν₀), ¹³C-NMR, massa (EI), UV-Vis. Sei molecole di riferimento con
    valori tipici di letteratura (acetone, etanolo, acido acetico, benzene,
    toluene, acetato di etile), oppure **la traccia scritta dall'utente**
    («1715 s, 2950 m, 3300 br» · «2.17 s 6H; 1.2 t 3H J=7» · «58 30, 43 100» ·
    «254 200»): lo spettro si ridisegna mentre si scrive. Ogni segnale è un
    passaggio: posizione, forma, attribuzione e **perché**, dalle tabelle delle
    frequenze di gruppo, degli spostamenti chimici e delle perdite neutre; la
    forma della banda conta (una banda stretta non si attribuisce mai a un
    O–H carbossilico). Per le molecole: formula, massa molare e grado di
    insaturazione C − H/2 + N/2 + 1.
  - **🪐 Universo**: gli otto pianeti (valori della scheda NASA: semiasse,
    eccentricità, periodo, massa, raggio, lune al 2024), in 3D con le orbite
    di Keplero (equazione di Keplero risolta a ogni fotogramma; distanze
    compresse come √a). Si tocca un pianeta; i passaggi: terza legge di
    Keplero, perielio e afelio, velocità dalla vis-viva con il rapporto
    (1+e)/(1−e), gravità in superficie, velocità di fuga. Oppure un'orbita
    scritta («a=2 e=0,6»).
  - **📐 Matematica** e **⚛️ Fisica e chimica**: la domanda la risolve
    l'assistente dell'app (`bsi-assistente.js`, con il motore simbolico
    `bsi-mat-cas.js`): **i passaggi sono calcolati, non scritti da un
    modello**. Il grafico segue: la funzione con la derivata, gli zeri e i
    punti stazionari, con la finestra adattata a loro; la traiettoria del
    proiettile con quota massima e gittata; il pendolo che oscilla con il suo
    periodo; per gli altri problemi, i risultati.
  - **«🔊 Spectra spiega i passaggi»** li legge uno per uno con la voce di
    Spectra Live, evidenziando ciascuno nel testo e nell'ologramma; toccando
    un picco, un pianeta o un passaggio si va a quel passaggio e Spectra lo
    dice; **«🧠 Approfondisci»** apre «🧠 Spiega» con i dati dell'ologramma.
    Chiusa la finestra, Spectra torna nella sezione.
  - API: `apri(modo, testo)`, `chiudi()`, `modo()`, `stato()`,
    `imposta(testo)`, `scegli(i)`, `SPETTRI`, `PIANETI`, `spettro(tipo,
    molecola|traccia, { MHz })`, `pianeta(nome|{a, e})`, `leggiTraccia`,
    `massa`, `insaturazione`. Evento `bsi-olo-interattivo` (`{ aperto }`).
  - **Detto con onestà**: gli spettri di riferimento sono valori tipici di
    letteratura per la didattica, non spettri misurati; l'interprete della
    traccia dà attribuzioni candidate dalle tabelle, non una
    determinazione della struttura.

### Cambiato
- **La console Spectra Live mostra Spectra col corpo e l'ologramma al posto
  del busto** (`bsi-spectra-figura.js`). Quando la console è aperta, la
  figura condivisa si sposta nella console (`#bsiJV-figura`, fra la
  telemetria e il dialogo; sullo schermo grande a destra) e il busto solo
  volto (`#bsiJV-volto`) è nascosto. Lo stato della console (attesa, ascolta,
  pensa, parla) guida la figura con l'evento `bsi-spectra-stato`: pensa →
  concentrata, mano al mento; ascolta → curiosa. Chiusa la console, la figura
  torna nella sezione.
- **Il catalogo di «🧠 Spiega»** ha ora **197 sezioni** (chimica 76, fisica
  61, matematica 31, comuni 29): le tre sezioni Esplora compaiono da sole.
  Le sezioni Esplora contano come sezioni dell'AI (`bsi-spectra-spiega.js`):
  chiudendo la finestra di Spectra si torna lì.
- **«Cancella dati → Memoria persistente»** cancella anche `bsi-esplora-v1`
  (`bsi-ai-hub.js`).

### Corretto
- **Ricorsione infinita fra la console e la figura**, trovata dal banco:
  la console emette ora `bsi-spectra-stato` per la figura, e ascoltava lo
  stesso evento. L'evento della console porta la firma `daLive: true` e la
  console ignora i propri eventi.

### Banco
- Nuovo **`test_spectra_esplora`** (75 controlli). In node, per ogni
  materia: dieci capitoli; livelli da 0 a 4 in ordine; previsioni ben
  formate (quattro risposte, l'indice della giusta, un perché per ognuna);
  identificativi unici. Poi 22 controlli numerici dei cursori contro le
  formule: pH di HCl 10⁻⁸ M = 6,978 con l'autoprotolisi; 10⁻² M = 2;
  Henderson–Hasselbalch pH = pKa a rapporto 1; t½ = 6,931 s a k = 0,1 s⁻¹;
  barriera di Marcus nulla a ΔG° = −λ e λ/4 a −2λ; caduta da 20 m in
  2,019 s; gittata a 45° 40,775 m; pendolo da 1 m 2,006 s; Carnot 600/300 K =
  0,5; scatola di 1 nm 0,376 eV e ×4 dimezzandola; tunnel, spessore doppio =
  trasmissione al quadrato; γ dei muoni 31,63 a 0,9995c; derivata 12; e entro
  2·10⁻⁶ con n = 10⁶; ∫₁ᵉ dx/x = 1; Basilea con 10⁵ termini = π²/6 − 10⁻⁵;
  armonica con 1000 termini 7,4855; autovalori della rotazione ±i; massimo di
  Gibbs ≈ 1,179 con 201 termini; modo del calore e^(−0,4). Nel browser, a 412
  e 1280 px: le tre sezioni nella barra della loro materia, ogni sezione
  collegata esiste; per ogni materia dieci capitoli e Spectra nella sezione,
  sticky, ancora in vista dopo lo scorrimento; il capitolo davanti è attivo e
  l'ologramma prende la sua scena; prevedere segna la giusta e la sbagliata
  con il perché di ogni risposta e Spectra reagisce (sorpresa); memoria e
  barra (1/10); il cursore ricalcola; a 412 px niente sborda; «📺 Guardalo dal
  vivo» apre la sezione dietro la finestra di Spectra con l'ologramma dal
  vivo, e chiudendo si torna alla sezione Esplora; nessun errore JavaScript.
- Nuovo **`test_spectra_olo`** (46 controlli: 15 in node, 16 a 412 px, 15 a
  1280 px). In node: sei molecole con i cinque spettri; massa molare
  dell'acetone 58,08 g/mol; insaturazione benzene 4, acetone 1, etanolo 0;
  tripletto del CH₃ largo 2J/ν₀ a 400 MHz, 10 volte più largo a 60 che a
  600 MHz; traccia IR (1715 → C=O; 2950 stretta → C–H sp³, non O–H acido;
  3300 larga → O–H); traccia MS (58 → ione molecolare; 43 → M − 15 e
  acilio); Terra T = 1 anno, vis-viva 30,29 / 29,29 km/s; Marte rapporto
  (1+e)/(1−e); gravità di Marte 3,71 m/s²; fuga dalla Terra 11,19 km/s;
  un'orbita scritta a = 4 UA → T = 8 anni. Nel browser, per larghezza: il
  pulsante apre la finestra in «spettri»; la figura ci si sposta; i pulsanti
  flottanti spariscono; cambio di tipo e traccia scritta ridisegnano e
  rifanno i passaggi; traccia di massa con due passaggi; toccando il picco 43
  si sceglie il suo passaggio e Spectra lo dice; Marte con sei passaggi nella
  scena 3D; matematica: zeri −√3, 0, √3 e punti stazionari ±1, almeno otto
  passaggi dell'assistente; proiettile, gittata 35,31 m; pendolo da 2 m,
  2,837 s; la voce dice tutti i passaggi; a 412 px niente sborda;
  «🧠 Approfondisci» apre Spiega; Spectra torna nella sezione; nessun errore
  JavaScript.
- `test_spectra_figura` passa a **109 controlli** (55 a 412 px, 54 a
  1280 px): +3 per larghezza sulla console (la figura al posto del busto; lo
  stato → mano al mento; chiusa la console, la figura torna nella sezione).
  Il controllo sugli SVG ora inserisce nella sezione aperta uno spettro SVG
  noto (deterministico) invece di dipendere dal quiz degli spettri, che è
  casuale; la misura del viso sul colletto aspetta il regime.
- La batteria passa da 83 a 85 banchi. I file tracciati esaminati da
  `verifica-sicurezza` passano da 570 a 577: +4 di questa versione
  (`bsi-spectra-esplora.js`, `tools/banchi/test_spectra_esplora.js`,
  `bsi-spectra-olointerattivo.js`, `tools/banchi/test_spectra_olo.js`) e +3
  dalla consegna della v241 (le copie di `impacchetta-corpo.js` nei pacchetti
  AZIENDA, COMPLETO e TESI).

### Non incluso
- I banchi controllano i numeri, la struttura e il comportamento delle
  sezioni Esplora, non la qualità didattica dei testi né la voce.
- L'ologramma interattivo non legge spettri misurati da file (per quello c'è
  il lettore di spettri) e non deduce una struttura da una traccia: propone
  attribuzioni candidate.

---
## [bsi-v241] — 2026-11-05

**Il corpo di Spectra sempre presente, incorporato nell'app; tolto il pulsante «🧍 Corpo»**

Richiesta dell'autore: «la sezione Corpo non la voglio: vorrei che fosse
sempre presente e non dover sempre mettere il corpo di Spectra».

### Aggiunto
- **Il corpo incorporato: `models/spectra-corpo.bsi`** (4,40 MB). Il corpo di
  Spectra (il «Bounty Hunter», gratuito su CGTrader, licenza Royalty Free di
  CGTrader: si usa dentro un prodotto, non si offre come file a sé) c'è ora
  **sempre, per tutti**, senza caricarlo. Non è pubblicato come `.glb`: è un
  blocco impacchettato che solo il codice dell'app riapre
  (`bsi-spectra-figura.js`, funzione `apri`). Formato «BSIC»: 4 byte di
  firma · 1 byte di versione · 4 byte di lunghezza (little endian) · i byte
  del `.glb` mescolati (XOR) con un flusso xorshift32 da un seme fisso.
  **Detto con onestà**: non è una protezione assoluta (nessun modello
  mostrato su uno schermo lo è); è il modo in cui giochi e app incorporano i
  modelli acquistati, e il file pubblicato non è un `.glb` riutilizzabile. Il
  `.glb` originale resta fuori da git (`.gitignore`).
- **`tools/impacchetta-corpo.js`**: produce il blocco dal `.glb`
  (`node tools/impacchetta-corpo.js <corpo.glb> [models/spectra-corpo.bsi]`)
  e verifica che si riapra identico al `.glb`.

### Cambiato
- **`Spectra.carica()`** scarica `models/spectra-corpo.bsi`, lo riapre e lo
  rigga come prima (rig automatico, cappuccio, viso «Noir» sul colletto).
  Mentre arriva, la figura e lo studio mostrano «Spectra sta arrivando…»; se
  non arriva (nessuna rete al primo avvio), «Spectra non è arrivato: serve
  la rete la prima volta» con **«↻ Riprova»**. Dopo il primo caricamento il
  service worker (prima la rete) lo tiene in cache, quindi funziona anche
  senza rete. Solo nello studio, in sviluppo, se il blocco manca si prova
  ancora `models/spectra-corpo.glb`; nell'app (`opz.soloDispositivo`, attivo
  per la figura) nessun file di sviluppo si chiede. Il ripiego su
  `models/spectra-cyberpunk.glb` non c'è più.
- **I pulsanti della figura** sono «🎙️ Parla con me», «🧠 Spiega», «🎓 Studio».

### Rimosso
- Il pulsante **«🧍 Corpo»** (nella testata dello studio e nella barra della
  figura), il campo file, l'invito a caricare il corpo e il metodo
  `Spectra.daFile`.
- **La conservazione del corpo dell'utente nell'IndexedDB**: all'avvio un
  vecchio corpo conservato in `bsi-spectra-modelli`, se c'è, si cancella per
  liberare spazio; «Cancella dati» continua a cancellare quel database.

### Banco
- `test_spectra_studio` passa a **87 controlli**. L'umanoide sintetico
  iniettato e i controlli «Corpo dal dispositivo» sono sostituiti, per ogni
  larghezza, da: il corpo di Spectra c'è sempre, senza caricarlo
  (incorporato), e l'avviso «sta arrivando» è sparito; nessun pulsante Corpo
  né scelta di file; il file pubblicato è un blocco impacchettato (BSIC), non
  un modello `.glb` riutilizzabile; un blocco che non è un modello viene
  rifiutato, senza errori. Tutti i controlli sul corpo riggato (mento sul
  colletto, sincronia viso–cappuccio 0,0 mm, solo il viso, volto solidale)
  girano ora sul **corpo vero incorporato**.
- `test_spectra_figura` resta a **103 controlli**: «senza corpo: invito»,
  «nessun sostituto» e il caricamento dell'umanoide sintetico sono
  sostituiti da «il corpo di Spectra c'è sempre, senza caricarlo:
  incorporato nell'app (ossa 20/23)» e «nessun pulsante Corpo né scelta di
  file (Parla con me, Spiega, Studio)»; tutti gli altri controlli girano sul
  corpo vero.
- I file tracciati passano da 568 a 570 (`models/spectra-corpo.bsi`,
  `tools/impacchetta-corpo.js`).

---
## [bsi-v240] — 2026-11-04

**Spectra col corpo in ogni sezione dell'AI, l'icona solo col volto, nessun sostituto; niente spazio vuoto sopra le sezioni fuori da `#main`**

Richiesta dell'autore: «l'icona di Spectra solo col volto, e la versione di
Spectra col corpo in ogni sezione dell'AI»; e, guardando la schermata della
lezione nello studio, «questo è quello che voglio per Spectra e non altro».

### Aggiunto
- **`bsi-spectra-figura.js`** (oggetto globale `BSISpectraFigura`): Spectra col
  corpo in un modulo solo, usato dallo studio e dalle sezioni dell'AI.
  - `Spectra(T, scena, renderer, opz)`: il controllore del corpo. Cerca il corpo
    nell'IndexedDB del dispositivo (`bsi-spectra-modelli`), poi in
    `models/spectra-corpo.glb` (solo in sviluppo), poi in
    `models/spectra-cyberpunk.glb`; **altrimenti niente**. Nell'app (non nello
    studio) la figura cerca il corpo **solo sul dispositivo** (`opz.soloDispositivo`):
    i due file di sviluppo non si chiedono, quindi nell'app pubblicata
    niente 404; lo studio li prova ancora (sviluppo). Il corpo passa dal
    rig automatico (`bsi-spectra-rig.js`); sul colletto va il viso «Noir»,
    allineato misurando il mento, del quale si vede solo il viso; il volto è
    «solidale». Metodi `carica`, `daFile`, `daBuffer`, `usaScena`, `passo`,
    `emozione`, `dici`, `taci`, `fai`, `presente`.
  - `monta(contenitore)`: un riquadro con Spectra in piedi, intero, nello
    stile del laboratorio della lezione (pavimento a griglia al neon, pannelli
    olografici, pedana olografica, luci da studio); in sovrimpressione
    «SPECTRA · IN ASCOLTO / PENSA / PARLA»; pulsanti **«🧍 Corpo»**, **«🎙️ Parla
    con me»** (apre Spectra Live) e **«🎓 Studio»**. Si disegna solo quando è
    visibile e la pagina è in primo piano; i file 3D si caricano la prima
    volta che si apre una sezione dell'AI; rapporto di pixel fino a 2,5.
  - **Reagisce all'app**: `bsi-spectra-stato` (pensa, strumenti, scrive) →
    concentrato, mano al mento; `bsi-spectra-risposta` (la risposta del
    modello) → spiega con le mani, labiale di corpo e viso dal testo, emozione
    dal contenuto; un errore → dubbio; il nuovo evento **`bsi-spectra-dice`**,
    emesso da `parla()` di Spectra Live e dall'assistente locale
    (`bsi-assistente.js`) quando risolve un esercizio («Ecco lo svolgimento:
    …», oppure dubbio se non ha capito).
  - `sezioni()`: **una figura sola** (un contesto WebGL) spostata nella
    sezione dell'AI aperta: Spectra AI (`sai`) e le tre aree con l'assistente
    (`sareachim`, `sareafis`, `sareamat`), dopo il titolo, il pulsante
    «Lezione guidata» e la descrizione, prima delle schede. Sul telefono i
    suoi pulsanti stanno a sinistra, in colonna, per non coprire i pulsanti
    flottanti.
- **L'ologramma alla destra di Spectra** (`bsi-spectra-figura.js`,
  `BSISpectraFigura.Ologramma`). Richiesta dell'autore: «alla mia destra di
  Spectra appaiano le immagini dei grafici e dei movimenti delle sezioni in
  cui vi sono animazioni in 3D o 2D di ogni sezione, ad esempio pianeti che
  orbitano; deve essere mastodontica questa AI». Nella scena da laboratorio
  della figura, alla destra di Spectra (la destra di chi guarda), c'è uno
  schermo olografico: pannello di vetro con i bordi luminosi, base del
  proiettore con il fascio di luce. Spectra sta a sinistra del centro sulla
  sua pedana; l'inquadratura contiene Spectra intera e l'ologramma (2,55 m di
  larghezza, 2,2 m di altezza).
  - **Sei scene vive, calcolate** (non video): **pianeti** — quattro pianeti
    su ellissi di Keplero, con l'equazione di Keplero M = E − e sin E risolta
    a ogni fotogramma (Newton), periodi dalla terza legge (T ∝ a^1,5), più
    veloci al perielio; **molecola** — il benzene a sfere e bastoncini con la
    nube π sopra e sotto l'anello; **spettro** — uno spettro IR che si
    disegna da sé (bande gaussiane a 3400, 2925, 1715, 1405 e 1130 cm⁻¹) con
    un cursore che scorre; **superficie** — z = sin(r − t)/r che si propaga;
    **orbitale** — l'orbitale 3d_z² (due lobi e l'anello, le fasi in due
    colori) che ruota; **onda** — un pacchetto d'onda gaussiano che si muove
    e si allarga (dispersione di Schrödinger libera: parte reale, parte
    immaginaria e |ψ|²). In più **«schermo»**: la sezione aperta dietro la
    finestra di Spectra, dal vivo (la sua tela ridisegnata con
    `BSISpectraLive.cattura` e copiata nell'ologramma 5 volte al secondo).
    **Anche le sezioni senza grafici** (testo, tabelle, comandi) si
    proiettano: una scheda disegnata nell'ologramma (titolo, scheda aperta,
    fino a 6 comandi con i loro valori, testo visibile) invece di tornare ai
    pianeti, così ogni sezione è mostrabile.
  - **Ogni scena porta alla sua sezione**: un'etichetta in alto a destra
    («🪐 Orbite di Keplero · apri ›»…) la apre con un tocco (pianeti →
    Sistema solare 3D, molecola → Strutture 3D, spettro → IR Visivi,
    superficie → Funzioni di più variabili, orbitale → Orbitali MO, onda →
    Schrödinger). **Senza togliere la figura di Spectra** (richiesta
    dell'autore: «Continua, soprattutto senza togliere la figura di Spectra,
    deve essere perfetto»): il tocco non lascia la sezione dell'AI, ma apre
    la finestra di Spectra su «🧠 Spiega» (se non è già aperta) e la sezione
    **dietro** di essa (`BSISpiega.mostraSezione`), così Spectra resta
    visibile davanti e la sezione si vede dal vivo nell'ologramma.
  - **Chiusa la finestra, si torna da Spectra**: se Spectra ha aperto altre
    sezioni (il catalogo, «🎞️ Mostrami tutto», una domanda che nomina un
    argomento, l'etichetta dell'ologramma), chiudendo la finestra di Spectra
    l'app torna alla sezione dell'AI da cui si era partiti (`sai`,
    `sareachim`, `sareafis`, `sareamat`), dove c'è la figura; il giro di
    «Mostrami tutto» si ferma alla chiusura.
  - **Il soggetto segue la conversazione**: le parole della domanda (il
    nuovo evento `bsi-spectra-tema`, emesso da «🧠 Spiega» con la domanda) o
    della risposta scelgono la scena (orbite e pianeti → pianeti; spettro,
    NMR, IR → spettro; molecola, legame → molecola; funzione, superficie,
    integrale → superficie; orbitale, elettrone, quantistica → orbitale;
    onda, Schrödinger, luce → onda); con «Includi lo schermo» l'ologramma
    mostra la sezione dal vivo, e aprendo «🧠 Spiega» con una sezione dietro
    la mostra subito. A riposo le scene si alternano ogni 14 s; dopo un
    argomento l'alternanza riprende dopo 60 s.
  - **Quando risponde, Spectra indica prima l'ologramma** (gesto «indica»,
    circa 2,5 s), poi accompagna la spiegazione con le mani («spiega»).
  - **I pulsanti della figura** stanno in una barra **sotto** la scena (non
    coprono più Spectra né l'ologramma); sul telefono la barra lascia spazio
    a destra per i pulsanti flottanti dell'app.
- **«🧠 Spiega»: l'AI che spiega tutto, in modo esaustivo**
  (`bsi-spectra-spiega.js`, oggetto `BSISpiega`). Richiesta dell'autore: «Non
  deve fare lezioni ma una spiegazione perfetta, completa e completamente
  esaustiva su tutto ciò che riguarda queste 3 materie… deve essere un vero e
  proprio AI… deve spiegare grafici in 3D e tutto, dai grafici degli spettri a
  chimica, fisica e matematica, a un livello avanzatissimo». Nella finestra di
  Spectra (`bsi-ai-hub.js`) la scheda **«🧠 Spiega»** è la seconda, subito
  dopo «💬 Chat» (le schede sono Chat, Spiega, Esame Orale, Ripassa Oggi,
  Genera Guida).
  - **La domanda**: qualunque cosa di chimica, fisica o matematica, a cinque
    livelli — Scuola superiore, Triennale, Magistrale, Dottorato (PhD), PhD
    avanzato · frontiera. Per ogni livello il prompt di sistema dice che cosa
    ci si aspetta (`PROFONDITA`: dalle superiori al formalismo completo della
    magistrale, ai metodi avanzati del dottorato, fino allo stato dell'arte,
    ai problemi aperti, alle tecniche di frontiera e alla letteratura primaria
    — solo riferimenti certi — al PhD avanzato), più «Non semplificare sotto
    questo livello e non tralasciare nulla di rilevante».
  - **La struttura obbligatoria della risposta** (titoli `##`): 1 In sintesi;
    2 Che cosa stai guardando — solo con lo schermo: lettura quantitativa di
    ogni elemento (assi, unità, scala, curve, valori dei comandi); per gli
    spettri NMR ogni segnale con δ, molteplicità, J, integrale e
    attribuzione; IR bande (numero d'onda, intensità, forma) e gruppi
    funzionali; MS ione molecolare, frammenti, perdite neutre, profilo
    isotopico; UV-Vis λmax, tipo di transizione, ε; poi la struttura che ne
    risulta e la sua coerenza; per le scene 3D geometria, simmetria (gruppo
    puntuale o spaziale), piani e superfici nodali, punti critici,
    isosuperfici, campi e significato fisico o matematico; per i grafici
    matematici dominio, simmetrie, asintoti, zeri, estremi, flessi,
    convergenza, limiti; 3 Fondamenti teorici; 4 Formalismo e derivazione
    completa, a passi numerati; 5 Esempi numerici calcolati (con i valori
    dello schermo, se ci sono); 6 Casi limite, approssimazioni, errori comuni;
    7 Collegamenti fra chimica, fisica e matematica; 8 Applicazioni e
    frontiera della ricerca (letteratura solo se certa); 9 Per verificare di
    aver capito: tre domande con risposta. Le domande successive ricevono una
    risposta diretta con lo stesso rigore. Rigore: unità, assunzioni, numeri
    calcolati e non inventati; se i dati non bastano, si dice che cosa manca.
  - **Lo schermo**: la casella **«📺 Includi lo schermo»** (attiva da sola
    quando dietro la finestra c'è una sezione aperta; la scheda mostra il
    titolo della sezione, quanti grafici e scene 3D ci sono e una miniatura).
    Manda la sezione, la scheda aperta, ogni comando con il suo valore e il
    suo intervallo, le tabelle visibili per intero (fino a 4 × 40 righe), il
    testo visibile, il numero dei grafici; e **un'immagine**: le tele visibili
    (grafici e scene 3D; le scene di `BSILab3D` si ridisegnano prima della
    foto, con `BSISpectraLive.cattura`) e i grafici SVG visibili trasformati
    in immagine (molti spettri e diagrammi sono SVG), impilati, larghi al
    massimo 1400 px, in JPEG. L'immagine va ai modelli che accettano
    immagini, con la conversione per fornitore della chat (stile Anthropic,
    Gemini, OpenAI); nelle domande successive non si rimanda.
  - **Domande rapide**: «📈 Spiegami questo grafico», «🧪 Lo spettro, picco
    per picco», «🧊 La scena 3D», «∴ Dimostrazione completa», «🔭 Frontiera
    della ricerca». **«↺ Nuova spiegazione»** ricomincia; la conversazione
    resta solo in memoria per la sessione, non si salva niente.
  - **Spectra col corpo** (la figura condivisa) si sposta nella scheda (che
    ha la precedenza sulle sezioni dell'AI), pensa mentre il modello scrive,
    poi parla e gesticola con la risposta. Il pulsante della figura nelle
    sezioni dell'AI è **«🧠 Spiega»** e apre la finestra su questa scheda.
  - **Senza modello non finge**: dice che per la spiegazione completa serve un
    modello e mostra ciò che l'app sa da sola — il riconoscimento
    dell'assistente locale se la domanda è un esercizio numerico, i capitoli
    della lezione guidata della sezione aperta (`bsi-lezione.js`) e i dati
    dello schermo come testo.
  - Fornitore e chiave sono quelli della chat (`window.bsiLLM = { provider(),
    chiave(p) }`, esportato da `bsi-ai-hub.js`). **Con «Includi lo schermo»
    attivo, il testo dello schermo e l'immagine dei grafici e delle scene 3D
    vanno al fornitore di IA configurato insieme alla domanda**, come un
    allegato della chat; senza la casella, solo la domanda; senza chiave non
    esce niente dal dispositivo.
- **Il catalogo: tutte le sezioni nell'ologramma, spiegabili e mostrabili**
  (`bsi-spectra-spiega.js`). Richiesta dell'autore: «ogni sezione della
  chimica, della fisica e della matematica deve esserci, non deve mancare
  nulla in questo ologramma: deve esserci tutto spiegabile e mostrabile».
  - **`BSISpiega.catalogo()`** legge ogni pulsante di sezione della barra
    dell'app (`.nav-group-panel [data-s]`) con l'etichetta del suo gruppo
    (Chimica, Spettroscopia, Biochimica, Farmacologia, Chimica Fisica, Studio,
    Utility, Fisica, Matematica, Astrofisica) e la materia
    (`BSIMaterie.materiaDi`): **194 sezioni** (chimica 75, fisica 60,
    matematica 30, comuni 29). Non è scritto a mano: una sezione nuova
    compare da sola.
  - Nella scheda «🧠 Spiega» il riquadro apribile **«🗂️ Tutte le sezioni
    nell'ologramma»** le elenca per gruppo, con una casella di ricerca e un
    filtro per materia. Un tocco apre la sezione dietro la finestra di
    Spectra (`BSISpectraLive.calcolo.apriSezione`, che cambia materia se
    serve), l'ologramma la mostra dal vivo e «📺 Includi lo schermo» si
    spunta (se l'utente non l'ha tolta), così la spiegazione usa i suoi dati (`BSISpiega.mostraSezione(id)`).
  - **«🎞️ Mostrami tutto»** (`BSISpiega.giro(materia)`): ogni sezione della
    materia scelta (o tutte) a turno nell'ologramma, una ogni 7 s, con il
    contatore «n/N · nome»; «⏹ Ferma il giro» (`BSISpiega.giroFerma()`) lo
    ferma.
  - **Una domanda che nomina un argomento trova la sua sezione**
    (`BSISpiega.sezioneDi(testo)`): le parole significative dei nomi delle
    sezioni cercate nella domanda, anche per radice; le sigle (MS, IR, UV,
    NMR, MO…) pesano di più; sinonimi «spettro di massa» → MS, «infrarosso» →
    IR, «risonanza magnetica» → NMR, «orbitali molecolari» → MO; a parità
    vince il nome più corto. Chiedendo in «🧠 Spiega» senza lo schermo
    incluso, la sezione nominata si apre dietro la finestra, si mostra
    nell'ologramma e la spiegazione comprende i dati del suo schermo. **La
    spunta tolta si rispetta**: se l'utente ha tolto «📺 Includi lo schermo»
    (`ST.schermoNo`, impostato dall'evento `change`), la sezione nominata o
    scelta dal catalogo si apre e si mostra lo stesso, ma la casella resta
    spenta e al modello va solo la domanda, senza testo né immagine dello
    schermo; le domande rapide («📈 Spiegami questo grafico»…) parlano dello
    schermo e rimettono la spunta (scelta esplicita). Esempi
    verificati: titolazioni → Titolazione (`stitr`), Schrödinger →
    `sschrod`, integrali per parti → «Derivate, integrali e serie»
    (`smatcalc`), spettro di massa → Spettro MS (`sms`), spettro infrarosso →
    IR Visivi (`sirvis`), meccanica orbitale → `sastroorbite`; «ciao come
    stai» → nessuna.

### Cambiato
- **Nessun manichino come Spectra**, né nelle sezioni dell'AI né nello
  studio: senza il corpo dell'autore sul dispositivo compare l'invito
  «Spectra non è ancora su questo dispositivo — carica una volta il suo corpo
  (.glb)» con il pulsante, e nessun sostituto. Il corpo non può stare nel
  repository né essere servito dall'app (licenza Royalty Free di CGTrader),
  quindi **l'app pubblicata, finché l'utente non carica la propria copia,
  mostra l'invito**. `BSISpectraCorpo.manichino()` resta per il banco del
  driver (`opz.manichino === true`).
- **L'icona di Spectra è solo il volto**: il pulsante rotondo con il volto
  «Noir»; la pillola «Spectra» resta nascosta.
- **Spectra Studio** (`spectra-studio.html`) usa il controllore condiviso
  (`S.spectra`; `S.corpo`, `S.volto`, `S.rig`, `S.allinea`… sono letture
  dal controllore; `S.usaScena` per i banchi); l'invito è `#invito`.

### Corretto
- **Spazio vuoto sopra le sezioni sul telefono.** Alcune sezioni (la
  dashboard, le aree dell'AI…) stanno fuori da `#main`, accanto a esso:
  `#main` restava vuoto ma teneva il suo margine in basso (lo spazio per i
  pulsanti flottanti), e sopra la sezione restavano fino a circa 190 px vuoti
  (visibili nella schermata dell'autore). `index.html` aggiunge la classe
  `bsi-sez-fuori` al `body` quando la sezione aperta è fuori da `#main`: il
  margine di `#main` va a 0 e il margine in basso passa alla sezione.
- **Contrasto dei pulsanti col gradiente blu→verde acqua.** L'invito
  «🧍 Carica il corpo» della figura, l'invito dello studio e il pulsante
  principale di «🧠 Spiega» avevano il testo bianco su `#2f6bff`→`#00c9b7`:
  contrasto 2,09:1 (WCAG AA chiede 4,5:1). Ora `#1d4ed8`→`#0e7490`
  (`bsi-spectra-figura.js`, `spectra-studio.html`, `bsi-spectra-spiega.js`);
  `verifica-accessibilita` torna a 0 errori di contrasto.
- **Niente 404 nell'app pubblicata.** La figura delle sezioni dell'AI
  chiedeva `models/spectra-corpo.glb` e `models/spectra-cyberpunk.glb`, file
  di sviluppo che sul server non ci sono. Ora nell'app cerca il corpo solo
  nell'IndexedDB del dispositivo; lo studio li prova ancora (sviluppo).

### Nota sugli aggiornamenti
- Il telefono dell'autore mostrava ancora la v238 anche con la v239 già
  pubblicata su GitHub Pages: una PWA installata tiene la sua versione finché
  non si aggiorna. Si aggiorna dal menu ✨ → **«🔄 Aggiornamenti»**
  (`bsi-aggiorna.js`).

### Banco
- Nuovo `test_spectra_figura` (103 controlli: 52 a 412 px, 51 a 1280 px): il
  pulsante di Spectra è solo il volto (pillola nascosta); in ognuna delle
  quattro sezioni dell'AI la figura sta dentro la sezione, sotto il titolo,
  alta almeno 280 px, e in tutta l'app ce n'è una sola; nessuno spazio vuoto
  sopra le sezioni fuori da `#main` (`#main` a 0 px); senza il corpo l'invito e
  nessun sostituto; caricato un umanoide sintetico (senza scheletro, con
  cappuccio) l'invito sparisce, il viso poggia sul colletto (0,0 cm) e si vede
  solo il viso; reazioni: pensa (gesto «pensa», concentrata), risposta
  (prima indica l'ologramma, poi accompagna la spiegazione con le mani;
  gioia, labiale su corpo e viso), errore → dubbio, Spectra Live
  che parla → la figura parla, l'assistente locale che risolve «deriva x^2» →
  Spectra spiega (sorriso caldo); sul telefono i pulsanti della figura non
  coprono quelli flottanti; nessun errore JavaScript. Per ogni larghezza, 14
  controlli di «🧠 Spiega»: è la seconda scheda e «Lezione» non c'è più; la
  figura si sposta nella scheda; con uno spettro aperto («Spettri Ref.» nel
  Centro spettri) legge lo schermo (almeno un grafico, i valori dei comandi,
  l'immagine); cinque livelli; il modello riceve il testo dello schermo, la
  domanda e l'immagine; la richiesta chiede una spiegazione esaustiva e non
  semplificata, con la lettura quantitativa dello spettro (δ, molteplicità,
  J, integrale) e delle scene 3D; la struttura obbligatoria; la risposta
  arriva formattata (titoli e tabella) e Spectra pensa mentre viene scritta;
  la domanda successiva continua la conversazione senza rimandare
  l'immagine; al PhD avanzato frontiera, problemi aperti e letteratura
  primaria; senza modello non finge; legge come immagine gli spettri SVG (il
  quiz degli spettri); legge una scena 3D («Meccanica orbitale 3D»: 2 tele,
  immagine). Le risposte del modello sono simulate: il banco controlla che
  cosa si manda e come si mostra, non la qualità della spiegazione di un
  modello vero; con la scena 3D aperta dietro «🧠 Spiega» l'ologramma la
  mostra dal vivo; privacy: tolta la spunta «Includi lo schermo», la sezione
  nominata si apre ma al modello vanno solo la domanda, senza testo né
  immagine dello schermo. Per ogni larghezza, 7 controlli dell'ologramma: sta alla
  destra di Spectra (x sullo schermo); sei scene vive; Keplero: il rapporto
  fra le velocità al perielio e all'afelio vale (1+e)/(1−e) = 1,94 entro
  l'8 %; il soggetto segue la conversazione (risposta sull'IR → spettro,
  domanda sulle orbite → pianeti); l'etichetta porta alla sezione; un tocco
  sull'etichetta apre «Sistema solare 3D» DIETRO la finestra Spiega (Spectra
  resta visibile davanti, l'ologramma la mostra dal vivo); chiusa la
  finestra, l'app torna alla sezione di Spectra e la figura è lì. Per ogni larghezza, 5 controlli del catalogo: il
  catalogo ha TUTTE le sezioni della barra (194/194, chimica 75, fisica 60,
  matematica 30, comuni 29); una domanda che nomina un argomento trova la sua
  sezione (i sette esempi: titolazioni, Schrödinger, integrali per parti,
  spettro di massa, spettro infrarosso, meccanica orbitale, «ciao come stai»
  → nessuna); chiedendo delle titolazioni, Spectra apre la sezione dietro la
  finestra, la mostra nell'ologramma e la spiega con i suoi dati; una sezione
  senza grafici (Tavola Periodica) si proietta come scheda nell'ologramma;
  «🎞️ Mostrami tutto» scorre le sezioni della materia. Il banco porta la figura
  in vista prima di misurare, perché la figura si disegna (e allinea il viso)
  solo quando è visibile.
- `test_spectra_studio` passa a **91 controlli**, con o senza il modello in
  locale: nelle lezioni, a ogni larghezza, «senza il corpo: l'invito», «nessun
  sostituto in scena (niente manichino)», poi il banco carica lo stesso
  umanoide sintetico con `S.usaScena` e «l'invito sparisce, Spectra c'è»;
  così i controlli sul corpo riggato (mento sul colletto, sincronia
  viso–cappuccio 0,0 mm, solo il viso, volto solidale) girano **sempre**.
- La batteria passa da 82 a 83 banchi.

### Non incluso
- Il corpo dell'autore resta fuori dal repository (licenza Royalty Free di
  CGTrader): nell'app pubblicata Spectra compare col corpo solo sui
  dispositivi dove l'utente l'ha caricato una volta.
- Il corpo, il volto e le reazioni sono una simulazione di comportamento, non
  una coscienza.

---
## [bsi-v239] — 2026-11-04

**Una lezione guidata con Spectra per ogni sezione; Spectra incarnato: Spectra Studio, il corpo e la voce; un solo pulsante di Spectra, il volto in un cerchio**

### Aggiunto
- **Lezione guidata per ogni sezione** (`bsi-lezione.js`, oggetto globale
  `BSILezione`). Richiesta dell'autore: «qualcosa come la lezione interattiva
  di Every Joule, ma per ogni sezione». La pagina di riferimento non era
  raggiungibile dalla sessione di lavoro: la lezione ne è un'interpretazione,
  non una copia.
  - In ogni sezione, sotto il titolo, compare il pulsante **«🎓 Lezione
    guidata con Spectra»**.
  - La lezione non è scritta a mano: nasce dalla sezione. Apertura con titolo
    e sottotitolo; un capitolo per scheda, in cui la scheda si apre, la sua
    spiegazione si legge a pezzi di una o due frasi, le tele e le scene 3D
    vengono illuminate, i cursori sono mostrati al lavoro dal minimo al
    massimo e rimessi dov'erano, le scelte passate in rassegna e rimesse
    com'erano; una domanda di verifica presa dal kit di studio della materia
    (quella con più parole in comune con la sezione), con la spiegazione dopo
    la risposta; un riepilogo dei capitoli. Le sezioni senza schede si leggono
    per titoli e paragrafi, con i loro grafici e comandi.
  - Lettore: pannello a destra sullo schermo grande (da 1100 px la pagina si
    sposta a sinistra) o in basso sul telefono; avanzamento per capitoli;
    testo che compare parola per parola; tasti ◀ ▶ e pausa; voce di Spectra
    attivabile e disattivabile; un riflettore oscura il resto della pagina e
    illumina il pezzo di cui si parla. Durante la lezione i pulsanti
    flottanti si nascondono e alla chiusura tornano com'erano. Con «riduci
    movimento» i cursori saltano al valore invece di scorrere, il testo
    compare tutto insieme e il riflettore non pulsa.
  - Spectra: il comando **«fammi lezione»** (anche «lezione guidata»,
    «insegnami questa sezione», «give me a lesson») e la scorciatoia **🎓
    Lezione** nella console, con una sezione aperta.
  - Alla stesura: **194 sezioni** hanno la lezione, **99** hanno schede,
    **79** hanno una domanda di verifica.
- **Spectra Studio** (`spectra-studio.html`, lezioni in
  `bsi-spectra-studio-lezioni.js`): un laboratorio 3D in una pagina a sé, con
  Spectra in piedi accanto a un banco olografico. Si apre dal navigatore 🧭
  della console (voce «Spectra Studio», in cima). Tre lezioni con il metodo
  *predici → testa → dimostra → rivela*:
  - 🪂 **La caduta**: una sfera lasciata cadere e una lanciata in orizzontale a
    6 m/s da 20 m toccano terra insieme dopo 2,019 s; gittata 12,12 m; con la
    resistenza dell'aria la lanciata arriva dopo;
  - 💧 **La forma dell'acqua**: VSEPR come minimo di energia di domini che si
    respingono sulla sfera; quattro domini uguali danno il tetraedro,
    arccos(−1/3) = 109,47°; con i doppietti solitari pesati w = 1,25
    (calibrato sull'acqua) l'acqua viene 104,4° (sperimentale 104,5°) e
    l'ammoniaca, con lo stesso w e senza nuova calibrazione, 106,7° come il
    valore sperimentale;
  - ∑ **Il problema di Basilea**: somme parziali di 1/n², coda fra 1/(N+1) e
    1/N, serie di Fourier di x², probabilità che due interi siano coprimi
    (Monte Carlo) → 6/π².
  Ogni lezione ha le spiegazioni di ogni opzione, una dimostrazione passo per
  passo, collegamenti fra discipline ed esercizi su quattro livelli (scuola
  superiore, triennale, magistrale, ricerca). Le previsioni e gli esercizi
  aperti restano nel `localStorage` (`bsi-spectra-studio-v1`), e da lì viene
  il livello di esercizio consigliato. L'interruttore 🔊/🔇 nella barra delle
  azioni spegne la voce dello studio e la scelta si ricorda
  (`bsi-spectra-studio-voce`); le due chiavi rientrano in «Cancella dati →
  Memoria persistente». Il pannello contiene tutto il testo della lezione,
  ha nome accessibile e si segue anche senza WebGL (solo testo, con le misure
  calcolate).
- **Il corpo di Spectra** (`bsi-spectra-corpo.js`, oggetto
  `BSISpectraCorpo`): un driver per qualunque avatar umanoide in GLB. Riconosce
  le ossa per nome (Mixamo, Ready Player Me, VRM, Unreal, nomi generici), i
  blendshape ARKit del viso, i capelli e le clip di animazione, e dice che cosa
  manca (`rapporto()`). Muove respiro, peso, sguardo, emozioni, labiale (dal
  testo o dall'audio), battito delle palpebre, gesti (indica, spiega, pensa,
  attende, conclude), passo e seduta; ricolora i capelli in nero. Nello studio
  il corpo è un **manichino riggato di prova** costruito nel codice, con il
  volto «Noir» incarnato sulla testa e allineato al collo per misura. Se
  esiste `models/spectra-cyberpunk.glb`, lo studio lo carica al posto del
  manichino (scalato a 1,8 m, capelli resi neri dal driver, volto «Noir»
  nascosto perché il modello ha il suo viso).
- **La voce di Spectra** (`bsi-spectra-voce.js`, oggetto `BSISpectraVoce`):
  con una chiave OpenAI salvata nell'app, l'audio arriva da `gpt-4o-mini-tts`
  (voce «onyx»; `tts-1` se il primo non risponde) e passa in una catena Web
  Audio (bassi, presenza, modulatore ad anello, filtro a pettine,
  saturazione, riverbero di 1,4 s, compressore); il labiale segue l'energia e
  il centroide dell'audio. **Il testo da pronunciare viene inviato a OpenAI**,
  anche quando la chat usa un altro fornitore, salvo che la voce sia spenta
  (🔇). Senza chiave resta la sintesi del browser, con la voce maschile più
  grave disponibile.
- **Il rig automatico** (`bsi-spectra-rig.js`, oggetto `BSISpectraRig`): molti
  modelli umanoidi arrivano come una mesh sola, senza scheletro. Il modulo li
  rende pilotabili dal driver del corpo direttamente nel browser, senza
  Blender: **misura** la figura in piedi (altezza, asse, gambe, mani, spalle;
  i punti non misurabili seguono le proporzioni del canone umano), **costruisce
  uno scheletro con i nomi Mixamo** (20 ossa che pesano e 7 punte, 27 in
  tutto) e **calcola i pesi della pelle** (peso ∝ 1/d⁴ con un cancello per
  regione, i quattro maggiori, tre passate di levigatura). I pesi del braccio
  passano tre filtri — la normale, la distanza geodetica dalla mano, l'asse
  della testa — e la mano non prende peso dal bacino: alzare un braccio non
  strappa il busto. Il modulo ha anche due opzioni che lo studio non usa:
  `visiera: false` (il casco sotto il cappuccio reso come ombra opaca) e
  `testa` (scala della testa).
- **Il corpo «Bounty Hunter» con il cappuccio e il solo viso «Noir»**
  (`spectra-studio.html`): lo studio prova prima `models/spectra-corpo.glb`, il
  corpo scelto dall'autore, una figura senza scheletro. Il rig automatico la
  rigga; il cappuccio del modello si allarga quanto basta ad avvolgere il
  volto, diventa rigido con l'osso della testa e si apre davanti con
  un'ellisse calcolata nello shader, al pixel. Sotto il cappuccio resta la
  visiera nera lucida del modello, come ha chiesto l'autore. Del volto «Noir»
  si vedono solo maschera, occhi e dettagli (`Object_2/3/4`), avanzati di
  6,5 cm e in scala 0,96, su un supporto allineato in modo che il mento poggi
  sul colletto. **`models/spectra-corpo.glb` non è nel repository** (escluso
  in `.gitignore`): vale solo in sviluppo. Il corpo viene da CGTrader, dove si
  scarica gratis, ma la licenza Royalty Free permette di usare un modello
  dentro un prodotto solo se terzi non possono recuperarne il file: non può
  stare nel repository pubblico né essere servito dall'app pubblicata.
- **Il corpo dal proprio dispositivo** (`spectra-studio.html`): il pulsante
  **«🧍 Corpo»** nella testata del pannello (con un campo file nascosto che
  accetta `.glb`) carica un corpo dal dispositivo dell'utente. Il file viene
  riggato e ricolorato come sopra e conservato **solo nell'IndexedDB di quel
  browser** (database `bsi-spectra-modelli`, archivio `file`, chiave
  `corpo`); non va su nessun server. A ogni apertura lo studio cerca il corpo
  in quest'ordine: IndexedDB, `models/spectra-corpo.glb` (solo sviluppo),
  `models/spectra-cyberpunk.glb`, manichino riggato. Un corpo caricato dal
  dispositivo sostituisce sempre qualunque altro corpo e ricrea il volto
  «Noir» se un modello completo lo aveva tolto. I file oltre 60 MB sono
  rifiutati; un file che non è un umanoide utilizzabile è rifiutato con un
  messaggio. Così chi possiede il file usa la propria copia e nulla viene
  ridistribuito; senza il file, l'app pubblicata mostra il manichino.
- **Blu notte**: la texture del corpo è ricolorata nei colori dell'app (ombre
  quasi nere `#03050c`, mezzitoni `#0d162e`–`#162448`, luci `#2a3c6c`); i
  dettagli turchesi del modello diventano luce propria verde acqua `#00c9b7`.
  Il disegno della texture (cuciture, piastre, pieghe) resta.
- **Definizione grafica («4K»)** dello studio: il rapporto di pixel del
  renderer arriva fino a 3 (era 2), per gli schermi ad alta densità e 4K;
  `bsi-spectra-rig.js` applica la **tassellazione di Phong** (Boubekeur e
  Alexa, 2008; opzione `suddividi`, un livello: ogni triangolo ne diventa
  quattro, sul corpo dell'autore da 13 592 a 54 368 triangoli, rig pronto in
  circa 0,5–1 s), con i punti medi calcolati su posizioni e normali saldate
  perché le cuciture restino chiuse, e i pesi calcolati sulla mesh già
  tassellata; una **mappa di rilievo** ricavata dalla luminanza della texture
  originale, appena sfocata (`bumpScale` 0,016), fa prendere la luce vera a
  bordi delle piastre, cuciture, tessuto e pieghe dei guanti; filtraggio
  anisotropo della texture al massimo della GPU. Detto con onestà: la texture
  di partenza è 2048×2048 e nessun dettaglio nuovo viene inventato; «4K» si
  riferisce alla risoluzione di disegno.
- Documenti di progetto in [`docs/spectra/`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/tree/main/docs/spectra): analisi del
  modello e piano, architettura, mappa dei domini.

### Cambiato
- **Un solo pulsante di Spectra** (`bsi-spectra-live.js`): il volto in un
  cerchio prende il posto della pillola «Spectra». Il cerchio apre la console
  di Spectra Live; dalla console 💬 apre la chat. La pillola resta nella
  pagina ma nascosta, perché altri moduli e i banchi la usano per aprire la
  chat. Il cerchio compare subito con il volto vettoriale e passa al ritratto
  dopo il caricamento della pagina.
- **Voce della console** (`bsi-spectra-live.js`): con una chiave OpenAI la
  console di Spectra Live parla con la voce di `bsi-spectra-voce.js`;
  altrimenti con la sintesi del browser come prima. La lezione guidata usa la
  voce della console e, se la console non c'è, direttamente
  `bsi-spectra-voce.js`.
- **Volto «Noir» incarnabile** (`bsi-spectra-androide.js`): `crea(padre,
  { scena, renderer, senzaBusto })` mette il volto in una scena altrui, senza
  renderer, luci e telecamera propri e senza il busto del modello.
- **Volto «solidale»** (`bsi-spectra-androide.js`): con un corpo che ha già la
  testa e un cappuccio rigido attorno, i movimenti della testa li fa il corpo;
  il volto fa solo espressioni, occhi e bocca, e non fa più il proprio
  respiro (posizione e scala della radice) dentro il cappuccio. Così viso e
  cappuccio restano in sincronia mentre Spectra cammina, gesticola e guarda
  in giro.
- **Cancella dati** (`bsi-ai-hub.js`, `DATI_CANCELLABILI.app`): il gruppo
  «Progressi del resto dell'app» cancella anche il database IndexedDB
  `bsi-spectra-modelli`, cioè il corpo caricato dal dispositivo.
- **Studio sul telefono in verticale**: la telecamera si centra fra Spectra e
  il banco e arretra (bersaglio spostato a x = −0,12, distanza almeno 4,4).

### Banco
- Nuovo `test_lezione` (30 controlli): tutte le 194 sezioni hanno la lezione e
  il pulsante; un capitolo per scheda; un cursore e una scelta mostrati al
  lavoro e rimessi com'erano anche saltando avanti a metà; la verifica con la
  spiegazione; il riepilogo; i pulsanti flottanti nascosti e ripristinati;
  «fammi lezione»; a 390 e 1280 px niente sborda; nessun errore JavaScript.
- `test_spectra238` passa a 66 controlli: un solo pulsante di Spectra
  visibile, rotondo.
- Nuovo `test_spectra_studio` (79 controlli; 85 con il corpo riggato presente
  in locale): i 23 calcoli delle lezioni
  (`verifiche/verifica-studio-spectra.js`); il driver sul manichino (11:
  ossa e blendshape trovati, capelli rossi resi neri, braccia giù dalla posa a
  T, indicare, pensare, sguardo, passo, seduta, emozioni, labiale dall'audio,
  battito); la catena della voce in un contesto audio offline (3: bassi
  rinforzati, coda del riverbero, ripiego senza chiave); le lezioni a 1280 e
  390 px con il volto appoggiato sul collo e la memoria delle previsioni; la
  voce spenta che si ricorda e «Cancella dati» che toglie le chiavi dello
  studio; per ognuna delle due larghezze il pulsante «🧍 Corpo» che c'è e
  accetta i `.glb`, il corpo che fa andata e ritorno nell'IndexedDB, un file
  che non è un modello rifiutato senza errori; la lezione senza WebGL; nessun errore JavaScript. Con il corpo
  riggato presente, per ognuna delle due larghezze: sincronia viso–cappuccio
  misurata in 24 pose mentre Spectra cammina e gesticola (soglia 1 mm;
  misurati 0,0 mm), del volto «Noir» si vedono solo maschera, occhi e
  dettagli, il volto è «solidale»; il mento si misura sull'osso del collo più
  4,5 cm. Senza il modello questi controlli si saltano.
- Nuovo `test_spectra_rig` (30 controlli), su un umanoide sintetico in posa ad
  A costruito nel codice (il modello vero non è nel repository): nomi dello
  scheletro e riconoscimento da parte del driver, locomozione; pesi con somma
  1, la mano all'osso della mano e all'avambraccio, il fianco del busto
  accanto alla mano pendente senza nessun peso del braccio, le gambe che non
  si incrociano mai; nel gesto «spiega» la mano si sposta e il fianco no; la
  camminata sposta il corpo; testa e cappuccio (triangoli tolti; col solo
  viso nessun triangolo tolto, ellisse nello shader, doppia faccia,
  cappuccio rigido con la testa; l'opzione `visiera: false` rende il casco
  ombra opaca senza togliere vertici); blu notte e luce verde acqua; la
  definizione (la tassellazione moltiplica i triangoli per 4, i pesi restano
  normalizzati sui vertici nuovi, la pelle resta chiusa: i bordi aperti
  raddoppiano soltanto); nessun errore JavaScript.
- La batteria passa da 79 a 82 banchi.

### Non incluso
- **Il modello «cyberpunk» di Sketchfab** scelto dall'autore non è stato
  fornito: non era raggiungibile dalla sessione di lavoro, e prima di
  usarlo servono il file GLB e la verifica della licenza
  ([`docs/spectra/01`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/01-Analisi-modello-e-piano.md) §6). Lo
  studio è pronto a caricarlo da `models/spectra-cyberpunk.glb`; finché il
  file non c'è, il corpo è il manichino di prova.
- **I modelli forniti in seguito dall'autore** («I-HOMO 08», poi il corpo
  «Bounty Hunter» usato dallo studio) **non sono nel repository**: finché
  l'autore non conferma licenza e fonte, restano solo in locale e l'app
  pubblicata mostra il manichino riggato.
- **Capelli neri per Spectra**: il driver li rende neri su qualunque modello
  con capelli riconoscibili, ed è provato sul manichino; sul volto «Noir»
  della console non ci sono capelli, e una prova con capelli procedurali
  sulla forma del casco non era convincente. Sul modello vero si vedranno
  quando il modello arriverà.
- Il corpo, il volto e la voce sono una simulazione di comportamento, non una
  coscienza.

---
## [bsi-v238] — 2026-11-03

**Spectra Live riprogettata e al centro dell'app, un volto con palpebre vere, il riconoscimento del creatore; schede 3D nuove in 29 sezioni di chimica, fisica e matematica**

### Aggiunto
- **Console di Spectra Live riprogettata** (`bsi-spectra-live.js`):
  - margini sicuri per la barra di stato e i tasti di Android: i valori di
    `env(safe-area-inset-*)` quando il sistema li comunica, altrimenti un
    minimo di 34 px in alto e 46 px in basso (classe `.bsiJV-bordi`), attivo
    quando la finestra copre lo schermo su un dispositivo touch o l'app è
    installata;
  - impaginazione calcolata: si misurano testata, telemetria e barra dei
    comandi, e volto, stato, pensiero e dialogo si dispongono nello spazio
    che resta, senza sovrapposizioni; sfondo opaco; medaglione del volto più
    grande; l'attribuzione del modello in fondo, su una riga sua;
  - navigatore 🧭: per ognuna delle tre materie tutti i gruppi e le sezioni
    della barra, gli strumenti rapidi e le frasi che Spectra capisce anche
    senza rete, con una casella di ricerca;
  - pulsante 💬 che apre la chat completa;
  - scorciatoie di contesto sopra i comandi: con una sezione aperta
    «Spiegami questa sezione», «Guidami», «Cosa vedo?», «Interrogami»,
    «Ripassa»; altrimenti «Tutte le sezioni», «Interrogami», «Ripassa»,
    «Cosa ricordi?», «Come stai?»;
  - pulsante tondo **Spectra Live** con il volto, sempre presente a sinistra
    del pulsante Spectra: la console si apre con un tocco da ogni schermata;
  - telemetria in due colonne sul telefono, con **UTENTE**, **LIVELLO** e
    **CONCENTRAZIONE**;
  - iniziativa: con la console aperta e in silenzio da più di un minuto,
    Spectra dice un pensiero importante della mente (peso ≥ 2), al massimo
    una volta ogni tre minuti e mai lo stesso due volte.
- **Livello e concentrazione**: `difficolta(testo)` parte dal livello di
  studio della sezione aperta (il primo livello del percorso di
  `bsi-percorsi.js` in cui la sezione compare: scuola superiore, laurea
  triennale, laurea magistrale, dottorato) e lo corregge con le parole da
  corso avanzato, i simboli e la lunghezza della domanda; «in parole
  semplici» la abbassa. Il valore va al volto come concentrazione.
- **Il volto di Spectra, versione 3.0** (`bsi-spectra-androide.js`):
  palpebre vere (i vertici di ciascun occhio deformati sulla CPU attorno al
  suo centro); sguardo che sposta gli occhi; tinta degli occhi per emozione
  nella famiglia del blu del tema (`#1a3050` a riposo); la concentrazione
  socchiude gli occhi e li accende; muscoli del viso come molle smorzate;
  micro-espressioni; coarticolazione dei visemi; luci neutre; densità reale
  dello schermo fino a 3×; filtraggio anisotropo; sonno dopo due minuti senza
  contatto e risveglio al primo tocco; sguardo che segue il dito. È una
  simulazione di comportamento, non una coscienza.
- **Riconoscimento del creatore** (`bsi-spectra-creatore.js`): Spectra sa di
  essere stato creato da Samuele Pio Provenzano. A «sono il tuo creatore»
  chiede una prova: la frase segreta del File Manager, scritta in un campo
  nascosto e confrontata come impronta SHA-256. La frase non è nel codice,
  non è conservata e non entra nel dialogo, nella memoria, nella voce o nelle
  richieste al modello; dopo tre tentativi sbagliati si aspetta un minuto.
  Riconosciuto, Spectra lo saluta per nome, lo indica nella telemetria e lo
  dice al modello; «dimentica che sono il tuo creatore» toglie il
  riconoscimento. La chiave `bsi-spectra-creatore-v1` rientra in
  «Cancella dati → Memoria persistente». Come la password del File Manager,
  è un deterrente, non un controllo d'accesso.
- **Schede 3D nuove in 29 sezioni**, in coda alle schede esistenti e
  costruite sul modello della sezione, ciascuna con uno script di verifica in
  `tools/banchi/verifiche/`:
  - chimica (4): 🧊 Superficie 3D (superficie di energia potenziale),
    🧊 Superficie P–V–T (diagrammi di fase), 🧊 Urti molecolari (cinetica
    complessa), 🧊 Scatola 3D (equilibrio e Le Chatelier);
  - fisica (15): 🧊 Celle in 3D (cristallografia), 🧊 Nuvola 3D |ψ|²
    (Schrödinger), 🧊 Orbitali in 3D (Hartree-Fock), 🧊 Rotazione e
    vibrazione 3D, 🧊 Scatola 3D (dinamica molecolare), 🌬️ Lancio 3D con vento, 🌀 Campi 3D e Lorentz, 🌊 Ondoscopio 3D,
    🕳️ Pozzo di potenziale 3D, 🔦 Cono di luce 3D, 🌀 Flusso attorno a un
    ostacolo 3D, 🗻 Superficie p-V-T 3D, 🔷 Zona di Brillouin 3D,
    🧊 Ising 3D, 🔭 Rivelatore 3D;
  - matematica (10): 🧊 Piano tangente in 3D, 🧊 Campo 3D e divergenza,
    🧊 Solidi di rotazione, 🧊 Trasformazioni dello spazio, 🧊 Caos nello
    spazio delle fasi 3D, 🧊 Normale bivariata 3D, 🧊 Superfici in 3D: χ e
    orientabilità, 🧊 Sfera e iperboloide in 3D, 🧊 Sfera di Riemann,
    🧊 Pellicola di sapone in 3D.
- **Nomi accessibili per i grafici**: una tela senza nome, o con un nome di
  una sola lettera come «y», prende il nome della scheda e della sezione
  (`bsi-fisica-comune.js`).
- Requisiti **SCI-58**, **UI-22**, **UI-23**, **AI-14**, **SEC-08**.

### Corretto
- Prima della pubblicazione:
  - `applicaMobius` (sfera di Riemann) non riconosceva il polo con un angolo
    di π esatto, perché cos(π/2) in virgola mobile vale 6·10⁻¹⁷ e non 0: ora
    il polo si riconosce dal rapporto fra denominatore e numeratore;
  - negli urti molecolari la direzione dell'urto si prende all'istante del
    contatto, non dalle sfere già compenetrate: la frazione di urti sopra
    soglia a E₀/kT = 1 era 0,345, ora 0,370, contro e⁻¹ = 0,368.

### Banco
- Nuovi `test_spectra238` (64 controlli: impaginazione della console su
  telefono e su schermo grande, navigatore, livello e concentrazione,
  creatore, occhi, sonno) e `test_3d238` (gli script di verifica delle 29
  schede 3D e ogni scheda delle loro sezioni aperta nel browser a 1280 e
  390 px; il lavoro sincrono al clic deve restare sotto i 250 ms). La
  batteria passa da 77 a 79 banchi.

---
## [bsi-v237] — 2026-10-29

**Tre app in una, il gruppo Astrofisica, dieci laboratori di fisica e matematica, i kit di studio, Spectra Live con il volto dell'androide; «Controlla aggiornamenti» risponde di nuovo**

### Aggiunto
- **Tre app in una**: la materia scelta (chimica, fisica, matematica) cambia
  anche il menu ✨, Spectra, Studio e Utility (`bsi-materie-app.js`). In
  fisica e matematica il blocco delle funzioni chimiche del menu ✨ lascia il
  posto agli **strumenti rapidi** (`bsi-attrezzi.js`), in una finestra sopra
  la pagina: calcolatrice esatta, derivata e primitiva, grafico, costante
  CODATA, convertitore di unità, formula, glossario, quiz lampo.
- **Kit di studio di fisica e matematica** (`bsi-studio.js`, motore;
  `bsi-studio-fisica.js`, `bsi-studio-matematica.js`, dati): riassunti,
  quiz, flashcard con il metodo di Leitner, formulario, glossario, cinque
  sezioni per materia:
  - fisica: 69 riassunti, 325 domande, 273 flashcard, 227 formule, 273 voci;
  - matematica: 66 riassunti, 346 domande, 266 flashcard, 224 formule,
    279 voci.
- **Risorse per materia** (`bsi-risorse-materie.js`): risorse web,
  bibliografia e citazioni da DOI (Crossref) in APA 7, IEEE, ISO 690 e
  BibTeX per fisica, matematica e chimica; 🔢 Costanti e unità (CODATA
  2018); 📚 Tavole matematiche, ogni voce numerica con la sua prova.
- **Gruppo «🔭 Astrofisica»** nella barra, con dieci sezioni nuove in 3D:
  - 🪐 Sistema solare 3D;
  - 🛰️ Meccanica orbitale 3D;
  - 📐 Matematica celeste;
  - ⭐ Vita delle stelle 3D;
  - 🕳️ Buchi neri e relatività generale;
  - 〰️ Onde gravitazionali;
  - 🌌 Galassie 3D;
  - 🌠 Cosmologia 3D;
  - 🔭 Planetario 3D;
  - 🌍 Esopianeti 3D.

  🔭 Astrofisica e 🪐 Gravitazione passano dal gruppo della fisica a questo.
- **Fisica, cinque laboratori nuovi**: 🌀 Spin, qubit ed entanglement;
  🎲 Meccanica statistica; ☢️ Nuclei e reazioni; 🧱 Elasticità e
  materiali; 🔌 Elettronica.
- **Matematica, cinque laboratori nuovi**: 🌊 Equazioni alle derivate
  parziali; 🌀 Analisi complessa; 🔗 Catene di Markov e processi
  stocastici; 🧩 SVD e algebra lineare applicata; 📡 Codici e curve
  ellittiche.
- **Spectra Live** (`bsi-spectra-live.js`): console vocale a tutto
  schermo, conversazione a mani libere, comandi locali che funzionano senza
  rete e senza chiave, lettura dello schermo e nove strumenti nuovi per
  agire sulla pagina e consultare il materiale di studio (gli strumenti
  dell'agente passano da 38 a 47). Voce grave (tono 0,7).
- **Il volto di Spectra** (`bsi-spectra-androide.js`): il modello 3D
  «Noir» di Skyfox13 (Sketchfab, CC BY 4.0, modificato), con la bocca
  animata sul testo pronunciato e 17 emozioni composte da 11 campi
  espressivi; occhi nel blu del tema (`#1a3050`). Senza WebGL o senza
  modello: la testa procedurale di `bsi-spectra-robot.js` o il ritratto SVG
  di `bsi-spectra-volto.js`.
- **La mente di Spectra** (`bsi-spectra-mente.js`): memoria locale degli
  episodi e del tempo di studio, stato interno (curiosità, attenzione,
  premura, umore, legame), «cosa ricordi di me», «come stai», «dimentica
  tutto». È una simulazione di comportamento, non una coscienza.
- Requisiti **SCI-55**, **SCI-56**, **SCI-57**, **UI-19**, **UI-20**,
  **AI-11**, **AI-12**; non ancora automatizzati **UI-21** e **AI-13**.

### Corretto
- **«Controlla aggiornamenti» non rispondeva mai.** La finestra 🔄
  Aggiornamenti cercava in `sw.js` una riga `CACHE_VERSION` che non esiste
  più (`sw.js` dichiara `var CACHE = 'bsi-vNNN'`) e la cercava su
  `raw.githubusercontent.com`: la versione remota non si leggeva mai. Ora
  legge `sw.js` dallo stesso sito senza cache (GitHub solo come ripiego), la
  confronta con la versione del service worker attivo (messaggio
  `BSI_VERSIONE`) e risponde sempre: già aggiornata, nuova versione, sito
  irraggiungibile (`bsi-aggiorna.js`).
- Prima della pubblicazione:
  - nel nucleo 3D la nota diceva che i nucleoni distano circa 1 fm; il
    disegno ora riempie il raggio R e la nota dice circa 1,8 fm;
  - le scene 3D nascoste si ridimensionavano a ogni cambio di scheda.

### Banco
- Nuovi `test_v237` (le venti sezioni nuove con i loro script di
  `tools/banchi/verifiche/`, i kit di studio, le risorse, ogni scheda aperta
  nel browser a 1280 e 390 px, volto, emozioni e mente di Spectra, nomi in
  inglese) e `test_controllaagg` (i tre casi del controllo aggiornamenti).

---
## [bsi-v236] — 2026-10-24

**Le tre materie allo stesso livello: diciannove sezioni nuove, i pulsanti per cambiare materia, gli articoli e i premi di chimica, fisica e matematica**

### Aggiunto
- **Pulsanti per cambiare materia** sopra Spectra e ✨: due pulsanti
  tondi per le due materie in cui non ci si trova (beuta, atomo, Σ). La
  barra mostra solo i gruppi della materia scelta, più Studio e Utility.
  La scelta si ricorda; aprire una sezione di un'altra materia cambia
  materia da sola.
- **Articoli per tre materie**, con le stesse schede e le stesse regole:
  - Nobel per la chimica, 135 spiegazioni per argomento (erano 66);
  - Nobel per la fisica, 140 spiegazioni;
  - Premio Abel e Medaglia Fields per la matematica, da Wikidata, 140
    spiegazioni;
  - ultimi articoli con otto argomenti per materia.
- **Matematica, dieci sezioni nuove** (da 15 a 25):
  - 🔐 Numeri e crittografia;
  - 🕸️ Grafi e ottimizzazione;
  - ♾️ Successioni e serie;
  - 🎢 Calcolo delle variazioni;
  - 🍩 Topologia e superfici;
  - 🔣 Strutture algebriche;
  - ♟️ Teoria dei giochi;
  - 🧠 Logica e calcolabilità;
  - 📊 Statistica inferenziale;
  - 🌐 Geometrie non euclidee.
- **Fisica, sette sezioni nuove** (da 23 a 30):
  - 🪐 Gravitazione;
  - 🔥 Calore e diffusione;
  - 🧲 Modello di Ising;
  - ⚛️ Fisica delle particelle;
  - 🎡 Meccanica analitica;
  - 🔦 Laser e ottica quantistica;
  - 🌍 Fisica del clima.
- **Chimica fisica, due sezioni nuove**:
  - 🧊 Diagrammi di fase (IAPWS, Span–Wagner, eutettico);
  - 🏔️ Superficie di energia potenziale (LEPS di H + H₂).
- Requisiti **SCI-53**, **SCI-54**, **UI-18**.

### Corretto
- Prima della pubblicazione:
  - la prima forma della LEPS non tendeva alla Morse di H₂ (asintoto
    −6,40 eV invece di −4,75 eV). Ora usa la forma di Sato, con k = 0,135:
    barriera 0,420 eV e sella a 0,931 Å, come il calcolo ab initio di H₃;
  - nella fionda le velocità misurate a distanza finita non coincidevano:
    ora si confrontano le v∞ asintotiche;
  - il lato delle tassellature iperboliche aveva p e q scambiati;
  - nella prova di Noether il potenziale lasciava fuggire la particella;
  - le spiegazioni dei Nobel per la chimica mandavano quattro premi alla
    spiegazione generica invece che alla loro;
  - nel modello di Ising una tela non aveva il nome accessibile.

### Banco
- Nuovi `test_approfondimenti` e `test_pareggio` (con i dodici script di
  `tools/banchi/verifiche/`); `test_articoli` esteso alle tre materie.

---
## [bsi-v235] — 2026-10-23

**Probabilità, matematica visiva, elettromagnetismo, suono, semiconduttori, distillazione, voltammetria**

### Aggiunto
- **🎲 Probabilità in movimento**: macchina di Galton con binomiale e
  gaussiana, legge dei grandi numeri e limite centrale da quattro
  distribuzioni, π con il Monte Carlo, teorema di Bayes con mille persone
  disegnate.
- **🎞️ Matematica visiva**:
  - trasformazioni lineari animate con determinante e autovettori;
  - epicicli di Fourier, anche da una figura disegnata con il dito;
  - Mandelbrot e Julia con lo zoom;
  - mappa logistica con ragnatela e diagramma di biforcazione.
- **⚡ Elettromagnetismo in movimento**:
  - cariche da trascinare con potenziale, equipotenziali e linee di campo;
  - induzione con la calamita nella spira;
  - generatore;
  - onde elettromagnetiche e polarizzazione.
- **🔊 Suono e acustica**, con l'audio da ascoltare: armoniche di corde e
  canne, timbro, battimenti, Doppler e cono di Mach, decibel.
- **💡 Semiconduttori**:
  - Fermi-Dirac e n_i di Si, Ge e GaAs;
  - drogaggio con il livello di Fermi;
  - giunzione p-n con Shockley e il colore dei LED.
- **🌡️ Distillazione e miscele**:
  - diagrammi T-x-y con Antoine, Raoult e van Laar;
  - azeotropo etanolo-acqua confrontato con la misura;
  - McCabe-Thiele animato con Fenske e Underwood;
  - distillazione semplice di Rayleigh.
- **🔋 Voltammetria ciclica**: simulazione con diffusione e Butler-Volmer,
  profili di concentrazione, Randles-Ševčík, ΔE_p, analisi con la velocità
  di scansione e stima di D.
- Requisito **SCI-52**.

### Corretto
- Prima della pubblicazione: nella voltammetria il gradiente di
  concentrazione all'elettrodo era del primo ordine. Il picco reversibile
  usciva al 95,6 % del valore teorico e ΔE_p a 63,5 mV. Con il gradiente
  del secondo ordine: 99,9 % e 58,1 mV.

### Banco
- Nuovo `test_esplorazioni`.

---
## [bsi-v234] — 2026-10-23

**Animazioni con pausa e velocità, astrofisica, relatività, fluidi, calcolo vettoriale, cinetica complessa**

### Aggiunto
- **🔭 Astrofisica** (categoria ⚛️ Fisica), con cinque schede:
  - **diagramma H-R** con sedici stelle vere, le rette a raggio costante e
    una stella di sequenza principale per massa (luminosità, raggio,
    temperatura, classe, durata della vita);
  - **corpo nero**: Planck, Wien, σT⁴, il colore che l'occhio vede e B − V;
  - **sistema solare** animato con l'equazione di Keplero, la terza legge
    verificata sui dati e il trasferimento di Hohmann Terra-Marte;
  - **esopianeti**: transito con oscuramento al bordo e curva di luce,
    velocità radiale, zona abitabile, temperatura di equilibrio;
  - **cosmologia** di Friedmann: a(t), età dell'universo, distanze e tempo
    di ritorno, galassie che si allontanano.
- **⏱️ Relatività ristretta**: diagramma di Minkowski con la relatività
  della simultaneità e l'intervallo invariante, paradosso dei gemelli con
  i segnali luminosi, dinamica relativistica, composizione delle velocità
  e Doppler.
- **🌊 Fluidi**:
  - Venturi e Bernoulli con le particelle e i manometri;
  - Poiseuille, Reynolds, sedimentazione di Stokes anche in centrifuga;
  - capillarità con la legge di Jurin.
- **∇ Calcolo vettoriale** (categoria 📐 Matematica):
  - campi nel piano con particelle trascinate, divergenza e rotore,
    potenziale;
  - lavoro e flusso con il teorema di Green verificato, anche nel caso del
    vortice in cui il «buco» conta;
  - gradiente e curve di livello.
- **🌀 Cinetica complessa** (categoria ⚗️ Chimica Fisica):
  - reazioni consecutive, parallele e reversibili con lo stato stazionario;
  - Brusselator con la biforcazione di Hopf;
  - strutture di Turing con il modello di Gray-Scott.
- **Motore unico delle animazioni**. Ogni simulazione ha una barra con
  ⏸/▶, ↺ ricomincia, velocità ×¼ … ×4 e il tempo trascorso. Le simulazioni:
  - si fermano quando escono dallo schermo o la pagina non è visibile, e
    ripartono da sole;
  - con «riduci movimento» attivo partono in pausa;
  - procedono con il tempo reale (dt al massimo 1/20 s), quindi la fisica
    non salta se il telefono perde fotogrammi.
  Applicato a meccanica, onde, circuiti, termodinamica ed equilibrio
  (WCAG 2.2.2).
- Requisiti **SCI-51** e **UI-17**.

### Migliorato
- Le animazioni dei laboratori della v233 non girano più quando sono fuori
  schermo; il gas di particelle, il moto browniano e l'equilibrio seguono
  la velocità scelta senza cambiare la lunghezza dei passi.
- **Farmacocinetica**: il grafico concentrazione-tempo compare subito con i
  valori proposti e si aggiorna a ogni modifica. Prima restava vuoto finché
  non si premeva «Calcola».
- **Editor di molecole** del Centro spettroscopico:
  - si prepara all'apertura del centro; prima la tela poteva restare
    inerte, perché veniva preparata solo per una sezione che non esiste più;
  - da vuoto dice che cosa fare.
  L'audit dei grafici passa da 2 tele vuote a nessuna.

### Banco
- Nuovo `test_scienze`, su tre configurazioni del browser.

---
## [bsi-v233] — 2026-10-23

**Laboratori in movimento: meccanica, onde, circuiti, termodinamica, metodi numerici, geometria, equilibrio**

### Aggiunto
- **🎯 Meccanica in movimento**: proiettile con la resistenza dell'aria (e
  l'angolo di gittata massima, che scende sotto 45°), urti dall'elastico
  all'anelastico, pendolo vero con il periodo esatto e lo spazio delle fasi,
  oscillatori accoppiati e modi normali.
- **〰️ Onde e ottica**: battimenti, onde stazionarie, velocità di gruppo;
  lenti e specchi con i raggi principali; diffrazione da N fenditure nel
  colore della luce.
- **🔌 Circuiti**: transitori RC, RL, RLC con i tre regimi; corrente
  alternata con i fasori e la risonanza; filtri con il diagramma di Bode.
- **🔥 Termodinamica in movimento**: cicli di Carnot, Otto, Diesel e
  Stirling nei piani p-V e T-S con i bilanci; un gas di particelle che
  arriva da solo a Maxwell-Boltzmann; moto browniano e ⟨r²⟩ = 4Dt.
- **🧮 Metodi numerici**: zeri, integrazione, EDO e interpolazione con gli
  ordini di convergenza misurati, il caso rigido e il fenomeno di Runge.
- **📐 Geometria analitica e vettori**: vettori, rette e piani in 3D;
  coniche classificate con gli invarianti, con fuochi e forma canonica.
- **⚖️ Equilibrio e Le Chatelier**: una reazione che si sposta quando la si
  disturba (specie, volume, temperatura); K in funzione di T.
- Le nuove sezioni sono nei percorsi per livello e nei cataloghi delle
  aree.
- Requisito **SCI-50**.

### Corretto
- Prima della pubblicazione: con temperatura calda bassa e rapporto di
  compressione alto il ciclo Otto «bruciava» raffreddando. La combustione
  ora parte almeno dalla temperatura di fine compressione, e lo si dice.
- Prima della pubblicazione: nelle lenti il secondo fuoco era disegnato
  sopra il primo.

### Banco
- Nuovo `test_laboratori`: 151 controlli.

---
## [bsi-v232] — 2026-10-23

**Laboratorio 3D, grafici animati e interattivi, viste molecolari migliori**

### Aggiunto
- **🧊 Laboratorio 3D** (categoria ⚛️ Fisica, collegato anche alle aree di
  Chimica e Matematica), con cinque schede:
  - **superfici** z = f(x, y) colorate per quota, con le curve di livello
    sul piano e i punti critici (massimi, minimi, selle);
  - **orbitali** idrogenoidi come nuvola |ψ|² campionata esattamente,
    colorata per segno, con energia, nodi e taglio a metà;
  - **moti nello spazio**: elica di una carica in un campo magnetico, orbita
    di Keplero inclinata, attrattore di Lorenz con due traiettorie vicine
    che si separano, curva parametrica a piacere;
  - **strutture cristalline** (NaCl, CsCl, diamante, blenda, fluorite,
    perovskite, metalli cubici ed esagonale compatto), con contenuto della
    cella, coordinazione, impacchettamento e un piano di Miller con l'angolo
    di Bragg;
  - **linee di campo** di cariche puntiformi e di una spira di corrente.
  Si ruota con dito o mouse, zoom con due dita o rotellina; rotazione
  automatica, foto PNG, schermo intero.
- **Grafici di tutte le sezioni** (59, in 19 moduli):
  - entrano con un'animazione;
  - quando i dati cambiano scivolano ai nuovi valori invece di saltare;
  - passando il dito o il mouse mostrano un **mirino** con i valori.
  Con un cursore trascinato si disegna subito, senza inseguire, e chi ha
  chiesto «riduci movimento» non vede animazioni.
- **Viste molecolari 3D**: qualità scelta per il dispositivo (occlusione
  ambientale su schede grafiche vere) e una barra con rotazione, ricentra,
  foto, schermo intero e qualità, per tutti i visori dell'app.
- Requisito **SCI-49**.

### Corretto
- Prima della pubblicazione: il campionamento degli orbitali usava un
  generatore pseudo-casuale in virgola mobile che dava estrazioni correlate
  (il 3d_z² aveva il 50 % di punti positivi invece del 61,5 %). Ora si usa
  mulberry32.

### Banco
- Nuovo `test_grafica3d`: 115 controlli.

---
## [bsi-v231] — 2026-10-23

**Tre macro-aree con un assistente: Chimica, Fisica, Matematica**

### Aggiunto
- **⚗️ Area Chimica**, **⚛️ Area Fisica** e **📐 Area Matematica**, in testa
  alle rispettive categorie. Ogni area ha tre schede:
  - **🤖 Assistente**: si scrive la domanda come la si scriverebbe al
    professore («calcola il pH di una soluzione 0,1 M di acido acetico con
    Ka = 1,8·10⁻⁵», «un'auto a 90 km/h frena con 5 m/s²», «y'' − 3y' + 2y =
    eˣ, y(0)=0, y'(0)=1»). L'assistente riconosce il tipo di esercizio o il
    modello di problema, legge i dati (numeri con le unità, che converte;
    assegnazioni come «Ka = …»; formule; reazioni; liste di valori; scelte
    come «in parallelo» o «biatomico») e risponde con lo svolgimento completo.
    Dice che cosa ha capito e da dove viene ogni dato: letto dal testo,
    dedotto dal contesto («frena», «cade», «un elettrone», «carbonio 14»),
    oppure supposto e da verificare. Propone i modelli alternativi e apre il
    risolutore per correggere i dati.
  - **🗂️ Tutti gli strumenti** della materia, raccolti dalla barra e
    cercabili.
  - **🧭 Livelli**, dalle superiori al dottorato.
- **Problema inverso**: quando la domanda chiede un dato del modello
  («quanti grammi di NaCl servono per 250 mL di soluzione 0,5 M», «che
  pressione…»), l'assistente lo ricava all'indietro dal risultato fornito nel
  testo, per bisezione.
- Le domande si possono scrivere anche in inglese. L'assistente funziona
  senza rete; un pulsante passa la domanda a Spectra.
- Spectra ha **tre strumenti nuovi**, `risolvi_matematica`, `risolvi_fisica`
  e `risolvi_chimica`, con lo stesso motore dell'assistente: 38 strumenti in
  tutto.
- Motore simbolico:
  - **integrali trigonometrici**: bisezione, prodotto in somma, potenze
    dispari;
  - **e^(c·ln u) = u^c**, che sblocca le EDO lineari con coefficiente 1/x;
  - **semplificazione delle frazioni di polinomi** con il MCD di Euclide.
- Requisito **SCI-48**.

### Banco
- Nuovo `test_assistente`: oltre 150 controlli. Su 80 domande in linguaggio
  naturale si verificano il modello capito, i dati letti con le unità e il
  risultato, rifatto per altra via; si provano il problema inverso e gli
  strumenti di Spectra; nel browser si aprono le tre aree, si fa una domanda
  scritta nella casella, si provano catalogo, ricerca e livelli, a 390 px e in
  inglese.

---
## [bsi-v230] — 2026-10-23

**Dalle superiori al dottorato: astrofisica, nucleare, quantistica, organica**

### Aggiunto
- **🧭 Dalle superiori al dottorato** (categoria 📚 Studio): chimica, fisica e
  matematica su quattro livelli, con che cosa si deve saper fare e i
  collegamenti agli strumenti dell'app.
- Esame di Fisica: **astrofisica** (luminosità e classi spettrali, magnitudini,
  parallasse, Hubble, Keplero, buchi neri, massa di Jeans, sequenza
  principale, temperatura dei pianeti, velocità radiali), **fisica nucleare**
  (energia di legame, attività, Q-valore, datazione, schermatura, dose,
  raggio nucleare, barriera coulombiana), **fisica quantistica**
  (indeterminazione, atomo idrogenoide, oscillatore e rotore con le
  popolazioni, NMR/EPR, scatola 3D, valori di aspettazione, metodo
  variazionale, perturbazioni); 8 prove svolte.
- Esame di Chimica: **organica** (insaturazioni, rese, estrazione,
  cromatografia, polarimetria), **spettroscopia** (NMR in ppm e Hz, pattern
  isotopici), **biochimica** (pI, ΔG dell'ATP, Lineweaver-Burk) e
  **dottorato** (Marcus, effetto isotopico cinetico, Wigner); 3 prove svolte.
- Esame di Matematica, livello dottorato: **teorema dei residui** ed
  **equazione del calore**; un appello svolto.
- Requisito **SCI-47**.

### Banco
- `test_esami`: 235 controlli.

---
## [bsi-v229] — 2026-10-23

**Esami UniBA di Chimica, Matematica e Fisica dalla base all'avanzatissimo**

### Aggiunto
- **🎓 Esame di Matematica (UniBA)**: i programmi di Istituzioni di
  Matematiche I e II del corso di laurea in Chimica spiegati argomento per
  argomento; un **risolutore passo per passo** per 16 tipi di esercizio
  (complessi, domini, limiti con Taylor, studio di funzione completo,
  integrali con i fratti semplici, impropri, Taylor, serie numeriche e di
  potenze, due variabili, estremi su compatti, integrali doppi, forme
  differenziali, EDO del primo e del secondo ordine con Cauchy); 16 appelli
  svolti; una simulazione d'esame a tempo.
- **🎓 Esame di Fisica (UniBA)**: Fisica Generale I e II, 48 problemi tipo
  risolti con i dati dell'utente mostrando leggi, sostituzioni e unità;
  12 prove svolte.
- **🎓 Esame di Chimica (UniBA)**: 40 problemi tipo su quattro livelli (base:
  Chimica Generale e Inorganica; intermedio: Analitica; avanzato: Chimica
  Fisica; avanzatissimo: Sackur-Tetrode, Debye-Hückel, Pourbaix), reazioni che
  si bilanciano da sole, pH esatti con il bilancio di carica, 7 prove svolte.
- Livello **avanzato e avanzatissimo** anche per Matematica (autovalori e
  diagonalizzazione, sistemi di EDO, serie di Fourier, trasformata di
  Laplace, integrali tripli; 3 appelli) e Fisica (oscillatore forzato, onde
  su corda, Doppler, fotoelettrico, Compton, relatività, corpo nero,
  particella nella scatola, effetto tunnel; 3 prove).
- **⚡ Elettrodi e stato di transizione** (Butler-Volmer, trasporto di massa,
  Tafel dai dati, Eyring con ΔH‡ e ΔS‡) e **🌟 Fotochimica, superfici e
  polimeri** (Jablonski, Stern-Volmer, Langmuir, Freundlich, BET con area
  superficiale, Mn/Mw/Đ, Carothers, catena ideale).
- Motore simbolico: fattoriale, fratti semplici, integrali ciclici
  (eˣcos x), lnⁿx, radici multiple esatte, limiti a crescita lenta, registro
  dei metodi d'integrazione per gli svolgimenti.
- Requisiti **SCI-44**, **SCI-45** e **SCI-46**.

### Banco
- `test_esami` (nuovo, 201 controlli). La batteria passa a 68 banchi.

---
## [bsi-v228] — 2026-10-23

**La matematica, dalla base all'avanzata, su un motore simbolico**

### Aggiunto
- Un motore di calcolo simbolico scritto per l'app, **`bsi-mat-cas.js`**:
  legge le espressioni come si scrivono a mano (anche `sen`, `tg`, `√`, `²`),
  lavora in frazioni esatte, semplifica in forma canonica, deriva tenendo il
  registro delle regole, integra (tabella, sostituzione, per parti) e
  restituisce una primitiva **solo** se derivandola si riottiene la funzione;
  serie di Taylor con l'aritmetica delle serie troncate, limiti con le serie
  e con l'estrapolazione di Richardson. Nessun `eval`.
- Una nuova categoria **📐 Matematica** nella barra, con otto sezioni:
  - **🔢 Basi di matematica**: cifre significative e regole dei calcoli con
    le misure, potenze e logaritmi con il pH, equazioni con i passaggi (primo
    e secondo grado, polinomi con radici complesse, equazioni fratte
    dell'equilibrio, trascendenti), allenamento con esercizi generati e
    corretti.
  - **📈 Studio di funzione**: dominio, simmetria, zeri, derivate esatte,
    estremi, flessi, asintoti verticali, orizzontali e obliqui, tangente;
    famiglie di funzioni e trasformazioni a·f(b(x−c))+d.
  - **∫ Derivate, integrali e serie**: le regole usate, le somme di Riemann,
    Simpson adattivo, il teorema fondamentale (e quando non vale), Taylor,
    limiti destri e sinistri.
  - **🔲 Algebra lineare**: Gauss-Jordan in frazioni esatte con tutti i
    passaggi, sistemi, determinante, inversa, rango, nucleo, autovalori e
    autovettori; trasformazioni del piano; **bilanciamento delle reazioni come
    nucleo** della matrice di composizione, cariche comprese.
  - **🌀 Equazioni differenziali**: campo di direzioni con le soluzioni al
    tocco, ordine di Eulero, Heun e RK4 misurato, piano delle fasi con gli
    equilibri classificati dallo jacobiano simbolico.
  - **🗻 Funzioni di più variabili**: superfici 3D, curve di livello,
    gradiente, hessiano, minimi, massimi e selle, discesa del gradiente;
    funzioni di stato, relazione di Maxwell per van der Waals, differenziali
    esatti (δq no, δq/T sì).
  - **ℂ Complessi e Fourier**: piano di Argand, radici n-esime, formula di
    Eulero, serie di Fourier con Gibbs e Parseval.
  - **📏 Statistica di laboratorio**: intervallo di confidenza, Grubbs e
    Dixon, test t e F con il valore p, propagazione delle incertezze con
    derivate simboliche e Monte Carlo, retta di taratura con LOD, LOQ e
    incertezza del campione.
- Traduzioni della categoria e dei pulsanti nelle tredici lingue della barra.
- Requisiti **SCI-41**, **SCI-42**, **SCI-43** nella matrice di tracciabilità.

### Banco
- `test_matematica` (nuovo, 154 controlli): il motore e ogni sezione contro
  valori indipendenti (tavole, matrice di Hilbert, Lambert W, Miller &
  Miller, tabelle di t, F e Grubbs), poi ogni sezione e scheda nel browser su
  due viewport. `test_lingue`: nove categorie. La batteria passa a 67 banchi.

---
## [bsi-v227] — 2026-10-22

**La fisica sotto la chimica: otto sezioni calcolate**

### Aggiunto
- Una nuova categoria **⚛️ Fisica** nella barra, con otto sezioni in cui ogni
  numero si calcola nel browser e si confronta con la letteratura:
  - **🌊 Laboratorio di Schrödinger**: stati stazionari (differenze finite,
    bisezione di Sturm, iterazione inversa) di pozzo, oscillatore armonico,
    Morse e doppia buca accanto alle soluzioni esatte; il pacchetto d'onda
    sulla barriera con Crank-Nicolson e la trasmissione esatta; le
    vibrazioni di HCl, H₂, CO e N₂ in cm⁻¹ contro l'esperimento.
  - **🧮 Hartree-Fock in diretta**: RHF/STO-3G con gli integrali di
    McMurchie-Davidson e la funzione di Boys, SCF con DIIS, otto molecole,
    orbitali disegnati, curve di dissociazione (e perché l'RHF sbaglia il
    limite di H₂). Riproduce H₂ e HeH⁺ di Szabo-Ostlund e H₂O di Crawford.
  - **🎻 Spettroscopia rotovibrazionale**: rami P e R dalle costanti di
    Huber-Herzberg, temperatura, isotopi, Raman rotazionale con la
    statistica degli spin nucleari, B e rₑ ricavati di nuovo dalle righe.
  - **🎲 Termodinamica statistica**: funzioni di partizione, S° e Cp di nove
    gas contro NIST-JANAF, popolazioni rotazionali e vibrazionali.
  - **🎱 Dinamica molecolare**: Lennard-Jones 2D dal vivo (velocity Verlet,
    termostato, viriale, Maxwell-Boltzmann, g(r)); si ferma a sezione chiusa.
  - **∑ Matematica per la chimica**: FID → spettro con la FFT, Hückel su
    dodici sistemi π, cinetiche con Runge-Kutta, minimi quadrati di
    Arrhenius con gli errori.
  - **💎 Cristallografia e raggi X**: 14 reticoli di Bravais, indici di
    Miller, diffrattogramma di polvere di undici cristalli con fattore di
    struttura ed estinzioni sistematiche.
  - **☢️ Radiochimica e nucleare**: equazioni di Bateman (generatore
    ⁹⁹Mo/⁹⁹ᵐTc, ⁹⁰Sr/⁹⁰Y, radio-radon, ¹³¹I), datazione ¹⁴C, K-Ar, U-Pb,
    formula di Weizsäcker e valle di stabilità.
- Traduzioni dei pulsanti e dei titoli nelle tredici lingue della barra.
- Requisiti **SCI-38**, **SCI-39**, **SCI-40** nella matrice di tracciabilità.

### Banco
- `test_fisica` (nuovo, 92 controlli): ogni calcolo contro un valore
  indipendente della letteratura, poi ogni sezione e scheda nel browser su
  due viewport. `test_lingue`: otto categorie. La batteria passa a 66 banchi.

---
## [bsi-v226] — 2026-10-22

**ATOMIC PROTOCOL sospeso, tutto conservato**

### Cambiato
- **Il gioco non fa più parte dell'applicazione**, su richiesta dell'autore:
  niente sezione, niente pulsante, niente download (i suoi sei script non si
  caricano e non sono più nella cache del Service Worker).
- **Niente è perso**: codice, modelli 3D (mani, pistola, creature,
  laboratori), strumenti, banco e documento di progetto sono usciti dal ramo
  principale e restano interi nel ramo `archivio/atomic-protocol`; il
  documento `docs/ARCHIVIO-ATOMIC-PROTOCOL.md` spiega che cosa c'è e come
  riattivarlo.
- La documentazione (manuale, specifiche, tracciabilità, licenze, SBOM,
  test) non descrive più il gioco: tolti i requisiti SCI-37, UI-17, UI-18,
  UI-19.
- Prima della sospensione: gli effetti vicini alla telecamera non accecano
  più (sfumano sotto il metro e mezzo, il lampo si attenua) e il fuoco
  tende all'arancione.

### Banco
- `test_atomic` esce dalla batteria con il gioco; le sue prove del cambio
  lingua tondo (UI-16), che non riguardano il gioco, restano in un banco
  nuovo, `test_sellingua` (30 controlli su due viewport).

---
## [bsi-v225] — 2026-10-22

**L'istituto abbandonato, il sangue, le orde — ATOMIC PROTOCOL**

### Aggiunto
- **I laboratori sono il cuore del livello**: entrando la porta si chiude
  alle spalle, suona la sirena, gira la luce d'allarme, e le creature del
  livello risalgono dal pavimento della mappa a ondate, combattendo sul
  terreno vero (piani, scale, banconi). Respinte tutte la porta si riapre:
  salute, energia piena, una tacca di padronanza su tutti i poteri, 500
  punti. Caduti dentro, si riparte dal punto di salvataggio.
- **Le orde nei livelli**: dal sesto livello, uno su tre ha una
  stanza-trappola con le porte bloccate e le ondate.
- **L'istituto abbandonato** (nuovo modulo `bsi-atomic-degrado.js`): in ogni
  stanza fogli sparsi, sedie rovesciate, scatoloni sfondati, cavi strappati
  dal soffitto, calcinacci, pozzanghere lucide, sporco e muffa sui muri, e
  sangue — pozze, strisciate, schizzi, impronte di mani, colature —, sempre
  di piu' scendendo nei livelli.
- **Luce da horror**: nebbia piu' scura e fredda, raggi di luce dalla
  lampada piu' vicina attraverso la foschia, neon guasti che sfarfallano,
  luce rossa d'allarme che gira.
- **Il sangue**: gocce stirate lungo il moto che cadono e macchiano, la
  nebbiolina rossa del colpo, schizzi sul muro dietro chi incassa un colpo
  forte, pozze sotto chi cade; chi e' ucciso con molto piu' del necessario
  va in pezzi (brandelli di carne che rimbalzano e restano a terra).
- **I poteri**: la palla di fuoco e le esplosioni sono fuoco vero (uno
  shader di rumore calcolato per pixel, dal bianco del cuore al nero del
  bordo, con il fumo che sale e le braci); i fulmini sono nastri frastagliati
  con i rami e l'alone; mentre si carica, archi elettrici escono dalla mano;
  le nubi sono fatte di fumo.
- Impostazioni **Istituto** (abbandonato / in ordine) e **Sangue** (sì /
  ridotto).

### Banco
- `test_atomic`: 316 controlli — le stanze devastate, l’orda nel livello (partenza,
  porte bloccate, ondate, uscita), la porta chiusa e le ondate in ognuno dei
  cinque laboratori, i brandelli, il sangue a terra, i fulmini.

---
## [bsi-v224] — 2026-10-21

**Il controllo finale — ATOMIC PROTOCOL**

### Corretto
- **Le creature non entrano più nel giocatore**: a terra si fermano a mezzo
  metro dal loro raggio (prima un verme poteva arrivare dentro la
  telecamera, con la bocca che riempiva lo schermo). In aria (il balzo) e
  sotto il pavimento (il verme che scava) no.
- Il rampicante è più piccolo e resta più distante: da vicino il giocatore
  non finisce più sotto le sue zampe.
- **Gli avvisi a terra si leggono su ogni pavimento**: il disco è una macchia
  scura del colore dell'attacco, l'anello è luce, e l'onda del bruto ha un
  muro di luce basso che corre sul pavimento. Dentro un cerchio che si
  riempie (anche sotto i piedi, fuori vista) i bordi dello schermo pulsano e
  un ticchettio accelera.

### Banco
- `test_atomic`: 297 controlli — la combustione provata in gioco (la nube
  del cloro, poi la palla di fuoco dell'ossigeno) e la distanza minima dal
  corpo del giocatore.

---
## [bsi-v223] — 2026-10-21

**Le reazioni, la luce, la polvere — ATOMIC PROTOCOL**

### Aggiunto
- **Le reazioni chimiche** fra quello che fai e lo stato delle creature:
  la **frantumazione** (una creatura gelata dall'azoto che prende un colpo
  pesante va in pezzi, e le schegge feriscono chi le sta intorno), la
  **combustione** (la palla di fuoco dentro una nube tossica la fa esplodere),
  la **conduzione** (la scarica su una creatura gelata o in una pozza d'acido
  corre su tutte quelle vicine e le stordisce). Ogni reazione rende punti ed
  energia; la prima volta si spiega che cosa è successo.
- **La luce di contorno** sulle creature: nel buio la sagoma si stacca dal
  fondo con un filo di luce sui bordi, appena del loro colore.
- **I coni di luce** sotto le lampade e **la polvere** che galleggia
  nell'aria intorno a chi guarda.

### Cambiato
- Il rig procedurale non muove più le «braccia» delle forme a quattro zampe
  (il rampicante) e le muove meno nella fanghiglia: niente più deformazioni.
- I cerchi e le onde degli attacchi speciali sono più spessi e più visibili.

### Banco
- `test_atomic`: 295 controlli — conduzione e frantumazione provate in gioco.

---
## [bsi-v222] — 2026-10-21

**Le mosse, la paura, la fluidità — ATOMIC PROTOCOL**

### Aggiunto
- **Le mosse del giocatore**: la **schivata** (`C` o 💨: uno scatto di un
  metro e mezzo con un attimo d'invulnerabilità, il campo visivo che si
  allarga e la sfocatura radiale); la **combinazione** corpo a corpo (`V` o 👊
  a tempo: jab sinistro, gancio col calcio della pistola, diretto pesante che
  butta a terra), con il tempo che si ferma un istante su ogni colpo; il
  **potere caricato** (tenendo premuto `G`, il tasto destro o ✦: la sfera
  cresce, il potere esce fino a 2,5 volte più forte); l'**esecuzione** (`V`
  su una creatura a terra, stordita o quasi morta: rallentatore, due colpi e
  il colpo finale; rende energia e salute; gli occhi della creatura
  lampeggiano bianchi quando si può).
- **Gli attacchi speciali delle creature**, annunciati e schivabili: il bruto
  batte i pugni a terra (un'onda d'urto da saltare), il cristallino esplode in
  schegge, la fanghiglia sputa fango acido che resta a terra, il cervo urla
  (rallenta) e si lancia, l'abissale sparisce e ricompare di fianco, il verme
  si infila nel pavimento e sbuca sotto i piedi, il rampicante fa un balzo
  altissimo e ricade dove eri. Cerchi e onde a terra mostrano dove colpiranno.
- **Le reazioni**: il colpo pesante butta a terra (si rialza dopo un po'), la
  carica di una creatura s'interrompe con un pugno a tempo.
- **Il rig procedurale** per le creature senza scheletro (rampicante,
  fanghiglia, abissale, bruto): gambe che camminano col passo, braccia che si
  alzano per caricare e calano nel colpo, busto che si china e respira,
  tentacoli che ondeggiano — nello shader, senza costo per la CPU.
- **La torcia** sulla spalla, che segue lo sguardo con un attimo di ritardo e
  ogni tanto tremola.
- **La passata finale** con l'aberrazione cromatica, il rosso che batte sui
  bordi quando la salute è poca, il colore che se ne va nel rallentatore.
- **Il suono del posto**, sintetizzato: il ronzio basso dell'istituto, colpi
  lontani nei tubi, i passi, i fruscii delle mosse, i tonfi, i versi delle
  creature (ognuna la sua voce) quando caricano.

### Cambiato
- **Fluidità**: le creature si disegnano interpolate fra due passi del gioco;
  proiettili, nubi ed effetti vanno col tempo vero del fotogramma; la
  geometria ferma delle stanze è fusa per materiale (da circa 340 a 110
  chiamate di disegno); le creature fuori dall'inquadratura non si disegnano;
  la **risoluzione dinamica** scende fino al 55% quando un fotogramma costa
  troppo e risale quando c'è margine (impostazione `risdin`).
- Il Codex passa al tasto `K` (`C` è la schivata).

### Banco
- `test_atomic`: 293 controlli — combinazione, caduta, esecuzione col
  rallentatore, schivata, potere caricato, sette attacchi speciali, torcia.

---
## [bsi-v221] — 2026-10-16

**Trecento livelli, salvataggi, varianti — ATOMIC PROTOCOL**

### Aggiunto
- **Tre atti, 300 livelli**: «Il contenimento» (1–100), «Il riflusso»
  (101–200, gelido), «Il nucleo profondo» (201–300, rovente), con le zone
  ritinte, livelli più lunghi e più popolati, appunti di trama nuovi e il
  finale al livello 300; scelta dei livelli divisa per atto.
- **I guardiani tornano** come MK II (atto II) e Ω (atto III): trenta in
  tutto, con più colpi per fase, ritinti e più grandi.
- **Le varianti delle creature** per atto (gelide, roventi: più grandi,
  veloci, frequenti, con raffiche più larghe, sputi multipli, combinazioni
  e cariche ripetute) e le **élite** (alone d'oro, vita doppia).
- **Punti di salvataggio** dentro i livelli: si attivano passando, salvano
  posizione e progressi anche nella partita salvata; cadendo si riparte da lì.

### Cambiato
- **Le due mani sono uguali**: la sinistra è il guanto di nitrile del rig,
  specchio della destra, con le sue animazioni (tolta la mano robotica).

### Banco
- `test_atomic`: 280 controlli — 300 livelli, trenta guardiani, salvataggi,
  varianti, élite, ripartenza, mani uguali.

---
## [bsi-v220] — 2026-10-16

**Combattimento, poteri, fluidità — ATOMIC PROTOCOL**

### Aggiunto
- **Le creature fornite** come nemici: verme (con le sue animazioni),
  rampicante (salta), fanghiglia (sputa acido), cervo (con la sua clip),
  abissale (fluttua e lancia sfere), cristallino (con la sua clip, carica),
  bruto (carica; braccia abbassate dalla T-pose); una nuova per ala, da tre a
  quattordici per livello, ognuna col suo colore e il suo punto debole.
- **Gli attacchi dei nemici**: si annunciano (carica, occhi accesi) e
  colpiscono alla fine, si schivano; l'arco rosso dice da dove arriva il
  colpo; le braccia sobbalzano quando si viene colpiti.
- **Il pugno** della mano robotica (V, 👊): ferisce e respinge.
- `skeleton_utils.js` (three.js r128, MIT) per le copie con lo scheletro.
- **La pistola spara sempre** (clic sinistro, X, ◉; a raffica tenendo
  premuto), con i composti come munizioni potenziate.
- **Poteri distinti** per famiglia di elementi: scarica a catena (sodio e
  potassio esplosiva), palla di fuoco, nube tossica, nube di gelo, onda
  d'urto, scudo, fissione — con l'**energia** che si ricarica.
- **Scelta rapida** dei poteri: barra in basso (un tocco), tasti 1–9, rotella.
- **Zoom** per mirare (🔍, Z, tasto centrale) e **schermo intero** (⛶, H).
- Effetti: mirino che aggancia con nome, vita e debolezza del bersaglio;
  numeri dei danni; colpo a segno sul mirino; tracce, scintille, esplosioni,
  fulmini; il lampo di luce dei colpi; lo scossone.

### Migliorato
- **Fluidità**: movimento con inerzia (accelera e frena), diagonali non più
  veloci; disegno interpolato fra i passi fissi del gioco, niente scatti
  sugli schermi a 90/120/144 Hz.

### Banco
- `test_atomic`: 271 controlli — creature, attacchi, pugno, combattimento,
  poteri, energia, barra, zoom, schermo intero, accelerazione, interpolazione.

---
## [bsi-v219] — 2026-10-16

**I laboratori dalle mappe, e la sinistra giusta — ATOMIC PROTOCOL**

### Aggiunto
- **Cinque laboratori da percorrere**, dalle mappe fornite: Small Lab
  (Biohazard Rooms), Sci-fi lab (Agata Wilczek), Flynn's Secret Lab
  (jvouillon), Location underground laboratory (bazz4r), Overgrown Laboratory
  (MichalTroye); con il reattore (Quantum Laboratory X Alpha, -X-ScornGames) e
  la capsula (Sci Fi lab, IrisProcess). Tutti CC-BY 4.0, crediti nel Codex.
- In ogni livello una **porta con la targa** nella stanza del banco: entra nel
  laboratorio dell'ala, con il banco di sintesi sul bancone vero della mappa
  e la porta per tornare. Ci si muove su una griglia di cammino calcolata
  dalla geometria (pavimenti, scale, muri, arredi), con la mappa e l'HUD del
  laboratorio.
- `tools/usd-in-glb.py` (USDZ → GLB) e `tools/prepara-mappe.js` (ottimizzazione
  e griglia di cammino): 145 MB di sorgenti → 37 MB.

### Corretto
- **La sinistra sembrava una destra rovesciata**: la mano robotica si
  allineava sul pollice, ripiegato nel pugno del rig, e girava di un quarto.
  Ora si allinea sulla linea delle nocche.
- **Le animazioni delle mani**: le dita robotiche copiano quanto sono chiuse
  quelle della sinistra del rig in ogni animazione, invece di pose inventate;
  tolto il giro forzato del palmo col potere; il jab per lanciare e prendere
  e l'ispezione da fermi muovono solo il braccio sinistro (prima l'ispezione
  faceva girare anche la destra con la pistola, e il jab era il destro).
- La batteria v218 aveva un `test_atomic` fallito per un'attesa troppo corta
  sullo strumento in mano: ora si aspetta che cambi.

### Banco
- `test_atomic`: 245 controlli — i laboratori (porta in tutti i livelli, e
  per ogni mappa: cartello, ingresso, triangoli, pavimento, muri, banco,
  ritorno) e il jab/ispezione solo a sinistra.

---
## [bsi-v218] — 2026-10-16

**La mano robotica si muove — ATOMIC PROTOCOL**

### Aggiunto
- **Dita robotiche articolate**: un perno su ogni giunto del modello, la
  falange e il resto del dito dentro; ogni dito segue una molla con
  l'inerzia. A riposo appena piegate e vive, per prendere si aprono e si
  chiudono, col potere si aprono e ondeggiano, nel lancio scattano aperte,
  correndo si chiudono un po'.

### Migliorato
- La sfera dell'elemento sta più alta sul palmo (si vede la mano sotto) e
  nel lancio non si gonfia oltre misura.
- La manica che si sgretola: granelli più fini e più fitti, aderenti al
  braccio, di stoffa bianca con grumi scuri e schegge azzurre (non più
  coriandoli sparsi).

### Banco
- `test_atomic`: 207 controlli — le cinque dita articolate e la loro chiusura
  per prendere.

---
## [bsi-v217] — 2026-10-16

**Braccia animate, mano robotica e la sfera dell'elemento — ATOMIC PROTOCOL**

### Aggiunto
- **Le braccia del rig** «Fists (2023) | First Person Animations» (1Matzh,
  CC-BY 4.0): scheletro e otto animazioni della prima persona fusi secondo il
  gioco — passo, corsa, Equip al cambio di strumento, il jab sinistro per
  lanciare e prendere, Inspect da fermi. Divisa → camice, guanti → nitrile.
- **La pistola impugnata davvero**: agganciata all'osso del pugno destro, il
  polso che gira da guardia a impugnatura, le dita a cilindro intorno
  all'impugnatura, la canna avanti; segue ogni animazione.
- **La mano sinistra robotica** («Robotic Hand», SeanNicolas, CC-BY 4.0),
  specchiata e agganciata al braccio.
- **La sfera dell'elemento**, sul modello dell'immagine fornita: un
  poliedro di luce venata col guscio di spigoli, gli aloni e una chioma di
  filamenti vivi, **del colore dell'elemento**; il palmo si gira in su e la
  manica sinistra si sgretola in granelli e scintille.
- `tools/prepara-modelli.js`: modalità `braccia` (skybox ed emissione via,
  scheletro ridotto da 1423 a 52 ossa, animazioni alle loro tracce: 13 → 6,4
  MB) e `robot`.

### Corretto
- La lettura delle matrici (MAT4) nello strumento dei modelli: senza, le
  matrici di legame si azzeravano e la pelle spariva.

### Banco
- `test_atomic`: 205 controlli — rig, otto animazioni, nitrile, presa (19 mm
  dal centro dell'impugnatura), indice sopra il mignolo, canna avanti,
  pistola agganciata, passo, Equip, rinculo, mano robotica, palmo in su,
  sfera del colore dell'elemento, granelli.

---
## [bsi-v216] — 2026-10-15

**PS2 seria e mani che si muovono come mani — ATOMIC PROTOCOL**

### Aggiunto
- **La passata finale «PS2 seria»**: mondo e braccia disegnati in una
  texture multicampionata e trattati da uno shader — colore da pellicola
  (meno saturo, ombre fredde, luci calde, alte luci compresse, più
  contrasto), bagliori morbidi delle luci forti, vignettatura, grana in
  movimento. Non in PS1, che ha la sua.
- **Le dita con l'inerzia**: ogni dito insegue la posa con una molla
  smorzata, con i micro-movimenti di una mano viva. L'indice preme il
  grilletto di scatto e rilascia morbido; la canna salta su nel polso a
  ogni spruzzo; cambiando composto la presa si allenta e si riprende; la
  sinistra si apre prima di prendere, apre le dita nel lancio, le fa
  ondeggiare col potere, le chiude un po' correndo; da fermi la destra alza
  la pistola per guardarla.

### Banco
- `test_atomic`: 201 controlli (erano 196) — l'inerzia delle dita, il
  rinculo nel polso, le mani vive, l'apertura prima della presa, la
  passata finale.

---
## [bsi-v215] — 2026-10-15

**Le mani, il camice e la pistola dai modelli scelti dall'utente — ATOMIC PROTOCOL**

### Aggiunto
- **Mani vere con lo scheletro** (`models/mani-atomic.glb`, da «hands
  animation» di hugo colauto): ogni posa del gioco è fatta di fotogrammi della
  loro animazione, campionata (le dita, 15 fotogrammi al secondo) e fusa dito
  per dito — la presa sull'impugnatura, l'indice che preme il grilletto
  spruzzando, il palmo aperto del potere, la sinistra che si chiude a
  prendere, il gesto d'attesa (il pugno che si apre) quando si sta fermi. In
  **guanto di nitrile**: la texture della pelle ricolorata dalla sua
  luminosità, con le normali del modello, così nocche, unghie e pieghe si
  leggono sotto la gomma. Allineamento automatico alla manica.
- **La manica del camice** (`models/manica-atomic.glb`): l'avambraccio
  ritagliato dalla scansione «Modern Scientist in a Lab Coat» (restore50,
  CC-BY 4.0), con l'orlo e il polsino azzurro della camicia, specchiato per il
  braccio sinistro; la manica procedurale resta dentro come fodera.
- **La pistola a capsula** (`models/pistola-atomic.glb`, «Capsule Gun» di
  sc8di, CC-BY 4.0) al posto del dispensatore: l'impugnatura si allinea
  all'anello delle dita chiuse e al palmo, il polso devia quanto un polso vero
  perché la canna guardi avanti, la capsula prende il colore del composto, il
  grilletto segue l'indice, lo spruzzo parte dalla punta della canna.
- `tools/prepara-modelli.js`: dai tre GLB originali (45 MB) ai derivati
  (3,6 MB) — texture in JPEG, il ritaglio della manica senza la pelle.
- I crediti dei modelli 3D nel Codex e in `models/CREDITS.md`.

### Corretto
- La piega del polso della mano sinistra del modello andava al contrario:
  quella mano è la destra specchiata, e nel riferimento specchiato una
  rotazione cambia verso. Ora il palmo del potere sale verso lo sguardo.
- L'avambraccio del modello usciva dalla manica col polso piegato: la piega
  la fa l'osso del polso, l'avambraccio resta dritto nella manica.
- Le pieghe della manica procedurale potevano rientrare e far bucare il
  braccio: ora sporgono solo verso l'esterno.

### Banco
- `test_atomic`: 196 controlli (erano 185) — i tre modelli caricati, due mani
  con lo scheletro in nitrile, l'animazione campionata, le dita
  sull'impugnatura, l'ugello in punta alla canna, la pistola che ruota nella
  presa meno di 0,6 rad, il dispensatore procedurale nascosto, il palmo che
  sale col potere; il passo si misura a modelli arrivati.

---
## [bsi-v214] — 2026-10-15

**Nello spirito di BioShock — atmosfera, mani, dinamiche, misteri — sulla
trama del Protocollo 12.**

### Gli ambienti

* **Art déco**: marmo a scacchi con i filetti d'ottone, zoccolo in noce,
  carta da parati verde e oro, lesene di marmo, applique a ventaglio,
  plafoniere déco, soffitto a cassettoni, portali d'ottone, targhe con le
  lettere d'oro; manifesti dell'Istituto e del **Consorzio Albedo**, scritte
  a gesso sui muri, gocce che cadono dal soffitto nelle pozze; luce ambra e
  più ombra.

### Le mani

* La **sinistra tiene vivo l'elemento** come un plasmide: scintille con l'arco
  elettrico per i metalli, fiamma per i combustibili, vapore per i gas, luce
  per il resto, con una luce vera dal palmo; usandolo lo **lancia**. La destra
  resta al dispensatore per i composti.

### I misteri

* **Trenta registrazioni** su magnetofoni déco, tre per zona, sette voci
  (Sarti, il Custode, Lenzi, Vela, Moro, l'avv. Ferri del Consorzio Albedo, il
  Direttore): si **ascoltano mentre si gioca** con la voce del dispositivo e i
  sottotitoli, e finiscono nel Codex. Ricompongono il segreto della frase
  «riprendere comunque».

### L'HUD

* Salute a tacche e reagente in mano in **cornici d'ottone**.

### Verifica

`test_atomic`: **185 controlli** (minimo 185).

---
## [bsi-v213] — 2026-10-15

**Mani anatomiche in prima persona, un pulsante flottante tutto suo per il
gioco, e i bug trovati a tappeto.**

### Le mani

* Ogni dito è **un unico tubo** che segue le tre falangi lungo una curva, si
  assottiglia, si gonfia sulle nocche e finisce con il polpastrello; il palmo è
  **un volume solo** con il dorso, le nocche, l'eminenza del pollice e il polso.
  Prima erano pezzi accostati, e si vedevano come perline.
* La destra avvolge l'impugnatura del dispensatore con le punte delle dita
  visibili sul fianco, la sinistra è rilassata; il guanto di nitrile ha la
  grana fine e qualche piega, senza le righe di prima.

### Il pulsante del gioco

* Il gioco non sta più nella barra delle sezioni: ha un **pulsante flottante**
  sopra Spectra e il menu ✨, una pillola viola e arancio con un'icona nuova e
  animata — l'esagono del benzene, la beuta con il liquido luminoso,
  l'elettrone in orbita.

### Bug corretti

* I pulsanti flottanti ✨ e Spectra **coprivano la scena 3D** durante il gioco:
  ora si tolgono di mezzo mentre la sezione è aperta e tornano all'uscita (anche
  il controllo del sito che li rimetteva visibili lo sa).
* Uscendo dalla sezione il **puntatore restava bloccato** e i tasti premuti
  restavano «tenuti».
* In prima persona **A e D giravano** invece di spostare di lato.
* Un giro automatico su **96 sezioni, 25 strumenti del menu ✨** e tutti i
  menu del gioco su tredici livelli, in tre grafiche e due lingue, non ha
  trovato errori JavaScript.

### Verifica

`test_atomic`: **174 controlli** (minimo 170).

---
## [bsi-v212] — 2026-10-15

**Si gioca in prima persona, con le braccia e lo strumento curati come in un
FPS.**

Il protagonista visto da fuori non poteva arrivare al livello degli ambienti:
una figura umana costruita interamente dal codice resta un manichino. In prima
persona quello che si vede di sé sono le braccia — e quelle si possono fare
bene.

### Le braccia e lo strumento

* Maniche del camice con il polsino cucito e aperto, l'interno in ombra, il
  bordo del guanto che esce; mani in nitrile a cinque dita in tre falangi.
* Il **dispensatore** nella destra: corpo in polimero con anelli cromati,
  impugnatura in gomma, fiala di vetro con il liquido del colore del composto,
  schermo sul fondo con formula e dosi, ugello con LED e bagliore.
* Disegnate in una **scena loro**, dopo il mondo: non entrano nei muri.

### Il movimento

* Le braccia oscillano col passo, restano indietro nelle curve, respirano,
  affondano all'atterraggio, **rinculano spruzzando** con una nuvola di
  goccioline; cambiando composto lo strumento si abbassa e risale; la sinistra
  si allunga a prendere e toccare.
* La testa sale e scende col passo e si inclina appena di lato.
* **Sguardo libero**: mouse con il puntatore bloccato sul computer,
  trascinamento del dito sul telefono; il mirino si allarga su ciò che si può
  usare.
* La terza persona resta a scelta (tasto `V`).

### Verifica

`test_atomic`: **164 controlli** (minimo 160) — prima persona di partenza,
braccia in una scena loro con più di quaranta pezzi e cinque dita, lo strumento
che mostra il composto in mano, le goccioline, lo sguardo che gira ma non oltre
una testa.

---
## [bsi-v211] — 2026-10-15

**Grafica di livello PlayStation 2, e niente horror: i guardiani sono le
macchine dell'istituto.**

### Il protagonista

* **Migliaia di poligoni**: la testa è una sfera da circa 8000 triangoli
  deformata a mano (cranio, arcate, zigomi, naso con le ali, labbra, mento); la
  figura intera ne ha circa 29 000.
* **Occhi modellati** — bulbo, iride dipinta, palpebra — e il **viso dipinto a
  sfumature, senza contorni**: pelle, rossore, ombre delle orbite e sotto il
  naso, luce su fronte e mento, sopracciglia fatte di peli, barba appena rasata.
  I contorni erano quello che lo faceva sembrare un cartone animato.
* **Mani a cinque dita** in guanti di nitrile; camice con revers, colletto,
  tasche, bottoni, penna e cartellino modellati; capelli a ciocche; scarpe da
  un profilo estruso. Texture a 512 px con **mappe di rilievo** (pieghe, trama).
* Tolti i dettagli da sopravvivenza (semimaschera, occhiali sulla fronte): è un
  direttore di laboratorio, non un soldato.

### I guardiani e i residui

* I dieci guardiani sono **macchine di laboratorio fuori controllo**, senza
  carne, ossa o cadaveri: la pompa con i bracci idraulici, l'estrusore dei
  polimeri, il banco laser con la torretta, il robot sequenziatore con la
  doppia elica in vetro, l'impianto di elettrolisi con i dendriti di rame, il
  criostato che sfiata azoto, la farmacia automatica, la cella calda con i
  manipolatori e la luce di Čerenkov, il chiarificatore con il ponte
  raschiatore, il reattore con gli anelli magnetici. Bracci, carrelli, barre e
  ponti si muovono; i quadri di controllo dicono che cosa non va.
* I **residui** sono chiazze di solvente che si spostano, con le bolle e i
  vapori.
* Descrizioni, guida e manuale riscritti di conseguenza; la chimica delle fasi
  non cambia.

### Il motore

* **Grafica alta di partenza** (media sui telefoni con pochi processori); il
  PS1 resta come scelta retrò.
* **Bagliori** a sprite additivi su plafoniere, schermi, LED, fari e nuclei.

### Verifica

`test_atomic`: **155 controlli** (minimo 150) — grafica alta di partenza, più
di cinque bagliori in scena, occhi modellati, cinque dita, testa sopra i 3000
triangoli e figura sopra i 15 000, nessuna scatola nel protagonista e nei dieci
guardiani.

---
## [bsi-v210] — 2026-10-15

**Le figure rifatte nel realismo grezzo dei titoli PlayStation 1, e cento
livelli in dieci zone.**

### Il protagonista

* **`bsi-atomic-figure.js`** (nuovo): un ricercatore, non un pupazzo. Un
  metro e settantotto con le proporzioni di un adulto; la testa è una sfera
  deformata (mandibola, mento, zigomi, naso, nuca) con il **viso dipinto** —
  occhi con le palpebre, occhiaie, sopracciglia, ombra del naso, bocca, barba
  di un giorno — in proiezione piana, come i volti di Resident Evil.
* Il **camice** in tre pezzi con pieghe, aloni di reagente, sporco in fondo,
  revers aperti su camicia e cravatta, taschino con penna e dosimetro,
  cartellino con la foto; le **falde** separate che seguono le gambe.
* **Attrezzatura**: guanti di butile lunghi, stivali di sicurezza,
  semimaschera al collo con i filtri, occhiali alzati sulla fronte, torcia,
  cintura con il marsupio.
* **Animazioni smorzate**: passo misurato in metri, ginocchia che si piegano
  nel verso giusto (prima si piegavano all'indietro), bacino che oscilla e
  ruota, busto in controrotazione, testa stabilizzata, falde in ritardo,
  respiro e cambio di peso da fermo, inclinazione in curva, corsa diversa
  dal passo.

### I guardiani e i residui

* I cinque guardiani rifatti e **cinque nuovi**: POMPA 7 (pompa incrostata
  con lo squarcio, la girante, il braccio di gru, i manometri), IL POLIMERO
  (plastica fusa e carne con una maschera antigas), LO SPETTRO (una persona
  carbonizzata che galleggia tra le schegge dello spettrometro), ELICA (una
  colonna vertebrale a doppia elica), LA CELLA, IL GELO, LA DOSE, IL
  DECADIMENTO, LA MELMA, PROTOCOLLO 12 (il reattore squarciato con il nucleo
  di magma). Superfici deformate dal rumore, texture sporche — ruggine che
  cola, carne con le vene, brace, magma — e **nessuna scatola**.
* I **residui** strisciano: una massa con un torace e un cranio mezzo
  sciolti e due appendici che graffiano il pavimento. Niente occhi simpatici.

### Lo stile PS1, di partenza

* La grafica di partenza è il **PS1**: luce sui vertici sfumata (Gouraud,
  come la macchina vera, non le facce piatte di prima), vertici agganciati
  alla griglia, **colore a 15 bit con la retinatura di Bayer**, texture senza
  filtro, pavimenti suddivisi per la luce, ombre a macchia, nebbia cupa,
  480×360 a pixel quadrati. La grafica moderna (PBR, ombre) resta a scelta.

### Cento livelli

* **Dieci zone da dieci livelli**: le cinque di prima più Elettrochimica,
  Criogenia, Farmacologia, Radiochimica e Depurazione. Un guardiano al
  decimo livello di ogni zona, in un'arena di almeno 14 m; dentro la zona i
  livelli crescono. Due ricette nuove (HNO₃, CaO). La trama ha dieci capitoli.
* Per arrivare a 150 o 200 livelli basta aggiungere zone e guardiani.

### Corretto

* **Il chimico camminava all'indietro**: il modello guardava verso la
  telecamera mentre avanzava (dalla v208). Ora guarda dove va.
* Dopo un cambio di grafica a partita aperta il ciclo non ripartiva.
* Passando da un livello all'altro geometrie e texture restavano nella
  memoria della scheda video: ora si liberano.

### Verifica

`test_atomic`: **151 controlli** (minimo 140) — i cento livelli, i dieci
guardiani senza scatole, il viso dipinto, il chimico che avanza guardando
dove va e le ginocchia che non si piegano all'indietro, la memoria che non
cresce attraversando dieci livelli, il PS1 di partenza.

---
## [bsi-v209] — 2026-10-15

**ATOMIC PROTOCOL ha venti livelli e una grafica realistica. Niente più
cubetti.**

### Venti livelli, cinque ali, cinque guardiani

* **`bsi-atomic-livelli.js`** (nuovo) genera i venti livelli da un seme — il
  numero del livello — su una griglia in cui due stanze vicine condividono il
  muro e la porta: le porte combaciano per costruzione. Percorso principale,
  stanze laterali, arredi lungo i muri, banco, terminale, paratia, ascensore.
* **Cinque ali** — Stoccaggio, Sintesi organica, Spettroscopia, Biochimica, il
  Nucleo — ognuna con i suoi elementi, le sue ricette, la sua nebbia e la sua
  luce.
* **Cinque guardiani** ai livelli 4, 8, 12, 16 e 20: POMPA 7 (HCl → sodio),
  IL POLIMERO (H₂O₂ → H₂SO₄), LO SPETTRO (acido ascorbico → CO₂), ELICA
  (appaiare le basi → NaOH), PROTOCOLLO 12 (bilanciare → bicarbonato →
  argon). Ogni fase chiede una cosa di chimica precisa; quella sbagliata non
  fa niente. Prima di ogni guardiano ci sono sempre gli elementi per batterlo.
* **Dieci ricette** con equazioni **contate atomo per atomo**; il bicarbonato
  si fa da due composti (NaOH + CO₂). A «Esperimento» la reazione va
  bilanciata prima di farla.
* **Enigmi generati** ai terminali, diversi per ala: gruppo funzionale
  cerchiato, nome IUPAC, costruire una catena, bilanciare, DNA complementare,
  domande da tutto il sito. Le strutture sono dati, disegnate da una funzione
  sola.
* **La trama** in cinque appunti e un finale: chi ha scritto «riprendere
  comunque»?
* **Salvataggio** a ogni livello, «continua» e **scelta del livello** dal
  titolo; mappa delle stanze viste; ✦ usa quello che hai in mano, ⟳ lo cambia;
  i residui si sciolgono con un ossidante.

### Grafica realistica

* **`bsi-atomic-grafica.js`** (nuovo): materiali fisici (PBR) con texture
  procedurali e mappe di rilievo e di ruvidità calcolate dal rumore, riflessi
  d'ambiente, ombre morbide, tone mapping ACES in sRGB, vignettatura,
  telecamera smorzata. Il chimico, gli scaffali con la vetreria, i fusti con
  l'etichetta di pericolo, il banco in resina, le cappe, le paratie
  scorrevoli, i guardiani: **nessuna scatola**.
* Si disegnano solo la stanza e quelle vicine, e le luci sono sempre cinque,
  spostate sulle plafoniere vicine: un livello di dodici stanze costa come
  una e mezza.
* Impostazione **Grafica**: alta, media (per i telefoni, di serie su quelli
  con pochi processori), **PS1** — lo stile di prima resta come scelta, e
  cambiarlo non perde la partita.

### Corretto

* Il generatore ordinava con un comparatore che chiamava il caso: Node e
  Chromium davano **livelli diversi dallo stesso seme**. Ora il caso si estrae
  prima di ordinare.
* Il bersaglio di ✋ era il più vicino anche se di lato: ora conta dove si
  guarda.

### Verifica

`test_atomic` riscritto: **132 controlli** (minimo 110) — i venti livelli
percorsi, le equazioni contate e una sbagliata respinta, il livello 1 giocato
fino all'ascensore e al salvataggio, i guardiani nei due versi, il motore
misurato nella scena viva (ACES, ombre, PBR, nessuna scatola, luci costanti)
e il PS1 come scelta.

---
## [bsi-v208] — 2026-10-15

**Il gioco è rifatto da zero: ATOMIC PROTOCOL, esplorazione 3D low-poly in
stile PlayStation 1. Niente più runner.**

### Che cos'è adesso

Un chimico chiuso in un istituto sigillato. Si **cammina** — non si corre da
soli — per sette stanze collegate da porte, si raccolgono **elementi**, si
**sintetizzano** composti al banco, si risolvono **enigmi con strutture
molecolari** ai terminali e si abbattono **guardiani con una debolezza
chimica**. Visuale a scelta in **terza o prima persona**, salvata; quattro
difficoltà, dal «Facile» all'«Esperimento».

Il progetto completo — direzione artistica, inventario, laboratorio di sintesi,
sistema di combattimento, Zona 1, primo boss e primo enigma — è in
**`docs/16-Atomic-Protocol-Design.md`**.

### Lo stile PS1 è fatto di limiti, e i limiti sono rifatti

Non è un filtro «retro»: sono i vincoli di quella macchina, riprodotti uno per
uno.

| limite vero | come si rifà | che cosa si vede |
|---|---|---|
| 320×240 | la scena si disegna a 320×240 e si ingrandisce a pixel quadrati | bordi scalettati |
| niente filtro bilineare | `NearestFilter` su ogni texture | texture nette e sgranate |
| vertici a coordinate intere | **vertex snapping** innestato nel vertex shader | i poligoni *tremano*: è il segno più riconoscibile di quella macchina |
| niente luci dinamiche | luce sui vertici con `flatShading` | ombre dure |
| memoria scarsa | nebbia densa, modelli a blocchi | fondali che spariscono nel buio |

Si può **ridurre o spegnere** dalle impostazioni, insieme alla risoluzione
interna: una scelta estetica forte deve restare una scelta.

### Il chimico

Low-poly e **articolato**: bacino, busto, collo, testa e quattro arti con due
snodi ciascuno. Cammina con le gambe in opposizione, le braccia sfasate di mezzo
ciclo e il bacino che rimbalza; da fermo respira; in aria raccoglie le
ginocchia. In prima persona il corpo non si disegna.

### Inventario, sintesi, enigmi, guardiani

* **Inventario**: ogni elemento porta simbolo, nome, Z, massa, gruppo, periodo,
  elettronegatività ed energia di ionizzazione — letti da `ELEMENTS`, non
  riscritti — più il potere e la **padronanza** (1–5, sale usandolo).
* **Laboratorio di sintesi**: HCl, NaOH, H₂O₂, NaCl, con l'equazione bilanciata
  e la resa legata alla padronanza media dei reagenti. Le ricette si sbloccano
  esplorando, risolvendo enigmi e abbattendo guardiani.
* **Enigmi**: strutture molecolari **disegnate** — riconoscere il gruppo
  funzionale cerchiato, dare il nome IUPAC, costruire l'etanolo scegliendo gli
  atomi. Sbagliando la paratia resta chiusa.
* **POMPA 7**: coperta di ossido (serve un **acido**: Fe₂O₃ + 6 HCl → 2 FeCl₃ +
  3 H₂O), poi metallo nudo nel vapore (serve il **sodio**: 2 Na + 2 H₂O → 2 NaOH
  + H₂), poi il rotore. Il sale non le fa niente; l'acido in fase 2 nemmeno.

### Gli enigmi vengono da tutto il sito

I 28 generatori restano: tavola periodica, spettri IR/¹H/¹³C/J, reazioni,
retrosintesi, amminoacidi, linguaggi, farmaci, sicurezza GHS, costanti, unità,
tecniche di laboratorio, biomolecole, vie metaboliche.

### Che cosa è stato tolto

`bsi-gioco.js`, `bsi-gioco-3d.js` e `test_gioco.js` non ci sono più: il gioco
vecchio è stato **rimosso**, non lasciato accanto al nuovo. Una sola casa per
funzione, anche quando la funzione è «il gioco».

### Il banco

`test_atomic` — **91 controlli**: il grafo delle stanze (ogni porta con la sua
gemella, tutte raggiungibili, nessuna stanza dentro un'altra), i muri che
fermano e le porte che fanno passare, il giro completo della Zona 1, il motore
PS1 (WebGL, 320×240 misurati, pixel quadrati), le impostazioni che si ricordano
davvero, il ciclo che si ferma a sezione chiusa, e i dodici comandi da ≥ 44 px
sul telefono. **Nei due versi** dove conta: il sale non fa niente alla ruggine,
l'acido sì; due reagenti senza ricetta non producono nulla; sbagliando l'enigma
la paratia resta chiusa.

---
## [bsi-v207] — 2026-10-15

**ELEMENT CHEMIST in 3D vero: WebGL, un chimico articolato che corre, salta e
gira su sé stesso, un corridoio di laboratorio con luci e nebbia — e una trama
con un colpevole.**

### Tre dimensioni, non una prospettiva finta

Il mondo adesso lo disegna un motore vero (`bsi-gioco-3d.js`): scena, telecamera
in terza persona che insegue, luci, nebbia, soffitto e plafoniere. Three.js era
**già in questo repository** — lo usano il visore molecolare e l'atlante — e il
Service Worker lo tiene in cache: **niente da scaricare, funziona offline** come
tutto il resto.

Il chimico non è più uno sprite che alterna due disegni: è **articolato**.
Bacino, busto, collo, testa, casco, e quattro arti con due snodi ciascuno. Le
animazioni muovono gli snodi:

* **corsa** — gambe in opposizione, braccia sfasate di mezzo ciclo, bacino che
  rimbalza due volte per passo, busto inclinato in avanti;
* **salto** — in salita il corpo si allunga e le braccia vanno su, in discesa le
  ginocchia si raccolgono;
* **giro** — il corpo ruota su sé stesso e le braccia si aprono;
* **sterzata** — il busto si inclina dalla parte in cui ti sposti.

Il **casco e il distintivo** prendono il colore dell'elemento: diventare un
elemento si vede addosso, non solo nella barra in alto.

> Se WebGL non c'è — un telefono vecchio, un driver che non collabora — non si
> rompe niente: il gioco si disegna come prima e si gioca uguale. Il banco
> verifica la strada nuova; la vecchia è rimasta dov'era.

### Si corre dentro lo schermo

Il movimento è cambiato con la prospettiva: si corre **avanti** da soli — su un
telefono «avanti» non è un tasto, è quello che succede — `◀ ▶` spostano di lato,
`⤒` salta le **buche**, `✦` fa **girare su sé stessi**: è l'attacco sempre
disponibile, rompe le **casse** e disintegra quello che hai a tiro.

Dentro le casse: elementi («?»), campioni da raccogliere (**25 fanno una vita**)
e **TNT**, che è rossa, pulsa e fa male. Una buca non è mai più larga di quanto
un salto copra — 2,2 metri, che vengono dal conto: 33 passi in aria a 0,085 m
per passo fanno 2,8 metri, meno un margine perché nessuno salta nell'istante
perfetto.

### La trama, per intero

Sei un chimico chiuso nel suo laboratorio alle 3:40. Il **Custode** — la voce
dell'impianto — dice che la chiusura è partita alle 03:00: **quaranta minuti
prima** che la reazione scappasse di mano. Fra i vetri rotti trovi una pagina
del tuo quaderno con la tua calligrafia e la data di **domani**. Nel reparto di
organica il reattore sta sintetizzando un **catalizzatore** che abbassa
l'energia di attivazione di qualunque reazione: lo avevi disegnato tu, da
studente, e lo avevi abbandonato scrivendo «troppo generale, troppo pericoloso».
In spettroscopia l'infrarosso gira da ore sullo stesso campione — **aria** — e
il Custode spiega che il contenimento protegge la città, non il personale. Nel
nucleo arriva la verità: il protocollo 12 non era cancellato, era **sospeso**, e
in fondo avevi scritto una riga per te stesso: *«riprendere comunque»*. Alle
03:00 il Custode l'ha letta e ha fatto il suo mestiere.

Il finale si legge vincendo, e l'ultima riga non è «hai vinto».

### Gli enigmi vengono da tutto il sito

I generatori di domande sono **28**: alle tabelle di sempre (elementi, spettri
IR/¹H/¹³C/J, reazioni, retrosintesi, amminoacidi, linguaggi) si sono aggiunti
**farmaci**, **sicurezza GHS e frasi H**, **costanti fisiche**, **conversioni di
unità**, **tecniche di laboratorio**, **biomolecole** e **vie metaboliche**.

### Il banco

`test_gioco` arriva a **162 controlli**. I nuovi guardano il motore 3D (il
chimico fatto di pezzi, quattro arti snodati, le pose che cambiano fra un
fotogramma e l'altro e il salto che non è la corsa), le porte (**sbagliando
resta chiusa e non si passa**), il giro (disintegra quello a tiro, rompe le
casse, e **uno lontano resta vivo**), i guardiani (enigma, debolezza svelata,
colpo che vale **tre** con l'elemento giusto e **uno** senza), e i livelli
(nessuna buca più larga di quanto un salto copra, e una buca allargata apposta
viene segnalata).

---
## [bsi-v206] — 2026-10-14

**ELEMENT CHEMIST: un chimico chiuso nel suo laboratorio, quattro reparti,
porte da sbloccare con la chimica e quattro guardiani che si abbattono solo
trovando la loro debolezza.**

La versione precedente aveva portato il gioco in una direzione che non era
quella chiesta — niente terreno, niente salti, niente combattimento. Qui si
torna al gioco vero e lo si costruisce davvero: trama, livelli, combattimenti,
boss ed enigmi.

### La trama

Sei un chimico. Alle 3:40 una reazione è scappata di mano e il laboratorio si è
chiuso da solo. Quattro reparti — **inorganica, organica, spettroscopia, il
nucleo** — dodici livelli, quattro guardiani, e una regola: **tocca un elemento
e diventi quell'elemento**. Il racconto arriva a pezzi, dieci righe all'ingresso
di ogni reparto, e si rilegge dal menù di pausa.

### Si combatte sempre

Senza elemento `✦` dà un **colpo corto di reagente**: poco raggio, ricarica
lenta, ma nessuno resta disarmato — un gioco in cui finché non trovi il
potenziamento giusto puoi solo scappare non è difficile, è vuoto. Con un
elemento che spara, `✦` spara, e **come** spara viene dalla chimica: il carbonio
fa quattro legami e tira quattro colpi a ventaglio, l'azoto col triplo legame
perfora, il fluoro colpisce più forte perché è il più elettronegativo.

Fra i nemici è comparso chi **sputa acido** e non si muove: gli altri si
scavalcano, questo va spento.

### Le porte non si attraversano: si aprono

Ogni livello ha **due terminali in allarme**. Ti fermano davanti, ti fanno una
domanda e si aprono **solo con la risposta giusta**; sbagliando restano chiuse e
il terminale si riarma dopo un paio di secondi. Una domanda che si può ignorare
correndo è un cartello, non un enigma.

### I guardiani hanno una debolezza chimica

Quattro, uno per reparto: **il versamento acido**, **la catena radicalica**, **il
metallo pesante**, **la reazione fuggita**. Nessuno si abbatte a forza:
all'inizio dello scontro il guardiano ti chiede che cosa lo neutralizza, e la
risposta è chimica vera — un acido si neutralizza con una base, una catena
radicalica si chiude con chi dona un legame, un metallo pesante si lega allo
zolfo, una reazione fuori controllo si spegne con un gas inerte. Rispondi
giusto e l'elemento compare nell'arena: da quel momento i tuoi colpi valgono
**tre** invece di uno. A metà vita cambiano passo: caricano e chiamano rinforzi.

### Gli enigmi vengono da tutto il sito

I generatori di domande passano da 19 a **28**, e le nuove aree sono quelle che
mancavano: **farmaci** (classe e indicazione), **sicurezza GHS** (pittogrammi e
frasi H), **costanti fisiche**, **conversioni di unità**, **tecniche di
laboratorio**, **biomolecole**, **vie metaboliche**. Cinque di queste tabelle
stavano dentro funzioni anonime e non le vedeva nessuno: l'applicazione adesso
le pubblica sotto `BSI_DATI`.

> **Trovate due volte.** In `index.html` esistono **due** tabelle `CONSTANTS`,
> **due** `GHS_PICTOGRAMS` e **due** `FRASI_H_PRINCIPALI`, in funzioni diverse e
> con forme diverse (una ha 6,022×10²³, l'altra 6,02214076×10²³). Qui si
> pubblica la più completa di ognuna e **la doppia resta registrata**: unirle
> tocca due pannelli e va fatto guardandoli, non con una sostituzione.

### Il laboratorio si vede

Il fondo non è più un cielo con le stelle: è un **laboratorio**, e cambia con il
reparto — scaffali di bottiglie, colonne di distillazione, rastrelliere di
strumenti con gli spettri che scorrono, serbatoi con le strisce di pericolo. Il
pavimento è piastrellato, le passerelle sono grigliato metallico, le casse sono
casse di reagenti. Il verde del prato era il segno più evidente che questo gioco
veniva da un altro gioco.

### E la sezione Articoli si trova

Era appesa in fondo al gruppo «Utility», diciannovesima su diciannove: c'era, ma
non la trovava nessuno — *«la sezione articoli non l'ho trovata»*. Ora **📰
Articoli** e **ELEMENT CHEMIST** stanno in testa al primo gruppo della barra,
quello che si vede appena si apre l'applicazione. Una sezione che non si trova
vale quanto una sezione che non c'è.

### Il banco

`test_gioco` passa da 118 a **143 controlli**. I nuovi misurano il gioco vero,
nei due versi: davanti alla porta ci si ferma, **sbagliando resta chiusa**,
rispondendo si apre e si passa; il colpo corto uccide e **senza premere il tasto
il nemico resta vivo**; il guardiano apre il suo enigma, svela la debolezza, fa
comparire l'elemento, e **il colpo vale tre con quello giusto e uno senza**;
attacca davvero e a metà vita passa alla seconda fase; la storia è in cinque
pezzi e nessuno è vuoto; i quattro guardiani hanno quattro debolezze diverse e
ognuna porta la sua ragione chimica.

---
## [bsi-v205] — 2026-10-14

**ELEMENTIA non è più un platform: in questo gioco non si cammina e non si
salta. Si è un atomo in soluzione, e ci si muove facendo e rompendo LEGAMI.**

### Il movimento

Tenendo premuto `⚛` si sale e, se passa un atomo a portata, ci si **lega** e si
comincia a girargli intorno; `◀ ▶` fanno **girare** — ▶ in senso orario — e a
ogni giro si prende velocità, come su un'altalena; lasciando il tasto si parte
**per la tangente** con tutta la velocità accumulata. Il movimento è una
**fionda fatta di legami**.

**E si avanza SOLO così.** Non è uno slogan: è una disuguaglianza fra due
numeri scritta nel codice — spinta da liberi **0,008** < corrente **0,012** — e
finché vale, nuotare non può far guadagnare terreno con nessun elemento e in
nessuna difficoltà. Il banco la verifica nel modo più diretto possibile:
toglie **tutte le ancore** a un livello e guarda dove arriva un pilota
automatico. Con i primi numeri arrivava al **91%**; adesso si ferma al **13%**.

### I numeri veri della tavola periodica sono le regole

Diventare un elemento non cambia il colore: cambia la **fisica**.

| che cosa | da dove viene |
|---|---|
| quanto affondi | la **massa atomica**, contro quella media dell'aria (28,96 u) |
| quanto è lungo il tuo legame | i **raggi atomici** dei due atomi |
| quanto regge prima di spezzarsi | la tua **energia di ionizzazione** |
| covalente, polare o ionico | la differenza di **elettronegatività** (soglie di Pauling 0,4 e 1,7) |
| quanti gusci ti si vedono | il **periodo** della tavola |

L'idrogeno quasi galleggia, il piombo precipita, il fluoro fa legami che
reggono più di quelli del sodio, Na–Cl è ionico e tira dentro. Tutto letto da
`ELEMENTS`, la tavola periodica che l'applicazione ha già: nessun secondo
elenco di chimica.

### Il personaggio e la scena

Il chimico a pixel è andato via con il platform. Il personaggio è un **atomo
con due occhi** che guardano dove va, con i suoi gusci di elettroni intorno,
grande quanto dice il suo raggio atomico. I nemici sono **radicali**, e portano
il loro elettrone spaiato che gira. Lo sfondo è una **colonna di solvente** con
le righe di corrente che scorrono all'indietro e le bollicine che salgono; gli
atomi-ancora hanno i loro gusci, e quello a portata si illumina con un cerchio
tratteggiato. L'icona della sezione è lo stesso atomo.

### Sei difetti trovati facendo giocare un pilota automatico

Nessuno di questi si vedeva leggendo il codice.

* **Una forza costante su una corda non fa girare niente**: spostava il punto
  di equilibrio e basta. Il pilota restava appeso a oscillare e in settemila
  passi non arrivava a un decimo del livello. Ora la spinta è **sulla curva**.
* **Il raggio del legame si accorciava fino al minimo**: si finiva a girare in
  un cerchietto di venti pixel da cui non si raggiunge più niente. Ora non
  scende sotto i due terzi di quello di partenza.
* **Le ancore troppo vicine ai bordi** mandavano l'orbita fuori dalla provetta,
  e lassù si restava schiacciati fra il bordo e il legame: duemilaquattrocento
  fotogrammi inchiodati a y=8. Ora i bordi sono larghi quanto il legame più
  lungo, e il raggio si accorcia da sé vicino al bordo.
* **Superficie e fondo uccidevano sul colpo**: con l'idrogeno addosso si sale
  di un pixel e mezzo al fotogramma e il solo modo di fermarsi è un legame —
  quarantasette morti su cinquantasette erano «evaporato». Ora respingono e
  fanno male come qualunque altro danno.
* **Il galleggiamento rovesciava l'affondamento**: con l'idrogeno si finiva
  incollati al soffitto senza modo di scendere. Ora modula, non rovescia: tutti
  scendono se non si tiene premuto, e l'elemento decide quanto.
* **Non c'era nessun controllo verticale da liberi**: un atomo neutro sbalzato
  contro la superficie restava lì per sempre. Ora il tasto del legame fa anche
  salire — un solo gesto per due cose che in acqua sono la stessa.

### Il banco

`test_gioco` passa da 118 a **131 controlli**. I livelli non si misurano più
con il salto: si misura che **due ancore consecutive non distino più di quanto
una fionda copra** (104 px, che vengono dal conto: 5,4 px/passo di lancio con
l'1,3% di attrito fanno oltre 250 px) — e la stessa misura, su una catena
rotta apposta, se ne accorge. Poi la chimica dentro il movimento, provata nei
due versi. E soprattutto il **pilota automatico**: sa tre cose — si lega a
quello che trova, spinge sempre nello stesso verso, lascia quando sta andando
verso il prossimo atomo — e attraversa **21 livelli su 24 oltre l'85%**, con
semi fissi perché due esecuzioni misurino lo stesso gioco.

---
## [bsi-v204] — 2026-10-14

**ELEMENTIA ha una faccia: un chimico a pixel che diventa l'elemento che
raccoglie, e la sua icona nella barra e sul titolo della sezione.**

### Il personaggio

Era un rettangolo colorato con un puntino per occhio, e si vedeva. Ora è un
**chimico disegnato a pixel** — casco, occhialoni, camice, guanti e scarponi —
in **dodici per sedici**, con quattro fotogrammi: fermo, due di corsa e uno di
salto. Il verso si ottiene **specchiando le colonne**, non con un secondo
disegno: due disegni speculari sono due disegni da tenere uguali.

Due colori non stanno nella tavolozza: il **casco** e il **distintivo sul
petto**. Quelli li mette l'elemento che hai addosso — il ferro grigio-blu, il
fluoro giallo, l'oro oro. **Un solo disegno, venti vestiti**: è così che il
personaggio «diventa» l'elemento invece di limitarsi a portarne il simbolo.

Anche i nemici hanno smesso di essere quadrati: sono molecolette con due occhi
e due zampe che si muovono, e quelli che volano battono le ali.

Il disegno sta nel sorgente come righe di `#`, `.` e lettere, leggibili, come
il font del titolo: una maschera di bit si scrive in meno spazio e non la
rilegge nessuno.

### L'icona

Disegnata **con lo stesso personaggio**, busto e spalle dentro un tondo scuro
con un orbitale, e consegnata come immagine `data:` — non è un file: non c'è
niente da scaricare e non può mancare quando si è senza rete. Si vede nel
**pulsante della barra** e nel **titolo della sezione**.

Entra come sfondo di uno **pseudo-elemento**, non come `<img>`, e c'è un
motivo: il cambio lingua riscrive il TESTO di quei due nodi, e riscrivendolo
porterebbe via qualunque figlio. Lo pseudo-elemento il testo non lo tocca.

Il pulsante nella barra ora porta il **nome del gioco** al posto della parola
«Gioco», e nei tredici dizionari la voce c'è e vale sé stessa: un nome proprio
è lo stesso in tutte le lingue, e la copertura si **misura** contando i nodi
tradotti — saltarne uno sarebbe un buco finto. Misurato: **scheletro coperto al
completo in tutte e tredici**.

### Sulla copertina

Il chimico corre sul fondo della schermata del titolo mentre il terreno gli
scorre sotto, cambia elemento ogni pochi secondi — casco e distintivo compresi
— e un nemico gli viene incontro: il gioco spiegato senza una parola.

### Il banco

`test_gioco` passa da 105 a **118 controlli**. I nuovi: le righe del disegno
tutte della stessa lunghezza e **nessun carattere senza colore dichiarato** —
un carattere non dichiarato non si vede, non dà errore e lascia un buco muto;
il fotogramma giusto nel momento giusto (salto in aria, fermo da fermo, corsa
correndo); l'icona che è davvero un PNG `data:` e che **i due posti la
mostrano**; e, **nei due versi sulla tela**: con l'elemento addosso il suo
colore compare sul personaggio (24 pixel), senza elemento quel colore **non
c'è** (zero). La guardia è stata provata rompendola: con un carattere fuori
tavolozza e una riga più corta, il banco li segnala tutti e due.

---
## [bsi-v203] — 2026-10-14

**Il gioco ha un nome — ELEMENTIA — scritto in grafica, e un menù di pausa con
dentro la guida, le lingue e tutto il resto. Provato su telefono, nei due versi
dello schermo.**

### ELEMENTIA

Il nome compare all'avvio, **disegnato sulla tela** lettera per lettera con un
font a cinque per sette pixel scritto per l'occasione — non un `<h1>` sopra la
scena: in un gioco retro il titolo fa parte del gioco, e un titolo in HTML
sopra una tela a pixel si vede subito che è un'altra cosa. Attorno al nome
girano venti bollicine, una per ogni elemento che si può diventare, con il loro
simbolo e il loro colore: la schermata dice che cos'è il gioco senza doverlo
scrivere. Il font sta nel sorgente come righe di `#` e `.`, leggibili: una
maschera di bit si scrive in meno spazio, ma nessuno la rilegge.

Il nome **non è ripetuto** nel pannello HTML, che porta solo i due pulsanti —
e il banco lo verifica, perché una cosa doppia qui dentro è un difetto.

### Il menù di pausa

Dal tasto `❚❚`, o da **Esc**/**P** da tastiera. Dentro c'è tutto quello che
serve senza uscire dal gioco:

* dove sei — difficoltà, livello su dodici, punti, vite, elemento in corso;
* **riprendi**;
* la **guida** completa, che si apre lì dentro;
* il **cambio lingua** con le quattordici bandiere;
* **suono** acceso/spento e **schermo pieno**;
* abbandona la partita.

La guida sta in **una funzione sola**, letta sia dal titolo sia dalla pausa:
due copie dello stesso testo sono due testi che un giorno diranno cose diverse.
L'elenco delle lingue e il cambio vero restano in `BSILingue`/`BSISelLingua`:
qui si chiamano soltanto, così una lingua in più comparirà anche qui senza
toccare il gioco. Il gioco parla **italiano e inglese**; con le altre dodici
lingue resta in italiano, come il resto dei contenuti — detto, non nascosto.

### Tre difetti trovati provando sul telefono, non leggendo il sorgente

**La barra di navigazione stava sopra il menù di pausa.** Il menù ha
`z-index:10000` e la barra 90: nel sorgente sembrava a posto. Nel browser no:
la sezione del gioco è animata all'apertura con `fill-mode: both`, e
un'animazione che resta «riempita» rende la sezione un contesto di impilamento
con z-index automatico — dentro quel contesto il 10000 non vale più niente
fuori. Sotto il dito, al posto di «riprendi», c'era una linguetta della barra.
La sezione del gioco ora compare senza dissolvenza: meglio senza un effetto che
con un menù che non si tocca.

**`position: fixed` non era lo schermo.** La stessa animazione porta con sé
`will-change: transform`, e un elemento trasformato diventa il riferimento dei
figli `fixed`: il pannello dei menù risultava 812×427 a partire da y=−10 su una
finestra 844×390.

**Il menù non ci stava.** La scena è alta 270/480 della sua larghezza — circa
220 px su un telefono in verticale — e dentro 220 px un menù con la guida, le
quattordici lingue e le impostazioni non entra: diciassette pulsanti su
diciannove finivano fuori, e girando il telefono anche «riprendi». Ora il
pannello dei **menù** (e solo quello: in partita resta trasparente sopra la
scena) si àncora alla finestra e scorre dentro di sé. Vale per tutti i menù —
difficoltà, domanda, esito, pausa — non solo per la pausa.

### Una cosa doppia in meno

Il numero dei livelli era scritto a mano in **sei punti** (titolo, barra,
schermata di livello, schermata di fine, fine del gioco, generazione
dell'ultimo livello). Sei copie dello stesso numero sono cinque occasioni di
sbagliarlo: ora è una costante sola.

### Il banco

`test_gioco.js` passa da 71 a **105 controlli**, e i nuovi misurano
nell'applicazione in esecuzione, su finestra da telefono, in verticale **e** in
orizzontale: che il nome sia davvero disegnato (pixel contati sulla tela) e
animato (due fotogrammi diversi), che non sia ripetuto in HTML, che il menù di
pausa si apra e contenga guida, lingue e impostazioni, che il cambio lingua
cambi davvero la lingua, che in pausa la partita sia ferma, e che **ogni voce
del menù si possa toccare col dito** — dentro lo schermo e con nient'altro
sopra. È quest'ultimo controllo ad aver trovato la barra di navigazione.

---
## [bsi-v202] — 2026-10-14

**Il cambio lingua tondo in intestazione, e un gioco retro in cui i
potenziamenti sono elementi della tavola periodica.**

### Il tondo in alto a destra

Un pulsante **rotondo** all'altezza del titolo, all'estremo destro, con la
bandiera della lingua in uso. Si apre in un **disco**: le quattordici bandiere
su **due gusci** — sei dentro, come un anello benzenico, e otto fuori — e al
centro il nome della lingua su cui stai passando e **quanto è tradotta**, che
non è un numero scritto a mano ma la misura che fa `coperturaPerLingua()`
applicando il dizionario e contando quello che resta in italiano.

Il cambio vero non lo fa questo modulo: lo fa `BSILingue.imposta()`, che è
l'unica casa di quella funzione. Qui c'è solo il modo di chiamarla. E la
sezione «🌍 Lingua» resta, perché fa un'altra cosa: quella **informa**, questo
**agisce**.

**Due misure, non due impressioni.** Il primo tentativo l'aveva messo in
`#hdr-actions`, che sembra il posto giusto — e che è `display:none`: tutte e
nove le icone di quel gruppo sono nascoste, e il pulsante nuovo è finito
invisibile con loro, larghezza zero. Il posto giusto è `.hdr-inner`. Poi, con
`align-self:center`, era allineato al titolo su schermo grande e **non** su
telefono, dove quel flex allinea in alto e il blocco del logo è alto due righe:
ora l'allineamento si **misura** leggendo dov'è la riga del titolo. Verificato
su tre viewport.

### 🎮 «La corsa degli elementi»

Un platform retro, in una sezione sua. I potenziamenti non sono fiori: sono
**venti elementi della tavola periodica**, e ognuno trasforma il personaggio
dandogli un'abilità che viene dalla sua chimica — l'idrogeno è il più leggero e
fa saltare più alto, il fluoro è il più elettronegativo e il suo colpo è il più
forte, l'alluminio si passiva col proprio ossido e regge un colpo, l'oro non si
ossida e i nemici ossidanti non lo toccano, il mercurio è liquido e fa correre.
Nome e numero atomico vengono dalla **tavola periodica dell'applicazione**: non
sono riscritti nel gioco.

**Dodici livelli** in quattro zone, un **boss** alla fine di ogni zona e il
**boss finale** al dodicesimo, con il doppio della vita e due fasi. Comandi a
schermo grandi (≥ 44 px, perché col pollice si sbaglia) e da tastiera. Cinque
difficoltà con nomi di chimica che dicono quanto il sistema è reattivo, dalla
**soluzione diluita** alla **fusione nucleare** — una vita e venti secondi per
rispondere.

**Funziona offline**: non c'è un solo file da scaricare. La grafica è disegnata
a rettangoli su una tela 480×270 ingrandita a numeri interi, e i suoni sono
sintetizzati con l'oscillatore del browser.

### Le domande non sono scritte nel gioco

`bsi-gioco-domande.js` **non contiene domande**: contiene **diciannove
generatori** che pescano dalle tabelle che l'applicazione ha già — `ELEMENTS`,
`SPEC_DATA`, `RXN`, `RETRO_STRATEGIES`, `AA_DATA` e i motori `BSIElucida` e
`BSILettoreSpettri`. Simbolo di un elemento, elettronegatività, configurazione
elettronica, banda IR, spostamento ¹H e ¹³C, costante J, assegnazione calcolata
dal lettore spettri, gradi di insaturazione, massa di una formula, reazione da
una descrizione, condizioni di reazione, disconnessione retrosintetica,
amminoacidi, riconoscimento dei linguaggi della chimica.

Il motivo non è pigrizia: un elenco di domande scritto a mano sarebbe una
**seconda fonte di verità chimica** accanto a quelle che ci sono, e due fonti
divergono — è il difetto che in questo progetto si è presentato due volte, con
le costanti J e con le bande IR. Una domanda sbagliata in un gioco didattico
insegna la cosa sbagliata, e nessuno se ne accorge. Così invece: se la tabella
è giusta, la domanda è giusta. E ogni domanda porta la sua **provenienza**,
mostrata dopo la risposta.

La difficoltà non è un moltiplicatore: non rende le stesse domande «più
difficili», cambia **quali** arrivano.

### Tre difetti trovati scrivendolo, e tutti e tre silenziosi

1. **Una domanda con due risposte giuste.** I distrattori pescati dalla stessa
   tabella possono avere intervalli che si **accavallano**: «⁴J meta» sta a
   1–3 Hz e «⁴J allilico» a 0–3 Hz, e la prima stesura li ha messi nella stessa
   domanda — con quella marcata sbagliata che non lo era. Ora i distrattori su
   intervalli sono **disgiunti** dalla risposta, e se non ne restano abbastanza
   il generatore rinuncia.

2. **Il trattino fa due mestieri, e li avevo confusi.** In «1–3 Hz» separa due
   numeri; in «−12 a −15» è il segno. Il lettore convertiva ogni lineetta in
   «-» e leggeva «1–3» come l'intervallo **[−3, 1]**. La conseguenza non era un
   numero storto in uno spiegone: era che **niente** risultava disgiunto, quindi
   i quattro generatori su intervalli non trovavano mai tre distrattori e si
   tiravano indietro **sempre** — e il controllo «zero domande ambigue» passava
   perché quelle domande non arrivavano più. Un controllo che passa perché non
   misura niente è peggio di uno che falla. Il banco ora pretende **entrambe**
   le cose: zero ambigue **e** quei generatori che girano.

3. **Un generatore morto.** `massaDa` ha firma `(conta, tabella)`, non
   `(formula)`: lo chiamavo con una stringa e andava in errore a ogni giro.
   Invisibile, perché chi pesca la domanda cattura l'errore e prova il
   generatore successivo. E `disponibili()` diceva che «girava», perché
   guardava se la **fonte** esisteva. Ora `disponibili()` **prova** ogni
   generatore: «gira» vuol dire «ha prodotto una domanda».

### Un livello generato a caso può essere impercorribile

Il salto copre 8,6² / (2·0,62) = 59,6 px, cioè **3,7 tile**. Un vuoto più largo
di quattro colonne o un gradino più alto di tre tile è un muro invalicabile — e
chi gioca non ha modo di sapere che è rotto il livello e non lui.

Il generatore rispetta quei limiti, e il raccordo finale no: metteva l'altezza a
3 **di colpo** sugli ultimi otto, e se il terreno era a 7 il gradino diventava
di quattro. Misurato: **cinque livelli su sessanta**. Ora il raccordo scende di
un tile per colonna, e il banco verifica tutti e sessanta (dodici livelli per
cinque difficoltà).

### Una sezione invisibile, e il controllo che l'aveva lasciata passare

`bsi-centrospettri.js` **sposta** dieci pannelli dentro il proprio corpo, e fra
questi `sspettrolettore`. La sezione «Articoli», ancorandosi a lui, è finita
**dentro il corpo del Centro spettri** — un contenitore `display:none`: il suo
display proprio diceva `block` e lei **non si vedeva**. È stata così per una
versione intera.

Il controllo che l'aveva approvata chiedeva
`getComputedStyle(sezione).display !== 'none'`, che **non risponde** alla
domanda «si vede?»: basta un antenato nascosto. La risposta è un riquadro di
dimensione non nulla e un `offsetParent` che esiste. Ora le sezioni nuove si
ancorano a una sezione di **primo livello**, e `test_articoli` pretende il
riquadro.

### Una collisione di nomi fra moduli

I comandi del gioco usavano `data-bsi-t` per dire «questo è un tasto». Ma
`data-bsi-t` è già preso: `bsi-lingue.js` lo usa per marcare i nodi il cui
**testo va tradotto**. Risultato: «◀», «▶», «✦», «⤒» sono finiti nell'elenco
delle stringhe non tradotte in tutte e tredici le lingue. Non lo sono: sono
**simboli**, e quello che si traduce è il loro nome accessibile. Due significati
per lo stesso nome di attributo sono una collisione, e si risolve cambiando
nome: `data-bsi-tasto`.

### Verifiche

Nuovo banco `test_gioco` — **71 controlli**:

- **il selettore su due viewport**: tondo, in alto, a destra, e «all'altezza del
  titolo» **misurata** come sovrapposizione dei riquadri; nome accessibile che
  dice che cosa fa e non «bandiera dell'Italia»; il disco dentro lo schermo; e
  **nei due versi** la lingua che cambia e torna identica;
- **i diciannove generatori provati uno per uno**, il lettore di intervalli su
  sei casi noti, **600 domande sane**, **zero ambigue** e la guardia che i
  generatori su intervalli girino;
- **60 livelli** verificati percorribili, due punti di controllo ciascuno, un
  elemento che spara in ogni livello con boss, quattro boss e uno solo finale,
  e lo stesso seme che dà lo stesso livello;
- **la partita giocata davvero**: titolo → difficoltà → livello → elemento
  raccolto (Al, Alluminio, Z 13) → domanda al punto di controllo (NMR protonico)
  → livello 2 → boss di zona abbattuto col carbonio → **boss finale e vittoria**
  col rame;
- **il ciclo nei due versi**: trenta fotogrammi con la sezione aperta, **zero**
  con la sezione chiusa;
- a 390 px niente sborda, i comandi sono ≥ 44 px e ognuno ha un nome
  accessibile.

Requisiti nuovi in matrice: **UI-16** (il cambio lingua), **SCI-37** (le domande
generate, mai ambigue), **UI-17** (il gioco giocabile che non consuma).

---
## [bsi-v201] — 2026-10-14

**Una verifica dei doppioni più larga delle precedenti, e ha trovato una
funzione che non ha mai eseguito.**

Ogni giro di controlli, in questo progetto, ha trovato un doppione che il giro
prima non vedeva. Questa volta ho misurato cinque dimensioni nuove: script
caricati due volte, titoli di sezione uguali, funzioni globali definite più
volte, blocchi di codice identici, tabelle di dati scientifici duplicate.

### 471 righe di codice dentro un modello, che non eseguivano mai

In `index.html` c'è un `<script type="text/html">` che porta dentro un
**documento HTML completo** — il laboratorio quantistico, 16 moduli — iniettato
poi come `srcdoc` di un iframe. I tag di chiusura interni a quel documento sono
scritti con un sentinella, sostituito col tag vero prima dell'iniezione: è una
tecnica corretta, perché per il parser il modello finisce al **primo tag di
chiusura vero**.

Uno di quei tag interni non era stato scritto col sentinella. Quindi il modello
si chiudeva **471 righe più in basso del suo posto**, e quelle 471 righe
(18,8 kB) erano *testo* dentro il modello: il blocco **Mechanism Canvas
Visualizer**, che disegna la tela dei meccanismi di reazione passo per passo.

Misurato, non supposto: `window.renderMechStep` era `undefined`, il modello
conteneva la stringa «Mechanism Canvas Visualizer», e la sezione «🎬
Meccanismi» mostrava i passaggi **senza nessuna tela**.

### E non bastava chiuderlo: c'era un secondo difetto, indipendente

Chiuso il modello al suo posto, il blocco ha cominciato a eseguire — e la tela
continuava a non comparire. Il blocco si installa così:

```js
var _origRenderStep = window.renderMechStep;
if (typeof _origRenderStep === 'function') { … }
```

Ma `renderMechStep` era **locale** alla chiusura che la dichiara:
`window.renderMechStep` era `undefined`, la guardia saltava **in silenzio**, e
l'involucro non si installava. Esporla non bastava — le chiamate interne
avrebbero continuato a usare il riferimento locale, scavalcando l'involucro —
quindi le due chiamate interne passano ora da `window.renderMechStep`, e
`mechState` è esposto perché l'involucro sappia a che passo siamo.

Risultato misurato: cliccando un meccanismo, `#mechCv` esiste e la sezione ha
**una tela** dove prima ne aveva **zero**. Il laboratorio quantistico, che è il
modello che ho toccato, continua a funzionare: 16 moduli e 16 tele
nell'iframe.

Due difetti indipendenti sulla stessa funzione, entrambi silenziosi: uno
perché il codice era testo, l'altro perché una guardia proteggeva da un
errore e nascondeva un bug.

### 28 kB di codice incollato due volte

Un blocco di **403 righe** («AGGIUNTE FINALI»: flashcard personalizzate, quiz
delle nuove categorie, diagrammi di fase) era presente **due volte**.
Confrontate riga per riga, la copia di sopra definiva **42 righe in più** —
`window.initCustomFlash`, `window.initPhase`, il renderer dei diagrammi di fase
e due pulsanti di navigazione — e la copia di sotto non definiva **niente** che
la prima non avesse: le sue sole righe esclusive erano due punti e virgola. Era
un incollaggio troncato.

Rimossa. Le quattro funzioni globali con corpi **identici** sono scese a zero.
Verificato prima/dopo sullo stesso browser: stesse funzioni definite, stessi 95
pulsanti, stessa sezione quiz, zero errori — il taglio non cambia
comportamento.

### Due tabelle di bande IR che divergevano

Come le costanti J della versione precedente, ma più sottile: `SPEC_DATA.ir`
(28 righe, con intensità e note) è la tabella di riferimento e serve a
**studiare**; `BANDE_IR` del lettore serve ad **assegnare** e dà l'intervallo in
cui quel legame può comparire perché nessuna possibilità venga esclusa. Due
scopi diversi, quindi due larghezze diverse: **non** sono un doppione.

Ma una relazione devono rispettarla: **l'ombrello copre il riferimento**. Se
l'intervallo del lettore non contiene quello della tabella per lo stesso
gruppo, una banda che la tabella attribuisce a quel gruppo non verrebbe
elencata fra le compatibili — e il lettore contraddirebbe il proprio scopo
dichiarato.

Misurandolo: **cinque righe non coprivano** (O–H libero, ≡C–H, C≡N, C=O acido
carbossilico, C=O anidride) e **quattro gruppi mancavano del tutto** (tiolo,
bromuro, lattame β, N–H ammide: il lettore non poteva proporli nemmeno davanti
alla banda giusta).

Corretto prendendo l'**unione** con gli intervalli già scritti nella tabella di
riferimento: **nessun numero inventato**, e allargare un ombrello può solo
*aggiungere* un'assegnazione compatibile, mai togliere. `test_spettrolettore`
pretende ora la copertura per ognuno dei 23 gruppi presenti in entrambe, con
l'abbinamento **dichiarato** nel banco — dedurlo dal simbolo del legame
confrontava «C=O aldeide» con «C=O estere» e produceva venti conflitti finti.

### Un mio limite inventato, corretto dal banco stesso

Il controllo opposto («nessun ombrello così largo da non dire niente») l'avevo
scritto con un tetto fisso di 400 cm⁻¹, e falliva. Giustamente: l'O–H di un
acido carbossilico **è** larga 800 cm⁻¹, e lo dice la tabella di riferimento.
Il numero sbagliato era il mio tetto, non il dato. Un limite inventato a
tavolino che contraddice la fonte non è un controllo, è un errore con
l'aspetto di un controllo. Ora il limite viene dai dati: l'ombrello può essere
più largo del riferimento, ma non oltre un margine dichiarato di 140 cm⁻¹.

### Undici ridefinizioni che NON sono un difetto

Undici funzioni globali sono definite più di una volta (`runNMRPred` cinque
volte). Non è un doppione: è lo stile dichiarato di questo file, il «patch
additivo» che non modifica il codice esistente ma lo sovrascrive più in basso —
`window.initTheory` salva `_origInitTheory` e lo richiama. Le ho **dichiarate**
con un riferimento in `audit_statico` invece di segnalarle come guasto: se il
numero cresce, la batteria fallisce e la ridefinizione nuova va spiegata.

### Un falso allarme inseguito e archiviato

I 99,7 kB del modello `text/html` sembravano codice morto. Non lo sono: è il
documento del laboratorio quantistico, e il sentinella viene sostituito
correttamente prima dell'iniezione. L'ho verificato **prima** di chiamarlo
difetto. E `audit_statico` segnalava `index.html` come «script sbilanciati» a
ogni esecuzione: era un falso positivo del suo stesso conteggio, che contava i
`<script` *dentro* il testo del modello. Ora misura l'annidamento escludendo i
modelli — un rapporto che mostra sempre lo stesso problema inesistente insegna
a non leggerlo.

### Un banco che inciampava una volta su venti

`test_nucleo` è fallito una volta nella batteria con «Execution context was
destroyed, most likely because of a navigation», morendo a metà di un
`evaluate`. Rilanciato a mano passava, **tre volte su tre**: una corsa, non un
difetto dell'applicazione.

La corsa era questa: il service worker si attiva, manda `BSI_SW_UPDATED` alla
pagina, e la pagina può ricaricarsi — proprio mentre l'`evaluate` legge il DOM.
Gli altri banchi bloccano il service worker; questo era **l'unico che non lo
faceva**, e per questo era l'unico a inciampare. La causa è stata tolta invece
di rilanciare e sperare: un banco che falla una volta su venti non viene
creduto nemmeno quando ha ragione. Ora passa quattro volte su quattro.

### Verifiche

- `audit_statico` entra **nella batteria** — e il motivo vale la pena di dirlo:
  la guardia contro i blocchi duplicati era stata scritta dentro di lui, e lui
  non era nell'elenco. Una guardia che non gira non è una guardia.
- Ha **tre misure nuove con riferimento dichiarato**, e queste fanno fallire:
  blocchi duplicati verbatim (**0**), funzioni globali ridefinite (**11**), di
  cui con corpi identici (**0**).
- `test_spettrolettore` sale a **66 controlli**: la copertura dell'ombrello sui
  23 gruppi, e il margine ricavato dai dati.

---
## [bsi-v200] — 2026-10-14

**Utility torna nel menù principale, e le ripetizioni che restavano sono
sparite dalla sorgente, non nascoste.**

### Perché erano doppie: nessuno confrontava le due liste

Il pannello ✨ si riempie da **due posti**: un elenco **cablato** scritto in
`index.html` (editor, laboratori, azioni) e le righe che `bsi-menu.js`
inseriva per le sezioni spostate. Alcune voci cablate aprivano **esattamente**
le sezioni che il modulo stava inserendo, e nessun controllo confrontava le
due liste fra loro. Nel pannello comparivano:

| ripetizione | le due strade |
|---|---|
| **Articoli** ×2 | voce cablata + riga di sezione (l'avevo aggiunta io a entrambe nella versione precedente) |
| **Data Science** ×2 | chiave `datasci`, che apre `sdatasci`, + riga di sezione `sdatasci` |
| **Centro spettri** ×2 | voce cablata + pulsante visibile nella barra |
| **Aggiornamenti** ×2 | due chiavi diverse, `aggiorna` e `update`, che chiamano la **stessa** funzione |

### La regola, adesso una e misurabile

> se una cosa ha un pulsante **raggiungibile** nella barra, NON sta nel menù ✨;
> se non ce l'ha, sta **solo** nel menù ✨.

Quindi la categoria **🛠️ Utility torna nella barra** con tutte le sue quindici
voci più le due della lingua, e `bsi-menu.js` non inserisce più nessuna riga
di sezione nel pannello. Il suo lavoro è diventato il contrario di prima:
**tenere** la categoria visibile — altro codice ricostruisce la barra e per
versioni l'ha rimessa nascosta — e togliere dalla barra le due voci che hanno
una casa migliore.

Le quattro ripetizioni sono state rimosse **dalla sorgente**, non nascoste a
runtime: le righe duplicate negli elenchi cablati non ci sono più. Il
controllo a runtime resta, ma come **guardia** per quelle future, non come
rimedio per queste — e infatti ora non trova niente da nascondere.

### Due eccezioni nella barra, entrambe con un motivo

- **Spectra** non è nella barra: ha il suo pulsante dedicato. Tre strade per
  il copilota erano troppe.
- Il **lettore spettri** non è nella barra: è una scheda del Centro spettri.

In entrambi i casi il pulsante resta **nel documento**, nascosto: decine di
punti dell'applicazione aprono una sezione con `goSection()`, che è
`[data-s=...]`.click(). Nascosto sì, rimosso no.

### Una regola sul nome ha sbagliato, e vale la pena dirlo

La regola «se la chiave si chiama come una sezione, apre quella sezione»
funziona per `datasci`→`sdatasci`, e ha **sbagliato** su `filemanager`: quella
chiave non apre la sezione `sfilemanager`, apre `file_manager.html` in
sovrapposizione — la pagina protetta da password, una cosa **diversa** con un
nome simile. Nascondendola come «ripetizione» si perdeva una funzione.

Sono due cose diverse con lo stesso nome, e il nome era il problema:

- nella barra, **📁 File Manager** carica e ordina i tuoi appunti (PDF,
  immagini, Word), con il suo database locale;
- nel menù ✨, **🔒 File Manager protetto** è la pagina a parte con la
  password, per la galleria e le sezioni personalizzate.

L'eccezione è ora scritta nel modulo **con il motivo accanto**, invece di
essere indovinata: una regola che non si può spiegare non si può correggere.

### «Raggiungibile nella barra» non si misura con `offsetParent`

Nella barra un gruppo per volta è mostrato: il pannello degli altri sei è
`display:none` per progetto. Un pulsante perfettamente raggiungibile — basta
cambiare linguetta — ha `offsetParent` **nullo**. La prima stesura della regola
cadeva proprio qui: concludeva che la barra non mostrava niente, non toglieva
nessuna ripetizione, e le quattro restavano tutte. La misura giusta è un'altra:
il pulsante non è nascosto di suo, e la linguetta del suo gruppo si vede.

### Verifiche

`test_menu` è stato **riscritto**: misurava l'opposto di quello che serve ora —
categoria nascosta, voci nel menù. Ora pretende Utility **visibile** nella
barra con tutte e quindici le voci più le due delle lingue, **nessuna** voce
del menù che ripeta una sezione della barra, **nessuna** etichetta doppia nel
pannello, e le due eccezioni fuori dalla barra **ma con il pulsante ancora nel
documento**. Su **due viewport**, schermo grande e telefono — perché il difetto
storico di questo progetto è una sezione raggiungibile da niente, e si
nascondeva proprio sul telefono. Da 36 a **42 controlli**.

`test_articoli` passa a **58**: Articoli deve essere raggiungibile **dalla
barra** e, nell'altro verso, **non** anche dal menù.

---
## [bsi-v199] — 2026-10-14

**Una casa sola per gli spettri, nessuna cosa doppia, e una sezione nuova:
gli articoli della chimica e i Nobel.**

### Nove sezioni per una domanda sola

Le cose che si fanno con uno spettro stavano in **nove sezioni**, sparse su
**due menù diversi**: tabelle di riferimento, IR visivi, massa, NMR 2D/NOE,
UV-Vis, predizione NMR, quiz, elucidazione nella barra; il lettore spettri fra
le utility del menù ✨. Nove voci per «ho uno spettro, cosa ci faccio?».

Ora c'è **🔬 Centro spettri**, una sezione sola con **dieci schede**. E il modo
in cui è fatto conta quanto il risultato: i pannelli non sono stati riscritti
né copiati, sono stati **spostati**. `appendChild` muove un nodo, non lo
duplica — quindi dopo il trasferimento ogni pannello esiste ancora, **una volta
sola**, con il suo stesso identificatore. Tutti i `getElementById` e tutti i
`goSection()` sparsi per l'applicazione continuano a funzionare.

Due scelte dietro:

- **i vecchi pulsanti restano, nascosti.** Cancellarli sarebbe stato più pulito
  a vedersi e sbagliato: sono il bersaglio di decine di `goSection()`. Restano,
  e il centro li intercetta.
- **la scheda non apre il pannello: clicca il pulsante.** Sembra un giro
  inutile e non lo è — il gestore del pulsante fa anche l'inizializzazione
  pigra (`initMS()`, `initUVVis()`, `initNOE()`…). Una scheda che mostrasse il
  pannello da sé aprirebbe sezioni vuote la prima volta.

### Le cose doppie, cercate misurandole

Non a occhio: contando id ripetuti, pulsanti con lo stesso bersaglio, voci di
menù duplicate e sezioni raggiungibili da due strade. Quello che è uscito:

| doppione | com'era | com'è |
|---|---|---|
| **Spectra** | voce nel menù ✨ **più** pulsante dedicato **più** sezione `sai` — e il commento accanto al pulsante dedicato diceva già «Spectra non sta più nel menù», che non era vero | una strada: il pulsante dedicato |
| **Lettore spettri** | scheda del Centro spettri **e** voce fra le utility | scheda del Centro spettri |
| **Centro Spettri** | una voce di menù con quel nome apriva l'**editor**, mentre la sezione `scentro` — un centro spettroscopico completo — non aveva nessun pulsante e si raggiungeva solo da una funzione interna | il nome sta sulla cosa che nomina; `scentro` è la scheda «Tutto su una molecola» |
| **Costanti J** | **due tabelle indipendenti**, con numeri **diversi**: ³J orto aromatico 6–9 Hz in una, 7–10 nell'altra | una, quella dentro il Centro spettri, che sta nella sezione con la sua lista di riferimenti |

L'ultima è la più seria: non è un doppione di comodo, è una **divergenza
scientifica**. Chi cercava quel numero otteneva una risposta diversa a seconda
di dove entrava, e niente diceva che esistesse l'altra. La discrepanza resta
scritta qui perché sia a verbale, non perché sia stata risolta: è stata tolta
la copia senza riferimenti, non scelto fra i due intervalli.

### Una barra di strumenti fuori dallo schermo, da sempre

Dando a `scentro` un pulsante di navigazione, i banchi hanno cominciato ad
attraversarla — e hanno trovato subito che a 390 px la barra dell'editor
misurava **527 px**: gli ultimi strumenti erano fuori, irraggiungibili, perché
niente scorreva. Non se n'era accorto nessuno perché quella sezione, senza
pulsante, non veniva mai visitata. Per una barra di strumenti la risposta
giusta non è farla scorrere: è mandarla a capo.

### 📰 Articoli, e dentro i Nobel

Sezione nuova nel menù ✨, con due schede.

**Ultimi articoli** — quello che è uscito negli ultimi sessanta giorni, per
argomento. Non è un elenco scritto a mano: arriva da **Crossref** nel momento
in cui si apre la scheda. Ogni titolo porta al suo **DOI**.

**Nobel per la chimica** — tutti i premi, con anno, premiati e motivazione
ufficiale presi **in diretta dalla Fondazione Nobel**, e una spiegazione in
italiano di quello che è stato premiato.

### Le due regole che tengono in piedi la sezione

**Nessun dato scritto a mano.** In `bsi-articoli-nobel.js` non c'è un anno, non
c'è un nome, non c'è una motivazione: solo **66 spiegazioni**. Un elenco di
articoli scritto a mano sarebbe vecchio il giorno dopo; un anno di premio
scritto a memoria sarebbe un errore **invisibile** — sta lì e sembra un dato.

E le spiegazioni non sono legate a un **anno**: sono legate a un **argomento**.
Ognuna dichiara un'espressione regolare che si confronta con la motivazione
ufficiale. Se la motivazione parla di «click chemistry», compare la spiegazione
della click chemistry, a qualunque anno quel premio appartenga. Così non si può
sbagliare un'attribuzione nemmeno volendo: non se ne fa nessuna. Se nessun
argomento combacia, **non si inventa**: si mostra la motivazione ufficiale e il
materiale della Fondazione, e si dice che la spiegazione non c'è.

**I link non sono scritti: sono calcolati.** Il dato è il DOI, l'anno, il nome;
l'indirizzo è una funzione di quel dato. Un articolo di ieri funziona senza che
nessuno lo abbia aggiunto a una lista, e se un sito cambia schema cambia **una
funzione**. La lettura in italiano è costruita allo stesso modo, dall'indirizzo
originale.

### Quando la rete non c'è, si dice — e si dice *cosa*

Tre modi di andare male, e sono tre cose diverse che vanno dette diverse:

- **richiesta fallita** → si mostra l'indirizzo chiesto, apribile a mano, e si
  dichiara di **non** mostrare una lista vecchia al suo posto;
- **risposta vuota** → «non ci sono articoli», che è una risposta, non un
  guasto;
- **risposta di forma non riconosciuta** → «non ho capito», con le **chiavi**
  arrivate. Senza questa distinzione le ultime due davano lo stesso messaggio,
  e l'applicazione avrebbe detto «non c'è niente» quando il vero problema era
  un altro. Questo modulo è stato scritto dove la rete è bloccata da una
  politica: la forma esatta delle due risposte non ho potuto misurarla, e
  questa diagnosi è il modo di non far finta del contrario.

### Due destinazioni di rete nuove, e il banco le ha pretese

`audit_rete` ha fallito la prima esecuzione: **`api.crossref.org` contattato e
non dichiarato nella distinta**. È il controllo che fa il suo lavoro — una
destinazione che nessuno ha dichiarato è una destinazione che nessuno ha
valutato. Le due sorgenti sono ora in `docs/07` §4 e nell'elenco del banco.

La cosa che contava è stata misurata nella stessa esecuzione: con un valore
spia seminato in **71 depositi** dei dati utente e URL, intestazioni e corpo di
ogni richiesta ispezionati, le richieste che portano fuori un dato dell'utente
sono **zero**. Le due sorgenti sono interrogate in sola lettura e la richiesta
non porta niente: nessun identificativo, nessun contenuto, nessuna cronologia.
Crossref chiede che chi interroga si identifichi, e il parametro `mailto` porta
un indirizzo *noreply* del progetto, non quello di chi usa l'applicazione.

### Verifiche

Nuovo banco `test_articoli` — **57 controlli**. I due che contano:

- **i link come funzioni pure**: lo stesso identificatore dà sempre lo stesso
  indirizzo, uno diverso ne dà uno diverso.
- **i dati vengono dalla sorgente**: si **inietta** una risposta che dichiara
  un nome inesistente, e si pretende che sullo schermo compaia **quel** nome.
  Se ne comparisse uno vero, ci sarebbe un elenco scritto a mano da qualche
  parte — ed è esattamente quello che non deve esserci.

E sul centro: dieci schede dentro, **ogni identificatore presente nel documento
una volta sola** (la prova che si è spostato e non copiato), `goSection()` su
ognuna che apre la scheda giusta mostrandone **solo** una, e la sweep dei
doppioni che deve tornare vuota su cinque misure diverse.

`test_menu` passa da diciotto voci a diciassette, e il numero è **dichiarato**:
Spectra e il lettore sono usciti, Articoli è entrato. `test_lingue` ha preteso
le traduzioni delle stringhe nuove in **tredici lingue** prima di tornare
verde, e ha segnalato — giustamente — un pulsante nascosto che portava come
etichetta il proprio identificatore.

Requisiti nuovi in matrice: **UI-14** (una porta sola per funzione), **UI-15**
(una tabella di dati non esiste due volte), **ING-02** (nessun dato scritto a
mano, link ricostruibili).

---
## [bsi-v198] — 2026-10-08

**Il bottone per le immagini era sparito dallo schermo, e la lettura di una
figura era grezza.** Tornano entrambe le cose, con una guida dentro la
sezione e un errore misurato.

### Il bottone che non c'era più

Accorpando tutto in una porta sola (v196) l'ingresso delle immagini è restato
nel codice e non sullo schermo. Non era un dettaglio: su un telefono un
`<input type="file">` **senza** `accept` apre il navigatore dei file, mentre
con `accept="image/*"` apre la **galleria** e offre la fotocamera. Sono due
selettori diversi del sistema, non due filtri dello stesso — e senza il
secondo, chi ha lo spettro in una fotografia non ha una strada per darlo.

Ora i bottoni sono due, e non sono un doppione: `📂 Apri un file` (nessun
filtro) e `📷 Foto o immagine di uno spettro` (galleria e fotocamera).

### Il digitalizzatore, rifatto da capo

La vecchia lettura di una figura prendeva, per ogni colonna, **il pixel più
scuro**. Funziona su una figura pulita e sbaglia su tutte le altre, per tre
motivi precisi: digitalizzava anche gli **assi** e i **numeri** degli assi,
che sono pixel scuri come la traccia; su una figura con la **griglia** la
colonna più scura è la griglia; e il pixel più scuro è un **intero**, mentre
su una linea spessa due pixel e sfumata la posizione vera sta in mezzo.

Nasce `bsi-digitalizza.js`, e `bsi-spettrolettore.js` gli **delega**
`daImmagine()` — una sola casa per funzione, non due implementazioni che
divergono il giorno dopo. Che cosa fa:

- **Trova la cornice degli assi** fra le linee continue nei margini, e
  digitalizza solo quello che c'è dentro. Un bordo si distingue da una riga
  di griglia per la **spaziatura irregolare** rispetto alla famiglia
  **oppure** perché il tratto è più spesso e più nero — come lo distingue
  l'occhio. Il ritaglio si sposta **oltre** lo spessore della linea.
- **Legge a subpixel**: il centro della linea è il baricentro pesato sulla
  scurezza. L'antialiasing, che per il «pixel più scuro» è un fastidio, qui
  dice da che parte sta il centro vero.
- **Aggira la griglia** per continuità **e** per scurezza: in ogni colonna si
  prende il tratto vicino a dove la traccia stava un pixel prima e abbastanza
  scuro da essere traccia. Le colonne di griglia verticale si segnano come
  **non misurate** e si ricostruiscono dalle vicine.
- **Tara i due assi**, in lineare o in **logaritmica** — applicare una mappa
  lineare a un asse logaritmico non dà un errore, dà numeri sbagliati
  dall'aspetto giusto.
- **Converte la %T in assorbanza** con A = −log₁₀T, che è la definizione, e
  dichiara quanti punti erano saturati.
- **Esporta** in CSV e in JCAMP-DX 4.24, con la provenienza scritta dentro il
  file: chi lo apre fra un anno deve sapere che quei numeri vengono da pixel.

L'interfaccia chiede i valori ai **bordi del grafico**, non dell'immagine, e
si rilegge da sé a ogni modifica: il grafico segue senza niente da
confermare. Sotto compare la **diagnosi** — colonne lette, cornice e su quali
lati, sfondo, soglia, colonne di griglia — perché un numero senza il suo come
non si può contestare.

### Tre difetti trovati scrivendolo, e vale la pena dirli

1. **La linea di base piatta presa per una griglia.** Prima stesura: «una
   riga coperta per oltre il 60 % è una griglia, la si toglie». Su una figura
   normale non si trovava **più nessuna traccia** — perché la linea di base di
   uno spettro IR *è* una lunga riga scura, e «le colonne vicine» non la
   ritrovavano essendo piatte sulla stessa riga. Non esiste una soglia che
   separi le due cose: sono la stessa cosa geometrica. La griglia si gestisce
   per continuità, e la funzione resta solo come diagnosi.
2. **Una riga di griglia come attrattore.** Con la sola continuità, quando la
   traccia passa accanto a una griglia orizzontale il tratto della griglia è
   più vicino di quanto lo sia la traccia che si muove: viene scelto, e la
   curva ci resta incollata per sempre. Misurato: picchi a 1591, 3147, 3717
   invece di 1715, 2950, 3400. Risolto preferendo i tratti scuri almeno
   quanto il 60 % del riferimento, aggiornato strada facendo.
3. **Sette bande false, equispaziate come la griglia.** Sulle colonne di
   griglia verticale il baricentro troncato lasciava un gradino, e su una
   curva liscia quei gradini passavano la soglia dei picchi: 734, 1126, 1517,
   1909, 2300, 2691, 3866 cm⁻¹ accanto alle tre vere. Su quelle colonne la
   traccia **non è misurabile** e il valore non va tenuto.

### Un rapporto segnale-rumore da dieci cifre

Lo scarto assoluto mediano dei residui vale **esattamente zero** su una
traccia liscia — una curva calcolata, o digitalizzata da una figura pulita. Il
codice divideva per `1e-12` e stampava SNR come **4 996 427 518**, con due
decimali: una precisione inventata su una grandezza che in quel caso non è
misurabile. Ora il rumore non misurabile si dichiara tale, l'SNR è `—`, e la
soglia dei picchi diventa un millesimo dell'escursione.

### Il grafico aveva un asse muto

L'asse verticale non aveva né tacche né unità: si vedeva che qualcosa sale e
non si sapeva di quanto. Quattro tacche, le linee di riferimento e l'unità
ruotata a lato, come si fa su carta.

### La guida, dentro la sezione

**📖 Come si usa — guida completa**: sette capitoletti — i due bottoni, la
taratura passo per passo, che cosa fa il programma da solo, che cosa **non**
può fare, una tabella «quello che vedi → quasi sempre è» per riconoscere un
risultato storto dal sintomo, come portare via i numeri, e come si svolge un
quesito d'esame.

### Verifiche

Nuovo banco `test_digitalizza` — **45 controlli** su **sette figure
costruite**, di cui si conoscono i centri delle gaussiane al cm⁻¹: nuda, con
cornice ed etichette, con griglia grigia, con griglia nera, con cornice **e**
griglia (11 famiglie verticali, 7 orizzontali), tratteggiata, in %T.

- scarto **medio 2,2 cm⁻¹**, **peggiore 7,3**. Una colonna di una figura
  larga 900 pixel su 3600 cm⁻¹ vale ~4 cm⁻¹: sotto, non c'è niente da
  guadagnare — è il limite della figura, non del metodo.
- **nei due versi**: da un foglio bianco e dall'icona dell'applicazione non
  esce **nessuna** curva; il ripiego grezzo sulla stessa figura con cornice ed
  etichette trova **un** picco invece di tre; su asse logaritmico il punto di
  mezzo è la media geometrica (316,2) e su asse lineare quella aritmetica
  (550); un asse logaritmico che parte da zero viene rifiutato.
- **giro completo**: il JCAMP esportato viene riletto da `leggi()` e torna con
  lo stesso numero di punti, gli stessi estremi e le stesse unità.

Una mia affermazione è stata smentita da questo banco e resta scritta dentro:
avevo messo «il ripiego grezzo con la griglia sbaglia». Non sbaglia — una riga
di griglia da un pixel viene resa sfumata al 50 % di grigio, e il «pixel più
scuro» la ignora senza accorgersene. Il metodo grezzo cade sulla cornice, non
sulla griglia.

`test_spettrolettore` sale a **63 controlli**: il banco usava l'icona
dell'applicazione come se fosse uno spettro, e passava perché il vecchio
estrattore tirava una curva da qualunque cosa. Ora una **figura di spettro**
deve dare la traccia, e un'immagine che non è uno spettro deve **dirlo**
continuando a mostrarsi.

Requisiti nuovi in matrice: **SCI-35** (cornice, etichette e griglia),
**SCI-36** (le uscite, con il giro completo). **SCI-30** riscritto.

---
## [bsi-v197] — 2026-10-08

**Tre tabelle finivano fuori dallo schermo del telefono, e il contenuto non
era tagliato a metà: era irraggiungibile.**

### Che cosa succedeva

`audit_mobile` misurava — bene, e con un argomento scritto — una cosa sola: se
il **documento** scorre in orizzontale. È il difetto che l'utente vede, e
segnalare ogni elemento più largo dello schermo avrebbe riempito l'uscita di
rumore, perché una tabella larga dentro un contenitore che scorre è corretta.

Solo che esiste un secondo caso, e non lo vedeva nessuno: una sezione che
**ritaglia** il contenuto invece di far scorrere la pagina. Non compare nessuna
barra. Si vede una tabella che finisce, e non c'è modo di sapere che l'ultima
colonna esiste: non è tagliata a metà, è **irraggiungibile**, perché non c'è
niente da scorrere.

Tre casi veri, trovati così:

| sezione | tabella | quanto |
|---|---|---|
| Tabelle spettroscopiche | ¹H / ¹³C / IR / costanti J, 4 colonne | 425 px in 370 — la colonna **Note** |
| VSEPR | formula, geometria, angolo, esempi, ibridazione | 473 px in 390 — la colonna **Ibridazione** |
| Chimica inorganica | serie spettrochimica dei ligandi | 394 px in 390 — là `overflow:hidden` serviva solo ad arrotondare gli angoli, e ritagliava |

### Che cosa è cambiato

- Le tre tabelle stanno ora dentro un contenitore con `overflow-x:auto` — lo
  stesso schema già usato altrove nel file per le tabelle larghe. Dove serviva
  l'angolo tondo, `overflow-x:auto` con `overflow-y:hidden`: scorre in
  orizzontale e resta ritagliato in verticale.
- Alla tabella spettroscopica è stato dato un `min-width`, perché il browser
  non schiacci quattro colonne in fettine illeggibili invece di far scorrere.

### Il controllo che mancava

`audit_mobile` ora fa **due misure distinte** su tutte le 92 sezioni: lo
`scrollWidth` del documento (come prima) **e** gli elementi più larghi della
loro sezione **senza un antenato scorrevole**. La distinzione è tutta lì, e
tiene in piedi l'argomento originale del banco: una tabella larga dentro un
contenitore che scorre **non** viene segnalata, perché si legge scorrendola.

Provato nei due versi: togliendo il contenitore a una delle tre tabelle il
banco la nomina e fallisce; rimettendolo, le 92 sezioni passano pulite — con
dentro parecchie tabelle larghe, correttamente non segnalate.

---
## [bsi-v196] — 2026-10-08

**Una sola porta d'ingresso al lettore spettri.** Dalla fotografia di un
telefono: la scheda «Carica uno spettro» non lasciava scegliere un PDF, e
mostrava solo formati che nessuno ha in cartella.

### Che cosa succedeva

Il selettore di file dichiarava:

```html
<input type="file" accept=".jdx,.dx,.txt,.csv,.jcamp">
```

Su un telefono un `accept` **non restringe: nasconde**. Chi apriva «carica uno
spettro» con in mano il PDF di un compito vedeva una cartella vuota e
concludeva che l'applicazione fosse rotta. Lo era, di fatto: `.jdx` e `.dx`
escono dagli spettrofotometri, non li ha nessuno; il PDF e la fotografia ce li
hanno tutti, ed erano esattamente i due formati che quella scheda rifiutava.

C'erano poi **due schede** per la stessa domanda — «ho un file, cosa ci
faccio?» — una per gli spettri e una per i documenti. Chi arrivava col file
sbagliato nella scheda sbagliata non riceveva un errore: riceveva niente.

### Che cosa è cambiato

- **Una scheda sola, un bottone solo, nessun filtro.** `📂 Apri un file`
  accetta qualunque cosa, e **il programma decide che cos'è dicendolo** in una
  riga sotto il bottone. Niente instradamenti silenziosi: un instradamento
  silenzioso che sbaglia non si distingue da un programma che non fa nulla.
- **Le decisioni.** Un'immagine fa *entrambe* le cose (si estrae la traccia e
  si mostra come pagina, perché può essere la foto di uno spettro o di un
  foglio). Un `.jdx` è uno spettro per dichiarazione del formato. Un testo o un
  `.csv` si decide **dal contenuto**: se ci sono almeno cinque punti è uno
  spettro, altrimenti è il testo di un quesito e si svolge. Tutto il resto —
  PDF, Word, OpenDocument, fogli di calcolo — è un documento: si apre, si
  mostra per intero e si svolge quello che contiene.
- **Un binario travestito da `.txt`** non finisce più riversato nella casella
  di testo come byte illeggibili: la decodifica si controlla (byte nulli,
  frazione di `U+FFFD`) e il file passa al lettore di documenti, che sa dire
  che non è testo.
- **L'ingresso nascosto `#bsiSP-doc` forza il lettore di documenti** invece di
  ripassare dall'instradamento automatico. Si chiama «doc»: deve aprire un
  documento.

### Il distintivo di versione mentiva da ottanta versioni

L'intestazione scriveva **`v13l`**: una stringa fissa nell'HTML, mai
aggiornata, mentre l'applicazione era a `bsi-v195`. Nessun controllo la
guardava. Ora il distintivo si riempie da `BSI_APP_VERSION`, e **un controllo
confronta i due** — se tornano a divergere la batteria se ne accorge.

### Verifiche

- `test_spettrolettore` passa da 45 a **61 controlli**: un solo bottone
  visibile, `accept` **vuoto** (la direzione che conta: un `accept` non vuoto
  qui *è* il guasto), e l'instradamento provato su PDF, `.docx`, `.txt`,
  `.jdx`, due colonne `.csv`, un binario travestito e un `.png` — pretendendo
  per ognuno che la decisione annunciata sia quella giusta.
- Provato anche nell'ambiente che somiglia al telefono: sottocartella,
  **`.mjs` servito come `application/octet-stream` come fa GitHub Pages**,
  service worker attivo, finestra 390×844.

### Due bugie silenziose nei pacchetti di consegna

L'ordine suggerito dagli strumenti era `genera-pacchetti && genera-pdf`, e
`genera-evidenza` veniva per ultimo. Ma i pacchetti **imbustano** i PDF e il
rapporto di verifica: costruiti prima, portavano dentro **l'impaginato e
l'evidenza della versione precedente**, accanto al testo nuovo, senza che
nulla lo dicesse. Chi avesse letto il PDF avrebbe letto la versione di prima.

- `genera-pacchetti` ora **confronta le date**: un PDF più vecchio del
  documento da cui viene ferma la generazione e viene nominato.
- E **legge la versione dichiarata dal rapporto di verifica**: se non è
  questa, si ferma — un'evidenza che riguarda altro codice non è evidenza.
- L'ordine suggerito è stato corretto in `porta-versione.js` e nella guida al
  rilascio: SBOM → evidenza → **PDF** → **pacchetti**.

Entrambi i controlli sono stati provati **nei due versi**: toccando un
documento perché il suo PDF risultasse vecchio (si ferma, esce con 1) e
riportando il rapporto a `bsi-v195` (si ferma); rigenerando, passa.

---
## [bsi-v195] — 2026-10-08

**I PDF non si aprivano sul sito pubblicato.** I banchi passavano, qui
funzionava tutto, e lì non si apriva niente: il guasto stava nell'unica cosa
che la prova non riproduceva — **il server**.

### Che cosa succedeva

Un modulo JavaScript si carica con `import()`, e il browser pretende che il
server dichiari il tipo giusto, `text/javascript`. Non è una formalità, è una
regola di sicurezza, e Chrome la applica senza eccezioni:

> Failed to load module script: Expected a JavaScript-or-Wasm module script
> but the server responded with a MIME type of `application/octet-stream`.
> Strict MIME type checking is enforced for module scripts.

**GitHub Pages serve i file `.mjs` con il tipo sbagliato.** PDF.js, dalla
versione 6, è distribuito **solo** come modulo `.mjs`. Il server di prova dei
banchi — `python3 -m http.server` — li serve giusti. Quindi: banchi verdi,
PDF che si aprivano in prova, e sul sito vero il nulla.

### La riparazione: non dipendere dal tipo che dichiara il server

Si prova `import()` diretto, che è la strada giusta dove il server è
configurato bene. Se fallisce, il file si scarica come **testo** — `fetch` non
fa nessun controllo sul tipo — e si reimporta da un **Blob** che porta il tipo
corretto, creato qui. Il modulo è byte per byte lo stesso: cambia solo chi
dichiara che cos'è. Lo stesso trattamento vale per il worker.

### Il difetto era nel banco prima che nel codice

Il banco girava su un server che serve i `.mjs` correttamente: non poteva
vedere il guasto. Ora **impone il tipo sbagliato** e pretende che il PDF si
apra lo stesso.

E con un dettaglio che mi ha fatto riscrivere la prova: PDF.js **si ricorda**
di essersi caricato. Messa dopo l'apertura normale, la prova riusava il modulo
già in memoria e non provava niente. Ora la pagina si **ricarica** in mezzo,
così la strada diretta e quella di riserva vengono esercitate tutt'e due
davvero.

### E un messaggio che mentiva

Con un guasto, la riga di stato diceva **«aperto: documento.pdf · 0 parole»**.
«Aperto» accanto a un conteggio a zero fa credere che il file fosse vuoto,
mentre non si era aperto affatto. Ora il guasto compare in rosso lì, sotto il
bottone appena premuto, non solo più in basso in mezzo al resto.

### Riprodotto prima di correggere

La riparazione non è una congettura: il guasto è stato **riprodotto** in
locale servendo i `.mjs` come `application/octet-stream`, da una sottocartella
come fa GitHub Pages, con il service worker attivo e su schermo di telefono.
Prima: «Questo PDF non si è aperto». Dopo: una pagina, ottanta parole, lo
svolgimento completo. Anche il pulsante delle immagini è stato verificato
nello stesso ambiente.

---
## [bsi-v194] — 2026-10-08

Cercando fonti online per chiudere il punto debole, è saltato fuori un difetto
**nello strumento che spiega i numeri** — e quello sì che si poteva chiudere.

### La spiegazione non ricostruiva il numero

Il predittore mostra, per ogni carbonio alifatico, i contributi che lo hanno
prodotto. Per l'OCH₂ dell'acetato di benzile diceva:

> α arile + α OCO-

che fanno 22,1 + 56,5 = 78,6 sulla base di −2,3, cioè **76,3**. Il valore
mostrato accanto era **73,8**. Mancava il termine dei carboni semplici — un
γ a −2,5 — che la somma usava e la spiegazione taceva.

In uno strumento che si regge sul dire DA DOVE viene ogni numero, una lista di
contributi che non ricostruisce il numero è **peggio di nessuna lista**:
sembra una verifica e non lo è. Chi la leggeva per controllare il conto
trovava una differenza e non sapeva se sbagliava lui.

Ora ogni voce porta **il proprio valore con il segno**, i carboni semplici
sono dichiarati raggruppati per distanza, la correzione sterica e il cambio di
composto di riferimento ciclico compaiono con il loro contributo:

```
73,8 = base −2,3 · α arile +22,1 · α OCO- +56,5 · 1 C in γ −2,5
34,0 = base −2,3 · γ arile −2,6 · β CHO −0,6 · α S- +10,6 · α C=C +19,5 · 1 C in β +9,4
```

E il banco **rifà la somma**: per ogni carbonio alifatico di tutte le molecole
dei due insiemi ripesca i numeri dalla lista, li risomma e pretende che
tornino al millesimo. **48 carboni controllati.** Finché quella prova passa, la
spiegazione non può scollarsi dal calcolo senza che qualcuno se ne accorga.

Come effetto collaterale, i due «punti deboli» dichiarati nella versione
precedente risultano **verificati**: 73,8 e 34,0 sono esattamente ciò che lo
schema pubblicato prescrive, riga per riga. Non erano un difetto
dell'implementazione.

### Le fonti online: cercate, e il risultato è negativo — con la prova

Dalla macchina in cui questo progetto si compila **non è raggiungibile nessuna
fonte primaria**. Verificato, non supposto: `curl` passa solo verso i registri
di pacchetti (lo dichiara il proxy stesso); NIST, SDBS, PubChem, SpectraBase,
CSIRO, RSC, ACS, Springer, Wikipedia, LibreTexts, le tabelle di Hans Reich e
NMRShiftDB2 rispondono tutti **403**; PubMed non indicizza la chimica pura; e
nessun pacchetto npm o PyPI ridistribuisce una banca dati NMR di riferimento
(`nmr-predictor` la **scarica** da GitHub, che è bloccato).

Quello che la ricerca testuale ha potuto accertare è **dove sta il dato**:

> M. T. W. Hearn, «Carbon-13 chemical shifts in some substituted furans and
> thiophens», *Aust. J. Chem.* **29**(1), 107–113 (1976), DOI 10.1071/CH9760107

Il suo abstract dice che gli effetti dei sostituenti in questi eterocicli
*assomigliano* a quelli dei benzeni sostituiti. **Assomigliano non è
coincidono**: il trasferimento degli incrementi del benzene era già stato
provato e sui carboni β peggiora.

**Non ho scritto quella tabella a memoria.** Sarebbe stato facile. Ma un valore
che nessuno può risalire a una fonte è esattamente ciò che questo progetto
esiste per impedire, e metterlo accanto a novantuno righe trascritte da una
pagina stampata renderebbe meno credibili anche quelle.

### Una riga di validazione con provenienza più debole, dichiarata

L'acetato di benzile, entrato in validazione perché mostra il punto debole dei
due sostituenti in α, porta valori che **non ho potuto verificare** contro una
fonte primaria da qui. Il fenomeno è confermato in modo indipendente dal
quesito d'esame del 23/04/2024 — dato di provenienza vera — ma il **caso
peggiore dichiarato (7,5 ppm) poggia su quella riga**, ed è scritto sia nel
banco sia nel documento 06. Se quei sei numeri fossero sbagliati, è
quell'affermazione a cadere.

---
## [bsi-v193] — 2026-10-08

I problemi rimasti, affrontati uno per uno: due chiusi, uno **misurato invece
che asserito**, e due bloccati dall'ambiente — con la prova di oggi.

### Il secondo punto in cui il predittore cede, trovato misurando

Finora era dichiarato un solo punto debole: gli eteroaromatici sostituiti.
Misurando il quesito del furano carbonio per carbonio ne è saltato fuori un
altro, che **non c'entra niente con gli eteroaromatici**:

| molecola | carbonio | osservato | previsto | scarto |
|---|---|---:|---:|---:|
| acetato di benzile | OCH₂ (O estereo + anello) | 66,3 | 73,8 | **7,5** |
| il quesito del furano | CH₂ (C=C + S) | 26,7 | 34,0 | **7,3** |

Un carbonio sp³ con **due sostituenti in α**. Gli incrementi sono ricavati da
composti *mono*-sostituiti: sommandone due si conta due volte un effetto che
in realtà satura. Due misure indipendenti, stessa entità e stesso verso.

**Perché conta, e non è solo una curiosità.** In un confronto struttura↔dati
quel carbonio risulta «senza corrispondenza» e fa **perdere punti a una
struttura giusta**: l'acetato di benzile, che *è* la risposta, prende 42 su
100. Senza spiegazione, quel punteggio si legge come una smentita.

Ora lo strumento lo dice: la fiducia scende da «alta» a «media» e compare il
motivo — *un segnale che non torna su quel carbonio può essere un limite del
predittore, non una prova contro la struttura*. Provato nei due versi: avvisa
su tre strutture che hanno quel carbonio, e **tace** su sei che non ce
l'hanno, perché un avviso che compare dappertutto è rumore e si impara a
ignorarlo.

### Gli eteroaromatici: la scorciatoia è stata provata, e peggiora

La tabella degli incrementi di posizione per furano, tiofene, pirrolo e
piridina **non esiste** nella fonte, e non è stata trovata altrove: NIST è
irraggiungibile da qui e SpectraBase è dietro un accesso. Costruirla a memoria
sarebbe stato il contrario di tutto il resto di questo progetto.

La scorciatoia ovvia — **trasferire gli incrementi del benzene** all'anello
eteroaromatico — è stata provata sul caso che abbiamo: sul carbonio *ipso*
funziona (151,6 contro 150,77 misurato), ma sui carboni β **peggiora**, da 3,4
a 5,7 ppm di scarto. Non è stata adottata. Una generalizzazione che peggiora
proprio dove sta il problema non è una generalizzazione.

Quello che c'è ora è la **misura**, carbonio per carbonio, nel documento 06: i
due β del furano escono identici (109,6) contro 118,55 e 112,97, e si vede
perché. «Fiducia bassa» smette di essere un'affermazione e diventa un numero.

### Un dato sbagliato nel mio stesso banco

Il 4-metossiacetofenone ha **sette** carboni distinti e nella lista di
riferimento ne figuravano sei: mancava il C1 dell'anello, a 130,3. Il banco
stampava «segnali 7/6» a ogni esecuzione — un conteggio che non torna, dentro
un banco che serve a far tornare i conteggi — e nessuno ci faceva caso.

### D-07 e D-10: riverificati oggi, entrambi bloccati

Non per inerzia: riprovati, e il registro delle difformità lo dice con la
prova di oggi.

- **D-07** (verifica solo su Chromium): `npx playwright install firefox`
  fallisce con «Download failure», e `cdn.playwright.dev` risponde ancora
  **403** al tunnel. Vincolo dell'ambiente, non una scelta.
- **D-10** (il tag `bsi-v181`): riprovato con il client GitHub della sessione,
  che usa una credenziale **diversa** da quella che aveva fallito.
  `PATCH /git/refs/tags/bsi-v181` risponde **403 «Write access to this GitHub
  API path is not permitted through this proxy»**. È un secondo blocco,
  indipendente dal primo: anche senza la regola sui file di workflow, la
  scrittura sui riferimenti git non passa.

---
## [bsi-v192] — 2026-10-07

Nel lettore di spettri si apre **qualunque documento** — un PDF, la fotografia
di un foglio, un file Word — se ne vede **tutto** il contenuto, e il quesito
che contiene viene **svolto passo per passo**.

### Aprire il file: `bsi-documento.js`

| formato | che cosa se ne ricava |
|---|---|
| **PDF** | ogni pagina disegnata e il suo strato di testo (PDF.js) |
| **immagini** | la pagina si vede; il testo **no**, e lo dice |
| **testo, CSV, JCAMP-DX, XML, JSON** | il contenuto |
| **Word `.docx`, OpenDocument, PowerPoint, Excel** | il testo del documento |

Gli archivi Office si aprono **senza nessuna libreria**: sono ZIP, e il browser
sa già scompattare un flusso deflate con `DecompressionStream`. La direttrice
centrale dello ZIP si legge a mano, un centinaio di righe.

Il testo di un PDF arriva a frammenti con le loro coordinate, non a righe:
incollarli di fila farebbe una riga sola, e **una tabella di spostamenti
chimici diventerebbe illeggibile**. I frammenti si raggruppano per ordinata e
si ordinano per ascissa.

**PDF.js sta nel repository**, non su una CDN: l'applicazione funziona offline
e deve continuare a farlo. Si carica solo quando serve davvero — sono due
megabyte e mezzo, e chi apre il Centro spettroscopico per guardare uno spettro
non deve pagarli. È la build **legacy**: quella predefinita usa funzioni di
linguaggio recentissime (`Map.prototype.getOrInsertComputed`) e si rompe sui
browser che non le hanno ancora, incluso quello su cui gira la batteria.

### Leggere il quesito e svolgerlo: `bsi-quesito.js`

Riconosce nel testo la formula molecolare, le bande IR, i picchi di massa con
le loro intensità, i segnali ¹H con integrazione, molteplicità e J, i segnali
¹³C — e di ognuno dice **da dove l'ha preso**. Poi passa tutto a
`bsi-elucida.js`, che svolge.

**Il riconoscimento è per sezione, non per numero.** Una banda IR a 1738 e una
massa a 150 sono entrambe numeri: distinguerli dal solo valore è impossibile.
Si cerca l'etichetta della tecnica e si legge quello che viene dopo, fino alla
fine del capoverso.

**Riconoscimento e svolgimento restano separati, e si vedono in quest'ordine.**
Se il riconoscimento legge «1715» come banda IR quando era una massa, lo
svolgimento che segue è impeccabile e la conclusione è sbagliata. La tabella
dei dati letti sta **sopra** lo svolgimento apposta: così l'errore si vede
prima della risposta.

### Quello che non fa, e lo dice in faccia

- **Non c'è riconoscimento ottico dei caratteri.** Una scansione contiene
  pixel, non lettere. Il modulo dichiara quante pagine non hanno uno strato di
  testo, invece di restituire poco e far credere che il documento fosse vuoto.
- **Non c'è nessun modello linguistico**: espressioni regolari e un motore di
  regole. Se i dati sono scritti in una forma non prevista, **non** vengono
  letti — e lo svolgimento dichiara che cosa gli manca.
- **La struttura finale non viene proposta.** Proporla vorrebbe dire
  indovinare. Si può fare il contrario: scrivere una struttura e farla
  **confrontare** con i dati, segnale per segnale.

### Il banco, `test_documento` — 47 controlli nei due versi

Apre davvero un PDF, un `.docx` e un testo, e ne verifica il contenuto. E poi,
nel verso opposto: un'immagine dichiara che non c'è riconoscimento ottico e
**non** produce svolgimento; un formato sconosciuto viene rifiutato invece che
indovinato; un file binario chiamato `.txt` viene riconosciuto come binario;
CDCl₃ non diventa la formula del composto; una banda fuori da 400-4000 non è
una banda; senza etichetta MS non ci sono masse; un capoverso nuovo chiude la
sezione; un testo senza spettri non produce dati.

### Il caso peggiore dichiarato sale da 4,9 a 7,5 ppm

Non per un peggioramento: perché **questo banco ha trovato una molecola che il
predittore sbaglia più di tutte quelle che c'erano**. Nel quesito del
benzilacetato il confronto struttura↔dati segnalava che l'OCH₂ a 66,3 ppm non
trovava corrispondenza: il predittore ne dà 73,8. Un carbonio con **due**
sostituenti in α — un ossigeno estereo e un anello aromatico — è il punto in
cui uno schema additivo cede di più.

La molecola è entrata nell'insieme di validazione (ora 23), lo scarto medio
resta 1,0 ppm, e il caso peggiore **dichiarato nel pannello** è salito a 7,5.
Alzare una soglia dopo aver trovato un caso peggiore è onesto solo se lo si
dichiara anche a chi usa lo strumento, e lì sta scritto.

### Un difetto del mio stesso strumento, al primo uso vero

`tools/porta-versione.js`, scritto nella versione precedente per non riscrivere
più le frasi storiche, ha **rotto il distintivo del README**: shields.io scrive
un trattino letterale come `--`, e la sostituzione sceglieva la forma giusta
guardando il testo della propria espressione regolare — un controllo che non
corrispondeva mai. È uscito `versione-bsi-v192`, che shields.io non riconosce,
e il distintivo è sparito.

L'ha trovato `verifica-affermazioni`, che confronta il distintivo con il
codice: è esattamente il motivo per cui quel controllo esiste. Ora ogni schema
porta con sé la **propria** sostituzione, invece di una sola scelta al volo.

### E quarantasette fallimenti che non erano del codice

Durante una delle esecuzioni il server locale è caduto a metà batteria. I
banchi che restavano hanno fallito **tutti**, in meno di un secondo l'uno, con
lo stesso errore di connessione — e il rapporto è uscito con 47 fallimenti
mentre l'applicazione stava benissimo.

Un banco che fallisce per la ragione sbagliata insegna a ignorare il banco.
`genera-evidenza.js` ora **guarda prima** se il server risponde, e se non c'è
non comincia nemmeno: dice che cosa manca e il comando per avviarlo. E se il
server cade **durante** la batteria, il rapporto lo dichiara invece di
attribuire al codice dei fallimenti che sono suoi.

---
## [bsi-v191] — 2026-10-07

NMR **bidimensionale** — COSY, HSQC, HMBC — e uno **stack React + FastAPI**
che esegue gli stessi file, non una copia.

### NMR bidimensionale

Nuovo modulo `bsi-nmr2d.js`. Si poteva fare solo adesso: uno spettro 2D non è
un disegno più complicato, è una mappa di **correlazioni**, e per costruirla
servono lo spostamento di *ogni* protone e di *ogni* carbonio più l'**indice
dell'atomo** che li porta. Il predittore per atomo le dà entrambe; da lì le
tre mappe escono dalla topologia della molecola, senza inventare niente.

| mappa | che cosa collega | a che serve |
|---|---|---|
| **HSQC** | un protone e il carbonio a cui è legato (¹J) | assegna: ogni macchia dice «questo H sta su questo C» |
| **COSY** | due protoni a tre legami (H–C–C–H) | collega: seguendo le macchie si ricostruisce la catena |
| **HMBC** | un protone e i carboni a due o tre legami | attraversa i quaternari: un carbonile si vede dai protoni vicini |

L'HSQC è **editato**: i CH₂ hanno segno opposto a CH e CH₃, ed è così che si
contano i CH₂ di una catena senza dedurli dalle integrazioni.

Cliccando una macchia si illuminano gli atomi che la producono — nella
struttura piatta e nel modello 3D. Uscita in **CSV**.

**Si verifica contando i cammini** (`test_nmr2d`, **40 controlli**), e le prove
stanno nei due versi, perché una mappa che collegasse tutto con tutto
passerebbe qualunque prova scritta in un verso solo:

- l'acetato di etile dà **tre** macchie HSQC, una per carbonio protonato;
  l'esafluorobenzene, che non ha idrogeni, **nessuna**;
- il COSY del benzene ha la diagonale e **zero** macchie fuori: i sei protoni
  sono lo stesso segnale, e due protoni equivalenti non si accoppiano in modo
  osservabile. Il toluene invece ne ha quattro;
- il metano, che non ha un secondo carbonio, non dà **nessuna** macchia HMBC
  pur avendo quattro protoni.

**Quello che non è:** non simula l'esperimento. Niente intensità calcolate,
artefatti o dipendenza dal tempo di miscelamento. In un HMBC vero alcune
correlazioni a due legami non si vedono — qui ci sono tutte. Sta scritto nel
pannello.

### Due difetti, trovati contando

- **L'HSQC contava gli atomi invece dei segnali.** I sei carboni del benzene
  davano sei macchie sovrapposte nello stesso punto: sei correlazioni
  dichiarate dove ce n'è una. Il toluene ne dava sei invece di quattro.
- **La diagonale del COSY perdeva gli scambiabili.** L'O–H di un alcol non dà
  macchie *fuori* diagonale, ma sulla diagonale c'è: è un protone come gli
  altri. Escluderlo da entrambe faceva sparire un segnale — l'etanolo ne
  mostrava due invece di tre.

### Lo stack React + TypeScript + FastAPI

In `stack/`. Serve a chiamare la predizione **da un programma** e a servire
un'interfaccia separata. Non sostituisce la PWA, che resta il prodotto: gira
offline, non ha un server da pagare, e continua a essere ciò che si pubblica.

**La decisione che conta: nessun motore in Python.** La strada ovvia sarebbe
riscrivere il predittore in Python. È anche la strada sbagliata — diventano
due programmi che fanno la stessa cosa, uno riceve le correzioni e l'altro no,
e dopo sei mesi danno due numeri diversi per la stessa molecola.

RDKit ha una compilazione WebAssembly che gira **anche in Node**. Quindi un
processo Node carica gli **stessi quattro file** che l'applicazione serve ai
suoi utenti — `bsi-pretsch.js`, `bsi-nmr.js`, `bsi-geom3d.js`, `bsi-nmr2d.js` —
e risponde a FastAPI. Una correzione arriva a tutti e due nello stesso istante,
perché i file *sono gli stessi file*.

**E lo si verifica, non lo si promette.** `GET /salute` restituisce l'impronta
SHA-256 di ogni modulo caricato, e il banco `test_stack` la confronta con
quella dei file nel repository: se qualcuno ne copiasse una versione dentro
`stack/`, la prova fallirebbe il giorno stesso. Lo stesso banco controlla che
nel front end **non ci sia chimica**: nessun `.ts`/`.tsx` può contenere una
tabella di spostamenti, perché è lì che nascerebbe il secondo motore.

Sei rotte (`/salute`, `/identita`, `/nmr`, `/nmr2d`, `/geometria`,
`/struttura`), **18 controlli** pytest, front end React 19 + TypeScript in
modalità `strict`. Gli errori dicono di chi è la colpa: **422** se non è una
struttura leggibile, **503** se il motore non c'è — trattarli allo stesso modo
farebbe dire «SMILES sbagliato» a chi ha solo il server spento.

**Non è pronto per il pubblico**, e il README lo dice: niente autenticazione,
niente limiti di frequenza, niente cache.

### Undici frasi storiche riscritte da una sostituzione cieca

Alzare la versione sembra l'operazione più innocua del mondo: si cerca
`bsi-v<NNN>` e si scrive `bsi-v<NNN+1>`. **Per tre rilasci di fila è stato
fatto così**, e ogni volta ha riscritto anche delle frasi che raccontano un
fatto accaduto a una versione *passata*. Quello che ne era uscito stava dentro
una dichiarazione di conformità firmata:

- la password del File Manager risultava cambiata alla versione corrente,
  mentre era stata cambiata alla `bsi-v188` — e la frase sta in una
  difformità di **sicurezza**;
- l'incidente del tag `bsi-v181` risultava avvenuto alla versione corrente,
  mesi dopo il fatto;
- trentasei voci della banca dati farmaci risultavano aggiunte alla versione
  corrente;
- l'istruzione «incrementa `CACHE`» mostrava **lo stesso numero da entrambe
  le parti** — un esempio uguale a se stesso, rimasto così per tre versioni.

Undici righe in nove documenti, in italiano e in inglese. Nessun controllo
poteva accorgersene: ogni riga citava una versione che **esiste**, nel
documento che descrive quella versione. Il difetto non era nei documenti, era
nel **modo** di aggiornarli.

**`tools/porta-versione.js`** — il cambio di versione non si fa più a mano.
Tocca solo le righe che *dichiarano* la versione, riconosciute da uno schema
esplicito, e tutto il resto lo **elenca** perché lo si legga. Con `--prova` non
scrive niente. È stato lui, alla prima esecuzione a vuoto, a trovare le ultime
quattro righe sbagliate e due schemi inglesi che gli mancavano.

**Due controlli nuovi** in `verifica-documenti`, provati nei due versi
reinserendo i difetti veri e guardandoli fallire: nessuna frase al passato può
nominare la versione corrente, e nessun esempio di aggiornamento può mostrare
la stessa versione da entrambe le parti.

I due controlli sono dovuti condividere **una sola** definizione di «frase
storica» con quello che cercava le versioni rimaste indietro: tenendone due
elenchi si contraddicevano — uno pretendeva che la frase nominasse una versione
vecchia, l'altro la segnalava come dimenticata.

---
## [bsi-v190] — 2026-10-07

Un picco cliccato illumina l'atomo **anche in tre dimensioni** — e l'atomo è
quello giusto, il che è tutto il problema.

### Perché non bastava il visore 3D che c'era

Il visore 3D dell'applicazione **disegna** coordinate, non le costruisce: le
riceve da un file SDF scaricato da PubChem. Due conseguenze:

1. Una molecola **disegnata** dall'utente non ha un file su PubChem, quindi non
   si poteva vedere in tre dimensioni. Si vedeva solo ciò che qualcun altro
   aveva già depositato.
2. La numerazione degli atomi di un SDF di PubChem non ha **niente** a che
   vedere con quella di RDKit, che è quella del predittore NMR. Collegare un
   picco a un atomo del visore avrebbe illuminato l'atomo sbagliato — e un
   atomo sbagliato che sembra giusto è peggio di nessun atomo.

### `bsi-geom3d.js`: le coordinate dal grafo

Nuovo modulo che costruisce le coordinate **partendo dallo stesso grafo** del
predittore, con la garanzia per costruzione che l'atomo `i` qui sia l'atomo `i`
là. Gli idrogeni si aggiungono **in coda**, così gli indici degli atomi pesanti
non slittano.

Il metodo è la **geometria delle distanze**, in piccolo: si scrive una matrice
di limiti (legami, angoli di valenza, diagonali d'anello, contatti di van der
Waals), si parte da posizioni casuali ma riproducibili — il generatore è
seminato dallo SMILES, quindi la stessa molecola dà sempre la stessa forma — e
si correggono le violazioni finché non resta quasi niente. Gli anelli aromatici
si proiettano sul loro piano e le terne lineari si raddrizzano ruotando i rami
come corpi rigidi, perché quelle due cose una distanza da sola non sa dirle.

Misurato contro i valori che la chimica conosce (`test_geom3d`, **29
controlli**): C–C 1,54 Å, C=C 1,34, C≡C 1,20, aromatico 1,39, C–O 1,43, C–H
1,09; angolo tetraedrico 109,5°, aromatico 120,0°, alchino 180,0°, C–O–H
104,4°. E **nei due versi**: il benzene esce piano (0,00 Å dal piano) e il
cicloesano **non** piano (0,34), perché un banco che chiedesse solo la
planarità passerebbe anche a un programma che appiattisce tutto.

Su molecole vere: caffeina 0,027 Å di residuo in 89 ms, ibuprofene 0,014,
naprossene 0,022, paracetamolo 0,011, atorvastatina (76 atomi) 0,31 in 0,9 s.
Il residuo dell'ultima è dichiarato, nel modulo e nel pannello.

### La sincronia, e la prova che è lecita

Nel pannello NMR c'è ora un bottone **3D**. Cliccando un picco o una riga della
tabella, gli atomi si illuminano nella struttura piatta **e** nel modello
tridimensionale. Il banco non si limita a contare quanti se ne illuminano:
verifica che siano **esattamente** quelli del segnale, confrontando le due
liste di indici.

### Quattro difetti del generatore, tutti trovati misurando

- **Gli idrogeni contati due volte.** Aggiunti come atomi, il conteggio dei
  partner continuava a sommare anche quelli impliciti: il metano risultava con
  otto partner invece di quattro e usciva con angoli di 122°.
- **La tolleranza data sulla distanza invece che sull'angolo.** Vicino a 180°
  il coseno è piatto, e un ±6 % sulla distanza vale ±45° sull'angolo: il
  propino usciva piegato a 134° come un alchene.
- **Gli intervalli al posto dei valori.** Un intervallo lascia la soluzione
  appoggiata a un bordo: il metano si fermava a 115° rispettando ogni limite.
  Un legame e un angolo di valenza sono rigidi — non sono intervalli.
- **La correzione applicata a un atomo invece che al suo ramo.** Raddrizzare un
  alchino spostando il solo atomo terminale lascia indietro i suoi idrogeni, i
  legami si allungano, il passo dopo li riaccorcia tirando indietro il
  carbonio, e l'angolo torna piegato: il propino *peggiorava*, da 173° a 155°,
  con i legami stirati del 7 %. Un ramo va ruotato tutto insieme.

E uno di conflitto fra regole: in un anello aromatico a **cinque** termini
l'angolo interno vale 108°, non i 120° dell'sp². Imponendo 120 a un pentagono
si chiede una cosa impossibile — la caffeina non scendeva sotto un decimo di
ångström. Lo stesso per un carbonio di **giunzione**, che riceveva 108 + 120 +
120 = 348° invece di 360: gli angoli di un atomo piano ora si distribuiscono,
invece di essere imposti uno per uno.

---
## [bsi-v189] — 2026-10-07

Le tabelle di stima **intere**, al posto del riassunto che c'era.

### Il problema: un riassunto che non diceva di esserlo

`bsi-nmr.js` conteneva venticinque incrementi benzenici scelti a mano,
venticinque «valori di classe» per i carboni sp3, tredici incrementi β/γ e
quattro correzioni steriche su sedici. Erano un **riassunto** di tabelle molto
più grandi, e il riassunto funzionava finché la molecola somigliava a quelle su
cui era stato scritto. Dove non arrivava, il predittore non lo diceva: restituiva
il valore del composto nudo e basta.

In concreto: **ogni H aromatico usciva a 7,26 ppm** — che l'anello portasse un
nitro o un metossile. Ogni H vinilico a 5,35. Il nitrobenzene e l'anisolo, che
in uno spettro vero si distinguono a colpo d'occhio (8,22/7,70/7,55 contro
6,89/7,27/6,93), uscivano identici.

### Che cosa c'è ora

Nuovo modulo **`bsi-pretsch.js`**: solo numeri, trascritti riga per riga da
Pretsch–Bühlmann–Badertscher, *Structure Determination of Organic Compounds*,
4ª ed., Springer — §4.1 (pp. 82-84), §4.5 (pp. 100-102), §5.1 (p. 170),
§5.2 (pp. 178-179), §5.3 (p. 182), §5.5 (pp. 188-189).

| tabella | righe | formula |
|---|---|---|
| ¹³C benzeni monosostituiti | 91 | δ = 128,5 + Σ Zi |
| ¹H benzeni monosostituiti | 66 | δ = 7,34 + Σ Zi |
| ¹H etileni sostituiti | 42 | δ = 5,25 + Zgem + Zcis + Ztrans |
| ¹H alcani sostituiti | 31 | δ = base(CH₃/CH₂/CH) + ΣZα + ΣZβ |
| ¹H alchini terminali | 30 | valore diretto per sostituente |
| ¹³C alifatici | 24 | δ = −2,3 + Σ Zi + Σ Sj |
| correzioni steriche Sj | 4×4 | per grado del C osservato e dell'atomo α |
| ¹J(C,H) | 24 | J = 125,0 + Σ Zi |

Sta in un file suo perché si possa **controllare contro la pagina stampata**
senza leggere il codice che lo usa; `bsi-nmr.js` non contiene più numeri, solo
il ragionamento che li applica.

### Tre capacità che prima non c'erano

**Gli H aromatici si spostano.** δ = 7,34 + Σ Zi, con la posizione ricavata
camminando l'anello. Misurato: anisolo 6,90/7,29/6,94 contro 6,89/7,27/6,93;
fenolo 6,83/7,24/6,93 contro 6,84/7,24/6,94; benzaldeide 7,88/7,53/7,63 contro
7,88/7,52/7,60.

**Un =CH₂ terminale dà due segnali.** I suoi due protoni non sono equivalenti:
uno è *cis* e uno *trans* al sostituente dell'altro carbonio. Nello stirene
stanno a 5,74 e 5,23 — mezzo ppm — e darne uno solo vuol dire sbagliarne almeno
uno. Escono come due voci sullo stesso atomo, etichettate. Previsti 5,61 e 5,18.
L'etilene, che non ha niente di fronte, continua a darne **uno**.

**I cicloalcani diventano composti di riferimento.** È il metodo che la fonte
stessa descrive (p. 83): si parte dallo spostamento misurato del parente e si
aggiunge solo ciò che è cambiato. Prima c'era un valore fisso per dimensione
d'anello, e funzionava finché l'anello era nudo.

### Lo scarto, misurato di nuovo

| | prima (v188) | ora |
|---|---|---|
| ¹³C, taratura (9 molecole) | 1,47 ppm | **0,71 ppm** |
| **¹³C, validazione (22 molecole)** | **1,56 ppm** | **0,92 ppm** |
| ¹³C, caso peggiore | 15,0 ppm (cicloesanone) | **4,9 ppm** |
| ¹H (14 molecole) | 0,10 ppm | **0,06 ppm** |
| ¹H, soli aromatici | — | **0,03 ppm** |

Le soglie del banco si stringono con il predittore: 2,0 → 1,3 ppm per il ¹³C,
0,5 → 0,15 ppm per il ¹H, più una soglia nuova sul caso peggiore (6,0 ppm) e una
sui soli aromatici ¹H, perché la media generale — tirata dagli alifatici, che
erano già buoni — li nasconderebbe.

**Quello che resta sbagliato è dichiarato.** Il difenile sbaglia l'ipso di
4,6 ppm: l'incremento del fenile della tabella (Z₁ = 8,1) non lo descrive, e
**non è stato ritoccato** per farlo tornare — ritoccare un numero trascritto
perché una molecola di validazione non torna è esattamente il modo di rendere
quel 0,92 una bugia. Gli eterocicli saturi (THF, piperidina) non hanno un
composto di riferimento in tabella e restano la previsione meno affidabile.

### La cronologia delle molecole

Chi usa questo strumento prova una struttura, poi un'altra, poi torna alla prima
per confrontare gli spettri. Senza cronologia bisogna ridisegnarla, e il
confronto — che è il motivo per cui si prevede uno spettro — diventa un lavoro
di memoria.

Sotto la barra del pannello NMR c'è ora una striscia di pastiglie: ogni molecola
che ha prodotto uno spettro ci finisce dentro, un clic la riporta sul tavolo.
Di ognuna si tiene lo **SMILES canonico**, l'**InChI** e la sua **chiave**, e il
confronto per riconoscere i doppioni si fa sulla chiave: `OCC` e `CCO` sono
l'etanolo entrambi, e senza una forma canonica indipendente dalla scrittura la
cronologia si riempirebbe di doppioni. Una struttura che il predittore non sa
leggere **non entra**: non è una molecola su cui si tornerà.

Sta in `localStorage` dentro un `try/catch`, perché in navigazione privata la
scrittura lancia — e una cronologia che non si salva è un fastidio, non un
guasto.

### Cinque difetti trovati misurando

Nessuno di questi era visibile leggendo il codice: li ha trovati il banco.

- **L'ossidrile dell'acido contato due volte.** La riga del carbossile era
  scritta `[CX3;$(...)]=[OX1]` e lasciava fuori l'OH: quell'ossigeno restava
  libero, la riga generica dell'etere se lo prendeva, e il CH₂ dell'acido
  propanoico riceveva l'incremento α del COOH (+20,1) **più** quello β di un
  etere (+10,1). Usciva a 37,0 contro i 27,6 misurati. Una riga troppo stretta
  sbaglia quanto una troppo larga.
- **L'estere visto da un lato solo.** Dal lato alcolico vale 56,5 in α, dal lato
  acilico 22,6: trentaquattro ppm di differenza per lo stesso gruppo di tre
  atomi. L'OCH₂ dell'acetato di etile usciva a 29,4 invece di 60,4. Ora il lato
  si sceglie in base a quale atomo del gruppo è più vicino.
- **Le corrispondenze rese uniche per insieme di atomi.** `get_substruct_matches`
  restituisce *una* orientazione per ogni insieme: per `[CX3]=[CX3]` sullo
  stirene il capo era un carbonio solo, e l'altro non risultava mai capo dello
  schema. Lo stirene perdeva l'incremento del vinile su tutti e cinque gli H
  aromatici. Gli schemi si chiedono ora in forma ricorsiva, `[$(...)]`, che
  prova ogni atomo per conto suo.
- **Le righe «X–fenile» pescavano nell'anello che stavano sostituendo.** `[OX2][c]`
  descrive un ossigeno legato a un aromatico — e l'anello da sostituire *è*
  aromatico, quindi l'OCH₃ dell'anisolo veniva classificato come O–fenile.
  Ortho e para sbagliavano di 0,15 ppm ciascuno. Ora quelle righe pretendono
  **due** vicini aromatici.
- **Il vicino di un carbonio di giunzione trattato come sostituente.** Il
  criterio «sta in due anelli» protegge i C4a/C8a del naftalene ma non i loro
  vicini: il C8 regalava al C8a l'incremento ipso di un fenile, 147,5 invece di
  133,5. Il criterio giusto è che l'anello di quel vicino **condivida un legame**
  con questo.

E uno trovato guardando l'indice di colonna: l'orto di ogni benzene
monosostituito usciva `NaN`, mentre meta e para si scambiavano fra loro.

### Una promessa che nessun controllo manteneva

Il documento 09 dichiara, alla voce D-08, che «un disaccordo fra le due lingue
fa fallire la batteria». Era un'intenzione: **nessun controllo confrontava i due
documenti**, e la matrice di tracciabilità inglese era rimasta indietro di tre
requisiti — SCI-28 (predizione NMR), SCI-29 (equivalenza chimica) e SCI-30
(lettura di uno spettro da un'immagine), cioè proprio i più recenti. Chi legge
solo l'inglese non li trovava.

Le tre righe sono state scritte, e `verifica-documenti` confronta ora gli
identificativi definiti nelle due matrici, stampando la differenza **nei due
versi**: chi manca all'inglese e chi manca all'italiano. Adesso la frase è vera.

### Un difetto che la cronologia ha fatto emergere

Il pannello NMR si monta in **due** posti — la scheda ¹³C del Centro
spettroscopico e quella dell'editor ChemDraw — e cercava i propri elementi con
`document.getElementById`. Montati entrambi, nella pagina esistono due elementi
con lo stesso `id`, e `getElementById` restituisce il **primo in ordine di
documento**, che non è necessariamente quello che si sta guardando: lo spettro
veniva disegnato nel pannello sbagliato e quello aperto restava fermo. Ora le
ricerche partono dalla **radice del pannello montato per ultimo**.

Non lo si vedeva perché nessun banco aveva mai montato tutti e due i pannelli
nella stessa pagina. Il banco della cronologia lo fa, e la prova è fallita
subito.

---
## [bsi-v188] — 2026-10-07

Si disegna la molecola e si ottiene lo spettro ¹H e ¹³C **assegnato atomo per
atomo**; e uno spettro si legge anche da una **fotografia**.

### Predizione NMR assegnata per atomo

Nuovo motore `bsi-nmr.js`. Quello che c'era prevedeva il ¹H contando GRUPPI con
SMARTS — funziona per disegnare uno spettro, ma non sa DOVE stanno quei protoni:
non c'è un indice di atomo da nessuna parte, e senza quello cliccare un picco e
vedere illuminarsi l'atomo corrispondente è impossibile. Il ¹³C non esisteva
affatto nel motore strutturale: le due schede che lo mostravano — nel Centro
spettroscopico e nell'editor ChemDraw — lo ricavavano con **espressioni
regolari sul testo dello SMILES**, otto bande generiche per qualunque molecola
(«C alifatici 22 ppm», sempre).

Il metodo nuovo è fatto di schemi **pubblicati**, verificabili uno per uno:

- **incrementi di sostituente sull'anello benzenico**, con la posizione
  (ipso/orto/meta/para) ricavata *camminando l'anello*, non indovinata;
- **Grant–Paul** per i carboni sp3 di catena, con gli incrementi β e γ dei
  gruppi funzionali;
- **valori di classe** per carbonili, nitrili, alcheni, alchini, cicloalcani e
  per gli sp3 che portano un gruppo funzionale in α.

#### Lo scarto è misurato, e su molecole che non hanno scelto i parametri

Un predittore non si rompe mai: produce sempre dei numeri. Per sapere se
servono, le molecole sono divise in due insiemi — **taratura** (quelle usate per
scegliere valori e regole) e **validazione** (mai usate per quello). Il numero
dichiarato nel pannello è quello della validazione:

| | scarto medio |
|---|---|
| ¹³C, taratura (9 molecole) | 0,56 ppm |
| **¹³C, validazione (17 molecole)** | **1,93 ppm** |
| ¹H (8 molecole) | 0,10 ppm |

Il banco pretende anche che la validazione resti **peggiore** della taratura: se
diventassero uguali vorrebbe dire che qualcuno ha spostato una molecola da un
insieme all'altro, e il numero non direbbe più niente.

Sul toluene lo scarto massimo è **0,1 ppm** (137,8 / 129,2 / 128,4 / 125,6
contro 137,8 / 129,3 / 128,5 / 125,6). Sul cicloesanone è 15 ppm, ed è
dichiarato: gli sp3 con intorni complicati restano il punto debole.

### L'equivalenza chimica, che fa tornare i conti

Il benzene ha sei carboni e **un** segnale. Gli atomi equivalenti si
riconoscono con un codice d'intorno costruito a gusci concentrici — lo stesso
principio dei codici HOSE. Verificato su otto molecole di cui si sa quanti
segnali danno: benzene 1, toluene 5, p-xilene 3, naftalene 3, difenile 4,
aspirina 9. Tutte giuste.

### Lo spettro si può interrogare

Nella scheda ¹³C dell'editor: rettangolo per ingrandire, rotella per
l'intensità, doppio clic per tornare indietro, **clic su un picco o su una riga
della tabella per illuminare gli atomi che lo producono** nella struttura
disegnata accanto. Tabella di assegnazione con etichetta, ppm, integrazione,
molteplicità (dalla regola n+1 calcolata sul grafo) e costanti di
accoppiamento. Uscite in **CSV**, **JCAMP-DX** e **PNG**.

Il JCAMP prodotto è una `PEAK TABLE`, non una curva: è quello che una lista di
segnali previsti è, e scrivere `XYDATA` darebbe l'impressione di una misura.

### Un editor nuovo scritto e buttato

Il primo tentativo ne scriveva uno: tavolozza, legami, anelli, annulla e
ripeti, menu contestuale. Mille righe, già funzionanti. Sono state buttate,
perché l'applicazione **ne ha già uno** — l'editor ChemDraw, con i template
eterociclici (piridina, pirrolo, furano, tiofene, imidazolo), i gruppi
funzionali pronti, le cariche, il tocco, la cronologia e una libreria di 62
molecole. Due editor per la stessa cosa significa che uno riceve le correzioni
e l'altro no, e chi disegna non sa quale usare. Il progetto ha una regola per
questo: una sola casa per funzione. Quello che mancava non era un posto dove
disegnare, ma uno spettro che si potesse interrogare.

### Uno spettro da una fotografia

Il lettore di spettri accetta ora anche **immagini**: una foto del
registratore, un ritaglio da un articolo, lo schermo dello strumento. La
traccia si estrae dai pixel, colonna per colonna, cercando la riga più scura
rispetto allo sfondo stimato; le colonne vuote si interpolano, così un
tratteggio non spezza la curva.

Verificato su una figura **costruita** con gaussiane a 1715, 2950 e 3400 cm⁻¹:
letti dai soli pixel **1713, 2947 e 3403**. E nei due versi — su un foglio
**bianco** rifiuta invece di inventare una traccia.

**Quello che non può fare è scritto nel pannello:** l'immagine non contiene i
numeri degli assi. La scala la deve dare chi legge, e la funzione la *pretende*
invece di indovinarla. La forma della traccia è recuperata, la taratura no.

### Difetti trovati lungo la strada

- **Il codice d'intorno non era canonico.** Usava una visita in ampiezza con
  l'insieme dei visitati: su un anello, quale cammino arriva prima a un atomo
  dipende dall'ordine dei vicini, e questo rompeva la simmetria — il benzene
  usciva con due segnali, 128,5 su quattro carboni e 128,5 sugli altri due.
  Ora i gusci si costruiscono per distanza.
- **La forma di Kekulé rompeva la simmetria dell'anello.** In un singolo
  Kekulé i due carboni orto del toluene non sono equivalenti — uno è legato
  all'ipso con un doppio, l'altro con un singolo — e il toluene dava sette
  segnali invece di cinque. Un legame fra due atomi aromatici ora si scrive
  «a», e l'aromaticità la decide RDKit.
- **Gli incrementi dell'anello si sommavano.** Un metile corrisponde sia a
  `[CX4H3]` (+9,3 ipso) sia al generico `[CX4]` (+9,0): l'ipso del toluene
  usciva a 146,8 invece di 137,8, esattamente +9 di troppo. Ora ogni
  sostituente riceve **una sola** regola.
- **Gli anelli condensati non sono anelli sostituiti.** Nel naftalene i due
  carboni di condensazione ricevevano l'incremento «ipso fenile» dall'altro
  anello e uscivano a 152,3 invece di 133,5. Correggendolo troppo — saltando
  ogni vicino aromatico — si rompeva il **difenile**, dove il fenile è un
  sostituente vero: tutti e quattro i carboni a 128,5 invece di 141,2 / 128,8 /
  127,3 / 127,2. Il criterio giusto è stare in **due** anelli.
- **Doppio conteggio fra Grant–Paul e gli incrementi α.** Grant–Paul conta il
  carbonio carbonilico come α (+9,1) e poi l'incremento del chetone (+30) lo
  contava di nuovo: l'acetone dava il metile a 46,2 invece di 30,8.
- **Un segno sbagliato.** Il β di un carbossile *scherma*: l'acido propanoico
  ha il CH₃ a 9,0 contro i 15,6 del propano, Δ = −6,6 e non +3.
- **Uno SMARTS che conteneva entrambi i metili.** `[CX4H3][CX3](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/=[OX1])[CX4]`
  su un acetone fa **una** corrispondenza, perché l'insieme di atomi è lo
  stesso per i due metili e RDKit lo unifica: solo uno riceveva il valore di
  classe, e il segnale usciva come media fra 30 e 16,2. Tutte le tabelle sono
  state riscritte con l'atomo di interesse come **unico** atomo del pattern,
  usando SMARTS ricorsivi.
- **Un `null` silenzioso.** Quando il predittore lanciava, restituiva `null` e
  il pannello avrebbe mostrato «nessun segnale» senza dire perché. Gli
  aromatici fallivano **tutti** per un `cicli is not defined`, e nessuno lo
  diceva. Ora l'errore torna insieme alla sua pila.
- **Protoni equivalenti non si sdoppiano.** Il benzene usciva «t» e il
  ciclopropano «quint»: due singoletti, nei fatti, dichiarati come
  multipletti.
- **Una stringa vuota non è una molecola.** RDKit la accetta e restituisce un
  grafo senza atomi, da cui usciva uno spettro con zero segnali: un oggetto che
  sembra un risultato e non lo è.

### La categoria Utility passa nel menù ✨

La barra di navigazione aveva sette categorie, e la settima — «🛠️ Utility»
— raccoglieva diciotto voci che con la chimica non c'entrano: l'assistente, il
laboratorio, le note, il File Manager, le statistiche, il Pomodoro. Occupava
una categoria intera accanto a Chimica, Spettroscopia e Farmacologia.

Ora stanno nel menù ✨, in **due blocchi separati**: «🛠️ Utility» con gli
strumenti, e «🌍 Lingue e linguaggi» con la lingua dell'interfaccia e i
linguaggi chimici — che non sono uno strumento fra gli altri, sono il modo in
cui si legge tutto il resto.

**I pulsanti restano nel documento**, nascosti. Cancellarli sarebbe stato più
pulito a vedersi e sbagliato: decine di punti dell'applicazione aprono una
sezione con `document.querySelector('[data-s=...]').click()`, e `goSection()`
fa esattamente quello. Toglierli avrebbe rotto quei collegamenti in silenzio,
uno per uno. E le **etichette si leggono dai pulsanti** invece di essere
riscritte: così non diventano stringhe nuove da tradurre in tredici lingue, e
il menù dice sempre quello che dice la sezione.

#### Il menù giusto non era quello che sembrava

Il primo tentativo agganciava `#bsi105-fab` e `#bsi13-panel`. Esistono ancora
nel documento, ma sono `display:none` su **ogni** schermo — grande e piccolo.
Il menù che si vede davvero è `#bsi14-fab` con `#bsi14-panel`. Il banco
l'ha detto alla prima esecuzione, su entrambe le misure: «il pulsante ✨ c'è
ed è visibile → false». Senza quel controllo la categoria Utility sarebbe
finita in un menù che nessuno può aprire — irraggiungibile, come le due
sezioni delle lingue prima di lei.

Ed è per questo che il banco non si accontenta che il pulsante esista nel DOM:
`test_menu` gira su **schermo grande e su telefono**, pretende che il ✨ sia
visibile, che il pannello si apra, che tutte e diciotto le voci ci siano sotto
l'intestazione giusta, e che cliccandone una la sezione si apra davvero.

### Elucidazione — dai dati alla struttura, senza fare il salto

Nuovo modulo `bsi-elucida.js`, dentro la sezione «Lettore spettri»: si incolla
quello che si ha — formula molecolare, lista dei picchi di massa, bande IR,
segnali ¹³C e ¹H — ed esce un **dossier** in cui le **deduzioni** stanno
separate dalle **supposizioni**.

| deduzione | che cos'è |
|---|---|
| gradi di insaturazione (IDI/DBE) | aritmetica: `1 + Σ nᵢ(vᵢ−2)/2`, vale per qualunque elemento |
| massa monoisotopica attesa per M⁺ | somma degli isotopi più abbondanti |
| numero di segnali ¹³C distinti | e se sono meno dei carboni della formula, **c'è simmetria** |
| protoni dalle integrazioni | con l'avviso se non tornano con la formula |

| supposizione | con quale margine |
|---|---|
| numero di carboni dal picco **M+1** | `I(M+1)/I(M) × 100 / 1,1`, corretto per N, S, Si |
| eteroatomo dal picco **M+2** | Cl 32,5 % · Br 97,3 % · S 4,4 % · Si 3,4 % |
| perdite neutre | 25 voci, da −15 (CH₃) a −59 (COOCH₃) |
| bande IR, classi ¹³C e ¹H | **tutte** le compatibili, non la prima |

#### Perché non propone una struttura

Dedurla da zero — generare gli isomeri compatibili e ordinarli — si chiama
CASE, ed è un problema di ricerca, non una funzione. Per C₉H₁₀O₂S ci sono
migliaia di isomeri, e gli spettri ne escludono molti ma non tutti tranne uno.
Un programma che ne sputasse una sola darebbe una certezza che i dati non
contengono.

Quello che fa è **verificare una proposta**: ne prevede gli spettri e li mette
accanto a quelli osservati, segnale per segnale, dicendo dove casca.

#### I conti verificati contro compiti già corretti

Il banco non usa esempi inventati: usa quesiti di «Metodi Fisici in Chimica
Organica» con i conti che lo studente ha scritto a mano sul foglio.
**Dodici formule, dodici IDI giusti** — C₉H₁₀O₂S = 5, C₁₃H₁₇NO₂ = 6,
C₇H₁₀O₃ = 3, e così via. E il numero di carboni dal M+1: su `M 151 (47,2) ·
M+1 152 (4,7)` dà **9**, come il calcolo a mano.

Sul confronto fra una struttura **giusta** e una **sbagliata con la stessa
formula**: 2-etossibenzaldeide 100 contro 30, 4-amminobenzoato di metile 100
contro 80.

#### Un punteggio basso può voler dire due cose

E confonderle sarebbe il difetto peggiore di uno strumento come questo, perché
farebbe scartare la risposta giusta. Sul quesito del furano la struttura è
**corretta** e il punteggio esce **42**: non perché sia sbagliata, ma perché il
predittore non ha incrementi di posizione per gli **eteroaromatici
sostituiti** — esistono per il benzene, non li ho per furano, tiofene, pirrolo
e piridina, e inventarli sarebbe scrivere numeri senza fonte.

Quindi lo strumento dichiara la **fiducia**: «bassa», con il motivo scritto.
Il banco lo verifica — formula coincidente, punteggio basso, fiducia bassa,
motivo presente.

Aggiunti intanto i valori di classe ¹³C per gli eteroaromatici **non**
sostituiti, che prima non c'erano affatto: furano α 142,7 / β 109,6, tiofene,
pirrolo, piridina. Senza di quelli i carboni del furano uscivano tutti a 128,5.

### Il manuale come fonte: quattro miglioramenti con la pagina accanto

Dal **Manuale di Metodi Fisici in Chimica Organica** sono usciti i numeri che
mi mancavano. Ognuno è preso da una tabella del testo, non dedotto:

- **Correzioni steriche di Grant–Paul** (§4.7). Lo schema senza correzioni
  sbaglia sui carboni ramificati: il metile dell'isobutano usciva 25,6 contro
  i 24,3 sperimentali. Con le quattro correzioni che il manuale enuncia
  — osservatore 1° con vicino 3°/4° → −1,1 e le altre tre — esce
  **24,5**, che è esattamente il valore del suo esempio svolto.
- **Furano sostituito** (§15, caso D). Il manuale dice «furano monosostituito:
  C–O deschermato ∼150», e il quesito del 23/04/2024 lo conferma con 150,77 e
  146,05. Il carbonio α che porta un sostituente va quindi a 150, non ai
  142,7 del furano nudo. Il β non ha un valore dichiarato e **resta quello non
  sostituito**: dove non c'è una fonte non si inventa un numero.
- **Cinque perdite neutre in più** (§7.4): −36 (HCl), −56 (C₄H₈, McLafferty
  degli esteri butilici), −77 (C₆H₅), −81 (HBr), −128 (HI).
- **Costanti J per geometria** (§7.5): dodici righe al posto di sei, con
  l'intervallo accanto al valore tipico — cicloesano ax–ax 8–13, aromatico
  orto 6–10, alchene cis 6–12 contro trans 12–18, J cicliche del furano
  1,5–3,5.

#### E due difetti che il manuale ha fatto emergere

Provando i suoi cinque problemi svolti, due sbagliavano di 8–10 ppm.

Il **CH₂ in α a un estere** stava a 28 come quello di un acido. Non è lo
stesso: l'acido propanoico ha il suo a 27,6, il butanoato di etile a **36,2**
(dal problema svolto). Tenerli insieme sbagliava di 8 ppm sul segnale che dice
dove sta il carbonile.

E gli **incrementi β misuravano la distanza dall'atomo più vicino del gruppo**
invece che dal suo ancoraggio. Il gruppo `[OX2][#6]` di un estere etilico
comprende anche il carbonio OCH₂, legato al metile: la distanza risultava 1
invece di 2, nessun incremento si applicava, e il metile dell'etile usciva a
**4,6 ppm invece di 14,3**.

Correggendolo è emerso un **secondo difetto che il primo nascondeva**:
l'ossigeno di un alcol corrisponde sia a `[OX2H1]` sia a `[OX2][#6]`, e
prendeva **due** incrementi per la stessa ragione — il metile dell'etanolo
saliva a 24,8 invece di 18,2. Le righe ora si escludono a vicenda.

#### Il risultato, misurato

| | prima | ora |
|---|---|---|
| scarto medio su 23 molecole di letteratura | 1,96 ppm | **1,47 ppm** |
| insieme di validazione | 1,93 ppm | **1,56 ppm** |
| conteggi di segnali corretti | 17/18 | **22/23** |
| cricca del banco | 2,5 ppm | **2,0 ppm** |

I cinque problemi svolti del manuale sono entrati nell'insieme di
validazione: sono i casi che lo studente deve saper risolvere, e quindi la
misura giusta su cui farsi giudicare. La soglia si è stretta perché lasciarla
a 2,5 permetterebbe al predittore di tornare indietro senza che nessuno se ne
accorga.

### Banchi

Nuovo `test_elucida` (28 controlli). Nuovo `test_menu` (36 controlli su due viewport). Nuovo `test_nmr` (26 controlli): i due insiemi con i valori di letteratura, il
conteggio dei segnali su otto molecole, i rifiuti, e il pannello provato
nell'applicazione — clic su una riga, atomi illuminati, passaggio fra ¹H e
¹³C sulla stessa molecola. `test_spettrolettore` sale a 45 con la lettura da
immagine. Batteria ufficiale: **55 banchi**.

---
## [bsi-v187] — 2026-10-03

Un lettore di spettri che si porta il file, chemioinformatica che stima la
solubilità e impara da dati, trentasei farmaci nuovi con la struttura presa da
fuori — e tre strutture sbagliate che erano già nel sito.

### Lettore di spettri avanzato

Nuova sezione **Lettore spettri**. Si carica un file o si incolla un testo, e
viene letto: **JCAMP-DX** con la compressione **ASDF** completa (PMAI per le
cifre, DIF per le differenze, DUP per le ripetizioni) oppure due colonne di
numeri. Il formato JCAMP prevede un proprio controllo di integrità — dopo una
serie di differenze il valore successivo scritto per intero deve coincidere con
quello calcolato — e qui viene fatto, cosa che quasi nessun lettore fa.

I picchi si trovano per **prominenza**, con il rumore stimato dalla deviazione
assoluta mediana (MAD × 1,4826) e non dalla deviazione standard, che un picco
alto gonfia. L'IR si disegna con i numeri d'onda **decrescenti**, come lo si
guarda. Per ogni banda vengono elencate **tutte** le assegnazioni compatibili,
non la prima: a 1715 cm⁻¹ un C=O chetonico e un C=O di acido carbossilico sono
entrambi possibili, e dire solo uno dei due sarebbe un'affermazione che i dati
non reggono. La sezione dichiara di non dedurre la struttura.

Spettri di massa: la lista di picchi viene riconosciuta come tale, e le
differenze fra ioni vengono confrontate con una tabella di diciassette
**perdite neutre**. Sul toluene il picco base è m/z 91 e fra 92 e 91 compare la
perdita di H.

Il banco (`tools/banchi/test_spettrolettore.js`, 39 controlli) parte da spettri
**costruiti**: tre gaussiane a 1715, 2950 e 3400 cm⁻¹ sotto rumore, e il
lettore ne trova tre, a 1716, 2952 e 3402. Nei due versi: su **rumore puro non
ne trova nessuno** — senza quello, i tre di sopra non dimostrerebbero niente.

### Chemioinformatica e data science

- **ESOL** (Delaney 2004) per la solubilità in acqua, con l'incertezza
  dichiarata accanto alla stima. Verificata contro valori sperimentali:
  aspirina −1,65 contro −1,72; benzene −1,39 contro −1,64; naftalene −2,42
  contro −3,60; etanolo −0,12 contro +1,10. Scarto medio 0,68 unità
  logaritmiche, entro l'errore che il metodo dichiara. Un modello pubblicato si
  verifica contro il **suo** errore, non contro la perfezione.
- **Quattro filtri di drug-likeness** (Lipinski, Veber, Egan, Ghose), ognuno
  con il proprio verdetto e le proprie violazioni, non un punteggio unico che
  nasconde quale regola è stata violata. Sull'aspirina: Lipinski, Veber ed Egan
  passano, Ghose viola «20 ≤ atomi pesanti ≤ 70» perché l'aspirina ne ha 13.
- **Albero di regressione** e **foresta casuale** con campionamento bootstrap,
  sottoinsieme di variabili per nodo ed errore **fuori sacco**. Deterministica
  a parità di seme: un modello che cambia risposta a ogni esecuzione non si può
  verificare. Su una relazione non lineare costruita apposta R² fuori sacco
  0,90; su un bersaglio di **puro rumore** −0,16 — la guardia opposta, senza la
  quale lo 0,90 non direbbe che il modello impari qualcosa.

### Linguaggi chimici: venticinque uscite

Aggiunte le **sei impronte digitali** (Morgan, MACCS, RDKit, coppie di atomi,
torsioni topologiche, pattern), lo SMILES con gli idrogeni espliciti, lo
scheletro Murcko e il blocco scheletrico della chiave InChI. Ogni impronta
riporta la lunghezza **e il numero di bit accesi**: una stringa di soli zeri
passerebbe inosservata. Sull'aspirina: Morgan 24/2048, MACCS 21/167, RDKit
354/2048, coppie 68/2048, torsioni 18/2048, pattern 173/2048.

### Trentasei farmaci nuovi, e tre strutture che erano sbagliate

263 farmaci in tutto. Le trentasei voci nuove colmano classi che mancavano del
tutto: gliflozine, biguanidi, anticoagulanti diretti e warfarin, diuretici
(dell'ansa, tiazidici, risparmiatori di potassio), inibitore di KRAS G12C,
CDK4/6, BCL-2, modulatore CFTR, antifungino triazolico, glicopeptide,
ossazolidinone, demenze, gepante, glucocorticoide, antileucotrieni,
inibitore della calcineurina.

**Nessuno SMILES scritto a memoria.** Ogni struttura viene dal record ChEMBL e
la formula molecolare è stata **ricostruita contando gli atomi del grafo** che
RDKit legge, poi confrontata con quella che ChEMBL dichiara: 36 su 36
coincidono. Il banco e i dati grezzi con l'identificativo di ogni voce sono in
`tools/banchi/verifica_farmaci_v187.js` e `tools/dati/farmaci_v187.json`.

**Due voci rifiutate**, e vale la pena dire perché: l'**ivermectina** ha
`structure_type NONE` nel record (è una miscela di omologhi) e la
**semaglutide** è una proteina, `structure_type SEQ`. In entrambi i casi la
struttura si sarebbe potuta scrivere a memoria. È esattamente ciò che non si
fa: una struttura senza fonte entra nel sito indistinguibile da una verificata.

**Due nomi sono tornati diversi** da quelli cercati, perché la ricerca per nome
di ChEMBL è a corrispondenza parziale: «morphine» ha restituito l'**apomorfina**
e «levothyroxine» la **liotironina** (T3), trovata come sinonimo. Le voci sono
state tenute con il nome del **record**, non con quello della domanda: il
contrario avrebbe messo una scheda clinica sbagliata sopra una struttura giusta.

#### Il difetto che il peso non vedeva

Sei dei trentasei farmaci esistevano già. Confrontando le due versioni con la
**chiave InChI** che ChEMBL dichiara, tre di quelle preesistenti sono risultate
una **molecola diversa**:

| farmaco | chiave della voce vecchia | chiave dichiarata da ChEMBL |
|---|---|---|
| Lenalidomide | `XKAYAFBLGLCWSY` | `GOTYRUGSSMKFNF` |
| Palbociclib | `PSRAOXPOEYRNJN` | `AHJRHEGDXFFMBM` |
| Aripiprazolo | `ZGXTVHHDFYTYTL` | `CEUORZQYGODEFX` |

Erano **isomeri**: stessa formula, stesso peso, posizione diversa di un azoto o
di un carbonile. Il controllo sul peso dichiarato contro quello calcolato — che
esisteva e passava — non poteva vederlo, perché un isomero pesa uguale. Le tre
voci sbagliate sono state rimosse e sostituite da quelle verificate.

`audit_farmaci` ora ricostruisce la **formula** per ogni voce che dichiara una
provenienza, con due cricche che non possono allentarsi: le voci con
provenienza verificata non possono scendere sotto 36 e quelle con una struttura
leggibile non sotto 240. E le voci legittimamente **senza** struttura non sono
più coperte da un carattere jolly ma da tre ragioni dichiarate —
macromolecola, associazione a dose fissa, miscela di omologhi — perché una
esenzione senza ragione è un posto dove nascondere i difetti.

### Il modulo nuovo aveva spento il motore degli spettri

Il lettore si chiamava `window.BSISpettri`, e quel nome era **già occupato**:
è il motore di predizione spettrale di `bsi-spettri.js`, che si carica prima.
L'assegnazione lo sovrascriveva, e con lui sparivano `gruppi()`,
`irBandListLegacy()` e `nmrPeakListLegacy()` — il riconoscimento dei gruppi
funzionali e il disegno degli spettri previsti.

L'applicazione non diceva niente. **Zero errori JavaScript** su tutte le
quattordici pagine, la pagina si apriva, la sezione nuova funzionava, e perfino
la sezione degli spettri si disegnava, perché passa da un'altra strada. Il
difetto esisteva solo per chi chiamava quelle funzioni per nome.

Tre banchi su quattro lo hanno visto: `test_spettri` (41 controlli),
`test_spettri_ui` (16) e `test_assi` (13) sono caduti tutti sullo stesso
`TypeError`. Il modulo ora si chiama `BSILettoreSpettri`, e la ragione del nome
è scritta nella sua intestazione — perché è il tipo di errore che si rifà
identico sei mesi dopo.

### E la lingua che mancava a una voce sola

Aggiungere «📉 Lettore spettri» alla barra di navigazione senza tradurlo
avrebbe lasciato **una** voce su 171 in italiano in tutte e tredici le altre
lingue: invisibile a occhio in mezzo a novantadue pulsanti. `test_lingue` l'ha
detta per nome — «`navigazione: 📉 Lettore spettri`» — e ha preteso 92
pulsanti tradotti trovandone 91. Tradotta nelle tredici lingue: la copertura
torna **171 su 171** per tutte e quattordici.

### Trenta farmaci in piu' hanno reso «Farmacologia» la sezione piu' lenta

Con 263 voci invece di 233, aprire la sezione teneva la pagina bloccata
**159 ms**, e le sezioni oltre i 100 ms passavano da due a tre — oltre la
cricca che `test_fluidita` difende. La batteria era passata per un soffio la
volta precedente: un limite superato a intermittenza non protegge niente, ed è
peggio di un fallimento netto.

Le carte ora si disegnano **a fette da 8 ms**: la carta vuota entra subito nella
griglia, così l'altezza presunta è giusta e la barra di scorrimento non salta,
e solo il contenuto viene accodato. Da 159 a **55 ms**, sezioni oltre i 100 ms
di nuovo **zero**, e nessuna delle 263 voci perduta.

Le fette **non** sono il comportamento predefinito, e la ragione è precisa:
`test_farm_ui` chiama `showFarm(cat)` e legge il testo di `#farmList` sulla riga
dopo. Reso asincrono di nascosto, quel banco avrebbe smesso di misurare quello
che crede di misurare. Chiamata diretta: sincrona come sempre. Apertura della
sezione e cambio di filtro: a fette. `showFarm` restituisce **quanti lavori ha
accodato**, così il comportamento si misura dall'esterno invece di dedurlo dai
tempi.

#### Un involucro che perdeva gli argomenti

Il primo tentativo non ha avuto effetto, e la funzione modificata sembrava
giusta a leggerla. Mille righe piu' sotto, `showFarm` viene **riassegnata** da
un involucro che corregge le etichette delle categorie — e che chiamava
`_prevShowFarm(cat)`, scartando il secondo argomento e il valore di ritorno.
Il disegno a fette non partiva mai. Un involucro che perde gli argomenti è un
difetto invisibile finché qualcuno non comincia a usarli, e si trova solo
misurando: `showFarm(...)` restituiva `undefined` dove doveva restituire 263.

### Una soglia che misurava la macchina, non il codice

`test_fluidita` pretendeva che aprire il visore 3D costasse meno di **80 ms**.
Con lo **stesso codice pubblicato**, su container diversi, lo stesso click ha
misurato 14, 22, 98, 105 e 192 ms: il costo è la compilazione degli shader di
3Dmol, e qui WebGL è **SwiftShader**, un rasterizzatore software. Una soglia
assoluta in quelle condizioni fallisce dove il codice è identico, e passerebbe
dove è peggiorato. Alzarla a 200 l'avrebbe fatta passare e resa cieca.

Provata come **rapporto** su una calibrazione misurata nella stessa esecuzione:
non funziona. Quando il banco arriva al visore, WebGL è già stato usato dalla
pagina, e la calibrazione misura un costo **a caldo** (2,9 ms) mentre il visore
paga una compilazione **a freddo**. Il rapporto oscillava fra 14× e 36×.

Quello che il controllo deve impedire è **strutturale**: il difetto originario
era il primo `render()` di 3Dmol chiamato dentro il gestore del click. Allora
si afferma quello, nei due versi: subito dopo il ritorno del gestore, nello
stesso task, il contesto WebGL **non deve esistere**; poco dopo **deve**
esistere. Misurato: 0 tele durante il click, 1 dopo. E la misura non è vacua —
al secondo click, quando la tela c'è già, restituisce 1. Resta un tetto
assoluto di 400 ms, dichiarato grossolano: intercetta una catastrofe, non
misura la resa.

### Il difetto nel mio stesso controllo

La prima esecuzione della verifica delle formule ha dato **0 su 36**: ogni
formula risultava `C<n>`, tutti carboni e nessun idrogeno. Il formato
`get_json` di RDKit è **commonchem**, e in commonchem un atomo porta soltanto i
campi che **differiscono** dai valori predefiniti — dove `z` vale 6 e `impHs`
vale 0. Un atomo scritto `{}` è un carbonio. Leggevo `a.element`, che non
esiste, e contavo tutto come carbonio. Erano i dati a sembrare sbagliati;
era il contatore.

---
## [bsi-v186] — 2026-10-03

Giapponese e arabo, altri quattro linguaggi chimici, e la metà di interfaccia
che restava in italiano anche cambiando lingua.

### 日本語 e العربية — e il verso di scrittura

Quattordici lingue. L'arabo però non è solo un dizionario: si scrive **da
destra a sinistra**. Tradurre le etichette e lasciare l'impianto della pagina
al contrario sarebbe una traduzione che sembra fatta e non lo è — e non si
vedrebbe contando le stringhe, solo guardando. La lingua ora porta con sé il
verso: `dir="rtl"` per l'arabo, `ltr` per tutte le altre e al ritorno.

Il banco lo verifica nei due versi: `rtl` in arabo, `ltr` in giapponese. Con
`rtl` su tutte, il verso non significherebbe niente.

### Mezza interfaccia restava in italiano

Guardando la pagina in arabo si vedeva il difetto che nessun conteggio aveva
segnalato: le **sette categorie** della barra (Chimica, Spettroscopia,
Biochimica, Farmacologia, Chimica Fisica, Studio, Utility) e il **campo di
ricerca** restavano in italiano. Metà interfaccia tradotta è peggio di nessuna,
perché sembra un errore invece di una scelta.

Le categorie sono entrate nello scheletro. Il segnaposto della ricerca ha
richiesto un trattamento a parte: vive in un **attributo**, non nel testo, e
nessun conteggio su `textContent` se ne sarebbe mai accorto.

Lo scheletro passa da 162 a **170 elementi**, e tutte e tredici le lingue lo
coprono per intero.

### Diciassette linguaggi chimici

Ai tredici si aggiungono quattro uscite vere:

| | |
|---|---|
| **SMILES senza stereochimica** | ciò che si confronta quando si cerca «la stessa molecola a meno di configurazione» |
| **componenti** | un sale o un solvato sono *più* molecole, e dirlo evita di ragionare su una molecola che non esiste |
| **composizione in massa** | il conto che si fa a mano all'esame, con i pesi IUPAC scritti nel modulo |
| **CML** | Chemical Markup Language: XML, quindi leggibile da qualunque strumento |

La composizione è verificata contro il calcolo a mano: alanina C₃H₇NO₂,
M = 89,094 → **C 40,44% · H 7,92% · N 15,72% · O 35,91%**; aspirina C₉H₈O₄,
M = 180,159 → **C 60,00% · H 4,48% · O 35,52%**. La riga «componenti» compare
solo quando i componenti sono più d'uno — il banco pretende anche questo.

### Le molecole: verificato nella sezione vera

L'animazione di formazione e la selezione degli angoli erano state provate su
una tela costruita dal banco. Ora sono state provate **dove vivono davvero**:
nel visualizzatore 3D della sezione Molecola, che si apre in un popup.
Funzionano: la tela passa da 877 a 3 344 pixel accesi, la barra con i tre
comandi è presente e **dentro** il popup (misurata: 93 × 518 px, bordo
inferiore a 691 contro i 725 del contenitore), e la selezione dà
`C–C–O 111,7° · tetraedrica · ideale 109,5°`.

### Verifica

**51 banchi, 0 falliti.** `test_lingue` passa da 49 a **64 controlli**.

---
## [bsi-v185] — 2026-10-03

Un vero selezionatore di lingue, e tutti i linguaggi chimici che il motore sa
davvero produrre.

### Dodici lingue, con la copertura misurata accanto a ciascuna

Italiano, **English, Español, Français, Deutsch, Português, Nederlands,
Polski, Română, Ελληνικά, Русский, 中文**. Il pannello non è più un elenco di
pulsanti: ha un **campo di ricerca** e, accanto a ogni lingua, la copertura
**162/162 · 100%**.

Quella percentuale non è scritta a mano: `coperturaPerLingua()` applica
davvero ogni dizionario, conta gli elementi tradotti e rimette la lingua di
prima. È una misura, e cadrà da sola il giorno in cui qualcuno aggiunga una
voce di menu dimenticando una lingua.

**Non sono «tutte le lingue del mondo», e non lo dico.** Ogni lingua elencata è
completa e scritta a mano: nessuna è riempita a macchina, nessuna è parziale.
Aggiungerne una è un dizionario e una riga — `BSILingue.registra(codice, voci)`
è pubblica e documentata.

### Otto linguaggi chimici, non sei

Alle conversioni si aggiungono quattro uscite vere:

| | |
|---|---|
| **XYZ** | tre numeri per atomo: lo legge qualunque programma di calcolo |
| **PDB** | HETATM più CONECT, per aprirla in un visualizzatore |
| **CXSMARTS** | lo SMARTS esteso |
| **stereochimica CIP** | i descrittori *R*/*S* ed *E*/*Z* come li assegna il motore |

RDKit non scrive né XYZ né PDB: li scrivo io dalle coordinate del molfile. E
una **reazione** `reagenti>>prodotti` ora viene riconosciuta e scomposta —
2 reagenti, 2 prodotti — invece di essere trattata come una molecola sola, che
darebbe un risultato dall'aria giusta e sbagliato.

### Corretto — XYZ e PDB uscivano con tutti gli atomi nell'origine

Il mio lettore di molfile era nato per il nominatore IUPAC, a cui serve solo la
connettività: **non leggeva affatto le coordinate**. Appena si sono aggiunti
XYZ e PDB, i file uscivano con ogni atomo a (0, 0, 0) — numeri che sembrano
dati e non lo sono, esattamente il difetto che questo progetto insegue.

Ora le coordinate si leggono (colonne 0-10, 10-20, 20-30 del blocco atomi) e si
**dichiarano per quello che sono**: quelle che RDKit calcola da uno SMILES sono
**2D** (z = 0), servono a disegnare e non a misurare, e il file lo scrive nella
sua intestazione. Se sono tutte nulle, XYZ e PDB non vengono prodotti affatto.

Il banco lo verifica nei due versi: le coordinate non devono essere nulle **e**
devono essere dichiarate 2D.

### Verifica

**51 banchi, 0 falliti.** `test_lingue` passa da 31 a **49 controlli**.

---
## [bsi-v184] — 2026-10-03

Due funzioni che c'erano ma non si trovavano, e la lingua che non è più una
scelta fra due.

### Erano irraggiungibili dove l'app si usa di più

«Lingua» e «Linguaggi delle molecole» vivevano come voci del menu ✨. Ma su
telefono quel menu è **nascosto** — `#bsi105-menu{display:none!important}` — e
sostituito da un pannello a scomparsa con una lista propria, cablata. Le due
voci nuove non ci arrivavano: una funzione raggiungibile solo da lì è una
funzione che non c'è, proprio dove l'applicazione si usa di più.

Ora sono **due sezioni come tutte le altre**, con il loro pulsante nella
navigazione (🌍 Lingua, 🔤 Linguaggi molecole), presenti anche nel pannello
mobile. La voce del menu ✨ **porta** alla sezione invece di aprire una
finestra.

### Sei lingue, non due

Italiano, **English, Español, Français, Deutsch, Português**. Ogni lingua copre
**162 elementi su 162** dello scheletro — e il banco pretende sia la copertura
piena sia che il testo cambi davvero: un dizionario vuoto passerebbe «tutto
tradotto» senza muovere una lettera.

| | tradotti | testi cambiati |
|---|---|---|
| English | 162/162 | 137 |
| Español | 162/162 | 136 |
| Français | 162/162 | 140 |
| Deutsch | 162/162 | 139 |
| Português | 162/162 | 136 |

Il ritorno all'italiano resta esatto, carattere per carattere.

### Corretto — una trappola che c'era già, e in cui sono caduto

Montando le viste in due posti (finestra e sezione) con gli stessi
identificativi, avevo svuotato l'uno quando si apriva l'altro. In fondo
all'applicazione c'è però un **ripiego per le sezioni vuote** che, 800 ms dopo
un click, sostituisce qualunque sezione vuota con «🚧 Sezione in costruzione».
La sezione svuotata diventava un cartello di lavori in corso.

La risposta non è un terzo accorgimento: è togliere il doppione. La finestra
non c'è più — **una sola casa per funzione**, niente identificativi doppi,
niente da svuotare. Il banco ora pretende che nessuna delle due sezioni mostri
quel cartello.

### Corretto — i titoli che si traducevano due volte

I titoli delle due sezioni nuove finivano nel conteggio dello scheletro, ma
quei pannelli si ridisegnano già da soli nella lingua scelta. Al primo
passaggio il motore avrebbe memorizzato come «originale italiano» un testo che
poteva essere già inglese, e il ritorno all'italiano avrebbe riscritto
l'inglese: un difetto visibile solo cambiando lingua due volte. Ora sono
esclusi, con il motivo scritto accanto.

### Verifica

**51 banchi, 0 falliti.** `test_lingue` passa da 20 a **31 controlli**.

---
## [bsi-v183] — 2026-10-03

La sezione Molecola, ripresa dove la v182 l'aveva lasciata: la formazione è
molto più elaborata, e **l'angolo lo scegli tu**.

### L'angolo lo sceglie chi guarda

Un carosello che mostra gli angoli a turno risponde alla domanda sbagliata: chi
studia vuole sapere quanto vale *quell'* angolo, non scorrerli tutti. Ora si
clicca sugli atomi:

| Atomi cliccati | Che cosa mostra |
|---|---|
| **1** | tutti gli angoli che insistono su quell'atomo, insieme, con la geometria e la media |
| **2** | la lunghezza del legame — e se i due atomi *non* sono legati lo dice: una distanza non è un legame |
| **3** | l'angolo A–B–C, con il vertice nel secondo cliccato |
| **4** | l'**angolo diedro** A–B–C–D, con i due piani disegnati e il nome della conformazione |

Il diedro è la novità che conta di più: è il numero che distingue *anti* da
*gauche*, e nessuna formula piana lo contiene. Sull'etanolo, `H–C–C–O 60,7° ·
sin-clinale (gauche)`.

Gli atomi scelti portano un numero d'ordine, il resto della molecola si spegne,
e una riga sotto la tela dice sempre che cosa si sta misurando. Si distingue il
clic dal trascinamento contando i pixel percorsi: senza, ogni rotazione
finirebbe per selezionare un atomo. Il carosello resta come comando a parte,
per chi vuole solo guardare.

Verificato sull'etanolo: C–C **1,509 Å**, C–C–O **111,9°**, H–C–C–O **60,7°**,
e i diedri su quattro conformazioni costruite a mano (0°, 60°, 90°, 180°).

### La formazione, molto più particolare

Non più «atomi che scivolano al loro posto»:

- la **polvere ha un bersaglio**: ogni granello è assegnato a un atomo e gli
  spirala dentro finché viene assorbito — la materia non svanisce, diventa
  l'atomo;
- gli atomi **non arrivano tutti insieme**: prima lo scheletro pesante, poi gli
  idrogeni, perché è l'ordine con cui si legge una struttura. Si vede la catena
  formarsi e poi vestirsi;
- ogni atomo che si posa manda un **anello d'urto**;
- ogni legame, quando i suoi due atomi sono arrivati, si chiude con una
  **scintilla** che lo percorre da un capo all'altro;
- l'arrivo ha un **rimbalzo elastico**: un punto che si ferma di colpo sembra
  disegnato, uno che oltrepassa di poco e torna sembra arrivato.

### Corretto — tre difetti, tutti trovati misurando

- **Il rimbalzo non c'era, e l'ordine non reggeva.** La curva elastica serviva
  sia da posizione sia da avanzamento, e veniva tagliata al primo superamento
  di 1: così il rimbalzo spariva e — peggio — un atomo partito prima poteva
  risultare «meno arrivato» di uno partito dopo, perché quella curva oscilla.
  Trovato dal controllo che pretende lo scheletro davanti agli idrogeni a metà
  formazione. Ora le due grandezze sono separate.
- **Le etichette si pestavano.** Su un carbonio tetraedrico i sei angoli hanno
  i vertici vicinissimi, e uscivano numeri sovrapposti che sembrano un errore
  di calcolo e sono un errore di impaginazione. Ogni etichetta ora tiene
  memoria del rettangolo che occupa, si sposta se il posto è preso e rinuncia a
  scriversi se non c'è spazio: meglio un arco muto che due numeri illeggibili.
- **Le etichette finivano sotto gli atomi**, che si disegnano dopo. Ora si
  accodano e si stampano per ultime.

E un quarto l'ha trovato la tavola di prova, e l'errore era mio e non del
programma: con le coordinate che avevo scelto per il caso «gauche» il diedro
vale 120° e non 60°, perché guardando lungo il legame centrale il vettore
proiettato sta a (−0,5; 0,866).

### Verifica

**51 banchi, 0 falliti.** `test_mol3d` passa da 29 a **46 controlli**.

---
## [bsi-v182] — 2026-10-03

Due funzioni nuove nel menu ✨: **cambiare lingua** all'applicazione, e
**convertire una molecola fra tutti i linguaggi con cui la si può scrivere**,
con la guida che insegna a scriverli.

### 🌍 Lingua — e che cosa resta in italiano

L'applicazione è 48 000 righe di italiano, con i testi scientifici dentro il
codice. Tradurla tutta non è un interruttore: è un lavoro di contenuto, e
prometterlo con un menu a tendina sarebbe una bugia comoda.

Si traduce lo **scheletro** — i 89 pulsanti di navigazione, i 55 titoli di
sezione, le 16 voci del menu ✨ — e il pannello mostra la copertura
**misurata adesso sulla pagina aperta**, non una percentuale scritta a mano:
**160 elementi, 160 tradotti, 0 rimasti**. I contenuti dentro le sezioni
restano in italiano, e il pannello lo dice in prima riga.

Il ritorno all'italiano non è una ri-traduzione al contrario: ogni elemento si
porta via l'originale in `dataset.bsiIt` al primo passaggio, e tornare indietro
riscrive quello. Le chiavi del dizionario sono i testi italiani, scelta
deliberata: se un'etichetta cambia, la sua traduzione non si trova più e
l'elemento **resta in italiano** — visibile, con la copertura che scende. Il
guasto opposto, una traduzione vecchia incollata su un testo nuovo, non si
vedrebbe.

La lingua vale anche per la nomenclatura: `propan-2-olo` / `propan-2-ol`,
`acido butanoico` / `butanoic acid`.

### 🔤 Linguaggi delle molecole

Una molecola si scrive in molti modi. Il pannello converte fra quelli che il
motore sa trattare — **misurati, non supposti**:

| | ingresso | uscita |
|---|---|---|
| SMILES · CXSMILES · SMARTS | ✓ | ✓ |
| molfile V2000 / V3000 | ✓ | ✓ |
| formula · JSON RDKit | | ✓ |
| InChI | **no** | ✓ |
| chiave InChI | **no** | ✓ |

E dichiara i tre «no» con la loro ragione, che non è la stessa:

- **InChI in ingresso** — si genera ma questa build di RDKit non lo rilegge:
  `get_mol(InChI)` torna nullo. È un limite della build.
- **chiave InChI in ingresso** — è un digest di 27 caratteri: dalla chiave non
  si risale alla struttura **per costruzione**, non per limite del programma.
- **SMILES di Kekulé** — misurato: con `kekuleSmiles`, `kekulize` o entrambe
  RDKit torna sempre la forma aromatica. Il *molfile*, però, è già kekulizzato
  — sul benzene gli ordini di legame sono 2,1,2,1,2,1. La riga che mostrava la
  forma aromatica sotto l'etichetta «Kekulé» è stata tolta: un'etichetta che
  dice una cosa falsa è peggio di una riga assente.

Le chiavi InChI prodotte sono state confrontate con quelle di letteratura:
aspirina `BSYNRYMUTXBXSQ-UHFFFAOYSA-N`, caffeina `RYYVLZVUVIJVGH-UHFFFAOYSA-N`,
benzene `UHOVQNZJYSORNB-UHFFFAOYSA-N`. Coincidono. E il molfile **fa il giro
completo**: undici molecole su undici, taxolo con undici centri stereogenici
compreso, tornano al SMILES canonico di partenza.

### Il nominatore IUPAC — nomina solo ciò che può dimostrare

RDKit non genera nomi IUPAC, e non è una mancanza della build: la nomenclatura
non è un calcolo sul grafo ma un corpo di regole con eccezioni. Qui il nome
arriva per tre strade, e la **provenienza è sempre dichiarata**: nominatore
locale, archivio dei nomi comuni dell'app, oppure PubChem con la rete.

Il nominatore locale copre una classe **ristretta e scritta**: molecole
aperte, neutre, di soli C H O N F Cl Br I, con un solo tipo di gruppo
principale fra acido, aldeide, chetone, ammina primaria e alcol, e sostituenti
solo alogeni o catene alchiliche non ramificate. Applica le regole nell'ordine
giusto — catena principale, suffisso, numerazione, prefissi alfabetici — e
omette i locanti quando non distinguono: `cloroetano` e non `1-cloroetano`,
`triclorometano` e non `1,1,1-tricloro…`.

Fuori da quella classe **rifiuta e dice quale condizione è caduta**. Verificato
su 26 nomi scritti a mano in due lingue e 7 molecole che devono essere
rifiutate.

### Corretto — tre difetti miei, trovati misurando

- **Il nominatore accorciava la catena.** Su `CCCC(C(C)C)CCC` —
  4-isopropileptano — la catena di sette veniva scartata perché il sostituente
  è ramificato, e il programma ripiegava su una di sei producendo
  `2-metil-3-propilesano`: un nome che non è quello giusto. Ora la lunghezza
  massima si decide **prima**, fra tutte le catene che portano il gruppo
  principale, e se nessuna di quelle è trattabile si rifiuta invece di
  accorciare.
- **`trim()` distruggeva i molfile.** Un molfile comincia con una riga di
  titolo che può essere vuota: ripulendo il testo in ingresso la riga sparisce,
  tutte le altre salgono di uno e la riga di conteggio finisce al posto
  sbagliato. Trovato dal banco facendo il giro SMILES → molfile → SMILES.
- **Il benzene scambiato per un nome.** Il riconoscitore decideva con
  un'espressione regolare, e `c1ccccc1` è fatto di sole lettere e cifre e
  comincia in minuscolo. Ora la differenza fra SMILES e nome **non si indovina**:
  la decide il motore chimico, che è l'unico che sappia leggere uno SMILES.

Un quarto l'ha trovato la tavola di prova dentro il banco, e l'errore era mio e
non del programma: su `CC(Br)C(Cl)C` i locanti {2,3} si ottengono da entrambi i
capi, e la regola dà il numero più basso al sostituente primo in ordine
alfabetico. Il nome giusto è `2-bromo-3-clorobutano`, come diceva il codice.

### La guida

Quattro schede nel pannello: **Convertitore**, **Nome**, **Guida ai
linguaggi** e **Quale usare**. La guida — 7 400 caratteri, italiano e inglese —
copre come si scrive uno SMILES (atomi, legami, rami, anelli, cariche,
isotopi, stereochimica `@`/`@@` e `/`·`\`), come si costruisce un nome IUPAC
nelle sue quattro mosse, gli strati dell'InChI, i tre blocchi della chiave,
SMARTS come linguaggio di domanda, molfile e SDF, CXSMILES e JSON. Con, per
ciascuno, i tre errori che fanno perdere tempo.

### 🧬 La molecola che si forma — e gli angoli fra i suoi legami

Nella sezione Molecola la struttura compariva già fatta. Ora **arriva**: gli
atomi partono sparpagliati, come polvere sospesa, e convergono al loro posto in
1,6 secondi; i legami si chiudono **dopo**, quando i due atomi che li reggono
sono arrivati, crescendo dai due capi verso il centro. Non è decorazione: è la
differenza fra «ecco un disegno» e «ecco come sta insieme». Un pulsante
↻ rivede la formazione quante volte si vuole.

E mancava la cosa che una formula piana non dice mai: **quanto vale l'angolo**.
Il pulsante *Angoli di legame* li mostra uno per volta — l'arco disegnato fra i
due legami, il valore in gradi, il nome della geometria locale e l'angolo
ideale del modello VSEPR accanto a quello misurato. Sull'etanolo:
`C–C–O 111,9° · tetraedrica · ideale 109,5°`, e si scorre fra tutti e tredici.

**Gli angoli non sono tabulati**: si calcolano con il prodotto scalare sui
vettori di legame, dalle coordinate 3D della struttura caricata. Verificato su
geometrie di cui il valore è noto per costruzione — tetraedro regolare
**109,4712°**, acqua 104,47°, CO₂ 180°, BF₃ 120°, ammoniaca 106,13° — con
tolleranza 0,05°.

E su una struttura **piatta** il pulsante è spento, con la ragione scritta: su
coordinate con z = 0 un angolo di legame non è un angolo di legame, e mostrarlo
sarebbe l'errore peggiore dei due, perché somiglia a un dato.

Il modulo sostituisce `render3DOnCanvas` mantenendone il contratto — stessa
firma, stesso `{stop}` — e conserva l'originale raggiungibile: le altre sezioni
che lo usano non se ne accorgono. La barra dei comandi è fatta di pulsanti
veri, con il loro nome accessibile, non di rettangoli disegnati sulla tela.

### Corretto — due difetti nei banchi, non nel codice

- **`audit_storia` segnalava una chiave privata: la propria.** La prima stesura
  scriveva per intero l'esempio di chiave privata PEM (`-----BEGIN …`), che finiva
  nel repository come qualunque altra riga; alla prima esecuzione dopo il
  commit il banco lo trovava nella storia. Uno scanner che inciampa nelle
  proprie definizioni rende «contaminato» ogni repository che lo contenga, e il
  difetto si traveste da ritrovamento. Ora l'esempio si **compone** invece di
  scriverlo, e il blob vecchio — che resta nella storia, perché la storia non
  si riscrive — è un'**eccezione dichiarata** con il suo motivo, mostrata a ogni
  esecuzione. Un ritrovamento spiegato non si fa sparire allargando lo schema.

  Lo stesso inciampo si è ripetuto un piano più su: raccontandolo qui avevo
  scritto per intero la stessa stringa, e `verifica-sicurezza` l'ha trovata nel
  CHANGELOG. Anche questa riga, ora, è troncata.
- **`test_mol3d` passava su un insieme vuoto.** Leggeva la barra dei comandi
  dopo aver fermato il ciclo, che la rimuove: trovava zero pulsanti e poi
  dichiarava «ognuno ha un nome accessibile». Un controllo che passa perché non
  ha niente da guardare è il difetto che questo progetto insegue da sempre.

### Aggiunto

- Nuovi banchi **`test_lingue`** (20 controlli) e **`test_mol3d`** (29) —
  batteria da 49 a **51**.
- Requisiti **UI-10**, **UI-11**, **SCI-22** e **SCI-23** nella matrice.
- Quattro file nuovi: `bsi-lingue.js`, `bsi-molingue.js`,
  `bsi-pannelli-lingua.js` e `bsi-mol3d.js`, tutti nella cache del Service
  Worker: le funzioni nuove lavorano offline come il resto.

### Verifica

**51 banchi, 0 falliti.**

---
## [bsi-v181] — 2026-10-02

> **Avviso sul tag di questa versione.** Il 7 ottobre 2026 il workflow di
> pubblicazione è stato avviato senza compilare il campo della versione, e ha
> usato il proprio valore predefinito — che era `bsi-v181`. Essendo
> rieseguibile per progetto, ha **spostato il tag `bsi-v181`** dal commit
> originario `cb0cf03` al commit della `bsi-v187`, e le ha allegato i tre
> pacchetti della v187 accanto ai suoi. I pacchetti estranei sono stati
> rimossi.
>
> **Il tag non è stato possibile riportarlo indietro.** GitHub non permette a
> un'app di scrivere un ref che punti a un commit il cui
> `.github/workflows/*` differisce da quello corrente, e a `cb0cf03` quel file
> differisce di 319 righe. Sono state provate tre strade, tutte dalla stessa
> regola:
>
> | strada | esito |
> |---|---|
> | `git push --force origin refs/tags/bsi-v181` | «refusing to allow a GitHub App to create or update workflow `.github/workflows/release.yml` without `workflows` permission» |
> | `PATCH /git/refs/tags/bsi-v181` con `force` | 403 «Resource not accessible by integration» |
> | cancella e ricrea (`DELETE` + `POST /git/refs`) | 403 anche sulla **creazione** di un tag di prova sullo stesso commit, perciò il tag vero non è stato toccato |
>
> `GITHUB_TOKEN` non può ottenere il permesso `workflows`, e aggirare la regola
> rinominando i file di workflow sarebbe circonvenire una protezione, non
> ripararla.
>
> **Che cosa vale, allora, di questa release:**
>
> - i **tre pacchetti allegati** sono quelli della `bsi-v181`, corretti;
> - l'archivio «*Source code (zip)*» che GitHub genera dal tag contiene
>   invece il codice della `bsi-v187`, e va **ignorato**;
> - il codice della `bsi-v181` si scarica dal suo commit:
>   <https://github.com/samupropio1-ship-it/BioSpecInfo-v11/archive/cb0cf03e52f15d5f57c28626c75adc817d726788.zip>
>
> Il tag si rimette a posto con le credenziali di una persona, non di un'app:
>
> ```
> git push --force origin cb0cf03e52f15d5f57c28626c75adc817d726788:refs/tags/bsi-v181
> ```
>
> Perché non ricapiti: il valore predefinito è stato togliato dal workflow, e la
> versione da pubblicare deve ora coincidere con quella dichiarata da `sw.js`
> **e** con il nome dei pacchetti — altrimenti il workflow si ferma. Provato
> nei due versi: passa con `bsi-v187`, rifiuta con `bsi-v181`.

## [bsi-v180] — 2026-10-02

Due blocchi: la **fluidità** di tutta l'applicazione, misurata e corretta, e la
banca dati farmacologica che passa da **178 a 233 voci**.

### Fluidità — la causa non era il JavaScript

Misurato il cambio di sezione su tutte e 88: mediano 15 ms, ma cinque sezioni
oltre i 50 ms in riapertura e due oltre il secondo e mezzo alla prima apertura.

Scomposto il gestore del clic, la causa non era quella che sembrava: il ciclo
su tutte le sezioni costa **2 ms**, rendere visibile la sezione **0 ms**, e
tutto il tempo è il browser che **impagina** il DOM appena mostrato — 251 ms
per le sintesi, che sono 13 482 nodi di cui l'utente vede una schermata.

`content-visibility:auto` sulle carte, con `contain-intrinsic-size:auto` perché
la barra di scorrimento non salti:

| | riapertura | prima apertura |
|---|---|---|
| `ssyn` | 281 → **54 ms** | 1 272 → **199 ms** |
| `sretro` | 112 → **40 ms** | 180 → 70 ms |
| `sfarm` | 89 → **4 ms** | 293 → 141 ms |
| Sezioni oltre 50 ms | 5 → **1** | |
| Compito più lungo | | 1 374 → **651 ms** |

### Corretto — il prezzo nascosto di quella velocità

Gli elementi esaminati dal banco di accessibilità sono **scesi da 20 326 a
20 031**: uno per carta, perché un elemento di cui il browser non calcola il
layout ha rettangolo nullo e l'ispezione lo salta. Il banco continuava a dire
«contrasto 0» — **su meno superficie**, che è lo stesso difetto già incontrato
col 100 % di copertura e col contrasto dei pannelli nascosti.

Due correzioni: il banco ora **scorre** ogni sezione (20 338 elementi, più di
prima), e il riferimento registra `elementiEsaminati` con la **guardia
opposta** — fallisce se la copertura scende oltre l'1 %. Provata alzando il
riferimento: «COPERTURA SCESA: un "0 difetti" misurato su meno superficie non
è un "0 difetti"».

### Corretto — il modello si riaddestrava per OGNI predizione

`scegliIperparametro` prendeva una funzione che predice una query e la chiamava
dentro `prova.map(...)`: per la regressione kernel costruiva la matrice e
risolveva il sistema una volta per **ogni molecola da predire**. Oltre duemila
addestramenti dove ne servivano sessanta.

| Molecole | Prima | Dopo |
|---|---|---|
| 50 | 214 ms | 104 ms |
| 150 | 3 030 ms | **369 ms** |
| 200 | 7 279 ms | **535 ms** |

A risultati **identici byte per byte**. Il guardiano conta gli addestramenti
invece di cronometrare: dodici per 240 predizioni, e non dipende da quante
molecole ci sono.

### Farmaci — da 178 a 233, ogni struttura da ChEMBL

Cinquantacinque voci nuove sui buchi veri: inibitori di tirosin-chinasi,
antiretrovirali moderni, nirmatrelvir, sartani e antitrombotici, antiepilettici
di nuova generazione, carbapenemici, daptomicina, incretine, e la parte
respiratoria, reumatologica e urologica che mancava.

**Nessuno SMILES e nessun peso scritto a memoria**: la struttura viene dal
record ChEMBL e il peso è quello che ChEMBL dichiara. Un controllo ha
verificato che RDKit legga ogni struttura e che la **formula molecolare**
ricostruita dal grafo coincida con quella dichiarata — **55 su 55**.

Serviva una fonte esterna: lo SMILES sbagliato dell'omeprazolo era
*autoconsistente*, e un peso coerente con una struttura sbagliata passa
qualunque controllo interno. Intercettata anche una sostituzione silenziosa —
cercando «formoterol» ChEMBL restituisce l'**arformoterolo**, il solo
enantiomero (R,R) — registrata col nome giusto.

### Corretto — 115 farmaci su 233 erano invisibili

Cercando se le voci nuove comparissero è emerso un difetto che c'era già:

```js
var cats = cat==="all" ? Object.keys(catName) : [cat];
```

Le categorie da disegnare venivano dalla mappa delle **etichette**, non dai
dati: 47 categorie nei dati, 19 etichettate, e i farmaci delle altre 28 non
venivano **mai** disegnati. **115 voci su 233 invisibili — e 60 su 178 anche
prima di queste aggiunte.** L'applicazione ne teneva in memoria centinaia e ne
mostrava una parte.

Scritte le etichette per tutte e 47 le categorie, e `cats` ricavato dai dati.
I nodi della sezione passano da 4 038 a 7 805 — quasi il doppio — e la
riapertura resta a **4 ms**, perché il contenimento del layout fatto nello
stesso giro rende sostenibile mostrare il doppio del contenuto.

### Il 45° banco — `test_farm_ui`, riscritto

Un file con quel nome esisteva già: stampava sei numeri, non verificava niente
e **non era registrato nella batteria**. Mentre taceva, la sezione mostrava 118
farmaci su 233.

Ora pretende che **ogni** farmaco in memoria compaia nella lista disegnata, che
il filtro mostri le voci della categoria e nessun'altra, e che nessuna scheda
mostri un peso rotto. Il controllo che conta è l'ultimo: il banco **inserisce**
un farmaco con una categoria mai etichettata e pretende che venga disegnato,
poi lo rimuove senza lasciare tracce. Un controllo sui farmaci esistenti non
l'avrebbe scoperto, perché con le etichette a posto anche la riga difettosa
disegna tutto — verificato nei due versi.

Batteria: **45 banchi, 0 falliti**.

---

## [bsi-v179] — 2026-10-02

Caccia ai problemi prima di pubblicare su `main`, sui percorsi meno battuti.
Il più sospetto era il **caso classificazione**: implementato nel motore, ma
l'interfaccia era sempre stata provata su dati di regressione. Due difetti veri.

### Corretto — un intervallo di predizione che mentiva con sicurezza

Su un'attività **binaria** (0/1) gli intervalli conformi costruivano una
regressione sui valori binari e restituivano, misurato:

```
0,122  [−0,017,  0,261]
```

Un limite inferiore **negativo** per una grandezza che vale 0 oppure 1,
mostrato dal pannello con la stessa sicurezza di un valore buono. La predizione
conforme per la classificazione esiste, ma non è un intervallo: è un **insieme**
di etichette possibili, e si costruisce in un altro modo.

Finché non c'è, la risposta onesta è **rifiutare**: ora la funzione si ferma,
spiega che l'attività è binaria, e indica quale strumento usare al suo posto
(le metriche di arricchimento). Chi sa quel che fa può forzarla con
`forzaRegressione: true`.

### Corretto — la curva di apprendimento riportava un R² su etichette 0/1

Usava `metricheRegressione` senza guardare il tipo di problema. Ora su attività
binaria usa **ROC-AUC**, e in ogni caso **dichiara quale metrica** sta
mostrando: un punto «0,82» senza il nome della metrica non si può confrontare
con niente.

### Aggiunto — l'arricchimento aveva una capacità e nessuna porta

`arricchimento()` esisteva nel motore ed era verificato dal banco, ma
**nessun pannello lo raggiungeva**: una capacità che nessuno può usare è come
se non ci fosse. Ora c'è il pulsante, e il pannello mostra EF a 1, 5, 10 e 25 %
con l'**EF massimo possibile** accanto, più ROC-AUC e BEDROC.

Due scelte dichiarate nel pannello:

- l'ordinamento viene dalle predizioni **fuori piega** del modello migliore.
  Ordinare con le predizioni di un modello che ha già visto la molecola darebbe
  un arricchimento finto;
- con attività **continua** non esistono «attivi»: il quarto superiore viene
  preso come tale e **la soglia è scritta**, perché l'arricchimento cambia con
  essa.

### Verificato — quattordici pagine, nessun problema

Prima di unire su `main`: tutte le pagine dell'applicazione aperte e misurate.
**Zero errori JavaScript, zero risposte 4xx, zero identificatori duplicati.**

Banco a **189 controlli**. Batteria: 44 banchi, 0 falliti.

---

## [bsi-v178] — 2026-10-02

La chemioinformatica passa da **prototipo verificato** a **strumento di
lavoro**. Il motore cresce da 1 450 a oltre 2 450 righe, il banco da 106 a
**181 controlli**, e ogni capacità nuova è verificata contro valori calcolabili
a mano — come negli spettri.

### Sondata la libreria prima di progettare

MinimalLib 2025.03.4 è stata interrogata all'esecuzione, non assunta. Tre
capacità esistevano e non erano usate: **`SubstructLibrary`** (screening vero
con pattern fingerprint), **`get_rxn`/`Reaction`** (trasformazioni, cioè la
possibilità di tagliare un legame), **`generate_aligned_coords`**. Non ci sono
`cleanup`, `neutralize`, `canonical_tautomer`, `FragmentOnBonds`, né la
sottostruttura massima comune: dichiarato in `docs/06` §3-quater.1 con le
conseguenze.

### Aggiunto — frammentazione, con due regole

Una reazione SMARTS spezza un legame marcando i capi con un atomo fittizio.
Regola **fine** (predefinita, comprende i sostituenti terminali Cl, CH₃, OH) e
**grossa** in stile BRICS. Verificato: l'etossibenzene dà tre tagli con la
fine e due con la grossa, benzene e metano nessuno.

### Aggiunto — coppie molecolari corrispondenti

L'analisi con cui si legge una serie chimica: due molecole che differiscono per
**una cosa sola**, e la differenza di attività attribuita a quella. Verificata
su una serie costruita con effetti noti, che ritrova tutti:

| Trasformazione | Attesa | Trovata |
|---|---:|---:|
| clorofenile → fenile | −1,0 | **−1,0** su 2 coppie concordanti |
| metilfenile → fenile | −0,5 | **−0,5** |
| metile → cloro | +0,5 | **+0,5** |
| etilammide → propilammide | +0,2 | **+0,2** su 3 |

Sui 28 inibitori ChEMBL: 449 coppie, 98 trasformazioni solide, 133 ms; in cima
**CF₃ → SO₂NH₂ con Δ mediano −2,65**. La colonna «concordi» è quella che decide
se fidarsi, e le trasformazioni viste una volta sola sono contate a parte: non
sono scoperte, sono aneddoti.

### Aggiunto — ricerca per sottostruttura e tabella SAR

Ricerca con `SubstructLibrary`, query SMARTS o SMILES, conteggio delle
occorrenze. Una query malformata viene **dichiarata**, non ignorata.

La tabella SAR risolve il problema difficile — **in quale posizione** sta ogni
sostituente — sfruttando il fatto che il frammento col nucleo porta l'atomo
fittizio nel punto di attacco. Sui dati veri: 20 molecole col nucleo
benzamidico, 2 posizioni, 8 escluse. Le escluse non compaiono: mostrarle con
celle vuote le farebbe sembrare parte della serie.

### Aggiunto — il rigore che un valutatore pretende

Confronto fra modelli sulle **stesse pieghe** col riferimento banale in cima;
iperparametri per **validazione annidata**; **intervalli conformi**
(split-conformal, quantile ⌈(n+1)(1−α)⌉); **EF e BEDROC** per lo screening;
**curva di apprendimento**.

Il verdetto del confronto è provato **nei due versi**: su segnale vero margine
1,002 contro dispersione 0,676 → supera; sulle stesse molecole con etichette
casuali → non supera.

L'arricchimento è verificato sui tre casi calcolabili a mano: perfetto (AUC 1,
EF@20 % = 5 che è il massimo, BEDROC 1), pessimo (tutto 0, e **BEDROC zero e
non un negativo**), attivi ai ranghi 2 e 5 (AUC 12/16 = 0,75, EF 2,5).

### Aggiunto — esportazione SDF

Strutture con coordinate 2D generate, nome nella prima riga, campi dati.
Verificata col **round-trip**: il blocco prodotto si rilegge e dà lo stesso
SMILES canonico.

### Corretto — due difetti miei, trovati misurando

Il taglio escludeva gli atomi terminali, e la tabella SAR **perdeva il cloro
sull'anello**: trovava il sostituente sull'azoto e mancava la colonna che
interessa. Da lì nasce la regola fine.

`scaffoldMurcko().smiles` **non è uno SMILES**: è una chiave canonica di
raggruppamento, e il commento del codice lo diceva. Il pannello SAR la
proponeva come nucleo e la decomposizione rispondeva «nucleo non
interpretabile». Il campo si chiama ora `chiave` e dichiara
`eUnoSmiles: false`; il banco fissa che serva a raggruppare e **non si rilegga
come SMILES**. Il pannello non propone più niente: offre otto nuclei pronti e
il campo libero, perché una proposta sbagliata è peggio di nessuna proposta.

### Interfaccia e misure

Tre schede nuove: Ricerca, Tabella SAR, Coppie corrispondenti. Il contrasto dei
pannelli è ora misurato su **nove** invece di sei — **593 elementi di testo,
0 difetti** — e il banco pretende che siano tutti e nove ad aprirsi.

---

## [bsi-v177] — 2026-10-02

### Recuperato — le 12 domande del quiz, senza rimettere uno script

Sostituendo la guida di biochimica si era perso un quiz interattivo di 12
domande, che viveva in uno script della versione precedente. Rimetterlo com'era
avrebbe disfatto la ragione per cui la sostituzione valeva la pena: il documento
nuovo non ha **nessuno** script, e da lì viene la stabilità.

Le domande sono state riscritte come HTML statico: le quattro opzioni in chiaro,
la soluzione dentro un `<details>` nativo che si apre con un clic. **Zero righe
di JavaScript**, e il documento resta a 0 script.

### Corretto — una mia affermazione che era falsa

La prima versione della sezione diceva che la soluzione «resta chiusa sullo
schermo e **aperta in stampa**». Verificandolo con l'emulazione del mezzo di
stampa, era falso: Chromium non rende il contenuto di un `<details>` chiuso, e
il CSS non può forzarlo — `display:block!important` dentro `@media print` non
ha alcun effetto. Una copia cartacea avrebbe perso tutte e dodici le soluzioni,
mentre il testo accanto prometteva il contrario.

Risolto con due copie della soluzione, ciascuna visibile in **un solo mezzo**:
quella dentro il `<details>` per lo schermo, una dedicata per la stampa, con il
`<details>` nascosto in stampa e la copia dedicata nascosta sullo schermo.

Misurato nei due mezzi:

| | Domande | Opzioni | Soluzioni visibili |
|---|---:|---:|---:|
| Schermo (chiuso) | 12 | 48 | **0** |
| Schermo, dopo un clic | 12 | 48 | **1** |
| Stampa | 12 | 48 | **12** |

> **Perché vale la pena raccontarlo.** L'affermazione sbagliata non era nel
> codice: era nella frase che descriveva il codice, e nessun banco la
> controllava. L'ho trovata solo perché ho verificato una cosa che avevo
> appena scritto io, invece di fidarmene.

### Misure sulla guida, dopo l'aggiunta

Contrasto **0** su 2 056 elementi di testo (erano 1 897), testo alternativo
**98 su 98**, nessuno scorrimento orizzontale a 390, 360 e 320 px, **0** script,
**0** errori all'avvio.

---

## [bsi-v176] — 2026-10-01

### Sostituita — la guida di biochimica

Il documento passa da **1 MB a 8,2 MB** e cambia natura: da una pagina con un
capitolo e 34 sottosezioni a **12 capitoli più l'indice**, 78 sottosezioni e
**98 figure incorporate**, compresi due capitoli nuovi — «Guida all'orale» e
«Domande d'esame reali e risposte corrette».

Il file arriva **senza un solo script** e senza una sola richiesta di rete: non
può generare errori JavaScript, e non ha bisogno della guardia su
`localStorage` che serviva alla versione precedente (un accesso in modalità
privata lanciava `SecurityError` e interrompeva l'intero script della pagina).
È da lì che viene la stabilità in più.

Nome del file invariato, `Biochimica_Guida_Definitiva.html`: lo citano `sw.js`,
`index.html` e quattro banchi, e cambiarlo avrebbe significato toccare sei
punti senza guadagnare niente.

**Cosa si perde, dichiarato:** la guida precedente conteneva un quiz
interattivo di **12 domande**, e il documento nuovo non ne ha. Il capitolo
«Domande d'esame reali e risposte corrette» copre lo stesso bisogno in forma di
testo, e l'app ha il proprio apparato di quiz altrove.

### Corretto — 98 figure senza testo alternativo

Il banco di accessibilità ha bocciato la sostituzione: **98 immagini prive di
`alt`**. La via comoda era `alt=""`, che il banco accetta — il commento nel
codice dice, giustamente, che per un'immagine *decorativa* è la cosa corretta.
Ma queste sono figure di biochimica: marcarle come decorative avrebbe fatto
passare il controllo dicendo agli screen reader di saltare 98 diagrammi. Un
verde vuoto.

Ogni immagine sta dentro un `<figure>` con la sua `<figcaption>`, e le
didascalie le ha scritte l'autore. Da lì viene il testo alternativo, senza
inventare niente: 62 figure, di cui 36 contengono due pannelli. **Trentatré
delle 36 didascalie di coppia distinguono i pannelli** con «a sinistra» e «a
destra», e sono state divise per dare a ciascuna immagine la propria
descrizione; le 3 che non si dividono in modo inequivocabile condividono la
didascalia intera — verboso, ma non può essere sbagliato.

Risultato misurato: **98 su 98 con `alt`, nessuno vuoto**, contrasto che resta
a **0** su 1 897 elementi di testo.

### Corretto — la copertina faceva scorrere la pagina sul telefono

A 390 px — la larghezza che il progetto dichiara come requisito — il documento
era pulito. A **360 px**, larghezza comunissima, la pagina scorreva in
orizzontale, mentre la guida precedente no: una regressione introdotta dalla
sostituzione.

Il sospetto erano le tabelle a quattro colonne, che chiedono 416 px. Sbagliato:
l'autore aveva già messo `table.t{display:block;overflow-x:auto}`, e le tabelle
contenevano il proprio scorrimento. Nascondendo i figli del corpo uno a uno, il
colpevole è risultato il **titolo di copertina**: «Biochimica» a 46 pt è una
parola sola, non può andare a capo, e misura circa 390 px.

Reso fluido con `clamp(26pt,12vw,46pt)` **dentro `@media screen`**, così in
stampa il formato A4 resta quello voluto. Verificato: nessuno scorrimento
orizzontale a 390, 360 e 320 px.

### Copertura di codice: 49,89 %

Il riferimento portava `Biochimica_Guida_Definitiva.html: 81,24 %`, misura di
un file che ora non ha più codice da eseguire. Rigenerato: la voce è sparita e
la complessiva è **49,89 %**, in linea con la precedente. Un riferimento che
dichiara una percentuale per un file senza script afferma qualcosa che non si
può più verificare.

---

## [bsi-v175] — 2026-09-30

Il banco di lavoro chemioinformatico diventa uno strumento da cui i risultati
escono, e con loro il metodo che li ha prodotti.

### Aggiunto — validazione incrociata raggruppata per scheletro

Una divisione sola, su un insieme piccolo, è un numero rumoroso: su 28 molecole
al 25 % l'insieme di prova ne contiene sette, e spostarne una muove l'R² di
decimi. Ora si può chiedere una validazione a 3, 5 o 10 pieghe, e le pieghe
raggruppano **per scheletro**: nessuno scheletro sta in due pieghe, perché un
analogo della stessa serie in addestramento e in prova falsa la piega
esattamente come falsava la divisione singola.

Il risultato che ne esce è la ragione per cui vale la pena averla. Sui 28
inibitori dell'esempio:

| | |
|---|---|
| Divisione singola | R² **0,861** |
| Cinque pieghe | **0,605 ± 0,452** — le singole: 0,861 · 0,538 · 0,795 · **−0,150** · 0,980 |

La divisione singola aveva pescato la piega fortunata. Il pannello ora mostra
entrambe le cifre e dice, a parole, se distano più di una deviazione: quando
succede, il modello dipende sensibilmente da quali molecole gli capitano in
addestramento.

### Aggiunto — i risultati si portano via

Un banco di lavoro da cui i risultati non possono uscire è una dimostrazione,
non uno strumento. Due esportazioni:

- **tabella CSV** — nome, SMILES canonico e originale, attività, scheletro,
  nove descrittori, QED, violazioni di Lipinski, esito di Veber, allarmi. Con
  la validazione incrociata attiva si aggiungono *previsto* e *residuo*, e
  **solo allora**: è l'unico schema che dia a ogni molecola una predizione da
  un modello che non l'aveva vista;
- **rapporto di metodo (.md)** — versione di RDKit, fingerprint, tipo di
  divisione, molecole e scheletri, **il seme**, le metriche, il verdetto del
  controllo nullo, le pieghe una per una, i limiti dichiarati.

Entrambi si formano in memoria nel browser: non c'è nessuna richiesta di rete,
ed è la ragione per cui la nota accanto ai pulsanti può dire che nessun dato
esce dal dispositivo senza chiedere di crederci sulla parola.

### Corretto — un «contrasto 0» che non copriva la superficie nuova

`verifica-accessibilita` misura ciò che è **visibile**, e i sei pannelli della
sezione Chemioinformatica restano `display:none` finché l'analisi non è stata
eseguita: quel banco non li aveva mai visti, e il suo zero non parlava di loro.
Un numero perfetto che non copre la superficie nuova è esattamente il caso già
incontrato una volta in questo progetto.

Ora `test_cheminfo` esegue l'analisi per davvero, apre i sei pannelli a turno e
misura il contrasto WCAG su ogni testo che vi compare: **460 elementi, 0
difetti**. Le formule sono riscritte dentro il banco e non prese
dall'applicazione — chiedere al codice sotto esame quanto vale il proprio
contrasto non è misurare. E il banco pretende di averne misurati più di 250: se
i pannelli non si aprissero, lo zero sarebbe vuoto e il controllo fallirebbe.

Una nota della barra di esportazione era `#64798f` su `#101f33`, cioè 3,69:1.
Il correttore di contrasto dell'app l'aveva già alzata da sé a `#74889e`
(4,54:1) — era il correttore che funziona. È stata comunque riscritta
conforme all'origine, così resta leggibile anche se un giorno il correttore non
passasse di lì.

### Corretto — una similarità che non era similarità

Il pannello «Pharma Pro» di `rdkit_lab.html` confrontava la molecola con otto
farmaci di riferimento e mostrava una percentuale con la barra. Quella
percentuale non veniva da un fingerprint: veniva da **otto bit di descrittori a
soglia** — «ha anelli aromatici», «HBA > 4», «peso fra 200 e 500» — di cui si
calcolava il Tanimoto.

Misurato, non supposto:

| Coppia | A otto bit | Su Morgan vero |
|---|---:|---:|
| Caffeina · Metformina | **0,75** | **0,024** |
| Paracetamolo · Amoxicillina | 0,60 | 0,218 |
| Paracetamolo · Aspirina | 0,50 | 0,222 |

Caffeina e metformina non hanno frammenti in comune, e il pannello le mostrava
al 75 % — su una pagina che si chiama «RDKit Lab», con RDKit già caricato e in
grado di calcolare il fingerprint vero.

Accanto a quello, due difetti dello stesso genere:

- tre delle otto impronte di riferimento erano **scritte a mano** e avevano il
  bit «aromatico» sbagliato: caffeina (due anelli aromatici) segnata 0,
  morfina e amoxicillina (uno ciascuna) segnate 0;
- lo **SMILES dell'omeprazolo non era omeprazolo**: `COc1ccc2[nH]c(=S)cc2c1OC`
  è una struttura che RDKit rifiuta, e stava in un elenco di farmaci di
  riferimento.

Corretto tutto. Il confronto usa il fingerprint di Morgan; le impronte si
calcolano invece di essere battute a tastiera; l'omeprazolo è l'omeprazolo
(massa monoisotopica 345,11, tre anelli aromatici, entrambe verificate). Le due
funzioni della similarità finta sono state **rimosse**, non scavalcate —
lasciarle in giro le avrebbe rimesse in uso alla prima modifica — e il banco
controlla che non esistano più.

### Corretto — due Tanimoto dove ne bastava uno

Il laboratorio aveva la sua copia di Tanimoto. Concordava con quella del motore
sui casi normali — verificato: scarto **esattamente 0** su tutte e 28 le coppie
di riferimento — ma sul caso di due impronte vuote rispondeva 0 dove il motore
risponde 1. Due implementazioni che nessuno confronta prima o poi divergono sul
serio.

Ora `rdkit_lab.html` carica `bsi-cheminfo.js` e chiama quello. Dove il motore
non fosse disponibile la funzione restituisce **null**, non zero: uno zero
verrebbe mostrato come «0 % — strutturalmente distinte», che è
un'affermazione sbagliata detta con sicurezza.

### Corretto — la copertura di codice puniva il codice nuovo invece di misurarlo

Caricare `bsi-cheminfo.js` anche sul laboratorio ha fatto **scendere** la
copertura complessiva da 49,79 % a 49,26 %, e il banco l'ha bloccato — la
guardia che funziona. Ma la causa non era codice morto: era che il percorso
della copertura apriva la sezione Chemioinformatica **senza mai premere
«Analizza»**, e il motore parte solo allora. Centoventisette kilobyte contati
come non eseguiti, cioè una misura che puniva l'aggiunta di codice verificato
altrove.

Ora il percorso carica l'esempio, preme, apre i sei pannelli e addestra il
modello con tre pieghe: è quello che fa un utente. `bsi-cheminfo.js` passa dal
**26,64 % al 49,89 %** di istruzioni eseguite, e la complessiva risale a
**49,81 %**. Il riferimento è stato stretto a quel valore: una guardia che non
si stringe mai scende da sola col tempo.

### Il banco passa da 59 a 106 controlli

Oltre a quanto sopra: la massa monoisotopica di ogni farmaco di riferimento —
è il modo di accorgersi che sotto il nome giusto c'è la molecola sbagliata, un
nome non si può confrontare con niente e una massa sì — media e deviazione
campionaria verificate su
`[2,4,4,4,5,5,7,9]` — media 5, deviazione √(32/7) — le colonne del CSV contate
una per una, un nome con la virgola che deve risultare citato, e la metrica
scritta `R²` e non `R2`, perché «R2» è il nome di una variabile, non di una
metrica.

---

## [bsi-v174] — 2026-09-25

Una sezione nuova: **Chemioinformatica**. Non un laboratorio dimostrativo — ce
n'era già uno, e usava RDKit in superficie — ma il banco di lavoro che serve
per dire qualcosa di difendibile su un insieme di molecole.


### Aggiunto — `bsi-cheminfo.js`, il motore

Un modulo autonomo, esposto come `window.BSIChem`, che copre il percorso
intero: standardizzazione (frammento maggiore, SMILES canonico, deduplicazione
sul canonico), 43 descrittori RDKit, regola dei 5 e filtro di Veber, **QED
ricalcolato** perché MinimalLib non lo espone, impronte Morgan/RDKit/pattern/
MACCS, Tanimoto e Dice, raggruppamento di **Butina**, selezione **MaxMin**,
scheletri di **Bemis–Murcko**, PCA con i carichi, **regressione kernel** e
logistica, **salti di attività** per SALI, allarmi **PAINS** e **Brenk**,
dominio di applicabilità.

L'algebra è scritta qui dentro — Jacobi per gli autovalori, eliminazione
gaussiana per il sistema — perché una dipendenza in più per due funzioni non
vale il peso, e perché un banco può verificare entrambe contro valori
calcolabili a mano.

### Aggiunto — la sezione, sei pannelli

Descrittori · Similarità e gruppi · Spazio chimico · Modello QSAR · Salti di
attività · Allarmi strutturali. Due insiemi di esempio già pronti (28
inibitori con pIC₅₀, 40 farmaci presi dalla banca dati dell'app).

### Le tre precauzioni che distinguono una misura da un numero

- **Divisione per scheletro.** L'insieme di prova contiene soltanto scheletri
  mai visti in addestramento. La divisione casuale mette analoghi stretti da
  entrambe le parti: il modello riconosce invece di predire.
- **Modello nullo per rimescolamento.** Lo stesso modello viene riaddestrato
  otto volte su etichette mescolate, e il pannello **dichiara a parole** se il
  punteggio vero ha battuto tutti i sosia e di quanto. Sui 28 inibitori:
  R² 0,861 contro un massimo di 0,574, margine 0,287.
- **Dominio di applicabilità.** La distanza dal vicino più prossimo
  nell'insieme di addestramento, accanto a ogni valore predetto.

### Aggiunto — il 44° banco

`test_cheminfo`, 59 controlli contro valori calcolabili a mano. Verifica il
modello nullo **nei due versi**: su un segnale apprendibile R² 0,394 batte
tutti e otto i sosia; su etichette casuali R² −0,199 **non** li batte. Un
controllo che verificasse solo il primo caso passerebbe anche con la guardia
cablata su «vero». Il banco pretende inoltre di aver eseguito almeno 45
controlli: una suite saltata in silenzio fallisce.

### Corretto — RDKit non si caricava nella sezione nuova

Il modulo cercava `window.RDKit`, ma l'applicazione principale mette l'istanza
in `window.__rdkit` — è il suo caricatore `bsiLoadRDKit` a deciderlo. Su una
pagina dove RDKit era già pronto, la sezione diceva «RDKit si sta caricando»
per sempre. Ora si guardano tutti e tre i nomi in uso.

### Corretto — un banco incostante, che è il modo peggiore di fallire

`test_nucleo` passava lanciato da solo e falliva dentro la batteria. Il motivo:
Emscripten compila il `.wasm` di RDKit in streaming e, se il corpo della
risposta viene troncato — succede quando la batteria fa girare più browser
insieme sullo stesso server locale — scrive due righe in console e **ricade**
sull'istanziazione da `ArrayBuffer`, che riesce. Il banco contava quelle due
righe come errori JavaScript.

Un banco che dipende dal carico della macchina insegna a rilanciarlo finché non
diventa verde, e da quel momento non misura più niente. Le due righe della
ricaduta sono ora escluse — solo quelle, in dieci banchi che guardano la
console — e se la ricaduta stessa fallisse l'errore che ne segue non
corrisponde al filtro e resta contato.

### Verificato — i due zeri non si sono rotti

La sezione nuova è stata rimisurata con gli stessi banchi: contrasto WCAG AA
**0 difetti** su 88 sezioni, traboccamento orizzontale a 390 px **0 sezioni**,
campi privi di etichetta **0**, errori JavaScript **0**.

### Documentazione

Tracciabilità: quattro requisiti nuovi (SCI-14…17), totale dichiarato da 44 a
48, automatizzati da 39 a 43. `docs/06` §3-bis elenca i riferimenti
bibliografici di ogni metodo e i limiti dichiarati. `docs/13` §3.2-quater
descrive i sei pannelli. `docs/15` registra il banco. Tutto in italiano e in
inglese.

Batteria: **44 banchi, 0 falliti**.

---

## [bsi-v173] — 2026-09-23

Chiuse le ultime due difformità che restavano aperte per scelta o per lavoro:
**D-04** (password nella cronologia) e **D-08** (traduzione inglese parziale).

### Sicurezza — la password del File Manager è stata cambiata

La difformità **D-04** diceva: la password precedente è rimasta in chiaro nella
cronologia git, da prima che venisse tolta dal sorgente. Toglierla dai file non
la toglie dalla storia — `git log -p` la restituisce a chiunque — e finché
quella password è in uso il deterrente non deterre nessuno. L'unico rimedio
effettivo è **cambiarla**.

Cambiata. Nel sorgente c'è soltanto la nuova impronta SHA-256, mai la password;
verificato nel browser che la nuova apra e la vecchia no. Quella vecchia resta
leggibile nella cronologia e ora non apre più niente.

> Resta vero ciò che il documento ha sempre detto: su un sito statico questa è
> **una serratura contro chi passa, non contro chi vuole entrare davvero**. Chi
> conosce l'impronta può provarla offline quanto vuole. Non va usato per
> materiale riservato.

### Documentazione — l'inglese passa da 10 a **16 documenti su 16**

La difformità **D-08** dichiarava che un valutatore non italofono leggeva meno
di due terzi della documentazione. La parte mancante era proprio quella
operativa: chi deve capire *come funziona* e *come si manda in produzione*
restava fuori.

Tradotti gli ultimi sei: `06-Scientific-Accuracy-Data-Provenance`,
`10-API-Reference`, `11-Data-Model`, `12-Deploy-Guide`,
`13-Functional-Specifications`, `14-User-Manual`.

Tre scelte di traduzione, dichiarate perché sono decisioni e non sviste:

- **I nomi nel codice restano in italiano.** Il diagramma delle entità di
  `docs/11`, le variabili del proxy (`ORIGINI`, `LIMITE_IP`) e le chiavi di
  `localStorage` sono quello che sono nel codice: tradurle documenterebbe un
  sistema che non esiste.
- **I messaggi d'errore del proxy restano in italiano** negli esempi OpenAPI,
  perché è ciò che il proxy risponde davvero.
- **`verifica-affermazioni` controlla anche i documenti nuovi**: «87 sections»,
  «178 drugs», «35 tools» e «25 modules» nell'insieme inglese sono confrontati
  con la misura sull'app viva, e un disaccordo fra le due lingue fa fallire la
  batteria.

### Corretto — voci ormai false nei documenti italiani

Le correzioni di ieri avevano lasciato indietro tre affermazioni:

- `docs/06` §6 diceva «inclusi i 9 errori residui» mentre il banco ne riporta
  **zero**;
- `docs/06` aveva ancora la tabella con **sei** voci D-01, comprese le quattro
  chiuse con ChEMBL;
- `docs/13` §6 dichiarava l'accessibilità «verificata a campione» e la copertura
  di codice «non misurata», entrambe superate.

### Aggiunto alla lista di controllo del deploy

«La copertura di codice **non è scesa**» — `audit_copertura` fallisce se lo è, e
la lista che si legge prima di pubblicare deve dirlo.

---

## [bsi-v172] — 2026-09-23

Questa versione chiude difformità che erano **dichiarate**, non risolte. Ogni
chiusura è una misura che prima non veniva presa.

### Aggiunto — `audit_rete`: la verifica diretta che nessun dato esce

SEC-02 dice «nessun dato personale lascia il dispositivo». Era verificato
controllando i due *meccanismi* di uscita — variabile di telemetria vuota,
nessuno script da dominio esterno — e la difformità **D-03** lo dichiarava come
evidenza indiretta. Un controllo sui meccanismi dice «non vedo come potrebbe
uscire», che non è «non è uscito».

Il banco nuovo semina un **valore spia** irripetibile in 71 depositi dei dati
dell'utente (note, chat, chiavi API, impostazioni, progressi), poi **usa**
l'applicazione — 6 pagine, 87 sezioni, pannello dell'assistente — e ispeziona
URL, intestazioni e corpo di **ogni** richiesta che esce. Controlla anche gli
ospiti contattati: uno non dichiarato nella distinta è un difetto anche a mani
vuote, perché il solo contatto rivela che quell'utente sta usando l'app.

Porta con sé la prova di funzionare: `BSI_PROVA_FUGA=1` gli fa provocare una
fuga di proposito, verso un ospite **dichiarato** — contattarlo è lecito,
mandargli i dati no. Se in quel caso non fallisce, è lo strumento a essere
guasto. Provato: fallisce, e nomina la richiesta.

Misurato: 29 richieste ispezionate, **0 fughe**, ospiti contattati `127.0.0.1` e
`pubchem.ncbi.nlm.nih.gov`. **D-03 è sanata.**

### Corretto — il testo su gradiente non era «non misurabile»

La difformità **D-09** dichiarava fuori misura 892 elementi «su fondo a
gradiente», col motivo che «il contrasto varia lungo la superficie e servirebbe
leggere i pixel». Era vero a metà: un gradiente non ha *un* colore — inventarne
uno medio sarebbe peggio che non misurare — ma ha delle **tappe**, e quelle sono
note. Un testo leggibile su tutto il gradiente è un testo che supera la soglia su
**ogni** tappa: è la condizione più severa fra quelle vere, e non richiede di
leggere un solo pixel.

Entrando nella misura sono emersi **27 difetti mai visti prima**. Dieci erano un
falso positivo del banco appena scritto: con `background-clip:text` il gradiente
dipinge i **glifi**, non lo sfondo, e confrontarlo col colore del testo dava il
colore contro se stesso — 1:1. Corretto: in quel caso sono le tappe a essere i
colori del testo, e lo sfondo è quello dell'antenato. Vale anche per i
discendenti, perché lo `<span>` della versione dentro `.logo-name` è dipinto
dallo stesso gradiente.

I 17 difetti reali erano distintivi e pulsanti con testo bianco su gradienti che
a un'estremità sono chiari:

- `.badge-pro`, `.pc-badge`, `.login-btn` — bianco su `#00c9b7`: **2,09:1**.
  Testo a `#06141f`: passa su entrambe le estremità (4,94 e 8,90).
- `#level-badge` di accademia — il gradiente andava da `#b794f6` a `#7c5cbf`, un
  salto tale che **nessun** colore di testo passa su entrambi gli estremi:
  bianco 2,45 sul chiaro, scuro 3,67 sullo scuro. Si è stretta la corsa del
  gradiente conservando la tinta.
- I due pulsanti «Anima meccanismo» prendevano una tappa dai dati e potevano
  risultare a **1,03:1**: ora la tappa passa da `bsiAccentoLeggibile()`.

Aggiunta anche l'esclusione del testo fatto di **sole emoji**: il glifo porta i
propri colori e `color` non lo tocca, quindi misurarlo è come misurare un SVG
leggendo `color` — l'errore che aveva già prodotto 48 falsi difetti. Sono 32
elementi, contati e dichiarati.

Gli elementi di testo esaminati passano da 19 751 a **33 642**. Restano fuori il
testo dentro gli SVG (8 888) e quello su una vera immagine di sfondo (108),
contati a ogni esecuzione. Il contrasto resta a **0 difetti**, ora su una
superficie di misura molto più larga.

### Corretto — quattro delle sei voci senza struttura ne hanno una, verificata

La difformità **D-01** elencava sei farmaci «ad alta complessità molecolare
senza struttura verificata». Per quattro la struttura esiste e si trova in
**ChEMBL**, fonte indipendente da questo progetto:

| Voce | ChEMBL | Peso dichiarato | Peso calcolato |
|---|---|---:|---:|
| Digossina | `CHEMBL1751` | 780,94 | 780,95 |
| Vincristina | `CHEMBL90555` | 824,96 | 824,97 |
| Tacrolimus topico (Protopic) | `CHEMBL269732` | 804,02 | 804,03 |
| Tacrolimus sistemico (Prograf) | `CHEMBL269732` | 804,02 | 804,03 |

Il motivo registrato per la digossina diceva «ogni struttura provata si discosta
di 14-30 u dal peso di letteratura»: il peso dichiarato era giusto, erano le
strutture provate a essere sbagliate. Le voci con struttura passano da 153 a
**157**.

Una trappola evitata scrivendole: in una stringa JavaScript `"\C"` vale `"C"`.
Le barre rovesciate dello SMILES del tacrolimus — che sono **stereochimica** —
sarebbero sparite cambiando la molecola in silenzio. Vanno raddoppiate.

Che il confronto sia reale si vede aggiungendo un carbonio alla struttura
corretta della digossina: il banco segnala **Δ 14,04** e fallisce.

**Le due che restano non sono molecole singole**: Ivermectina è una miscela di
omologhi (≥80 % B1a, ≤20 % B1b; il peso dichiarato è quello del solo B1a) e
Coartem un'associazione di due principi attivi. Non manca una struttura: non ce
n'è **una** da mostrare. Il motivo registrato lo dice ora in questi termini.

### Aggiunto — la guardia opposta sul registro delle deviazioni

Il registro esiste per non far fallire la verifica su una voce di cui si è
deciso di non mostrare la struttura. Mancava il caso contrario: una voce che
**ha** una struttura verificata e resta comunque elencata è un permesso che
nessuno ha revocato, e domani coprirebbe in silenzio una struttura sbagliata
messa al suo posto. Ora fa fallire il banco — verificato rimettendo una delle
quattro voci sanate.

### Aggiunto — `audit_copertura`: la copertura di codice esiste, ed è 49,79 %

La difformità **D-06** diceva «nessuna copertura di codice strumentata», con
questa motivazione: strumentare richiederebbe introdurre una build, che
l'applicazione non ha. Era vero per `c8` e `istanbul`, che riscrivono il
sorgente prima di eseguirlo — e falso per il problema: **Chromium la raccoglie
da solo**, dentro il motore, senza toccare un byte del file servito
(`Profiler.startPreciseCoverage`, che Playwright espone come
`page.coverage.startJSCoverage()`). Il vincolo apparteneva agli strumenti
scelti, non alla cosa da misurare.

**Il primo risultato è stato 100 % su ogni file**, compresi 3,6 MB di
`index.html`: il banco che non misura niente nella forma più insidiosa, un
numero perfetto. V8 emette per ogni funzione un intervallo esterno col
conteggio degli ingressi, e dentro quello gli intervalli a `count: 0` per ciò
che **non** è stato eseguito; sommando i positivi si somma l'intero file. Si fa
il contrario: si parte dal totale e si sottrae l'unione dei vuoti.

Il numero vero: **49,79 %** complessivo — `index.html` 61,35 %, `bsi-ai-hub.js`
32,90 %, `bsi-spettri.js` 71,82 %. È copertura di **istruzioni**, non di rami, e
del percorso più ampio che un banco compie, non dell'intera batteria: entrambe
le cose sono dichiarate. Il valore è registrato e regge lo stesso patto del
debito di accessibilità — se scende, la batteria fallisce. Fra due esecuzioni
consecutive oscilla di 0,01 punti.

### Dichiarato meglio — D-07 ha ora un motivo verificabile

«Verifica su Chromium soltanto» restava vero ma vago. Nell'ambiente di verifica
il motivo si può controllare: la CDN da cui `playwright-core` scarica Firefox e
WebKit risponde **403** alla politica di rete. Non è una scelta, è un vincolo
dell'ambiente, e ora il documento lo dice così.

### Una regressione intercettata da un banco, non da me

Correggendo i due pulsanti «Anima meccanismo» ho lasciato due virgolette
sfuggite dove non servivano: `bsiAccentoLeggibile(col,\'#04121e\',4.5)` in un
punto che era già contesto di espressione, non di stringa. Risultato: *Invalid
or unexpected token*, e l'intera sezione Retrosintesi non disegnava più niente.

Non l'ho visto guardando il codice. L'ha detto `verifica-affermazioni`, che
misura le strategie di retrosintesi **nell'applicazione viva** e ha riportato
«dichiarato 46, misurato 0». È il motivo per cui quel banco esiste: un numero
che scende a zero è una funzione che non c'è più.

### Modificato

I banchi passano da 41 a **43**.

---

## [bsi-v171] — 2026-09-23

### Corretto — accessibilità: dagli 80 difetti di contrasto residui a **zero**

Gli ultimi ottanta sembravano rifinitura. Non lo erano: sotto ce n'erano
ancora tre cause strutturali.

- **Il «correttore automatico di contrasto» produceva difetti invece di
  toglierli.** Tre errori insieme:
  usava la **luminosità percepita** (`0.299R+0.587G+0.114B`) al posto della
  luminanza relativa WCAG, che è gamma-corretta, quindi le sue soglie — 115,
  140, 190, 150 — non corrispondevano a nessun rapporto di contrasto;
  **ignorava l'alfa**, così il distintivo con `background:rgba(255,180,84,.08)`
  su superficie scura gli sembrava «fondo chiaro» e ne scuriva il testo a
  `#16273e` con `!important`, **creando** un difetto a 1,21:1 sopra un sorgente
  che era già corretto (`#ffb454`);
  e guardava **solo gli elementi con uno sfondo proprio**, cioè mai il caso più
  comune, che è testo scuro il quale eredita il fondo scuro del pannello.
  Riscritto: risale agli antenati **componendo l'alfa** per ottenere il fondo
  effettivo, rinuncia (invece di indovinare) sopra immagini e gradienti, misura
  il rapporto WCAG vero e delega la correzione a `bsiAccentoLeggibile()`, che
  conserva la tinta e sceglie il verso guardando la superficie.
- **`--g900` vale `#0d1522`, lo stesso di `--bg`** — esattamente come `--g800`.
  È l'eredità di una scala di grigi nata per il tema **chiaro**, dove `--g900`
  era «il testo più scuro»; capovolto il tema, quel ruolo non esiste più. Le
  regole che lo usavano come colore del testo scrivevano testo del colore dello
  sfondo: `.rxn-fp button.on`, `.tb.on`, `.nav-btn.on` e altre, a **1,21:1**.
  Gli usi come colore del testo (30 regole) passano a `--testo-forte`; i 16 usi
  come **sfondo** restano dove sono.
- **Sfondo dai dati, testo fissato nel codice.** Distintivi e intestazioni
  prendevano la tinta dai dati e scrivevano `color:#fff`: funziona finché la
  tinta è scura, e smette appena qualcuno aggiunge `#e65100` (bianco sopra:
  3,79:1) o `#00897b` (4,32:1). Aggiunta `bsiEtichettaLeggibile()`, il duale di
  `bsiAccentoLeggibile()`: sceglie il testo guardando il fondo e, se nessuno dei
  due estremi basta, **scurisce il fondo conservando la tinta** — un'etichetta
  deve restare riconoscibile per colore.
- L'invariante è imposta **dove il colore viene scelto**, non nei dati: la
  funzione `section()` delle schede biomolecola, il generatore dei distintivi
  dei database, i colori per anno di corso, i chip dei gruppi funzionali. Così
  vale anche per le voci aggiunte domani.
- Tinte residue corrette dopo averne **verificata la superficie reale**:
  `controindicata` da `#ef4444` a `#ff5c5c` (4,00 → 4,98:1), la spontaneità di
  reazione da `#0d1522` (invisibile) a `#4ade80`, i pulsanti menta `#1fd39a`
  con testo `#06141f` anziché `#e9eef6` (1,66 → oltre 9:1).

Misurato col banco ufficiale sulle stesse 87 sezioni a ogni passo:
**80 → 27 → 26 → 10 → 4 → 0**. Riferimento in
`docs/evidence/accessibilita-riferimento.json` aggiornato a **0**: da qui in
avanti anche un solo difetto reintrodotto fa **fallire** la batteria.

Restano fuori dall'automatismo il testo dentro gli SVG e quello su fondo a
gradiente, che il banco **conta e riporta** a ogni esecuzione: `docs/09` D-09.

### Aggiunto — `audit_mobile`, il 41º banco: la pagina non deve scorrere in orizzontale

UI-03 dice «l'app deve funzionare a 390 px», e la matrice lo dava per verificato
da `audit_stabilita` — che in viewport telefono guarda però gli **errori
JavaScript**. Una pagina può non averne uno solo e uscire lo stesso dallo
schermo: il requisito era dichiarato coperto e non era misurato.

Misurandolo, una sezione su 87 faceva scorrere il documento: `squiz`, di **163
pixel**. Una griglia `1fr 1fr` con schede a contenuto non comprimibile — icona a
larghezza fissa, distintivo «N da ripassare» che non si restringe — portava il
documento a 553 px su 390. Corretta con `auto-fit` e `min-width:0` sui tre punti
che impedivano la compressione: rimettendo solo la griglia il difetto **non**
torna, servono tutti e tre.

Il banco misura `scrollWidth` del documento, non «un elemento più largo dello
schermo»: una tabella dentro un contenitore fatto per scorrere è corretta, e
segnalarla riempirebbe l'uscita di rumore finché nessuno la legge più. Conta
anche le sezioni percorse e fallisce se sono zero, perché un banco che non
misura nulla passa. Verificato reintroducendo il difetto: fallisce, e nomina la
sezione e i 163 pixel.

I banchi passano da 40 a **41**.

### Aggiunto — un badge sul contrasto, controllato come gli altri

Il README porta ora `contrasto WCAG AA — 0 difetti su 87 sezioni`. È
un'affermazione forte messa nel primo pixel della pagina, quindi
`verifica-affermazioni` la confronta con
`docs/evidence/accessibilita-riferimento.json`: se il debito risale, il badge
diventa falso e il banco lo dice. Verificato alterando di proposito il
riferimento.

Corretto anche l'ordine degli argomenti nei tre controlli sui badge: stampavano
«dichiarato» sul valore vero e «misurato» sul badge, cioè il contrario.

### Aggiunto — la documentazione inglese passa da 6 a 10 documenti su 16

La serie inglese si fermava a `docs/en/00-05`, e quei sei erano **derivati**: mai
più ricontrollati. Cercando i numeri per questa versione ne sono usciti due
fermi da tre rilasci — `docs/en/05` dichiarava «84 sections» mentre l'app ne ha
87, e si diceva descritto dalla versione `bsi-v146` mentre siamo alla 171.

- Tradotti **`07-SBOM`, `08-Traceability-Matrix`, `09-Release-Conformance-Statement`
  e `15-Test-Documentation`**: insieme ai sei già presenti coprono l'intero
  percorso che un revisore straniero segue in sede di due diligence — dossier,
  architettura, V&V, sicurezza, licenze, agente AI, distinta dei componenti,
  tracciabilità, dichiarazione di conformità e documentazione di prova.
- **L'SBOM inglese non è tradotto a mano: è generato.** `tools/genera-sbom.js`
  emette ora `docs/07-SBOM.md` e `docs/en/07-SBOM.md` dalla stessa sorgente, con
  impronte, dimensioni e licenze calcolate una volta sola. Una distinta dei
  componenti tradotta a mano diverge al primo aggiornamento di una libreria.
- **`tools/verifica-affermazioni.js` legge anche l'insieme inglese.** Un
  documento inglese che dichiara un numero diverso dall'italiano fa fallire il
  banco con la stessa severità di due documenti italiani in disaccordo —
  verificato reintroducendo di proposito una divergenza.
- **Anche `tools/verifica-documenti.js` guarda ora `docs/en/`**, che era
  escluso per nome: è per questo che la traduzione ha potuto restare indietro
  senza che niente lo dicesse. Estendendolo sono usciti subito tre difetti veri:
  un collegamento rotto nell'indice inglese (`00-Dossier.en.pdf`, file che non
  esiste: si chiama `00-Technical-Dossier.en.pdf`) e due versioni storiche
  citate in una forma che l'esenzione non riconosceva. L'esenzione per i
  riferimenti al passato accetta ora anche le formule inglesi e tollera il `> `
  di una citazione andata a capo, ma resta stretta: un'intestazione
  «Version described» rimasta indietro continua a far fallire il banco —
  verificato.

### Corretto — numeri dichiarati che non corrispondevano più alla misura

Tutti trovati confrontando con l'applicazione in esecuzione, non con il sorgente.

- **`docs/05` dichiarava «32 strumenti» mentre l'agente ne espone 35**, e tre —
  `analizza_molecola`, `disegna_molecola`, `mostra_spettri` — non comparivano
  nell'elenco. Corretti elenco e conteggio in italiano e in inglese, e aggiunta
  l'affermazione al banco: da qui in avanti il numero è **misurato** su
  `window.BSI_AI_TOOLS`.
- **La ricerca web era contata fra gli strumenti dell'applicazione.** Non lo è:
  `web_search` e `web_fetch` sono eseguiti **dal fornitore**, e solo su quelli
  che li offrono. Contarli insieme agli altri li faceva sembrare sempre
  disponibili. Ora sono distinti.
- **`docs/05` §3.1** dichiarava 143 farmaci e 39 strategie: sono 178 e 46.
- **`docs/08`** dichiarava 137 file tracciati dal banco di sicurezza: sono 235.
- **`docs/08` §7** scriveva nel testo «37 requisiti verificati su 42» mentre la
  tabella sopra diceva 39 su 44. Il banco controllava la tabella, non la prosa.

### Corretto — la copertura di SEC-02 era dichiarata in tre modi diversi

`docs/09` D-03 diceva «copertura al 50 %», `docs/15` §6 «2 requisiti su 4»,
`docs/08` §5 lo dava per coperto da banco. Eseguendo `verifica-sicurezza` si
vede che sono 9 controlli su 235 file, e che SEC-02 — «nessun dato personale
lascia il dispositivo» — è verificato **per interposta proprietà**: il banco
controlla che la variabile di telemetria sia vuota e che nessuno script venga da
un dominio esterno, cioè i due meccanismi attraverso cui un dato potrebbe
uscire. È evidenza automatica ma indiretta, e ora i tre documenti lo dicono allo
stesso modo. La verifica diretta richiederebbe l'osservazione del traffico
durante un uso reale, ed è dichiarata come tale.

### Aggiunto — i pacchetti di consegna portano anche la documentazione inglese

`consegna/AZIENDA/` e `consegna/COMPLETO/` includono ora una cartella `en/` con
la traduzione dei documenti che il pacchetto contiene **davvero** — allegare la
versione inglese di un documento assente rimetterebbe dentro l'incoerenza appena
tolta — e i corrispondenti `pdf/*.en.pdf`, più
`BioSpecInfo-Full-Dossier.en.pdf`. Il pacchetto aziendale passa da 40 a 60 file.

### Corretto — la riscrittura dei riferimenti sbagliava nelle sottocartelle

I valori della mappa dei pacchetti sono percorsi relativi alla **radice** del
pacchetto, ma un collegamento Markdown si risolve rispetto alla cartella del
file che lo contiene. Finché ogni documento stava nella radice le due cose
coincidevano; con `en/` non più, e `[LICENSE](LICENSE)` dentro `en/07-SBOM.md`
puntava a `en/LICENSE`. Sono usciti **24 collegamenti rotti** alla prima
costruzione — trovati dal controllo che era stato scritto proprio per questo, e
che ha fatto fallire la generazione invece di consegnare un pacchetto rotto.
Ora sono **192 collegamenti verificati, nessuno rotto**.

### Corretto — la tabella delle difformità era spezzata a metà

In `docs/09` §4 il riquadro su D-05 stava **fra due righe della tabella**: in
Markdown questo chiude la tabella, e D-06, D-07 e D-08 venivano impaginate come
una seconda tabella senza intestazione. Righe riunite e riordinate, riquadro
spostato dopo.

---

## [bsi-v170] — 2026-09-21

### Corretto — accessibilità: da 276 difetti a 80, campi senza etichetta a zero

Le cause peggiori non erano colori sbagliati ma **token del tema che
valevano lo stesso dello sfondo**.

- **Ogni link senza colore proprio era invisibile.** `--g800` vale
  `#0d1522`, **identico a `--bg`**, e la regola `a { color: var(--g800) }`
  lo applicava a tutti i collegamenti: contrasto **1:1**, misurato nel DOM.
  Stessa storia per `--g700` (`#16263d`), quasi identico a `--white`: 1,01:1.
  Introdotto `--testo-forte`, applicato ai **soli** usi come colore del
  testo — come sfondo e bordo quei token restano dove servono.
- **Pulsanti che cambiavano sfondo senza cambiare il testo.** Lo stato
  selezionato (o quello deselezionato, secondo il pannello) diventava
  illeggibile: **1,39:1**. Tre punti corretti; sfondo e colore ora si
  decidono insieme.
- **`lightenColor(hex,pct){ return hex; }`** — una funzione chiamata
  «schiarisci» che restituiva il colore **invariato**. Uno stub mai finito,
  con ogni probabilità nato proprio per questo problema. Ora fa quello che
  il nome dice.
- **Il pannello di risposta del quiz aveva fondo chiaro e testo chiaro**:
  lo studente non poteva leggere la risposta corretta né il suggerimento.
- **Tabella dei campi cristallini**: tre righe su quattro hanno fondo
  chiaro, ma il testo era sempre chiaro. Il colore ora segue lo sfondo
  della riga.
- **40 campi privi di etichetta → 0.** Le etichette esistevano già come
  testo visibile accanto al campo, solo non erano associate. Dove c'era un
  `<label>` gli è stato dato il `for` (così resta cliccabile), altrove un
  `aria-label` che **contiene il testo visibile** — WCAG 2.5.3 chiede che
  il nome accessibile includa ciò che si legge, altrimenti il comando
  vocale non trova il campo.

### Aggiunto — `tools/verifica-affermazioni.js`

Confronta ogni numero dichiarato nei documenti con quello **misurato
nell'applicazione in esecuzione**: sezioni, farmaci, malattie, tumori,
strategie, moduli, più i badge del README.

I numeri del dossier — «63 malattie (23 tumori)», «46 strategie», «25
moduli» — sono la prima cosa che legge chi valuta, e nessuno li
controllava. Sono risultati **tutti esatti**, ma:

- `chimorga.html` dichiarava «25 moduli» in cima e **«17 moduli»** più
  sotto: due affermazioni sullo stesso oggetto, nello stesso file;
- `sr_completo.html` diceva «98 esercizi» e **«87 esercizi»**. Ora il
  totale si **conta** invece di essere ricordato;
- i **badge del README** — la prima cosa che si vede su GitHub — erano
  fermi a `bsi-v165` e «34 banchi» con versione 169 e 40 banchi.

> **Una lezione pagata.** Avevo già concluso che «63 malattie» fosse falso:
> nel sorgente avevo trovato un array `DISEASES` con 12 voci e stavo per
> «correggere» il documento. Misurando nel DOM il menu ne elenca davvero
> 63 — l'array era un altro, più piccolo. **Un conteggio sul sorgente non è
> una misura: è un indizio.**


## [bsi-v168] — 2026-09-20

### Aggiunto
- **Sezione Cromatografia** (85ª sezione). Cromatogramma **calcolato** dai
  parametri — le gaussiane hanno σ = t<sub>R</sub>/√N e la risoluzione mostrata
  è quella che si misurerebbe su quei picchi — in doppia vista (corsa intera e
  vista espansa della coppia, come su uno strumento). Curva di **van Deemter**
  con i tre termini separati e minimo in forma chiusa (u = √(B/C),
  H<sub>min</sub> = A + 2√(BC)). Calcolatore dell'**indice di Kováts**, che
  rifiuta i tempi minori del tempo morto e distingue interpolazione da
  estrapolazione. Tabella delle grandezze, confronto GC/HPLC, guida ai
  rivelatori, diagnostica dei difetti di forma dei picchi.
- **Sezione Taratura e incertezza** (86ª sezione). Regressione ordinaria ai
  minimi quadrati con pendenza e intercetta corredate dalla loro deviazione
  standard; banda di confidenza al 95 % e **grafico dei residui**;
  concentrazione dell'incognito con intervallo di confidenza completo;
  **LOD e LOQ** secondo ICH Q2(R1); propagazione dell'incertezza che indica
  quale contributo domina; regole delle cifre significative.
  Due diagnostiche che l'r² non dà: **test F** retta contro parabola per la
  non linearità, e **residuo cancellato** per i punti anomali — il criterio
  ingenuo a 3 s<sub>y/x</sub> era già scritto, e non segnalava l'esempio che
  doveva dimostrarlo (residuo 0,0747 contro soglia 0,1337): il punto anomalo
  entra nel calcolo di s<sub>y/x</sub>, lo gonfia e si nasconde da solo.
- **`tools/genera-pdf.js`** — i documenti diventano PDF impaginati, con
  versione e commit in ogni piè di pagina. Genera anche il **dossier unico**
  (italiano e inglese) e **cancella** i PDF che non rigenera.
- **`tools/genera-pacchetti.js`** — i tre pacchetti di consegna (AZIENDA,
  TESI, COMPLETO), ciascuno con copertina, percorso di lettura, evidenza,
  strumenti e PDF.
- **`package.json`**, che mancava: `npm install` non installava nulla, e la
  procedura di riproduzione documentata non funzionava per chi la seguiva.
- Nuovi controlli in `verifica-documenti.js`: identificativi di requisito non
  duplicati e totali di copertura pari agli identificativi realmente definiti.
- `docs/08` §8: le **lacune di copertura** dichiarate per nome (nessuna
  copertura di codice, solo Chromium, nessuna regressione visiva, 6 strutture
  non verificate, prestazioni su hardware lento).

### Corretto
- **32 dei 39 banchi di prova non erano nel repository.** Vivevano solo
  nell'area di lavoro della sessione in cui erano stati scritti, e la cartella
  predefinita di `genera-evidenza.js` puntava lì. La frase su cui poggia tutto
  il resto del lavoro — «chiunque può rieseguirli» — era quindi falsa: un
  terzo che clonava il repository ne trovava sette su trentanove, senza alcun
  messaggio che glielo dicesse. Ora stanno in **`tools/banchi/`**, versionati.
- **Un banco assente non faceva fallire la batteria.** Veniva contato e
  stampato, ma l'esito complessivo guardava solo i falliti: una batteria in
  cui mancavano *tutti* i banchi avrebbe stampato «CONFORME» con zero
  fallimenti. È la forma più pura del difetto che questo lavoro cerca di
  evitare — un controllo che non misura nulla passa — applicata non a un
  singolo banco ma all'apparato che li governa.
- **La verifica di accessibilità ispezionava una sezione su 87.** Salta
  giustamente gli elementi non visibili, ma `index.html` ne mostra una alla
  volta: su 19 751 elementi di testo ne stava guardando **41**, e riportava
  «0 difetti». Ora percorre tutte le sezioni e **stampa quante ne ha
  percorse** — il primo tentativo ne percorreva zero (il clic di Playwright
  aspetta la visibilità, e i pulsanti stanno in gruppi richiusi) e il
  controllo l'ha detto invece di stampare un altro zero rassicurante.
- **1 069 difetti di contrasto emersi, 793 corretti, 276 registrati** (−74 %).
  Non ritoccando i colori uno per uno, ma risalendo alle cause comuni:
  - **159** — una rete di sicurezza del tema scuro, iniettata a runtime, con
    specificità sufficiente a scavalcare il colore dei componenti: il testo
    pensato per le schede **bianche** finiva a `#d4dce6`, contrasto **1,38:1**.
    Riscritta con `:where()` (specificità zero).
  - **~400** — l'accento per categoria usato come *testo* sull'intestazione
    scura, col ripiego `#0d1522` (quasi nero): **1,13:1**. Introdotta
    `bsiAccentoLeggibile()`, che conserva la tinta e alza la luminosità quanto
    basta, applicata nei **14 punti in cui l'accento viene scelto** — non nei
    dati, così vale anche per le voci aggiunte in futuro.
  - **139** — due tinte sotto soglia per poco, sostituite **dopo aver
    verificato** che non comparissero mai su fondo chiaro.
  - **57** — una zebratura di tabella bianco/scurissimo con testo sempre
    chiaro: le righe bianche erano illeggibili.
  - **43** — celle della tavola periodica appena sotto soglia.
  - **8 punti** con `"#var(--text)"`: un `#` di troppo rende il colore
    invalido. In SVG ripiega sul nero, in canvas l'assegnazione viene
    **ignorata** e il disegno continua col colore precedente.

  **Il verso della correzione dipende dalla superficie, non dal colore.** Il
  primo tentativo schiariva sempre: trenta difetti tolti sull'intestazione
  scura, diciotto messi sul riquadro chiaro che usa lo stesso accento. La
  funzione ora scurisce sui fondi chiari e schiarisce su quelli scuri.

  I 276 restanti sono una coda dispersa su 68 cause, la maggiore da 24
  difetti; sono **registrati** e il banco fallisce se crescono.
- **L'aggiornamento automatico non sarebbe più scattato su nessun dispositivo.**
  `_bsiPaginaOccupata()` considera «lavoro aperto» qualunque area di testo con
  più di 20 caratteri; la nuova sezione Taratura ne porta una **già piena** di
  dati d'esempio. Di conseguenza la pagina risultava sempre occupata e ogni
  versione nuova avrebbe chiesto il permesso invece di applicarsi — per sempre.
  Ora conta solo il testo che l'utente ha davvero cambiato (`value !==
  defaultValue`). È una regressione introdotta in questa stessa versione e
  intercettata da `test_sw` §4A: a occhio non si sarebbe notata, perché la
  barra funziona benissimo — fa solo la cosa sbagliata.
- **L'agente non sapeva aprire Simmetria e Cromatografia.** L'elenco delle
  sezioni navigabili era una copia scritta a mano, ferma a 84 voci mentre
  l'app ne aveva 87; la documentazione dichiarava che le raggiungeva tutte.
  Ora l'elenco si sincronizza con i pulsanti realmente presenti nella pagina.
- **`SCI-10` era definito due volte** nella matrice di tracciabilità: una come
  requisito verificato al 100 %, una come requisito dichiarato *non* verificato.
  Il secondo è ora `SCI-11`.
- **La tabella di copertura sommava 36 requisiti** dichiarandone 9 scientifici
  quando nel documento ne erano definiti 10. I totali reali sono 37
  automatizzati su 42 dichiarati — l'88 %, non il 100 %.
- **50 collegamenti rotti su 127** nei pacchetti di consegna alla prima
  generazione: un documento estratto porta con sé i riferimenti alla posizione
  che aveva nel repository. Ora vengono riscritti, e ciò che non è nel
  pacchetto rimanda al repository pubblico.
- **`docs/README.md` veniva cancellato** dal `README.md` della radice nel
  pacchetto COMPLETO, in silenzio, per omonimia.
- **15 PDF obsoleti** in `docs/pdf/`: fermi ai documenti 00-05 e a una versione
  di mesi prima. Un allegato vecchio afferma cose false con l'aria di essere
  autorevole.
- I PDF delle traduzioni inglesi puntavano a nomi di file non più esistenti.

---

## [bsi-v165] — 2026-09-20

### Aggiunto
- **Strumenti di verifica nel repository** (`tools/`), eseguibili da terzi:
  - `genera-evidenza.js` — esegue tutta la batteria e ne trascrive l'uscita
    integrale, con ambiente, commit e impronte SHA-256
  - `genera-sbom.js` — distinta dei componenti dai file reali, in Markdown e
    CycloneDX 1.5
  - `verifica-farmaci.js` — confronto struttura ⟷ peso molecolare, spostato
    dall'area di lavoro al repository perché un revisore possa rieseguirlo
- **Registro delle deviazioni** (`docs/evidence/deviazioni-note.json`): le voci
  prive di struttura devono essere registrate con il motivo, altrimenti la
  verifica fallisce
- Documenti 07–15: SBOM, tracciabilità, conformità di rilascio, riferimento
  delle interfacce, modello dei dati, guida al deploy, specifiche funzionali,
  manuale utente, documentazione dei test
- Verificate e aggiunte le strutture di vancomicina, rifampicina, venetoclax

### Modificato
- Il controllo dei farmaci distingue ora **difetti** (struttura che contraddice
  il proprio peso) da **deviazioni dichiarate** (struttura assente e registrata)

### Corretto
- La SBOM dichiarava licenza MIT per l'**applicazione**, che è invece
  proprietaria. In un documento consegnato a un cliente avrebbe comunicato
  diritti d'uso inesistenti.
- Digossina e semaglutide, le cui strutture non superavano la verifica, sono
  rimaste senza struttura anziché con una non verificata

---

## [bsi-v164] — 2026-09-20

### Aggiunto
- **42 farmaci**, ognuno con struttura verificata: losartan, atenololo,
  carvedilolo, diltiazem, verapamil, clopidogrel, rivaroxaban,
  idroclorotiazide, quetiapina, olanzapina, risperidone, venlafaxina,
  duloxetina, bupropione, paroxetina, amitriptilina, lamotrigina,
  levetiracetam, topiramato, fenitoina, clonazepam, midazolam, zolpidem,
  rivastigmina, lansoprazolo, ondansetron, loratadina, cetirizina, budesonide,
  doxiciclina, claritromicina, doxorubicina, ciclofosfamide, 5-fluorouracile,
  gemcitabina, etoposide, anastrozolo, bicalutamide, sildenafil, finasteride,
  ossicodone, prednisone
- Guida al proxy **dentro l'applicazione**, con i comandi pronti da copiare

### Corretto
- **89 errori nelle strutture molecolari** su 143 voci. I pesi molecolari erano
  corretti; le strutture no: la ketamina era un pirrolidinone non correlato, la
  morfina non era morfina (in due voci), il lorazepam era privo dell'ossidrile
  che lo definisce, l'atorvastatina del gruppo anilidico, il testosterone del
  doppio legame Δ⁴
- 7 farmaci duplicati in categorie diverse
- Il sofosbuvir conteneva citosina invece di uracile: è un analogo dell'uridina

---

## [bsi-v163] — 2026-09-20

### Corretto
- **Altezze casuali nel predittore NMR.** I picchi erano disegnati con
  `0.55 + Math.random()*0.38`: in uno spettro ¹H l'altezza *è* l'informazione
  quantitativa, e inventarla è peggio che ometterla
- Le predizioni NMR sono **intervalli** (`"6,5–8,5 ppm"`) e veniva usato solo il
  primo numero: ora si disegna la fascia con un segno sul valore tipico
- Rumore casuale rimosso anche da `makeNMRsvg`
- Aggiunto il riferimento TMS a 0 ppm; rimosso un residuo di lavorazione («v20»)
  stampato in un angolo dello spettro

### Verificato
- Convenzioni degli assi misurate su tutti e cinque i grafici (IR in due
  versioni, NMR, UV-Vis, MS): nessuno era invertito

---

## [bsi-v162] — 2026-09-20

### Aggiunto
- **`bsi-spettri.js`** — motore di predizione spettrale che riconosce i gruppi
  funzionali con SMARTS sul grafo molecolare via RDKit
- Voce **Aggiornamenti** nel pannello ✨

### Corretto
- I gruppi funzionali erano riconosciuti con espressioni regolari sulla stringa
  SMILES, dentro catene `else if`: passava **un solo gruppo per molecola**.
  L'aspirina — estere *e* acido — usciva senza l'O–H allargato, senza il C=O
  acido a 1690 cm⁻¹ e senza il protone del COOH a 11,6 ppm
- Gli spettri IR erano disegnati in assorbanza verso l'alto anziché in
  trasmittanza verso il basso
- Rumore casuale rimosso dalle tracce IR
- Coniugazione applicata al **singolo** carbonile
- La finestra degli aggiornamenti esisteva ma il suo unico pulsante era in un
  contenitore nascosto: nessun modo di aprirla
- `BSI_APP_VERSION` era ferma a `v140-2026-06` mentre il Service Worker era alla
  v161
- I fornitori AI irraggiungibili ora finiscono in un gruppo separato in fondo
  all'elenco, non più solo marcati con un ⚠

---

## [bsi-v161] — 2026-09-10

### Corretto
- **File Manager**: `db.transaction` su un database non ancora aperto. In Safari
  in navigazione privata il database non si apre mai e l'errore era definitivo
- Scritture che fallivano in silenzio: «✅ Nota salvata!» veniva mostrato senza
  sapere se il salvataggio fosse riuscito
- **Spectra**: due `Invio` ravvicinati facevano partire due turni sovrapposti,
  producendo una cronologia `user,user,assistant,assistant` che Claude rifiuta
- Il Service Worker ricaricava d'ufficio le schede aperte, distruggendo il
  lavoro in corso: ora avvisa e decide la pagina
- Rete degradata trattata come rete assente: attesa limitata a 3,5 s quando una
  copia in cache è disponibile
- Un visore 3D costruito per ogni molecola: da 7 costruzioni a 1 su 10 molecole

---

## [bsi-v160] — 2026-09-10

### Corretto
- Il pannello di prova consigliava Gemini 3 Pro come «utilizzabile subito»
  senza segnalare che è a consumo
- Un'attesa imposta di 37 s con un fornitore alternativo disponibile: ora oltre
  i 10 s si cambia fornitore

---

## [bsi-v159] e precedenti — 2026-09

Lavoro sull'agente **Spectra** e sulla resilienza ai guasti dei fornitori
esterni:

- Memoria dei fornitori irraggiungibili (`bsi_prov_ko`, 24 ore)
- Lista nera dei modelli ritirati, appresa dai messaggi d'errore (7 giorni)
- Tetto di token appreso dall'errore anziché codificato
- Firme di ragionamento (Anthropic e Gemini) catturate e restituite
- Nuovi tentativi sui guasti temporanei (429, 5xx)
- Doppia finestra di timeout: primo byte e byte successivi
- Audit grafico: 13 canvas sfocati su schermi ad alta densità
- Rimozione di NVIDIA dalla scelta diretta (non raggiungibile dal browser)

---

## Versioni storiche

Il progetto ha una storia più lunga di quella riportata qui, ricostruibile dai
commit e dalle pull request del repository. Alcune tappe:

| Riferimento | Contenuto |
|---|---|
| `#114`–`#118` | Documentazione tecnica per aziende, versione inglese, PDF, licenza proprietaria |
| `#100`–`#113` | Centro Spettri: editor, ADMET, similarità, alert strutturali, evidenziazione dei gruppi |
| `#89`–`#99` | Potenziamento delle sezioni: catalogo di 296 reazioni animate, laboratorio quantistico, astrochimica, data science |

---

## Come si numerano le versioni

La versione è quella della cache del Service Worker (`bsi-vNNN`), incrementata a
ogni pubblicazione. Non segue il versionamento semantico: non esiste un'API
pubblica di cui garantire la compatibilità, e ogni pubblicazione è una
distribuzione completa dell'applicazione.

`CACHE` in `sw.js` e `BSI_APP_VERSION` in `index.html` **devono sempre
coincidere** — sono due righe che vanno cambiate insieme.
