# Documentazione dei test — BioSpecInfo

| Campo | Valore |
|-------|--------|
| **Software** | BioSpecInfo |
| **Versione descritta** | `bsi-v250` |
| **Scopo** | Descrivere come sono organizzati i test, come eseguirli, che cosa coprono e dove restano scoperti. |

---

## 1. Tipologie presenti

| Tipo | Presente | Note |
|---|:---:|---|
| **End-to-end (E2E)** | ✅ | Playwright su Chromium headless contro un server HTTP locale. È la forma prevalente. |
| **Verifica dei dati** | ✅ | Confronto dei dati scientifici con una fonte indipendente |
| **Prove di stabilità** | ✅ | Sessioni lunghe, memoria esaurita, rete degradata |
| **Coerenza documentazione/codice** | ✅ | Verifica che ciò che la documentazione promette esista davvero |
| **Unit test isolati** | ❌ | Vedi §6 |
| **Copertura di codice strumentata** | ✅ | `audit_copertura`, con il profilatore di Chromium: nessuna build, nessun sorgente riscritto. Vedi §6 |

### Perché E2E e non unit test

L'applicazione è composta da script classici che operano direttamente sul DOM,
senza moduli né iniezione delle dipendenze: non esistono unità isolabili senza
una riscrittura profonda. I difetti che si sono effettivamente verificati —
un canvas sfocato, un pulsante irraggiungibile perché il contenitore è nascosto,
un fornitore AI che smette di rispondere — **non sarebbero comunque emersi** da
un test unitario: vivono nell'integrazione fra codice, DOM e browser.

La scelta è quindi motivata, non subita. Ne restano i limiti, dichiarati al §6.

---

## 2. Come eseguire i test

### Requisiti

```bash
npm install                      # solo playwright-core
python3 -m http.server 8899 &    # RDKit WASM richiede contesto HTTP
```

> Senza server i test falliscono tutti: aprire i file con `file://` impedisce il
> caricamento dei moduli WebAssembly.

### Tutta la batteria, con rapporto

```bash
node tools/genera-evidenza.js
```

Esegue ogni banco, ne trascrive l'uscita integrale e produce
`docs/evidence/RAPPORTO-VERIFICA.md` con ambiente, commit e impronte SHA-256.
Esce con codice `0` solo se nessun banco fallisce.

```bash
node tools/genera-evidenza.js --veloce   # salta i banchi con browser
```

L'opzione `--veloce` è utile per un controllo rapido ma **non è sufficiente per
un'attestazione**: i banchi saltati sono proprio quelli che misurano il
comportamento reale.

### Un singolo banco

```bash
node tools/verifica-farmaci.js           # strumento a sé stante
node tools/verifica-farmaci.js --json    # uscita leggibile da programma

cd tools/banchi && node test_spettri.js  # un banco E2E
```

I banchi E2E stanno in **`tools/banchi/`**, versionati come il resto del
repository; la variabile `BSI_BANCHI` permette di indicare un'altra cartella.

> **Non è sempre stato così, ed è bene dirlo.** Fino alla versione `bsi-v168`
> la cartella predefinita era l'area di lavoro della sessione in cui i banchi
> erano stati scritti: **32 dei 39 banchi non erano nel repository**. Chi
> clonava e lanciava il comando documentato ne trovava sette, e non riceveva
> alcun avviso — perché un banco assente veniva contato ma non faceva fallire
> la batteria, che chiudeva con «CONFORME» e zero fallimenti.
>
> Entrambe le cose sono state corrette: i banchi sono versionati, e **un banco
> assente rende l'esito NON CONFORME**. Un banco che non c'è non è un banco
> superato.

---

## 3. Composizione della batteria

**90 banchi**, raggruppati per ciò che dimostrano.

### 3.1 Dati scientifici

| Banco | Verifica | Controlli |
|---|---|---:|
| `audit_farmaci` | Struttura ⟷ peso, duplicati, e la **formula ricostruita dal grafo** contro quella dichiarata da ChEMBL per ogni voce con provenienza | 263 voci, 36 con fonte |
| `test_spettri` | Riconoscimento dei gruppi funzionali su molecole di riferimento | 36 |
| `test_spettri_ui` | Innesto del motore nei punti dell'app che disegnano spettri | 16 |
| `test_assi` | Convenzioni degli assi negli spettri SVG | 13 |
| `test_assi_canvas` | Convenzioni degli assi negli spettri su canvas | 6 |
| `test_costanti` | Ricerca delle costanti fisiche e rifiuto delle ambiguità | 45 |
| `audit_dati` | Coerenza dei dati tabulati | 29 |
| `test_farm_ui` | Che l'Atlante Farmaci **disegni** ogni farmaco che ha in memoria, categoria per categoria, e che una categoria **mai etichettata** compaia comunque | 11 |
| `test_astro` | I dati di astrochimica: peso molecolare ⟷ formula delle 30 molecole interstellari contro i pesi atomici IUPAC, nessun corpo celeste ripetuto, ogni domanda del quiz con una risposta valida fra le sue opzioni | 13 |
| `test_datasci` | La matematica che la sezione Data Science **mostra**: R² su una relazione esatta, pesi standardizzati nel rapporto vero, ROC su valori calcolabili a mano, il comportamento su rumore puro, e che **nessuna sezione resti irraggiungibile** | 23 |
| `test_simmetria` | Gruppi puntuali, modi normali, regole di selezione IR/Raman | 26 |
| `test_cheminfo` | Il motore di chemioinformatica: Tanimoto e Dice su valori calcolabili a mano, impronte di Morgan e MACCS, raggruppamento di Butina, scheletri di Bemis–Murcko, PCA, regressione kernel, divisione per scheletro, **modello nullo per rimescolamento delle etichette**, validazione incrociata raggruppata, esportazioni CSV e SDF, **contrasto dei nove pannelli**, accordo fra laboratorio e motore, frammentazione, **coppie corrispondenti su effetti noti**, ricerca per sottostruttura, tabella SAR, confronto fra modelli nei due versi, arricchimento (EF e BEDROC) su casi calcolabili a mano, intervalli conformi e il loro **rifiuto sulla classificazione** | 189 |
| `test_spettrolettore` | Il lettore di spettri e i modelli che ne seguono: ASDF simbolo per simbolo, JCAMP esplicito e compresso in DIF/DUP, picchi per prominenza su spettri **costruiti** e **su rumore puro**, curva contro lista di picchi, perdite neutre sul toluene, ESOL contro quattro valori sperimentali, quattro filtri di drug-likeness separati, foresta casuale nei due versi, **una sola porta d'ingresso** (un bottone, `accept` vuoto, instradamento provato su PDF/`.docx`/`.txt`/`.jdx`/`.csv`/binario travestito/immagine) e il distintivo di versione confrontato con `BSI_APP_VERSION`. **E la relazione fra le due tabelle IR**: `SPEC_DATA.ir` serve a studiare, `BANDE_IR` ad assegnare, non sono un doppione — ma l'ombrello delle assegnazioni deve **coprire** il riferimento per ognuno dei 23 gruppi presenti in entrambe, e non essere arbitrariamente più largo (margine ricavato dai dati, non inventato) | 66 |
| `test_nmr` | La predizione NMR assegnata per atomo: due insiemi separati di molecole (taratura e **validazione**, quest'ultima mai usata per scegliere i parametri), il conteggio dei segnali su molecole di cui si sa quanti ne danno, i rifiuti su uno SMILES illeggibile e su una stringa vuota, la **cronologia** con il riconoscimento dei doppioni per chiave InChI, e la sincronia **picco ↔ struttura ↔ 3D** verificata sugli indici, non sul numero di atomi illuminati | 64 |
| `test_nmr2d` | Le mappe di correlazione contate sul grafo: HSQC con il segno invertito sui CH₂, COSY fra protoni non equivalenti, HMBC a due e tre legami. **Nei due versi**: l'esafluorobenzene non dà macchie HSQC, il benzene **nessuna** macchia COSY fuori diagonale, il metano **nessuna** macchia HMBC pur avendo quattro protoni | 40 |
| `test_digitalizza` | Uno spettro estratto da una **figura**, su sette immagini costruite di cui si conoscono i centri delle gaussiane al cm⁻¹: figura nuda, con cornice ed etichette, con griglia grigia, con griglia nera, con cornice **e** griglia, tratteggiata, in %T. Scarto **medio 2,2 cm⁻¹**, **peggiore 7,3** — una colonna vale ~4 cm⁻¹, che è il limite della figura e non del metodo. **Nei due versi**: da un foglio bianco e dall'icona dell'applicazione non esce **nessuna** curva; il ripiego grezzo sulla stessa figura con la cornice trova **un** picco invece di tre; su asse logaritmico il punto di mezzo è la media geometrica e su asse lineare quella aritmetica. Conversione %T→A sui valori esatti (50 %T → A = 0,301) e **giro completo** del JCAMP esportato, riletto dal lettore stesso | 45 |
| `test_fisica` | Le otto sezioni di **fisica** contro i numeri della letteratura: Schrödinger (oscillatore armonico, pozzo infinito, Morse esatto, norma di Crank-Nicolson), **Hartree-Fock STO-3G** (H₂ e HeH⁺ di Szabo-Ostlund, H₂O di Crawford a 10⁻⁶ Eh), rotovibrazionale (rₑ di HCl, B dalle differenze di combinazione, J dispari del Raman di O₂), entropie standard **NIST-JANAF** di otto gas, dinamica molecolare (energia conservata, picco di g(r)), Hückel, FFT, Runge-Kutta, Arrhenius, gli angoli 2θ di NaCl/Si/Cu/Fe con le estinzioni, Bateman (⁹⁹ᵐTc), ¹⁴C, Weizsäcker; poi nel browser ogni sezione e ogni scheda su due viewport, niente che sborda a 390 px, la simulazione ferma a sezione chiusa, i pulsanti tradotti. **92 controlli**, minimo dichiarato 90 | 92 |
| `test_matematica` | Le otto sezioni di **matematica** e il **motore simbolico** contro valori indipendenti: semplificazioni, derivate di tavola e una derivata complicata controllata con le differenze finite, primitive verificate (per parti, per sostituzione) e la gaussiana che **non** deve averne una, ∫e^(−x²) = √π, serie di Taylor (1/120, 17/315), limiti notevoli e destro/sinistro; cifre significative, pH, acido acetico dalla formula risolutiva, eˣ = 3 − x contro la W di Lambert; studio di funzione; **inversa intera della matrice di Hilbert** e det 1/2160, un det 4×4 rifatto a parte, autovalori 2 ± √2, **reazioni bilanciate** (permanganato, redox con cariche, Wöhler); l'ordine di Eulero, Heun e RK4 misurato; equilibri di Lotka-Volterra e del Bruxellatore; punti critici e relazione di Maxwell; e^(iπ) = −1, Gibbs, Parseval; t, F e Grubbs delle tabelle, **la retta di taratura di Miller & Miller**, propagazione contro Monte Carlo. Poi ogni sezione e scheda nel browser su due viewport, un'interazione vera e le traduzioni |
| `test_esami` | I **risolutori d'esame** di Chimica (40 modelli su quattro livelli), Matematica (Istituzioni I e II più il livello avanzato) e Fisica (Generale I e II più fisica moderna) e le sezioni di chimica fisica nuove: domini, limiti, fratti semplici, impropri, serie, estremi vincolati, integrali doppi, forme differenziali, EDO con Cauchy confrontati con SymPy o il calcolo a mano; i 48 modelli di fisica contro formule indipendenti; Tafel, Eyring, BET, Langmuir, Mn/Mw, rese quantiche; ogni esercizio degli appelli e delle prove svolte deve produrre uno svolgimento. Nel browser le quattro sezioni, un appello aperto, il risolutore che rifà i conti, le traduzioni |
| `test_assistente` | L'**assistente delle tre macro-aree**: su 80 domande in linguaggio naturale, il tipo di esercizio o il modello capito, i dati letti con le unità (M e m, μC, km/h, masse solari, percentuali), il risultato confrontato con SymPy o con una formula indipendente; il problema inverso; le aggiunte al motore simbolico verificate derivando; nel browser le tre aree, una domanda scritta nella casella, catalogo, ricerca, livelli, gli strumenti di Spectra, 390 px e inglese |
| `test_grafica3d` | **Ciò che si vede è giusto**: orbitali (nodi, ⟨r⟩ esatto sulla nuvola campionata, frazione dei lobi), Keplero e Lorenz, cristalli (contenuto, impacchettamento, piani di Miller, picco di NaCl), campi (Gauss, spira); nel browser il Laboratorio 3D su due schermi, i gesti, le animazioni dei grafici che finiscono identiche al disegno diretto, il mirino, «riduci movimento», i visori 3Dmol con barra e qualità |
| `test_laboratori` | **Le simulazioni ritrovano la risposta esatta**: proiettile nel vuoto, urti, pendolo con l'integrale ellittico, modi normali, lenti, reticolo, transitori RLC (Kirchhoff), filtri, cicli (ΔU = ΔS = 0, rendimenti), gas di dischi (Maxwell-Boltzmann, viriale), ordini dei metodi numerici, Runge, coniche, rette sghembe, equilibrio cinetico e Le Chatelier nei due versi; nel browser le 22 schede su due schermi e una perturbazione nella pagina |
| `test_scienze` | **Astrofisica, relatività, fluidi, calcolo vettoriale, cinetica complessa** contro valori noti (età dell'universo, Planck = σT⁴, Hohmann, transiti, gemelli, Poiseuille, Green, vortice, Brusselator) e il **motore delle animazioni**: pausa, velocità, arresto fuori schermo, «riduci movimento», su tre configurazioni del browser |
| `test_esplorazioni` | **Probabilità, matematica visiva, elettromagnetismo, suono, semiconduttori, distillazione, voltammetria** contro risultati noti (Bayes, limite centrale, Fourier, mappa logistica, dipolo, n_i, V_bi, Antoine, azeotropo, Fenske, Randles-Ševčík, Nicholson); nel browser le 24 schede su due schermi, il disegno a mano ricostruito dagli epicicli, le cariche trascinate |
| `test_approfondimenti` | **Numeri, grafi, gravitazione, calore, Ising, diagrammi di fase, superficie LEPS** contro risultati noti o un secondo metodo (π(x), RSA, Li(x), Floyd–Warshall, Prim, figura a otto, Lagrange, Onsager, IAPWS, Span–Wagner, eutettico misurato, sella di H₃); nel browser le 25 schede su due schermi; i **pulsanti delle materie** (gruppi visibili, icone, materia ricordata, nessuna sezione irraggiungibile) |
| `test_pareggio` | Le **dodici sezioni** che portano matematica e fisica al livello della chimica: esegue i dodici script di `verifiche/` (462 controlli contro risultati noti o un secondo metodo), apre le 47 schede su due schermi, controlla che ogni scheda si apra in meno di 100 ms e che matematica e fisica abbiano il numero di sezioni dichiarato |
| `test_v237` | Le **venti sezioni nuove** (dieci di astrofisica, cinque laboratori di fisica, cinque di matematica): esegue i loro venti script di `verifiche/` (705 controlli contro valori pubblicati o un secondo metodo, §3.1-bis) e quelli dei kit di studio e delle risorse; nel browser apre ogni scheda a **1280 e 390 px**; prova il volto, le emozioni e la mente di Spectra e i nomi delle sezioni in inglese. Pretende almeno 900 controlli | 1061 |
| `test_3d238` | Le **schede 3D nuove di 29 sezioni** di chimica, fisica e matematica: esegue i loro 29 script di `verifiche/` (311 controlli contro valori noti, una forma chiusa o un secondo metodo, §3.1-ter); nel browser apre ogni scheda delle 29 sezioni a **1280 e 390 px** e pretende schede piene, senza ⚠, tele disegnate e con un nome, l'ultima scheda una scena 3D che disegna, lavoro sincrono al clic sotto i **250 ms**; a 390 px niente sborda; nessun errore JavaScript | 488 |
| `test_potenzia250` | Le **quattro sezioni della v250**: Saha contro i manuali (metà ionizzazione, massimo di Balmer, Ca II nel Sole); la nube interstellare contro le soluzioni esatte e la struttura a strati; la deconvoluzione contro spettri di cui si conosce la verità; il t-SNE contro la PCA; e le pagine a 412 e 1280 px | 65 |
| `test_sellingua` | Il cambio lingua tondo, su **due viewport** (1280 e 390 px): il pulsante si vede, è tondo, in alto a destra, **all'altezza del titolo misurata** come sovrapposizione dei due riquadri, con un nome accessibile che dice che cosa fa; il disco con le quattordici bandiere su due gusci **dentro lo schermo**; e **nei due versi** la lingua che cambia davvero, la bandiera che segue, il disco che si chiude e, tornando all'italiano, il testo identico a prima. **30 controlli**, minimo dichiarato 30 | 30 |
| `audit_statico` | Le classi di bug che questo progetto ha già avuto, cercate in **tutti** i file invece che dove si sono manifestate: `calc()` senza spazi (il browser scarta la regola), segreti nei log, chiavi API nel codice, password in chiaro, `target="_blank"` senza `noopener`, id duplicati nel markup, script sbilanciati. Il rapporto **segnala e non blocca**, perché quelle classi hanno falsi positivi. Tre misure invece **bloccano**, e hanno un riferimento scritto: blocchi di codice duplicati verbatim (**0**), funzioni globali ridefinite (**11**, lo stile «patch additivo» dichiarato del file), di cui con corpi identici (**0**). Se crescono, la batteria fallisce | 3 cancelli |
| `test_articoli` | Che nessuna funzione abbia due porte d'ingresso, e che gli articoli non siano scritti a mano. Dieci schede dentro un solo Centro spettri, con ogni identificatore presente nel documento **una volta sola**; nessun id ripetuto, nessun pulsante doppio, nessuna sezione raggiungibile da due strade; Spectra fuori dal menù e con il suo pulsante dedicato. Poi gli articoli: i link provati come **funzioni pure** dell'identificatore, le spiegazioni dei Nobel abbinate all'argomento della motivazione e **nessuna** inventata quando non si riconosce, e la prova decisiva — una risposta **iniettata** con un nome inesistente, che deve comparire sullo schermo. **Tre guasti distinti**: richiesta fallita, risposta vuota, forma non riconosciuta | 58 |
| `test_geom3d` | La geometria 3D costruita dal grafo, misurata contro i valori di letteratura: legami, angoli di valenza, linearità degli alchini. **Nei due versi**: il benzene esce piano e il cicloesano **non** piano. E la prova che rende lecito il collegamento picco↔atomo: ogni atomo pesante ha **lo stesso indice e lo stesso elemento** del predittore | 29 |
| `test_documento` | L'apertura di qualunque documento e lo svolgimento del quesito che contiene: PDF, Word e testo aperti davvero e il contenuto verificato; i dati riconosciuti **con la loro provenienza**. **Nei due versi**: un'immagine dichiara che non c'è riconoscimento ottico e non inventa uno svolgimento, un formato sconosciuto viene rifiutato invece che indovinato, CDCl₃ non diventa la formula del composto, senza etichetta MS non ci sono masse | 47 |


> **Un banco che verifica un modello deve verificarlo anche quando il modello
> deve fallire.** `test_cheminfo` prova il modello nullo nei due versi: su un
> segnale apprendibile l'R² vero (0,394) batte tutti e otto i sosia con
> etichette rimescolate, con un margine di 0,287; sulle **stesse molecole con
> etichette casuali** l'R² (−0,199) **non** li batte. Un controllo che verifica
> solo il primo caso passerebbe anche se la guardia fosse cablata su «vero».

> **Un «contrasto 0» che non copriva la superficie nuova.**
> `verifica-accessibilita` misura ciò che è visibile, e i sei pannelli della
> sezione Chemioinformatica restano nascosti finché l'analisi non è stata
> eseguita: non li aveva mai visti. Ora `test_cheminfo` esegue l'analisi, apre
> i pannelli a turno e misura il contrasto su **460 elementi di testo**, con le
> formule WCAG riscritte dentro il banco — chiedere al codice sotto esame
> quanto vale il proprio contrasto non è misurare. Il banco pretende inoltre di
> averne misurati più di 250: se i pannelli non si aprissero, lo zero sarebbe
> vuoto e il controllo fallirebbe.

> **Tre picchi trovati non dimostrano nulla da soli.** Un rilevatore troppo
> sensibile ne trova trenta dove ce ne sono tre; uno troppo rigido non ne trova
> nessuno. In nessuno dei due casi compare un errore. `test_spettrolettore`
> parte da tre gaussiane **costruite** a 1715, 2950 e 3400 cm⁻¹ sotto rumore e
> pretende che il lettore ne trovi tre — 1716, 2952, 3402 — e poi, sullo
> **stesso rumore senza gaussiane**, che ne trovi **zero**. Senza il secondo
> controllo, il primo passerebbe anche con un rilevatore che segna ogni
> oscillazione. Lo stesso vale per la foresta casuale: R² fuori sacco 0,90 sulla
> relazione vera e **−0,16 su puro rumore**.

> **Un predittore non si rompe mai: produce sempre dei numeri.** Se sono
> sbagliati di venti ppm, lo spettro si disegna lo stesso e sembra uno spettro.
> L'unico modo di sapere se serve a qualcosa è confrontarlo con valori misurati
> da altri — e c'è una trappola che rende quel confronto inutile: tarare i
> parametri sulle stesse molecole su cui poi si misura l'errore. Il numero che
> esce dice allora quanto bene lo schema ricorda i propri esempi.
> `test_nmr` tiene due insiemi separati: **taratura** (9 molecole, scarto 0,56
> ppm) e **validazione** (22 molecole mai usate per quello, **0,92 ppm**). Il
> valore dichiarato nel pannello è il secondo. E il banco pretende che la
> validazione resti **peggiore** della taratura: se un giorno fossero uguali,
> vorrebbe dire che qualcuno ha spostato una molecola da un insieme all'altro,
> e il numero non direbbe più niente.

> **Il difetto era nel mio contatore, non nei dati.** La prima esecuzione di
> `verifica_farmaci_v187` ha dato **0 formule su 36**: ogni molecola risultava
> `C<n>`, tutti carboni e nessun idrogeno. Il formato `get_json` di RDKit è
> **commonchem**, dove un atomo porta soltanto i campi che **differiscono** dai
> valori predefiniti — `z` vale 6 e `impHs` vale 0 — così che un atomo scritto
> `{}` è un carbonio. Leggevo `a.element`, che in quel formato non esiste.
> Trentasei dati che sembrano sbagliati tutti insieme sono quasi sempre un
> contatore sbagliato.

### 3.1-bis Le venti sezioni della v237: che cosa è verificato

Ogni sezione ha uno script `tools/banchi/verifiche/verifica-<id>.js` che si può
eseguire da solo con `node` e che confronta i calcoli con valori pubblicati o
con un secondo metodo indipendente. Due o tre esempi per sezione, con il
valore che lo script stampa:

| Sezione | Script | Controlli | Esempi |
|---|---|---:|---|
| 🪐 Sistema solare 3D | `verifica-sastrosole` | 36 | Keplero risolto con residuo < 10⁻¹² fino a e = 0,97 e confermato per bisezione; data giuliana del 1957 ott 4,81 = 2436116,31 (Meeus, es. 7.a); Marte 2003 a 0,3730 UA il 27 agosto (vero: 0,3727) |
| 🛰️ Meccanica orbitale 3D | `verifica-sastroorbite` | 26 | elementi → stato → elementi su 2000 orbite casuali (400 iperboliche), errore 2,8·10⁻¹⁴; Curtis es. 4.3 (h = 58 312 km²/s, i = 153,25°, e = 0,1712); Hohmann LEO → GEO 3,893 km/s |
| 📐 Matematica celeste | `verifica-sastromat` | 34 | Newton, punto fisso e serie di Bessel concordi entro 10⁻¹²; limite di Laplace 0,6627434; q v q* = R(q) v su 500 rotazioni casuali |
| ⭐ Vita delle stelle 3D | `verifica-sastrostelle` | 32 | primi zeri di Lane–Emden: √6, π, 3,65375, 6,89685; soluzioni numeriche uguali alle esatte entro 10⁻¹³; massa di Chandrasekhar dal politropo n = 3, 1,4563 M☉ |
| 🕳️ Buchi neri | `verifica-sastrobh` | 30 | ISCO a 6M e sfera dei fotoni a 3M dal potenziale efficace; perielio di Mercurio 42,982″ al secolo; GPS +45,72 e −7,21 μs/giorno |
| 〰️ Onde gravitazionali | `verifica-sastrogw` | 29 | massa di chirp di GW150914 28,096 M☉; f ∝ (t_c − t)^(−3/8), pendenza −0,375; tempo di coalescenza di Peters uguale all'integrazione di da/dt |
| 🌌 Galassie 3D | `verifica-sastrogal` | 32 | funzioni di Bessel modificate contro le tabelle (I₀(1) = 1,2660659); picco del disco di Freeman a 2,150 R_d; M(r) di NFW in forma chiusa contro l'integrale, 7,6·10⁻¹² |
| 🌠 Cosmologia 3D | `verifica-sastrocosmo` | 38 | età con i parametri di Planck 13,791 Gyr; Einstein–de Sitter 2/(3H₀); D_A massimo a z = 5/4 in Einstein–de Sitter |
| 🔭 Planetario 3D | `verifica-sastrocielo` | 30 | GMST di Meeus es. 12.a e 12.b; giorno siderale 86 164,091 s; equazione del tempo: +16,45 min verso il 3 novembre, −14,20 min verso l'11 febbraio |
| 🌍 Esopianeti 3D | `verifica-sastroeso` | 27 | zona abitabile del Sole 0,95–1,67 UA; T_eq della Terra 254,8 K; profondità dei transiti di Terra e Giove 84,1 ppm e 1,056 % |
| 🌀 Spin, qubit ed entanglement | `verifica-sfisspin` | 30 | HZH = X, HXH = Z, S² = Z, T² = S; norma del vettore di Bloch 1 dopo 2000 porte casuali; frequenza misurata contro cos²(θ/2) entro 3σ |
| 🎲 Meccanica statistica | `verifica-sfisstat` | 30 | picco di Schottky a kT = 0,41678 Δ, C = 0,43923 k; v_rms di N₂ a 300 K = 516,84 m/s; energia conservata in 19 527 urti elastici |
| ☢️ Nuclei e reazioni | `verifica-sfisnuclei` | 28 | B/A del ⁵⁶Fe 8,7903 MeV dalle masse; ⁶²Ni con il B/A più alto; Q di D + T 17,589 MeV, di cui 14,049 al neutrone |
| 🧱 Elasticità e materiali | `verifica-sfismateriali` | 27 | pendenza elastica dell'acciaio = E = 207 GPa; momenti d'inerzia in forma chiusa contro l'integrale a strisce; frecce delle mensole numeriche uguali alle chiuse |
| 🔌 Elettronica | `verifica-sfiselettronica` | 27 | ripple simulato contro il calcolo esatto nei raddrizzatori; diodo con Newton = forma chiusa con la W di Lambert (0,650463089 V); Zener con Newton = bisezione |
| 🌊 Equazioni alle derivate parziali | `verifica-smatedp` | 46 | J₀(1) e J₁(1) delle tavole entro 10⁻¹⁴; dodici zeri di Bessel; membrana quadrata con ω₁₂ = ω₂₁ e ω₁₂/ω₁₁ = √(5/2) |
| 🌀 Analisi complessa | `verifica-smatanalcomp` | 49 | e^(iπ) + 1 = 1,2·10⁻¹⁶; salto di 2π del logaritmo attraverso il taglio; Cauchy–Riemann su nove funzioni |
| 🔗 Catene di Markov | `verifica-smatmarkov` | 51 | stazionaria con le potenze = sistema lineare = regola di Cramer; Ehrenfest con la binomiale e il bilancio dettagliato; periodi 2 e 3 riconosciuti |
| 🧩 SVD | `verifica-smatsvd` | 41 | ‖A − UΣVᵀ‖/‖A‖ ≈ 1,6·10⁻¹⁵ su matrici fino a 12×12; σ di [[3,0],[4,5]] = 3√5 e √5; σ del taglio = φ e 1/φ |
| 📡 Codici e curve ellittiche | `verifica-smatcodici` | 62 | Hamming(7,4): distanza 3, 112 errori singoli corretti, 336 doppi decodificati male; CRC-32("123456789") = 0xCBF43926 |

A questi si aggiungono `verifica-studio` (167 controlli sul motore dei kit),
`verifica-studio-fisica` e `verifica-studio-matematica` (schema e quantità
minime; per la matematica **264 risposte ricalcolate** su 346 domande) e
`verifica-risorse` (87 controlli: formati delle citazioni e prove delle
tavole).

> **Due soglie di tempo, e perché.** Nel browser `test_v237` misura quanto
> resta bloccata la pagina al clic su ogni scheda. Le schede **2D** devono
> aprirsi entro **250 ms**; quelle che creano una scena **3D** entro **6 s**.
> La differenza non è indulgenza: nella batteria il browser non ha una scheda
> grafica, e WebGL gira nel rasterizzatore software **SwiftShader**, dove creare
> un contesto e compilare gli shader costa da 0,2 a 4 secondi. Su un
> dispositivo con GPU è questione di millisecondi. Una soglia stretta sulle
> schede 3D misurerebbe SwiftShader, non l'app; una soglia larga sulle 2D
> lascerebbe passare un blocco vero.

### 3.1-ter Le schede 3D della v238: che cosa è verificato

Ventinove sezioni ricevono in coda una scheda 3D costruita sul modello della
sezione. Ogni scheda ha uno script `tools/banchi/verifiche/verifica-<id>-3d.js`
(per Topologia e Geometrie non euclidee i controlli sono stati aggiunti allo
script della sezione) che si esegue da solo con `node`. Due esempi per scheda,
con il valore che lo script stampa:

| Sezione · scheda 3D | Script | Controlli | Esempi |
|---|---|---:|---|
| 🏔️ Superficie di energia potenziale · 🧊 Superficie 3D | `verifica-schipes-3d` | 9 | alla sella una sola curvatura negativa: 2116 e −2022 cm⁻¹ (frequenza immaginaria); ω(H₂) del modello 4396,6 cm⁻¹ contro 4401 misurati |
| 🧊 Diagrammi di fase · 🧊 Superficie P–V–T | `verifica-schifasi-3d` | 8 | fattore acentrico dalla curva di vapore: acqua 0,3443, CO₂ 0,2249; aree di Maxwell uguali sulla cupola entro 5,5·10⁻¹² |
| 🌀 Cinetica complessa · 🧊 Urti molecolari | `verifica-schicinet-3d` | 7 | energia cinetica conservata dopo 6000 passi e 2993 urti (1,8·10⁻¹⁵); frazione di urti sopra E₀/kT = 2,5 pari a e^(−2,5) entro 3σ (0,0812 contro 0,0821) |
| ⚖️ Equilibrio e Le Chatelier · 🧊 Scatola 3D | `verifica-schiequil-3d` | 7 | A ⇌ B: K misurata 2,9976 contro 2,9951 teorica (entro l'1,5 %); dimezzando il volume il grado di dissociazione di N₂O₄ cala da 0,177 a 0,129 |
| 💎 Cristallografia e raggi X · 🧊 Celle in 3D | `verifica-scristalli-3d` | 9 | numeri di coordinazione 6, 8, 12, 12, 6, 8, 4 per SC, CCC, CFC, EC, NaCl, CsCl, diamante; d(hkl) = 1/\|G\| uguale a `dSpaziatura` entro 4,4·10⁻¹⁶ |
| 🌊 Laboratorio di Schrödinger · 🧊 Nuvola 3D \|ψ\|² | `verifica-sschrod-3d` | 10 | degenerazioni dell'oscillatore 3D 1, 3, 6, 10; frazione della nuvola fuori dalla regione classica 0,1107 contro P(χ²₃ > 6) = 0,1116 |
| 🧮 Hartree-Fock in diretta · 🧊 Orbitali in 3D | `verifica-shf-3d` | 9 | H₂ a 1,4 bohr: E = −1,116714 Eh (Szabo-Ostlund); ∫\|ψ\|² sulla griglia = 1,0000 per σg e σu |
| 🎻 Spettroscopia rotovibrazionale · 🧊 Rotazione e vibrazione 3D | `verifica-srotovib-3d` | 10 | T + V = G(v) lungo il moto classico entro 9,5·10⁻⁹; CO₂: ν₁ inattivo in IR, ν₂ e ν₃ attivi |
| 🎱 Dinamica molecolare · 🧊 Scatola 3D | `verifica-sdinmol-3d` | 7 | NVE: \|ΔE\| per particella 9,6·10⁻⁴ su 2000 passi; termostato: ⟨T⟩ = 1,400 come il bagno |
| 🎯 Meccanica in movimento · 🌬️ Lancio 3D con vento | `verifica-sfismecc-3d` | 7 | nel vuoto R = v₀² sin 2θ/g = 91,774 m anche con 15 m/s di vento; velocità limite √(g/k) = 22,145 m/s (misurata 22,1435) |
| ⚡ Elettromagnetismo in movimento · 🌀 Campi 3D e Lorentz | `verifica-sfisem-3d` | 8 | raggio di Larmor mv⊥/qB = 0,61538 (misurato 0,61539); deriva E×B = (0; −0,5) uguale per q = +1 e q = −1 |
| 〰️ Onde e ottica · 🌊 Ondoscopio 3D | `verifica-sfisonde-3d` | 6 | d = 3λ dà 6 linee nodali, d = 0,4λ nessuna; minimi lontani in arcsin((m + ½)λ/d) entro 2,1·10⁻⁵ rad |
| 🪐 Gravitazione · 🕳️ Pozzo di potenziale 3D | `verifica-sfisgrav-3d` | 8 | \|∇U\| nei cinque punti di Lagrange 1,1·10⁻¹⁵; periodo misurato 7,2779 = 2π a^(3/2) |
| ⏱️ Relatività ristretta · 🔦 Cono di luce 3D | `verifica-sfisrel-3d` | 6 | intervallo invariante in (x, y, ct) entro 2,7·10⁻¹³; composizione delle spinte Λ(β₂)Λ(β₁) = Λ((β₁ + β₂)/(1 + β₁β₂)) entro 5,3·10⁻¹⁵ |
| 🌊 Fluidi · 🌀 Flusso attorno a un ostacolo 3D | `verifica-sfisfluidi-3d` | 7 | sfera: v = 1,5U e C_p = −1,25; cilindro: v = 2U e C_p = −3; portanza −ρUΓ = −5988 N/m |
| 🔥 Termodinamica in movimento · 🗻 Superficie p-V-T 3D | `verifica-sfistermo-3d` | 8 | punto critico di van der Waals: p = 1, ∂p/∂V e ∂²p/∂V² nulli; a T = 0,9 p_sat 0,6470, V_l 0,6034, V_g 2,3488 |
| 💡 Semiconduttori · 🔷 Zona di Brillouin 3D | `verifica-sfissolido-3d` | 7 | zona fcc: 24 vertici, 36 spigoli, 14 facce (V − E + F = 2); m*_dos(Si) = 1,084 m₀ |
| 🧲 Modello di Ising · 🧊 Ising 3D | `verifica-sfisising-3d` | 6 | stato fondamentale e = −3, m = 1 (con h = 0,4: e = −3,4); \|m\| 0,946 a T = 3, 0,052 a T = 5,5 (T_c ≈ 4,5115) |
| ⚛️ Fisica delle particelle · 🔭 Rivelatore 3D | `verifica-sfispart-3d` | 6 | elica in 3,8 T: R = p_T/(0,3 B) = 0,8772 m; massa invariante ricostruita da 200 coppie Z → μμ uguale a quella generata entro 1,6·10⁻⁵ |
| 🗻 Funzioni di più variabili · 🧊 Piano tangente in 3D | `verifica-smatmulti-3d` | 9 | x² + y² in (1, 2): f = 5, ∇f = (2, 4); scarto dal piano tangente di ordine 2 (rapporto 4,0445) |
| ∇ Calcolo vettoriale · 🧊 Campo 3D e divergenza | `verifica-smatvett-3d` | 8 | F = (x, y, z), r = 1,2: flusso = ∭3 dV = 4πr³ = 21,7146884216; carica puntiforme: flusso 4π con l'origine dentro, 0 fuori |
| ∫ Derivate, integrali e serie · 🧊 Solidi di rotazione | `verifica-smatcalc-3d` | 8 | sfera unitaria V = 4π/3 = 4,188790204786; fuso di sin x V = π²/2 |
| 🔲 Algebra lineare · 🧊 Trasformazioni dello spazio | `verifica-smatlin-3d` | 9 | det = prodotto misto = Πλ = 6; riflessione: det −1 e det M(1/2) = 0 |
| 🌀 Equazioni differenziali · 🧊 Caos nello spazio delle fasi 3D | `verifica-smatode-3d` | 9 | esponente di Lyapunov di Lorenz 0,9036 contro 0,9056; RK4: rapporto degli errori 16,04 dimezzando il passo |
| 🎲 Probabilità in movimento · 🧊 Normale bivariata 3D | `verifica-smatprob-3d` | 7 | ∬ xy f = ρσxσy = 0,546; campioni dentro Q ≤ 1: 39,37 % contro 39,35 % |
| 🍩 Topologia e superfici · 🧊 Superfici in 3D: χ e orientabilità | `verifica-smattopo` | 45 (3 della v238) | triangolazioni di cinque superfici a quattro finezze con χ uguale alla maglia; Möbius: n(2π)·n₀ = −1 e n(4π)·n₀ = +1 |
| 🌐 Geometrie non euclidee · 🧊 Sfera e iperboloide in 3D | `verifica-smatnoneucl` | 56 (4 della v238) | iperboloide e disco di Poincaré con stessi angoli e lati entro 1,2·10⁻¹⁵; Gauss–Bonnet sull'iperboloide: π − Σ = area (1,0700757) |
| ℂ Complessi e Fourier · 🧊 Sfera di Riemann | `verifica-smatcompl-3d` | 7 | rotazioni della sfera = Möbius di SU(2) su 4 assi × 3 angoli × 30 punti entro 5,5·10⁻¹⁶; rotazione di π attorno a x: f(z) = 1/z e f(0) = ∞ |
| 🎢 Calcolo delle variazioni · 🧊 Pellicola di sapone in 3D | `verifica-smatvariaz-3d` | 8 | h*/R = 1,32549 (u* tanh u* = 1); h/R = 1,36 si strappa, h/R = 1,30 resta un catenoide |

Tutti gli script, eseguiti alla stesura di questo documento: **311 controlli
superati, 0 falliti**. Il conteggio di `smattopo` e `smatnoneucl` comprende i
controlli già presenti prima della v238.

> **Una sola soglia di tempo per le schede 3D nuove.** `test_v237` concedeva
> alle schede 3D 6 s, perché la scena si costruiva dentro il gestore del clic e
> nella batteria WebGL gira in SwiftShader (§3.1-bis). Le schede della v238
> costruiscono subito testo e comandi e la scena **dopo** il ritorno del
> gestore: il lavoro sincrono al clic deve restare sotto i **250 ms**, come per
> le schede 2D. Misurato nelle esecuzioni di prova: al massimo poche decine di
> millisecondi.

### 3.2 Agente AI

| Banco | Condizione simulata |
|---|---|
| `test_404` | Il fornitore ha ritirato il modello |
| `test_503` | Sovraccarico temporaneo |
| `test_ko` · `browser_ko` | Fornitore irraggiungibile dal browser |
| `test_firma` | Firme di ragionamento opache da restituire |
| `test_tetto` | Tetto di token appreso dall'errore |
| `test_attesa` · `test_attesalunga` | Timeout e attese imposte |
| `test_doppioinvio` | Due invii sovrapposti |
| `browser_prova` | Misura di raggiungibilità senza chiave |
| `test_nucleo` · `browser_prov` | Ciclo agentico e selezione del fornitore |
| `caccia_ai` | Risposte malformate, stream troncato, 502 con HTML, Stop durante la risposta, pannello chiuso a metà, testo ostile |

### 3.3 Stabilità

| Banco | Cosa mette alla prova |
|---|---|
| `audit_stabilita` | 194 sezioni aperte 5 volte, memoria piena, dati corrotti, raffiche di clic |
| `audit_promesse` | Promesse rifiutate e non gestite, con rete sana e con rete morta |
| `audit_quota` | `localStorage.setItem` forzato a fallire su 10 pagine |
| `test_sw` | Offline, rete degradata, aggiornamento durante il lavoro |
| `test_filemanager` | Archivio non disponibile, spazio esaurito, scritture fallite |
| `test_visore3d` | Consumo di contesti WebGL sfogliando molecole |

### 3.4 Interfaccia

`browser_reset` · `browser_proxy` · `browser_proxyui` · `browser_rdkit` ·
`browser_lab` · `browser_frontiera` · `test_aggiorna` · `test_controllaagg` ·
`test_spectra238` · `test_lezione` · `test_spectra_studio` · `test_spectra_rig` ·
`test_spectra_figura` · `test_spectra_esplora` · `test_spectra_olo` · `test_impronta` · `test_voce` ·
`test_guidaproxy` ·
`test_fluidita` · `test_avvio` · `test_giro` · `test_lingue` · `test_mol3d` · `test_spettrolettore`

**`test_spectra238` — 66 controlli.** Nasce da segnalazioni fatte con una
schermata dal telefono: con l'app installata la barra di stato e i tasti di
Android coprivano i comandi della console di Spectra Live, e l'attribuzione del
modello si sovrapponeva al dialogo. Dalla v239 controlla anche, prima di
tutto, che Spectra abbia **un solo pulsante visibile**: il cerchio con il volto
(`#bsiJV-fab`) si vede, la pillola «Spectra» (`#bsi-spectra-fab`) no, e il
cerchio è rotondo (`border-radius: 50%`). Il resto del banco lavora in quattro
parti:

| Parte | Che cosa pretende |
|---|---|
| Impaginazione | Su un telefono simulato (412×915, touch, finestra a schermo intero) la classe dei margini sicuri è attiva, il primo pulsante in alto sta ad almeno **34 px** dal bordo e i comandi in basso ad almeno **46 px**; la telemetria è in due colonne e non copre il volto. Su schermo grande nessun margine forzato. In entrambi: testata sopra il volto, volto sopra lo stato, stato sopra il dialogo, dialogo sopra scorciatoie e comandi, attribuzione dentro la barra dei comandi; almeno quattro scorciatoie con una sezione aperta |
| Navigatore | Per chimica, fisica e matematica il navigatore 🧭 elenca **esattamente** le sezioni della barra (più di 20 per materia), almeno quattro strumenti rapidi e dieci frasi; aprire una sezione di un'altra materia cambia materia, chiude la console e lascia il pulsante di Spectra Live |
| Livello e concentrazione | Una domanda da corso avanzato pesa più di un conto (scarto > 0,2); «in parole semplici» abbassa; la stessa domanda pesa di più (scarto > 0,3) in una sezione da dottorato che in una da scuola superiore, e il livello dichiarato è quello del percorso |
| Creatore, occhi, sonno | «chi ti ha creato?» nomina Samuele Pio Provenzano; «sono il tuo creatore» chiede una prova e il campo diventa password; una frase sbagliata è respinta, il campo torna normale e la frase non resta nel dialogo, nella pagina né nella memoria; dopo tre tentativi l'attesa; riconosciuto (il banco scrive il segno `bsi-spectra-creatore-v1` nel `localStorage`: la frase non compare nel banco): saluto per nome, telemetria «SAMUELE · CREATORE», contesto al modello e alla mente; «dimentica che sono il tuo creatore» lo toglie. Occhi: gioia li stringe (< 0,8), sorpresa li spalanca (> 1,25), dubbio li rende asimmetrici, a riposo `#1a3050`, quattro emozioni danno quattro tinte, la concentrazione socchiude e accende, il battito chiude le palpebre (< 0,2); dopo due minuti senza contatto dorme, al primo tocco si sveglia con la sorpresa |

Restano fuori, e lo dichiara `docs/08` §6 (AI-13): la voce, l'ascolto continuo
e gli altri comandi locali, che nel Chromium senza interfaccia della batteria non si
possono provare.

**`test_lezione` — 30 controlli.** Nasce dalla richiesta di una lezione
interattiva «per ogni sezione» (`bsi-lezione.js`). Poiché la lezione non è
scritta a mano ma costruita dalla sezione, il banco non ne prova una: le prova
tutte.

| Parte | Che cosa pretende |
|---|---|
| Tutte le sezioni | Apre una per una le sezioni della barra nelle tre materie (cambiando materia quando serve) e pretende di averne attraversate almeno 190 (**194** alla stesura). Per ognuna: la lezione esiste e va dall'apertura al riepilogo; il pulsante «🎓 Lezione guidata» c'è; se la sezione ha schede (**99**), i capitoli sono uno per scheda più apertura, riepilogo ed eventuale verifica. Almeno 60 lezioni devono avere una domanda di verifica (**79** alla stesura). Nessun errore JavaScript |
| Il lettore, a 390 e a 1280 px | Su 〰️ Onde e ottica: il pulsante apre la lezione dall'apertura; i pulsanti flottanti passano da visibili a nascosti; arrivati al primo cursore il valore cambia davvero (almeno quattro valori diversi in 4,5 s) e il riflettore è acceso; saltando avanti a metà il cursore torna al valore di partenza; una scelta passa almeno due opzioni e torna a quella di partenza; la verifica mostra la risposta giusta e una spiegazione di più di 20 caratteri; il riepilogo elenca i capitoli; niente sborda; alla chiusura il pannello sparisce, la classe `bsiLZ-aperto` è tolta e i pulsanti flottanti sono di nuovo visibili; `BSISpectraLive.comando('fammi lezione')` risponde e avvia la lezione; nessun errore JavaScript |

Restano fuori la voce della lezione (non c'è sintesi vocale nel Chromium senza
interfaccia) e la qualità didattica dei testi, che dipende dalle spiegazioni
delle sezioni e va giudicata leggendo.

**`test_spectra_studio` — 87 controlli**, sul corpo vero incorporato
(`models/spectra-corpo.bsi`, dalla v241). Prova Spectra incarnato
(`spectra-studio.html`, `bsi-spectra-figura.js`, `bsi-spectra-corpo.js`, `bsi-spectra-voce.js`,
`bsi-spectra-studio-lezioni.js`; progetto in
[`docs/spectra/02`](https://github.com/samupropio1-ship-it/BioSpecInfo-v11/blob/main/docs/spectra/02-Architettura.md)).

| Parte | Che cosa pretende |
|---|---|
| Calcoli (23) | Esegue `verifiche/verifica-studio-spectra.js`, anche da solo con `node`: caduta da 20 m in √(2h/g) = 2,0193 s per entrambe le sfere, gittata 12,116 m, con l'aria (k = 0,02 m⁻¹) la lanciata arriva dopo (2,1789 contro 2,1563 s), passo dimezzato che cambia il tempo meno di 10⁻⁴; VSEPR: tetraedro 109,471°, trigonale 120°, lineare 180°, acqua 104,40° con w = 1,25 (calibrato), ammoniaca 106,69° con lo stesso w (previsione), angolo che cala al crescere di w; Basilea: S(100 000) entro la coda di π²/6, coda fra 1/(N+1) e 1/N per N = 10, 100, 1000, Fourier di x² in π e in 1, armonica come ln N + γ, coprimi → 6/π² entro 3σ; per ogni lezione una sola risposta giusta, ogni opzione spiegata, almeno tre passi di dimostrazione, esercizi su quattro livelli |
| Corpo (11) | Sul manichino: ossa 22/23 (manca la mandibola), blendshape 14/14, capelli trovati e resi neri (RGB 0,039 0,039 0,047); braccia giù dalla posa a T; indica (avambraccio sul bersaglio, scarto 1,7°); pensa (mano a 20,8 cm dalla testa); sguardo verso destra; passo (0,96 m, gambe a 24°); seduta (anche giù di 42 cm); gioia → sorriso, preoccupazione → angoli giù e sorriso a zero; labiale dall'audio (mandibola 0,75); battito (palpebre chiuse) |
| Voce (3) | In un contesto audio offline: a 80 Hz i bassi escono rinforzati (6,9 dB), il riverbero lascia una coda dopo la fine del suono; senza chiave `qualita()` vale `'sistema'` |
| Lezioni, a 1280 e 390 px | Il volto «Noir» appoggiato sul collo (il riferimento è l'osso del collo più 4,5 cm, dove il mento poggia sul colletto); per caduta, acqua e Basilea le misure in scena (2,019 s, 109,47° e 104,4°, S₁₀₀₀ = 1,64393 e coprimi 0,6079), quattro previsioni, formule nella dimostrazione, la rivelazione con la risposta giusta e quattro esercizi di cui uno consigliato, la memoria che ricorda previsione ed esercizio aperto; a 390 px niente sborda; nessun errore JavaScript |
| Corpo riggato, a 1280 e 390 px (3 + 3) | Sul **corpo vero incorporato**. **Sincronia viso–cappuccio**: mentre Spectra cammina, fa il gesto «spiega» e guarda in 24 punti diversi, la posizione del viso misurata nel riferimento dell'osso della testa non si sposta più di 1 mm (misurati 0,0 mm); **del volto «Noir» si vede solo il viso** (sono visibili soltanto `Object_2`, `Object_3`, `Object_4`: maschera, occhi, dettagli); il volto è **«solidale»** (i movimenti della testa li fa il corpo, e il volto non fa il proprio respiro dentro il cappuccio) |
| Corpo incorporato, a 1280 e 390 px (4 + 4) | Il corpo di Spectra c'è sempre, senza caricarlo (incorporato), e l'avviso «Spectra sta arrivando…» è sparito; nessun pulsante «🧍 Corpo» né scelta di file; il file pubblicato è un blocco impacchettato (firma «BSIC»), non un modello `.glb` riutilizzabile; un blocco che non è un modello viene rifiutato, senza errori JavaScript |
| Voce e dati (2) | La voce spenta resta spenta dopo una ricarica; «Cancella dati → Memoria persistente» toglie `bsi-spectra-studio-v1` e `bsi-spectra-studio-voce` |
| Senza WebGL | Nessuna scena, ma la lezione dà le misure (2,019 s); nessun errore JavaScript |

Dalla v241 i controlli sul corpo riggato (mento sul colletto, sincronia
viso–cappuccio, solo il viso, volto solidale) girano sul corpo «Bounty Hunter»
vero, incorporato nell'app; l'umanoide sintetico iniettato dal banco e i
controlli sul corpo caricato dal dispositivo non ci sono più. Restano fuori:
il `.glb` originale (`models/spectra-corpo.glb`, fuori da git), che lo studio
prova solo in sviluppo; la chiamata a OpenAI e l'ascolto della voce (il banco non
raggiunge OpenAI e non ascolta); la qualità visiva del corpo e dei gesti, che
va giudicata guardando.

**`test_spectra_figura` — 111 controlli (55 a 412 px, 54 a 1280 px).** Nasce
dalla richiesta dell'autore: l'icona di Spectra solo col volto e, in ogni
sezione dell'AI, Spectra col corpo, «e non altro». Prova
`bsi-spectra-figura.js` nell'app, su un telefono (412 px) e su schermo grande
(1280 px). Dalla v241 il banco usa il **corpo vero**, incorporato nell'app
(`models/spectra-corpo.bsi`).

| Parte | Che cosa pretende |
|---|---|
| Icona | Il pulsante di Spectra è solo il volto; la pillola «Spectra» è nascosta |
| Le quattro sezioni | In Spectra AI (`sai`) e nelle aree con l'assistente (`sareachim`, `sareafis`, `sareamat`) la figura sta **dentro la sezione, sotto il titolo**, alta almeno 280 px; in tutta l'app c'è **una figura sola** (un contesto WebGL); per le sezioni fuori da `#main` nessuno spazio vuoto sopra (`#main` alto al massimo 12 px; misurati 0) |
| Il corpo incorporato | Il corpo di Spectra c'è sempre, senza caricarlo: incorporato nell'app (ossa 20/23); nessun pulsante «🧍 Corpo» né scelta di file (i pulsanti sono «🎙️ Parla con me», «🧠 Spiega», «🎓 Studio») |
| Con il corpo | Il viso «Noir» poggia sul colletto (0,0 cm, misurato a regime: il banco aspetta che l'allineamento dei primi fotogrammi sia finito); del volto si vedono solo `Object_2`, `Object_3`, `Object_4` |
| Console Spectra Live (3 per larghezza, v242) | Aperta la console, **Spectra col corpo (e l'ologramma) sta al posto del busto**: la figura è dentro `#bsiJV-figura`, alta più di 150 px, e il busto `#bsiJV-volto` è nascosto; la figura segue lo stato della console (elabora → gesto «pensa», mano al mento); chiusa la console, la figura torna nella sezione |
| Reazioni | `bsi-spectra-stato` «pensa» → gesto «pensa» ed emozione concentrata; `bsi-spectra-risposta` → Spectra prima indica l'ologramma (gesto «indica»), poi accompagna la spiegazione con le mani («spiega»), gioia, labiale sul corpo e sul viso; una risposta mancata → dubbio; Spectra Live che parla → la figura parla con lei; l'assistente locale che risolve «deriva x^2» → «Ecco lo svolgimento…» e sorriso caldo |
| «🧠 Spiega» (14 per larghezza) | «🧠 Spiega» è la seconda scheda della finestra di Spectra e «Lezione» non c'è più; la figura si sposta nella scheda; con uno spettro aperto («Spettri Ref.» nel Centro spettri) legge lo schermo: almeno un grafico, i valori dei comandi, l'immagine; cinque livelli; il modello riceve il testo dello schermo, la domanda e **l'immagine**; la richiesta chiede una spiegazione esaustiva e non semplificata, con la lettura quantitativa dello spettro (δ, molteplicità, J, integrale) e delle scene 3D; la struttura obbligatoria; la risposta arriva formattata (titoli e tabella) e Spectra pensa mentre viene scritta; la domanda successiva continua la conversazione senza rimandare l'immagine; al PhD avanzato frontiera, problemi aperti e letteratura primaria; senza modello non finge; legge come immagine i grafici SVG (dalla v242 il banco inserisce nella sezione aperta uno spettro SVG noto, deterministico, invece di dipendere dal quiz degli spettri, che è casuale); legge una scena 3D («Meccanica orbitale 3D»: 2 tele, immagine); con quella scena aperta dietro «🧠 Spiega» l'ologramma la mostra dal vivo; privacy: tolta la spunta «Includi lo schermo», la sezione nominata si apre ma al modello vanno solo la domanda, senza testo né immagine dello schermo |
| Ologramma (7 per larghezza) | Sta **alla destra di Spectra** (x sullo schermo); ci sono **sei scene vive**; Keplero: il rapporto fra la velocità al perielio e all'afelio vale (1+e)/(1−e) = 1,94 entro l'8 %; **il soggetto segue la conversazione** (una risposta sull'IR → spettro, una domanda sulle orbite → pianeti); l'etichetta porta alla sezione; un tocco sull'etichetta apre «Sistema solare 3D» **dietro** la finestra «🧠 Spiega»: Spectra resta visibile davanti e l'ologramma mostra la sezione dal vivo; chiusa la finestra, l'app torna alla sezione di Spectra e la figura è lì |
| Catalogo (5 per larghezza) | Il catalogo ha **tutte** le sezioni della barra (201/201 dalla v250: chimica 78, fisica 63, matematica 31, comuni 29); una domanda che nomina un argomento trova la sua sezione (titolazioni → `stitr`, Schrödinger → `sschrod`, integrali per parti → `smatcalc`, spettro di massa → `sms`, spettro infrarosso → `sirvis`, meccanica orbitale → `sastroorbite`, «ciao come stai» → nessuna); chiedendo delle titolazioni, Spectra apre la sezione dietro la finestra, la mostra nell'ologramma e la spiega con i suoi dati; una sezione senza grafici (Tavola Periodica) si proietta come scheda nell'ologramma; «🎞️ Mostrami tutto» scorre le sezioni della materia |
| Telefono | I pulsanti della figura non finiscono sotto quelli flottanti |
| Errori | Nessun errore JavaScript, a ogni larghezza |

Il banco porta la figura in vista prima di misurare: la figura si disegna, e
allinea il viso, solo quando è visibile.

Restano fuori: la qualità
visiva della figura e dei gesti, che va giudicata guardando; la voce; la
qualità della spiegazione di un modello vero: le risposte del modello sono
simulate, e il banco controlla che cosa si manda (testo dello schermo,
immagine, livello, struttura richiesta) e come si mostra, non che cosa un
modello vero spiegherebbe.

**`test_spectra_esplora` — 75 controlli (v242).** Nasce dalla richiesta
dell'autore: «non c'è la sezione richiesta per ogni materia come every-joule».
Prova `bsi-spectra-esplora.js`: in node i capitoli e i numeri dei cursori, nel
browser (412 e 1280 px) le tre sezioni «⚡ Esplora con Spectra».

| Parte | Che cosa pretende |
|---|---|
| Capitoli (12, in node) | Per chimica, fisica e matematica: **dieci capitoli**; livelli da 0 (Scuola superiore) a 4 (PhD avanzato · frontiera), in ordine; ogni previsione ha **quattro risposte**, l'indice della giusta e **un perché per ognuna**; gli identificativi sono unici |
| Numeri dei cursori (22, in node) | Contro le formule: pH di HCl 10⁻⁸ M = **6,978** con l'autoprotolisi dell'acqua, 10⁻² M = 2; Henderson–Hasselbalch pH = pKa a rapporto 1; t½ = ln 2/k = **6,931 s** a k = 0,1 s⁻¹; Marcus, barriera nulla a ΔG° = −λ e **λ/4 a −2λ** (regione invertita); caduta da 20 m in **2,019 s**; gittata a 45° con v₀ = 20 m/s **40,775 m**; pendolo da 1 m **2,006 s**; Carnot fra 600 e 300 K = 0,5; particella in una scatola di 1 nm **0,376 eV**, ×4 dimezzandola; tunnel, spessore doppio → trasmissione al quadrato; γ dei muoni a 0,9995c = **31,63**; derivata di x³ in 2 = 12; (1+1/n)ⁿ con n = 10⁶ entro 2·10⁻⁶ da e; ∫₁ᵉ dx/x = 1; Basilea con 10⁵ termini = π²/6 − 10⁻⁵; armonica con 1000 termini **7,4855**; autovalori della rotazione di 90° ±i; massimo di Gibbs con 201 termini ≈ **1,179**; modo del calore k = 2 a t = 0,1 → e^(−0,4) |
| La barra (1 per larghezza) | Le tre sezioni (`sesplchim`, `sesplfis`, `sesplmat`) stanno nella barra della loro materia, e ogni capitolo è collegato a una sezione che esiste |
| Per materia (5 per materia e per larghezza) | Dieci capitoli e **Spectra col corpo nella sezione, `sticky`, ancora in vista dopo lo scorrimento** (sotto la testata dell'app); il capitolo davanti (il quinto, portato al centro) è **attivo** e l'ologramma prende la sua scena; prevedere con una risposta sbagliata segna la giusta e la sbagliata, con il perché di ogni risposta, e **Spectra reagisce** (sorpresa); la memoria (`bsi-esplora-v1`) ricorda la previsione e la barra avanza (1/10); il cursore ricalcola |
| Telefono (3) | A 412 px niente sborda, per ogni materia |
| Guardalo dal vivo (2 per larghezza) | «📺 Guardalo dal vivo» apre la sezione collegata **dietro** la finestra di Spectra (scheda «🧠 Spiega») e l'ologramma la mostra dal vivo (scena «schermo»); chiusa la finestra, si torna alla sezione Esplora (`sesplmat`) |
| Errori (1 per larghezza) | Nessun errore JavaScript |

Restano fuori: la voce di «🔊 Ascolta Spectra» (nel Chromium senza interfaccia
non c'è sintesi vocale); la spiegazione di «🧠 Spiegamelo tutto», che dipende da
un modello (il percorso è quello di «🧠 Spiega», provato da
`test_spectra_figura`); la qualità didattica dei testi, che va giudicata
leggendo.

**`test_spectra_olo` — 69 controlli (15 in node, 28 a 412 px, 26 a 1280 px; v242, v248).**
Nasce dalla richiesta dell'autore di selezionare l'ologramma e interagire, con
ogni passaggio spiegato. Prova `bsi-spectra-olointerattivo.js`.

| Parte | Che cosa pretende |
|---|---|
| Spettri (8, in node) | Sei molecole di riferimento, ognuna con i cinque spettri (IR, ¹H, ¹³C, massa, UV); massa molare dell'acetone **58,08 g/mol**; grado di insaturazione benzene 4, acetone 1, etanolo 0; il tripletto del CH₃ a 400 MHz largo **2J/ν₀**; a 60 MHz il multipletto è **10 volte** più largo che a 600 MHz; traccia IR: 1715 → C=O, 2950 stretta → C–H sp³ e **non** O–H acido, 3300 larga → O–H; traccia MS: 58 → ione molecolare, 43 → M − 15 (CH₃·) e acilio CH₃CO⁺ |
| Universo (7, in node) | Terra: periodo di Keplero 1 anno, vis-viva **30,29 km/s** al perielio e **29,29 km/s** all'afelio; Marte: rapporto delle velocità = (1+e)/(1−e), gravità in superficie **3,71 m/s²**; velocità di fuga della Terra **11,19 km/s**; un'orbita scritta con a = 4 UA → T = 8 anni |
| La finestra (3 per larghezza) | Il pulsante «⛶ Interagisci» c'è sull'ologramma e apre la finestra in «spettri» (perché l'ologramma mostrava uno spettro); Spectra col corpo ci si sposta; i pulsanti flottanti dell'app spariscono |
| Spettri dal vivo (3 per larghezza) | Cambiando tipo (IR) e scrivendo una traccia, lo spettro e i passaggi si rifanno (1715 e 2950 cm⁻¹ fra i passaggi); una traccia di massa con due picchi dà due passaggi; toccando il picco a m/z 43 si sceglie il suo passaggio e Spectra lo dice |
| Il menu ✨ nell'ologramma (v248: 3 per larghezza) | Nell'elenco ci sono anche le **15 voci del menu ✨** (8 pagine e 7 finestre: Astrochimica 3D, Lab Quantistico, Accademia, Glossario…) e il Centro spettri; «Astrochimica 3D PRO» si apre **dentro il riquadro** (la sua pagina vera) e cambiando modo si toglie; per una finestra (Lab Quantistico) «↗ Apri la sezione» chiude l'ologramma e la apre |
| «🗂️ Tutta l'app» (v248: 4 per larghezza) | L'elenco ha **tutte** le sezioni della barra (201/201, letto dal catalogo, non scritto a mano), filtrabile per materia e per nome; la Tavola Periodica, senza grafici, è **ospitata davvero** nel riquadro (la sezione vera, spostata e viva); scelta un'altra sezione torna al suo posto e «Sistema solare 3D» si vede **dal vivo** con la sua lezione; chiusa la finestra l'app è di nuovo nella sezione di partenza |
| Lettura sul telefono e prova audio (v248: 2 a 412 px, 1 a 1280 px) | Sul telefono **tutta la finestra scorre**: l'ultimo passaggio arriva ad almeno 70 px dal bordo (sopra i tasti di Android), la testata resta in alto, i passaggi sono a 15,5 px; «🔔 Prova audio» suona un bip, dice una frase di prova e spiega che cosa fare se non si sente (muto, volume «Multimedia», voce del telefono) |
| Voce, tocco e Spiega senza chiave (3 per larghezza) | Scritta una traccia, Spectra la spiega **da sola a voce** dopo 1,4 s, senza toccare «🔊»; un tocco **sull'ologramma stesso** (il pannello alla destra di Spectra, colpito con un raggio dalla telecamera) lo apre interattivo; «🧠 Spiega» **senza chiave** risponde comunque alla domanda (pH di HCl 0,01 M: lo svolgimento dell'assistente locale per intero) e lo dice a voce |
| Universo, matematica, fisica (5 per larghezza) | Marte con i suoi sei passaggi, nella scena 3D; «studia f(x)=x^3-3x» → zeri −√3, 0, √3 e punti stazionari ±1, con almeno otto passaggi dell'assistente; il proiettile con gittata **35,31 m**; il pendolo da 2 m con periodo **2,837 s** |
| Voce, Spiega, ritorno (3 per larghezza) | «🔊 Spectra spiega i passaggi» li dice tutti; «🧠 Approfondisci» apre «🧠 Spiega»; chiuse le finestre, Spectra torna nella sezione |
| Telefono (1) | A 412 px niente sborda |
| Errori (1 per larghezza) | Nessun errore JavaScript |

Restano fuori: la voce vera (nel Chromium senza interfaccia non c'è sintesi
vocale: il banco controlla che i passaggi vengano detti tutti, non come
suonano); la spiegazione di un modello vero dopo «🧠 Approfondisci»; la
correttezza chimica di ogni valore delle sei molecole, che sono valori tipici
di letteratura per la didattica e non spettri misurati; l'interprete della
traccia propone attribuzioni candidate dalle tabelle, non determina una
struttura.

**`test_impronta` — 25 controlli (v243).** Nasce da due segnalazioni
dell'autore sulla v242: «non sento la voce» e «vorrei che fossi io con un
riconoscimento impronta, però solo con me». Prova `bsi-spectra-creatore.js`
(WebAuthn) e la voce di `bsi-spectra-live.js`.

| Parte | Che cosa pretende |
|---|---|
| L'impronta (12) | Con l'**autenticatore virtuale** di Chromium (protocollo DevTools, dominio WebAuthn) al posto del sensore: senza la frase segreta l'impronta non si lega; una frase sbagliata non riconosce; legata dopo la frase, si conservano solo `id` della credenziale e data; in una sessione nuova il ricordo del browser non basta e Spectra aspetta l'impronta; l'impronta giusta con la persona verificata riconosce il creatore e il modello lo sa; con la persona **non** verificata, o con **un altro** autenticatore, nessun riconoscimento |
| La console (6) | «attiva l'impronta» la lega e Spectra lo dice; aperta in una sessione nuova la console chiede l'impronta con «👆 Sono io»; toccato, riconosciuto e salutato per nome; «prova la voce» risponde; `statoVoce()` leggibile; «dimentica che sono il tuo creatore» toglie anche l'impronta |
| La voce (3) | Una sintesi finta che parte dopo 2,5 s **senza «onstart»** (come certi motori Android): **nessuna frase annullata** e 2/2 arrivate in fondo (prima della v243 si annullava dopo 1,2 s: la causa del silenzio); una sintesi che non parte affatto non blocca il discorso: il labiale lo porta avanti |
| Chat e sovraccarico (3) | «sono il tuo creatore» scritto nella scheda **💬 Chat** non va al modello: chiude la finestra e apre la console col campo nascosto (0 chiamate al modello); Gemini che risponde **503** sul primo modello: si passa da soli a un altro modello con la stessa chiave e la risposta arriva, in meno di 5 s |
| Errori (1) | Nessun errore JavaScript |

WebAuthn non accetta un indirizzo IP come dominio: il banco apre l'app da
`localhost`. **Non provato**: il sensore vero di un telefono e l'audio udibile.

**`test_voce` — 21 controlli (v246, v248).** Nasce dalla richiesta dell'autore di
una voce maschile robotica, «stile Ultron», per ogni risposta di Spectra nella
Chat, solo con la Web Speech API. Prova `bsi-ai-hub.js` (`speakRobotic`,
`stopSpeaking`, `toggleAutoSpeak`, `createSpeakButton`) con una sintesi vocale
**finta** che registra ogni frase e offre voci italiane e inglesi, maschili e
femminili.

| Parte | Che cosa pretende |
|---|---|
| Voce e parametri (5) | Scelta l'italiana maschile «Luca»; ogni frase a pitch 0,58, rate 0,88, volume 1; una risposta di 1228 caratteri letta **tutta**, a frasi (prima: 600 caratteri); niente markdown letto; nessun annullamento quando non c'è niente in corso |
| Nella Chat (9) | L'interruttore «🔊 Leggi automaticamente» c'è e si ricorda acceso e spento (`spectraAutoSpeak`); acceso, la risposta di Gemini (rete finta) si legge da sola; pulsante 🔊 su ogni risposta, che diventa «⏹ Ferma» e ferma; la voce si ferma chiudendo la finestra e cambiando sezione |
| Console (1) | Spectra Live usa gli stessi parametri |
| Android (4, v248) | Con l'identità di un telefono Android: nessuna frase vuota di sblocco al primo tocco; nessuna voce scelta per nome, solo la lingua `it-IT`; console e Chat parlano; dopo un annullamento la frase nuova parte ≥ 120 ms dopo |
| Senza sintesi (1) | Nessun pulsante, nessun errore |
| Errori (1) | Nessun errore JavaScript |

**Non provato**: il suono vero di una voce di un telefono.

**`test_spectra_rig` — 30 controlli.** Prova il rig automatico
(`bsi-spectra-rig.js`), che dà scheletro, pesi e colori dell'app a una figura
umanoide senza ossa. Il modello vero non è nel repository, quindi il banco
costruisce nel codice un **umanoide sintetico in posa ad A**, una mesh sola:
busto, braccia e gambe come tubi continui, testa con un cappuccio. Il caso
difficile è voluto: la mano pendente sta a pochi centimetri dal fianco, e in
linea d'aria il fianco è più vicino alle ossa del braccio che a quelle del
busto.

| Parte | Che cosa pretende |
|---|---|
| Scheletro (5) | Rig costruito in meno di 3 s; **27 ossa** (20 che pesano e 7 punte); nomi Mixamo (`Hips`, `Spine2`, `Neck`, `Head`, `LeftArm`, `RightForeArm`…); il driver del corpo le riconosce (almeno 20 su 23) e sa farlo camminare |
| Pesi (5) | Somma dei pesi = 1 su ogni vertice; i vertici della mano vanno alla mano e all'avambraccio; **il fianco del busto accanto alla mano pendente non prende nessun peso del braccio** (il difetto che strappava il busto alzando un braccio); una gamba non prende mai peso dalle ossa dell'altra; la gamba sinistra va alle sue ossa (oltre il 99 %) |
| Movimento (3) | Nel gesto «spiega» la mano si sposta (mezzo metro) e il fianco resta fermo (1 mm); la camminata sposta il corpo |
| Testa e cappuccio (8) | Senza testa si tolgono i triangoli sopra il collo; col cappuccio se ne tolgono meno, perché la nuca resta; con la testa nessuno; **col solo viso nessun triangolo tolto**: il foro è un'ellisse calcolata al pixel nello shader, sulla posa di riposo, quindi segue la testa; con l'opzione `visiera: false` (disponibile, non usata dallo studio, che tiene la visiera nera lucida) il casco sotto il cappuccio diventa ombra opaca senza togliere vertici; dal foro si vede l'interno del casco (doppia faccia), non il vuoto; il cappuccio è rigido con l'osso della testa (tutti i suoi vertici) |
| Colori (5) | Il grigio medio diventa blu notte; le ombre restano quasi nere; le luci restano chiare, appena azzurre; il turchese diventa luce propria verde acqua `#00c9b7` (0, 201, 183); il grigio non emette luce |
| Definizione (3) | Con la tassellazione di Phong (`suddividi: 1`) ogni triangolo ne diventa quattro; i pesi restano normalizzati anche sui vertici nuovi; la pelle resta chiusa: i bordi aperti raddoppiano soltanto (ogni lato di bordo diventa due), nessuna cucitura si apre |
| Errori (1) | Nessun errore JavaScript |

Il corpo vero, incorporato dalla v241, è provato da `test_spectra_studio` e
`test_spectra_figura`. Restano fuori: la qualità visiva delle pieghe (gomiti, ginocchia, ascelle) e del
cappuccio, che va giudicata guardando.

**`test_controllaagg` — 12 controlli.** Nasce da una segnalazione: «provando
ad aggiornare non esce nulla». Era vero. La finestra 🔄 Aggiornamenti cercava
in `sw.js` una riga `CACHE_VERSION` che non esiste più (`sw.js` dichiara
`var CACHE = 'bsi-vNNN'`) e la cercava su `raw.githubusercontent.com`: la
versione pubblicata non si leggeva mai. `test_aggiorna` apriva la finestra ma
non premeva «Controlla», ed è per questo che il difetto è sopravvissuto. Il
banco nuovo preme il pulsante in tre casi, ottenuti intercettando la sola
richiesta di controllo (`sw.js?controllo=`):

| Caso | Come si ottiene | Risposta attesa |
|---|---|---|
| Stessa versione | `sw.js` servito com'è | «Hai già l'ultima versione pubblicata», con il numero; nessun «Aggiorna ora» |
| Versione nuova | `sw.js` servito con un nome di cache più alto (v999) | «Nuova versione disponibile» con le due versioni, e «Aggiorna ora» |
| Sito irraggiungibile | richiesta interrotta, e anche il ripiego su GitHub | «Impossibile verificare ora» |

Negli stessi tre casi prova `BSIAggiorna.controlla()` (`'aggiornata'`,
`'nuova'`, `'offline'`), il suo avviso a comparsa e, nel secondo, che chieda
al service worker di aggiornarsi.

**`test_fluidita` — 15 controlli.** Misura quanto la pagina resta *bloccata*
a ogni cambio di sezione, su tutte le 91. Ha trovato tre difetti che nessun
altro banco vedeva: il «Viewer 3D PRO» che fermava la pagina **797 ms** al
primo click — il profilatore li attribuisce al primo `render()` di 3Dmol, che
compila gli shader del contesto WebGL; le **296 figure** di «Sintesi»
(5 351 nodi di SVG) disegnate tutte prima di mostrare qualunque cosa, mentre
all'apertura se ne vedono tre; e **296 timer a 40 ms di distanza** programmati
all'apertura della stessa sezione — undici secondi e mezzo di risvegli che
chiedevano `getTotalLength()` su ogni tratto di ogni figura, comprese quelle
fuori dallo schermo.

Dopo le correzioni: cambio mediano **16 ms**, peggiore **87 ms**, **nessuna
sezione oltre i 100 ms** (erano due, la peggiore a 1 166 ms).

Alla versione `bsi-v188` lo stesso banco ha intercettato due cose. La prima:
con 263 farmaci invece di 233, «Farmacologia» bloccava la pagina **159 ms** e le
sezioni oltre i 100 ms tornavano a essere **tre** — la batteria era passata per
un soffio la volta prima, e un limite superato a intermittenza non protegge
niente. Le carte ora si disegnano a fette da 8 ms: **55 ms**, zero sezioni oltre
i 100.

La seconda riguarda il banco stesso. La soglia sul visore 3D era **80 ms
assoluti**; con lo stesso codice pubblicato, su container diversi, lo stesso
click ha misurato 14, 22, 98, 105 e 192 ms, perché WebGL qui è **SwiftShader**
e il costo è la compilazione degli shader. Una soglia così misura la macchina:
fallisce a codice identico e passerebbe a codice peggiorato. Anche un
**rapporto** su una calibrazione nella stessa esecuzione non regge — quando il
banco arriva al visore, WebGL è già caldo (2,9 ms) e il visore paga il freddo:
il rapporto oscillava fra 14× e 36×. L'affermazione è diventata **strutturale**,
che è anche il difetto originario: subito dopo il ritorno del gestore del click
il contesto WebGL **non deve esistere**, poco dopo **deve**. Misurato 0 e 1; e
la misura non è vacua, perché al secondo click — quando la tela c'è già —
restituisce 1.

**`test_avvio` — 9 controlli (v247).** Nasce dalla richiesta dell'autore di
ottimizzare l'app. Il profilo dell'avvio su un telefono simulato lento (CPU ×4)
mostrava un solo blocco di ~2 s: due precaricamenti partiti da soli (l'archivio
dei nomi di «Linguaggi delle molecole» e il riscaldamento di RDKit). Il banco
pretende i **comportamenti**, non i millisecondi, che su una macchina di prova
non sono ripetibili: con l'app in uso RDKit non parte da solo e l'archivio non
si costruisce; in Fisica e con «Risparmio dati» non parte nemmeno da fermi; in
Chimica da fermi si scalda; l'archivio si costruisce aprendo «Linguaggi delle
molecole» (283 molecole); chi lo chiede lo ottiene subito; nessun errore
JavaScript.

**`test_giro` — 24 controlli (v249).** Il giro di controllo di tutta l'app,
nato dalla richiesta dell'autore di controllare tutto al massimo. Apre **una
per una tutte le sezioni del catalogo** (201) a 412 e a 1280 px e per ognuna
pretende: che la sezione chiesta per identificativo sia quella che si apre,
che sia visibile e non vuota, che la pagina non sbordi in orizzontale, che nel
testo non compaiano «undefined», «NaN» o «[object Object]», e nessun errore
JavaScript. Poi apre le **14 pagine a parte** (Astrochimica, Accademia,
Chimica Organica, RDKit Lab, PRO Hub, Simulazioni, le guide, lo Studio…) con
gli stessi controlli. La rete esterna è chiusa. La prima volta ha trovato sei
sezioni che ne aprivano un'altra dal nome simile, 36 reazioni stampate come
«undefined» e quattro pagine che sbordavano sul telefono.

**`test_lingue` — 64 controlli.** Sorveglia due funzioni nuove e due modi
diversi di mentire senza accorgersene.

*La lingua.* Un interruttore che «traduce l'applicazione» è facile da scrivere
e difficile da mantenere onesto: basta che qualcuno cambi un'etichetta italiana
e la sua traduzione non si trovi più. Il difetto non si vede — l'etichetta resta
in italiano in mezzo all'inglese — a meno che qualcuno conti. Il banco conta:
**160 elementi di scheletro, 160 tradotti, zero rimasti**. Pretende anche le due
prove contrarie: che passando all'inglese il testo **cambi davvero** (un
dizionario vuoto passerebbe «tutto tradotto» senza muovere una lettera) e che
tornando all'italiano il testo sia **identico carattere per carattere**.

*I linguaggi delle molecole.* Le conversioni si verificano contro fatti esterni
— sette chiavi InChI di letteratura **scritte dentro il banco** — e si pretende
il giro completo SMILES → molfile → SMILES. Le formule si contano a mano.

*Il nominatore IUPAC.* 26 nomi scritti a mano in due lingue, e sette molecole
che **devono essere rifiutate**: un nominatore che non rifiuta mai è un
nominatore che inventa.

Provato nei due versi: rimettendo il `trim()` che rompe i molfile e togliendo
una traduzione, il banco fallisce tre controlli su venti.

*Le porte.* Dalla v184 il banco verifica anche che le due funzioni siano
**raggiungibili**: pulsante di navigazione, sezione che si disegna davvero, e
— controllo nato da un difetto reale — che nessuna delle due mostri il cartello
«🚧 Sezione in costruzione», che il ripiego per le sezioni vuote stampa 800 ms
dopo un click in qualunque sezione lasciata vuota. Verifica inoltre che la voce
del menu ✨ **porti** alla sezione e non apra una finestra sovrapposta, e che
non esista alcun identificativo duplicato con entrambe le sezioni disegnate.

*Le sei lingue.* Per ognuna si pretendono due cose insieme: copertura piena
dello scheletro (**162 su 162**) e che il testo **cambi davvero** — un
dizionario vuoto passerebbe «tutto tradotto» senza muovere una lettera.

**`test_mol3d` — 46 controlli.** Sorveglia l'animazione di formazione della
molecola e la misura degli angoli di legame, due aggiunte che hanno due modi
diversi di sembrare giuste senza esserlo.

*L'animazione.* «C'è» o «non c'è» non si vede ispezionando il codice: un ciclo
che gira e ridisegna sempre la stessa cosa supera qualunque controllo
sull'esistenza della funzione. Il banco guarda i **pixel**: a 130 ms la tela
deve essere quasi vuota — polvere — e a 2,3 s deve esserci una molecola.
Misurato: **532 pixel accesi → 2 334**. Se i due numeri fossero uguali
l'animazione non ci sarebbe, comunque sia scritto il programma. Verifica anche
che il ciclo **si fermi** quando lo si ferma: una tela rimossa con il ciclo
ancora acceso è una perdita che si paga in batteria.

*Gli angoli.* Un numero con un «°» accanto sembra una misura. Si verificano su
geometrie costruite a mano, il cui valore è noto **per costruzione** e non
preso da una tabella: tetraedro regolare **109,4712°**, acqua 104,47°, CO₂
180°, BF₃ 120°, ammoniaca 106,13°. Tolleranza 0,05°.

*Il rifiuto.* Su una struttura **piatta** (z = 0) il pulsante degli angoli deve
essere spento e la ragione scritta: su coordinate 2D un angolo di legame non è
un angolo di legame, e mostrarlo sarebbe l'errore peggiore dei due perché
somiglia a un dato. Provato nei due versi: una struttura con z ≠ 0 non deve
essere scambiata per piatta, altrimenti nessun angolo si vedrebbe mai.

La prima stesura di questo banco leggeva la barra dei comandi **dopo** aver
fermato il ciclo, che la rimuove: trovava zero pulsanti e poi dichiarava
«ognuno ha un nome accessibile» su un insieme vuoto. Un controllo che passa
perché non ha niente da guardare è esattamente il difetto che questo progetto
insegue; ora la verifica pretende due pulsanti **e** due nomi.

*La selezione.* L'angolo lo sceglie chi guarda, cliccando sugli atomi: uno
mostra tutti gli angoli che insistono su di lui, due la lunghezza del legame,
tre l'angolo con il vertice nel secondo cliccato, quattro il **diedro**. Il
banco verifica tutti e quattro i casi sull'etanolo — C–C 1,509 Å, C–C–O 111,9°,
H–C–C–O 60,7° — e pretende che due atomi **non legati** siano dichiarati tali
invece di essere spacciati per un legame: una distanza non è un legame.

*I diedri.* Verificati su quattro conformazioni costruite a mano: eclissata 0°,
gauche 60°, ortogonale 90°, anti 180°. Anche qui la tavola scritta a mano ha
corretto un mio errore, non del programma: con le coordinate che avevo scelto
il diedro vale 120° e non 60°, perché guardando lungo il legame centrale il
vettore proiettato sta a (−0,5; 0,866).

*L'ordine d'arrivo.* «Prima lo scheletro, poi gli idrogeni» è una proprietà
**misurabile**, non un'intenzione: il banco legge l'avanzamento di ogni atomo a
metà formazione e pretende che ogni atomo pesante sia davanti a ogni idrogeno.
Questo controllo ha trovato un difetto reale: la funzione elastica che fa il
rimbalzo non è monotòna, e usandola anche come avanzamento un atomo partito
prima poteva risultare «meno arrivato» di uno partito dopo. Ora le due
grandezze sono separate — l'avanzamento è monotòno, il fattore elastico fa solo
il rimbalzo — e il rimbalzo, che prima veniva tagliato via, si vede.

Metà dei controlli sono le *prove contrarie*, perché una pagina che non
costruisce niente è fulminea: la tela WebGL deve comparire comunque, le 296
figure devono esistere tutte poco dopo, nessuna cornice deve restare vuota, la
stampa non deve uscire muta e la ricerca deve filtrare anche le carte la cui
figura non è ancora nata. E il banco conta le sezioni che ha attraversato: su
dieci invece di 89 i tempi sarebbero ottimi e la misura priva di valore.

### 3.5 Sicurezza e accessibilità

| Banco | Verifica |
|---|---|
| `verifica-sicurezza` | Chiavi API nei file tracciati, password in chiaro, segreti nel `wrangler.toml`, telemetria, script da domini esterni |
| `audit_storia` | Che nessuna credenziale sia MAI entrata nel repository: **1 551 versioni distinte di file di testo** su **390 commit**, con 9 schemi. Si rifiuta di passare su un clone superficiale |
| `verifica-accessibilita` | Contrasto WCAG AA, nomi accessibili, etichette dei campi, testo alternativo, gerarchia dei titoli, attributo `lang` — su 13 pagine |
| `audit_mobile` | Che a **390 px** la pagina non scorra in orizzontale, su tutte le 194 sezioni — **e** che nessuna sezione ritagli contenuto rendendolo irraggiungibile: un elemento più largo della sua sezione, senza un antenato che scorra, è testo presente e non leggibile. Una tabella larga dentro un contenitore scorrevole non viene segnalata |
| `audit_rete` | Che **nessun dato dell'utente lasci il dispositivo**: un valore spia seminato in 71 depositi, l'app usata su 6 pagine e 194 sezioni, URL, intestazioni e corpo di ogni richiesta ispezionati |
| `audit_copertura` | Quanti byte di JavaScript vengono **davvero eseguiti** percorrendo l'applicazione: 49,89 %, registrato e difeso |

**`audit_storia` — 6 controlli.** `verifica-sicurezza` esamina i file
*tracciati*, cioè lo stato attuale: risponde a «oggi nel repository non c'è
nessuna chiave» e non alla domanda che conta su un repository pubblico. Una
chiave messa in un commit e togliata nel successivo passa `verifica-sicurezza`
per sempre e resta leggibile a chiunque cloni, perché git non dimentica. Se
succede, il rimedio non è un commit di correzione: è revocare la chiave.

Questo banco esamina ogni *versione* di ogni file di testo mai entrata nel
repository. Esito: **zero credenziali in 1 551 versioni su 390 commit**.

Due difese contro sé stesso, perché qui un numero perfetto può nascere da meno
superficie o da uno schema cieco:

- **Il clone non deve essere superficiale.** Un `--depth 1` contiene una
  frazione della storia: il banco girerebbe, non troverebbe niente e direbbe
  «nessuna credenziale in tutta la storia» avendone vista un decimo. Se trova
  `.git/shallow`, fallisce e dice quale comando eseguire.
- **Gli schemi si provano prima di fidarsi.** Uno schema sbagliato non trova
  niente ed è indistinguibile da un repository pulito: ognuno dei 9 deve
  riconoscere un esempio costruito e deve *rifiutare* un quasi-esempio, ed
  entrambi vengono provati dentro una coda di rumore con cifre, come sarebbe in
  un file vero.

La seconda difesa è nata da un errore in questo stesso banco. Lo schema AWS
chiedeva una cifra con `(?=.*\d)`, condizione sempre soddisfatta in un file
grande perché la cifra sta più avanti: trovava 53 corrispondenze, tutte la
stessa stringa `AKIAAAAAAAAAAAAAAAAA` — sedici «A», la zona di zeri di
un'immagine in base64. Il quasi-esempio non se ne accorgeva perché era troppo
corto per contenere cifre. Ora l'identificativo AWS si giudica dalla *varietà*
dei suoi sedici caratteri, e i quasi-esempi portano la loro coda.

Provato anche nell'altro verso: con un commit locale che contiene una chiave
AWS di forma valida il banco fallisce nominando il blob; rimosso il commit,
torna a passare.

> **L'ostacolo era dello strumento, non del problema.** Per tre versioni la
> copertura di codice è stata dichiarata non misurabile, con questa
> motivazione: «strumentare richiederebbe introdurre una build, che
> l'applicazione non ha». Era vero per `c8` e `istanbul`, che riscrivono il
> sorgente prima di eseguirlo. Ma **Chromium la raccoglie da solo**, dentro il
> motore, senza toccare un byte del file servito: `Profiler.startPreciseCoverage`,
> che Playwright espone come `page.coverage.startJSCoverage()`. Non serviva una
> build: serviva accorgersi che il vincolo apparteneva agli strumenti scelti.
>
> **Il primo risultato è stato 100 % su ogni file**, compresi 3,6 MB di
> `index.html`. Era il banco che non misurava niente, nella forma più
> insidiosa: un numero perfetto. V8 emette per ogni funzione un intervallo
> esterno con il conteggio degli ingressi, e dentro quello gli intervalli a
> `count: 0` per ciò che non è stato eseguito. Sommando gli intervalli positivi
> si somma l'intero file. Si fa il contrario: si parte dal totale e si sottrae
> l'unione dei vuoti.
>
> Il numero vero è **49,89 %**, e regge lo stesso patto del debito di
> accessibilità: registrato, e il banco fallisce se scende. Una soglia assoluta
> («80 %») sarebbe una cifra inventata; «non deve peggiorare» è una promessa
> mantenibile.

> **Perché una spia e non un elenco di richieste.** SEC-02 — «nessun dato
> personale lascia il dispositivo» — era verificato controllando i due
> *meccanismi* di uscita: variabile di telemetria vuota, nessuno script da un
> dominio esterno. È un'evidenza vera ma indiretta: dice «non vedo come
> potrebbe uscire», che non è «non è uscito». Guardare invece l'elenco degli
> ospiti contattati sarebbe altrettanto debole, perché conclude per assenza di
> prove.
>
> La spia rovescia l'onere. Si scrive una stringa irripetibile dentro i dati
> dell'utente — note, chat, chiavi API, impostazioni, progressi — poi si **usa**
> l'applicazione, e ogni richiesta che esce viene aperta e letta. Se la stringa
> non compare da nessuna parte, è perché davvero non è uscita.
>
> ```bash
> BSI_PROVA_FUGA=1 node tools/banchi/audit_rete.js   # deve FALLIRE
> ```
>
> Il banco porta con sé la prova di funzionare: con quella variabile provoca una
> fuga di proposito, verso un ospite **dichiarato** — contattarlo è lecito,
> mandargli i dati dell'utente no. Se in quel caso non fallisce, è lo strumento
> a essere guasto.

> **Perché un banco sul traboccamento orizzontale.** UI-03 dice «l'app deve
> funzionare a 390 px», e la matrice lo dava per verificato da
> `audit_stabilita`, che però in viewport telefono guarda gli **errori
> JavaScript**: una pagina può non averne uno solo e uscire lo stesso di
> centosessantatré pixel dallo schermo. Era un requisito dichiarato coperto e
> non misurato. Il banco misura `scrollWidth` del documento — esattamente ciò
> che fa comparire la barra — e non un elemento più largo dello schermo, che
> dentro un contenitore fatto per scorrere è corretto e riempirebbe l'uscita di
> rumore finché nessuno la legge più.

> **Cosa non copre la verifica di accessibilità**, e va detto: il testo dentro
> gli SVG (il colore viene da `fill`, lo sfondo è una forma disegnata) e il
> testo su sfondi a gradiente (non hanno *un* colore). Gli elementi saltati
> vengono contati e riportati, non nascosti.

> **Una sezione per volta.** L'ispezione salta gli elementi non visibili — ed è
> corretto: un elemento nascosto non ha contrasto da misurare. Ma `index.html`
> alterna 194 sezioni e ne mostra una sola: su **19 751** elementi di testo il
> banco ne guardava **41**, e stampava «0 difetti». Non era un risultato falso,
> era un risultato su un campione che nessuno aveva dichiarato. Ora le sezioni
> vengono aperte una per una, e **il numero di sezioni percorse viene
> stampato**.
>
> Quel conteggio si è guadagnato lo stipendio alla prima esecuzione: il primo
> tentativo ne percorreva **zero** — il clic di Playwright aspetta che
> l'elemento sia visibile, e i pulsanti stanno dentro gruppi di navigazione
> richiusi — e il banco l'ha detto («96 sezioni presenti, nessuna percorsa»)
> invece di stampare un altro zero rassicurante.

### 3.5-bis Il debito di accessibilità, e il patto che non cresca

Percorrendo tutte le sezioni sono emersi **1 069** difetti di contrasto.
Oggi sono **zero** — l'elenco delle cause e dei rimedi è in `docs/09` §4 — e
i campi privi di etichetta sono scesi da 40 a **zero**.

Il meccanismo descritto qui sotto resta, e conta più del numero che custodisce.
Pretendere zero *da subito* avrebbe lasciato due sole vie, entrambe cattive: la
verifica rossa per sempre, oppure allentata finché torna verde. La terza via è
**dichiarare il numero** e impedirgli di crescere, qualunque esso sia. È così
che da 1 069 si è arrivati a zero: ogni scalino registrato, nessuno annullabile
di nascosto.

| File | Ruolo |
|---|---|
| `docs/evidence/accessibilita-riferimento.json` | Il conteggio registrato |

| Situazione | Esito del banco |
|---|---|
| Il conteggio **sale** | ✗ FALLITO — è una regressione |
| Il conteggio **scende** | ✓ passa, e chiede di aggiornare il riferimento |
| Il conteggio è **uguale** | ✓ passa in silenzio: debito dichiarato, non cresciuto — oggi quel valore è **0**, e il banco lo difende |

```bash
node tools/verifica-accessibilita.js --aggiorna-riferimento
```

Da usare **solo dopo aver ridotto** i difetti, mai per far tornare verde una
regressione. Anche a zero non è conformità WCAG piena: restano fuori il testo
dentro gli SVG e quello su fondo a gradiente, che l'automatismo non sa
giudicare e che il banco **conta e riporta** a ogni esecuzione (`docs/09` D-09).
È la misura onesta di ciò che si può misurare, con la garanzia che non peggiori
di nascosto.

### 3.6 Coerenza

| Banco | Verifica |
|---|---|
| `verifica_guida` | Che le promesse della documentazione esistano nel codice; assenza di marcatori di conflitto su 58 file |
| `verifica-documenti` | Collegamenti interni, allineamento delle versioni, coerenza dell'indice, motivazione delle deviazioni, **coerenza interna della matrice di tracciabilità** (identificativi non duplicati, totali di copertura pari agli identificativi realmente definiti) |
| `genera-pacchetti` | Riscrive i riferimenti dei documenti estratti e **verifica che nessun collegamento resti rotto** nei tre pacchetti di consegna. Verifica anche che **nessun PDF sia più vecchio del documento da cui viene** e che il rapporto di verifica imbustato dichiari **questa** versione: un impaginato o un'evidenza della versione precedente, in un pacchetto di adesso, è una bugia silenziosa |
| `genera-pdf` | Converte i documenti in PDF e fallisce se un file risulta sotto la soglia di plausibilità (conversione a vuoto) |
| `verifica-affermazioni` | Confronta ogni numero dichiarato nei documenti — sezioni, farmaci, malattie, tumori, strategie, moduli — con quello **misurato nell'applicazione in esecuzione**, in italiano *e* in inglese |
| `test_stack` | Che lo stack React/FastAPI esegua **gli stessi file** dell'applicazione: confronta le impronte SHA-256 che `GET /salute` dichiara con quelle dei file su disco, verifica che i numeri coincidano con quelli del browser, e che **nessun file `.ts`/`.tsx` contenga una tabella di spostamenti** — perché è lì che nascerebbe il secondo motore |

> **Perché i numeri vanno misurati, non ricordati.** Il dossier tecnico si apre
> con delle cifre: «63 malattie (23 tumori)», «46 strategie», «25 moduli». Sono
> la prima cosa che legge chi valuta, e bastano perché tutto il resto venga
> creduto o messo in dubbio. Nessuno le controllava: scritte una volta,
> restavano, mentre l'applicazione cambiava. E infatti `chimorga.html`
> dichiarava **«25 moduli»** in cima e **«17 moduli»** più sotto — due
> affermazioni sullo stesso oggetto, nello stesso file, una delle due falsa.
>
> **Una lezione pagata scrivendo il banco.** Avevo già concluso che «63
> malattie» fosse un'esagerazione: nel sorgente avevo trovato un array
> `DISEASES` con 12 voci, e stavo per «correggere» il documento. Misurando nel
> DOM ho visto che il menu ne elenca davvero 63 — l'array che avevo trovato era
> un altro, più piccolo. **Un conteggio sul sorgente non è una misura: è un
> indizio.** Per questo il banco apre la pagina, apre la sezione e conta.
>
> Controlla anche che i documenti concordino **fra loro**: due documenti che
> dicono cose diverse sullo stesso oggetto sono un difetto anche quando uno dei
> due ha ragione. La traduzione inglese conta come uno di quei documenti —
> `docs/en/05` è rimasto a «84 sections» e fermo alla versione `bsi-v146` per tre rilasci, e
> nessun banco se ne accorgeva perché nessuno guardava l'insieme inglese.

> **Perché un controllo sulla matrice.** La matrice dichiarava `SCI-10` due
> volte — una come requisito verificato al 100 %, una come requisito
> esplicitamente **non** verificato — e la tabella riassuntiva sommava 36
> requisiti mentre nel documento ne erano definiti 37. Entrambi gli errori
> stavano nel numero che un valutatore legge per primo. Ora il banco conta gli
> identificativi realmente presenti e fallisce se i totali scritti non
> corrispondono: la prova che il controllo misura davvero è che, reintrodotti
> i due errori uno per volta, li segnala entrambi.

---

## 4. Casi di prova notevoli

Alcuni banchi meritano una menzione perché verificano proprietà che un test
funzionale non osserva.

| Caso | Metodo | Risultato misurato |
|---|---|---|
| **Perdite di memoria** | 194 sezioni × 5 giri, nodi DOM contati a ogni giro | +26 876 al primo giro (costruzione), **+0** nei quattro successivi |
| **Memoria esaurita** | `setItem` sostituito con una funzione che lancia sempre | 10 pagine su 10 restano operative |
| **Rete degradata ≠ assente** | Richieste sospese 20 s, intercettazione a livello di contesto | Risposta dalla cache in **3 507 ms** (soglia 3 500) |
| **Riproducibilità degli spettri** | Doppio disegno, confronto byte a byte | Identici |
| **Contesti WebGL** | Costruzioni del visore su 10 molecole consecutive | Da **7 a 1** |
| **Cronologia corrotta** | Due `Invio` a 500 ms di distanza | `user,assistant` anziché `user,user,assistant,assistant` |
| **Contrasto del testo** | Formula WCAG su ogni elemento con testo proprio, 13 pagine **e 194 sezioni** | 19 751 elementi esaminati (erano 41): **1 069** difetti emersi, **1 069 corretti**, **0 registrati** come valore che non può crescere |
| **Annullamento immediato** | Stop premuto a 1,5 s, stato campionato ogni secondo | pulsante Invia disponibile dal **1º** secondo (era il 10º) |

---

## 5. Come aggiungere un banco

### Struttura minima

```javascript
/* Un commento che spiega COSA dimostra questo banco e perché serve. */
const { chromium } = require('playwright-core');
const CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

(async () => {
  const b = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
  // serviceWorkers:'block' se il banco modifica i file: senza, il SW
  // potrebbe servire una copia in cache e si misurerebbe il file vecchio
  const ctx = await b.newContext({ serviceWorkers: 'block' });
  const pg = await ctx.newPage();
  const err = [];
  pg.on('pageerror', e => err.push(e.message));

  let ok = 0, ko = 0;
  const att = (d, atteso, avuto) => {
    if (String(atteso) === String(avuto)) { ok++; console.log('  ✓ ' + d + '  → ' + avuto); }
    else { ko++; console.log('  ✗ ' + d + '\n      atteso: ' + atteso + '\n      avuto:  ' + avuto); }
  };

  await pg.goto('http://127.0.0.1:8899/index.html', { waitUntil: 'load', timeout: 60000 });
  await pg.waitForTimeout(2500);

  // … misure …

  att('nessun errore JS', 0, err.length);
  await b.close();
  console.log('\n' + (ko ? '✗ ' + ko + ' FALLITI, ' : '') + ok + ' passati');
  process.exit(ko ? 1 : 0);   // il codice di uscita è ciò che conta
})();
```

Poi si aggiunge il nome alla famiglia opportuna in `tools/genera-evidenza.js`.

### La regola che conta

> **Un banco che non misura nulla passa.** È il modo più insidioso di ottenere
> una falsa garanzia: nessun allarme, nessun fallimento, e nessuna verifica.

Perciò **ogni banco che simula una condizione deve contare quante volte la
simulazione è realmente scattata, e fallire se il conteggio è zero.**

Casi realmente incontrati durante lo sviluppo della batteria:

| Trappola | Come si manifestava |
|---|---|
| `page.route` non intercetta le richieste del Service Worker (serve `context.route`) | La prova «rete degradata» misurava una rete sana e concludeva in 16 ms invece di 3 500 |
| Sondare `localStorage` esaurito con una scrittura di un byte | Dopo la saturazione un byte trova sempre posto: il banco «passava» |
| Cercare `[data-tab]` dove la navigazione usa `[data-s]` | Zero schede trovate, quindi zero misure — e zero fallimenti |
| Le tacche di un asse su `<canvas>` non sono testo | Vanno raccolte intercettando `fillText`; e la riga più in basso è il *titolo* dell'asse, non le tacche |
| Sonda installata su una libreria caricata **dopo** | Viene sostituita insieme alla libreria: zero chiamate contate mentre il codice funzionava |
| Una `var` dentro una IIFE non è `window.qualcosa` | Assegnarla da fuori crea una variabile diversa |

---

## 6. Lacune di copertura

Dichiarate. La copertura riportata in
[`08-Traceability-Matrix.md`](08-Traceability-Matrix.md) misura **quanti
requisiti hanno un banco**, non quante righe di codice vengono eseguite: sono
due cose diverse e non vanno confuse.

| Lacuna | Situazione attuale | Raccomandazione |
|---|---|---|
| **Copertura di codice** | Misurata: **49,89 %** di istruzioni sul percorso più ampio. Resta fuori la copertura dell'intera batteria e quella di **rami**: un `if` entrato da un solo lato conta come coperto | Estendere la raccolta a ogni banco, e passare dalla copertura di istruzioni a quella di rami |
| **Accessibilità** | Automatizzata su 13 pagine e tutte le 194 sezioni: contrasto WCAG, nomi accessibili, etichette, testo alternativo, gerarchia dei titoli. Restano fuori il testo negli SVG e quello su gradiente, **contati** a ogni esecuzione | Affiancare `axe-core` per le regole che questo banco non implementa (ruoli ARIA, ordine di tabulazione, gestione del fuoco) |
| **Sicurezza** | `verifica-sicurezza` esegue 10 controlli su 605 file tracciati e copre SEC-01, SEC-03, SEC-05, SEC-06; SEC-04 è coperto da `verifica_guida`. **SEC-02 resta indiretto**: vedi `docs/09` D-03 | Osservare il traffico di rete durante un uso reale, l'unica verifica diretta di SEC-02 |
| **Browser diversi da Chromium** | Nessuna prova automatica su Firefox o WebKit | Estendere i banchi principali a `webkit`, dove le differenze su IndexedDB e Service Worker sono maggiori |
| **Prestazioni** | Prove manuali cross-device | Misura automatica del tempo di primo disegno |
| **Regressione visiva** | Assente | Confronto di schermate per i grafici, che sono il cuore del prodotto |
| **Spectra Live e strumenti rapidi** | Dalla v238 `test_spectra238` copre l'impaginazione della console, il navigatore, il livello, il volto e i comandi del creatore; dalla v239 il pulsante unico, e `test_lezione` la lezione guidata e «fammi lezione»; `test_spectra_studio` corpo, voce (senza OpenAI) e Spectra Studio, `test_spectra_rig` il rig automatico su un umanoide sintetico, `test_spectra_figura` Spectra col corpo nelle quattro sezioni dell'AI, nella console Spectra Live (dalla v242) e le sue reazioni; `test_spectra_esplora` (v242) le tre sezioni «⚡ Esplora con Spectra», i loro capitoli e i numeri dei cursori; `test_spectra_olo` (v242) l'ologramma interattivo (spettri e tracce scritte, universo, matematica e fisica dall'assistente, i passaggi letti da Spectra). Resta senza banco il resto dei comandi locali, la voce, gli strumenti che agiscono sulla pagina e il menu ✨ per materia (UI-21, AI-13). Il riconoscimento e la sintesi vocale non esistono nel Chromium senza interfaccia | Provare i comandi locali come funzioni pure (`BSISpectraLive.comando`) e gli strumenti rapidi in node, come si fa già con i calcoli delle sezioni |

---

## 7. Criteri di accettazione

Una versione non viene pubblicata se uno solo di questi non è soddisfatto.

- [ ] `node tools/genera-evidenza.js` si chiude con **0 falliti**
- [ ] `tools/verifica-farmaci.js`: nessun difetto, ogni deviazione registrata con il motivo
- [ ] `verifica_guida`: nessuna promessa della documentazione priva di riscontro
- [ ] Nessun errore JavaScript non di rete su tutte le pagine
- [ ] Rapporto di evidenza rigenerato sul commit che si pubblica

---

_Documento aggiornato alla versione `bsi-v250`._
